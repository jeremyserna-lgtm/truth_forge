import { AssessmentQuestion, AssessmentResult, KeganStage } from '../types';

export const ASSESSMENT_QUESTIONS: AssessmentQuestion[] = [
    {
        id: 'q1',
        scenario: 'A trusted colleague publicly critiques a project you have poured weeks of effort into. They say the fundamental premise is flawed.',
        options: [
            { text: "I feel personally attacked and humiliated. I want to defend myself or withdraw completely.", stageIndicator: KeganStage.STAGE_2_IMPERIAL },
            { text: "I worry about what the rest of the team thinks of me now. I try to smooth things over to maintain our relationship.", stageIndicator: KeganStage.STAGE_3_SOCIALIZED },
            { text: "I evaluate their critique against my own standards. If it's valid, I adjust; if not, I stand by my work regardless of their opinion.", stageIndicator: KeganStage.STAGE_4_SELF_AUTHORING },
            { text: "I see this as an opportunity to explore the conflict between our perspectives. What higher truth emerges from this friction?", stageIndicator: KeganStage.STAGE_5_SELF_TRANSFORMING }
        ]
    },
    {
        id: 'q2',
        scenario: 'You are offered a promotion that requires enforcing a policy you personally disagree with.',
        options: [
            { text: "I take it if the pay increase is good. It's just a job.", stageIndicator: KeganStage.STAGE_2_IMPERIAL },
            { text: "I struggle deeply. I don't want to disappoint my boss, but I also don't want to upset my team.", stageIndicator: KeganStage.STAGE_3_SOCIALIZED },
            { text: "I consider if this role aligns with my career trajectory and values. If the policy violates my core principles, I refuse.", stageIndicator: KeganStage.STAGE_4_SELF_AUTHORING },
            { text: "I accept the role to understand the system that created the policy, intending to evolve it from within.", stageIndicator: KeganStage.STAGE_5_SELF_TRANSFORMING }
        ]
    },
    {
        id: 'q3',
        scenario: 'When you are in a romantic relationship, how do you define yourself?',
        options: [
            { text: "I focus on getting my needs met and ensuring they treat me fairly.", stageIndicator: KeganStage.STAGE_2_IMPERIAL },
            { text: "My partner's happiness is my happiness. I often lose track of where I end and they begin.", stageIndicator: KeganStage.STAGE_3_SOCIALIZED },
            { text: "I am a complete person who chooses to share my life with another complete person. We have clear boundaries.", stageIndicator: KeganStage.STAGE_4_SELF_AUTHORING },
            { text: "Our relationship is a third entity that transforms both of us. I allow the connection to change who I am.", stageIndicator: KeganStage.STAGE_5_SELF_TRANSFORMING }
        ]
    },
    {
        id: 'q4',
        scenario: 'You encounter a political opinion that is diametrically opposed to your own.',
        options: [
            { text: "They are wrong and stupid. I block them.", stageIndicator: KeganStage.STAGE_2_IMPERIAL },
            { text: "I feel uncomfortable and look to my group to reaffirm that we are right.", stageIndicator: KeganStage.STAGE_3_SOCIALIZED },
            { text: "I listen to their logic but measure it against my own researched worldview. I agree to disagree.", stageIndicator: KeganStage.STAGE_4_SELF_AUTHORING },
            { text: "I become curious about the system of experiences that makes their view true for them. I look for the partial truth we both hold.", stageIndicator: KeganStage.STAGE_5_SELF_TRANSFORMING }
        ]
    }
];

export const calculateAssessmentResult = (responses: { questionId: string; stage: KeganStage }[]): AssessmentResult => {
    const stageCounts: Record<string, number> = {};
    
    // Count frequencies
    responses.forEach(r => {
        stageCounts[r.stage] = (stageCounts[r.stage] || 0) + 1;
    });

    // Find primary stage
    let maxCount = 0;
    let primaryStage = KeganStage.STAGE_3_SOCIALIZED; // Default fallback

    Object.entries(stageCounts).forEach(([stage, count]) => {
        if (count > maxCount) {
            maxCount = count;
            primaryStage = stage as KeganStage;
        } else if (count === maxCount) {
            // Tie-breaker: choose the higher stage (aspirational bias)
            // Implementation detail: Enums strings don't sort naturally by level, but for MVP we assume order or pick one.
            // Let's just stick to the last one found for simplicity in tie-breaking logic for now
            primaryStage = stage as KeganStage; 
        }
    });

    const confidence = Math.round((maxCount / responses.length) * 100);

    return {
        id: Math.random().toString(36).substr(2, 9),
        timestamp: Date.now(),
        calculatedStage: primaryStage,
        stageConfidence: confidence,
        growthEdge: generateGrowthEdge(primaryStage),
        responses
    };
};

const generateGrowthEdge = (stage: KeganStage): string => {
    switch (stage) {
        case KeganStage.STAGE_2_IMPERIAL:
            return "Moving from self-interest to empathy. Learning to see the needs of others as equal to your own.";
        case KeganStage.STAGE_3_SOCIALIZED:
            return "Defining the self apart from relationships. Learning to disappoint others to remain true to yourself.";
        case KeganStage.STAGE_4_SELF_AUTHORING:
            return "Holding paradox. Learning that your self-made system is not the only valid one; loosening the grip of your own ideology.";
        case KeganStage.STAGE_5_SELF_TRANSFORMING:
            return "Embodying the flow. Moving from systemic awareness to fluid manifestation.";
        default:
            return "Building foundational stability.";
    }
};

export const generateNotMePrompt = (stage: KeganStage): string => {
    switch (stage) {
        case KeganStage.STAGE_2_IMPERIAL:
            return "I see you focused on concrete outcomes. Let's look at the people involved.";
        case KeganStage.STAGE_3_SOCIALIZED:
            return "I feel your connection to others. Let's explore what YOU want, even if they disagree.";
        case KeganStage.STAGE_4_SELF_AUTHORING:
            return "I hear your strong internal voice. Let's examine the limitations of that code.";
        case KeganStage.STAGE_5_SELF_TRANSFORMING:
            return "I witness your fluidity. Let's dance with the contradictions.";
        default:
            return "I am listening.";
    }
};