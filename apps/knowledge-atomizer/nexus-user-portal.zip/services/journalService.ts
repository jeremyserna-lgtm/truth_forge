import { JournalEntry, KeganStage, GrowthArc, ReflectionPattern } from '../types';

export const generateReflectionPrompts = (stage: KeganStage): string[] => {
    switch (stage) {
        case KeganStage.STAGE_2_IMPERIAL:
            return [
                "What is a rule you followed today that you didn't want to follow?",
                "Who blocked you from getting what you needed today?",
                "Describe a moment you felt powerful."
            ];
        case KeganStage.STAGE_3_SOCIALIZED:
            return [
                "Whose opinion mattered most to you today?",
                "Did you feel torn between two people's expectations?",
                "When did you suppress your own voice to keep the peace?"
            ];
        case KeganStage.STAGE_4_SELF_AUTHORING:
            return [
                "Where did you enforce a boundary today?",
                "Did you compromise your own system for efficiency?",
                "Are your current values serving your long-term vision?"
            ];
        case KeganStage.STAGE_5_SELF_TRANSFORMING:
            return [
                "Where did you find truth in two opposing ideas today?",
                "How is your 'Self' getting in the way of the system?",
                "What identity are you ready to let go of?"
            ];
        default:
            return ["What is on your mind?"];
    }
};

export const analyzePatterns = (entries: JournalEntry[]): ReflectionPattern[] => {
    // Mock logic: scanning content for repeated themes
    const patterns: ReflectionPattern[] = [];
    
    // Heuristic checking
    const content = entries.map(e => e.content.toLowerCase()).join(' ');
    
    if (content.includes("afraid") || content.includes("scared")) {
        patterns.push({
            id: 'pat-1',
            theme: 'Fear of Conflict',
            frequency: 4,
            developmentalRelevance: 'Suggests Stage 3 anxiety about rupture.'
        });
    }
    
    if (content.includes("control") || content.includes("manage")) {
        patterns.push({
            id: 'pat-2',
            theme: 'Need for Control',
            frequency: 6,
            developmentalRelevance: 'Typical of early Stage 4 transition.'
        });
    }

    if (entries.filter(e => e.subjectAnalysis && e.objectAnalysis).length > 2) {
        patterns.push({
            id: 'pat-3',
            theme: 'Objectification Velocity',
            frequency: 3,
            developmentalRelevance: 'High capacity for self-observation detected.'
        });
    }

    return patterns;
};

export const calculateGrowthArc = (entries: JournalEntry[]): GrowthArc => {
    const shiftCount = entries.filter(e => e.objectAnalysis && e.objectAnalysis.length > 5).length;
    
    let trajectory: GrowthArc['trajectory'] = 'STABILIZING';
    if (shiftCount > 3) trajectory = 'SHIFTING';
    if (shiftCount > 8) trajectory = 'INTEGRATING';

    return {
        timespan: 'All Time',
        shiftCount,
        trajectory
    };
};

export const createEmptyEntry = (stage: KeganStage): JournalEntry => ({
    id: Math.random().toString(36).substr(2, 9),
    timestamp: Date.now(),
    lastModified: Date.now(),
    title: '',
    content: '',
    stageContext: stage,
    tags: []
});