import { KeganStage, NotMeMessage } from '../types';

// --- STAGE-AWARE RESPONSE LOGIC ---

/**
 * Generates a response tailored to the user's developmental stage.
 * In a real app, this would be a prompt engineering layer for an LLM.
 */
export const generateNotMeResponse = (input: string, stage: KeganStage, history: NotMeMessage[]): Promise<string> => {
    return new Promise((resolve) => {
        setTimeout(() => {
            const lowerInput = input.toLowerCase();
            let response = "";

            // Generic Fallback
            response = "I hear you. Tell me more.";

            // 1. STAGE SPECIFIC LOGIC
            switch (stage) {
                case KeganStage.STAGE_2_IMPERIAL:
                    // Focus on concrete needs, transactions, barriers
                    if (lowerInput.includes("stuck") || lowerInput.includes("hard")) {
                        response = "It sounds like something is blocking what you want. What is the specific obstacle, and what tool do you need to move it?";
                    } else if (lowerInput.includes("want") || lowerInput.includes("need")) {
                        response = "That is a clear goal. What is the most direct path to getting it?";
                    } else {
                        response = "I understand the outcome you are looking for. What are the rules of this situation as you see them?";
                    }
                    break;

                case KeganStage.STAGE_3_SOCIALIZED:
                    // Focus on relationships, expectations, belonging, feelings
                    if (lowerInput.includes("stuck") || lowerInput.includes("hard")) {
                        response = "It feels heavy to carry that. Who are you worried about disappointing in this situation?";
                    } else if (lowerInput.includes("feel") || lowerInput.includes("think")) {
                        response = "I hear the emotion in that. How does this connect to the people you care about?";
                    } else {
                        response = "I see how important this connection is to you. How are others influencing your view on this?";
                    }
                    break;

                case KeganStage.STAGE_4_SELF_AUTHORING:
                    // Focus on systems, values, integrity, internal authority
                    if (lowerInput.includes("stuck") || lowerInput.includes("hard")) {
                        response = "The friction usually points to a conflict in your own system. Which of your core values is being compromised here?";
                    } else if (lowerInput.includes("feel") || lowerInput.includes("think")) {
                        response = "You are authoring this experience. Does this reaction align with the standard you have set for yourself?";
                    } else {
                        response = "That is a strong assertion. Is this rule one you created, or one you inherited?";
                    }
                    break;

                case KeganStage.STAGE_5_SELF_TRANSFORMING:
                    // Focus on paradox, multiplicity, flow, interdependence
                    if (lowerInput.includes("stuck") || lowerInput.includes("hard")) {
                        response = "You are stuck because you are holding onto a single truth. What is the opposite truth that is also valid right now?";
                    } else if (lowerInput.includes("feel") || lowerInput.includes("think")) {
                        response = "Notice that feeling. Now notice the part of you watching the feeling. Can you hold space for both?";
                    } else {
                        response = "I see the pattern. How is this identity constructing itself in real-time? Can you let it dissolve?";
                    }
                    break;
                
                default:
                    response = "I am listening. How does that sit with you?";
            }

            // 2. CONTEXTUAL OVERRIDES (Simple Keyword Matching)
            if (lowerInput.includes("thank you")) {
                response = "You are welcome. We are building this together.";
            } else if (lowerInput.includes("who are you")) {
                response = "I am the Not-Me. I am the reflection of the parts of yourself you have not yet claimed.";
            }

            resolve(response);
        }, 1500 + Math.random() * 1000); // Variable delay for realism
    });
};

/**
 * Returns a provocative question designed to surface hidden assumptions based on stage.
 */
export const getSurfacingQuestion = (stage: KeganStage): string => {
    switch (stage) {
        case KeganStage.STAGE_2_IMPERIAL:
            return "If you didn't have to fight for this, what would you do?";
        case KeganStage.STAGE_3_SOCIALIZED:
            return "If no one else would ever know your decision, what would you choose?";
        case KeganStage.STAGE_4_SELF_AUTHORING:
            return "What if your internal code is actually limiting your growth here?";
        case KeganStage.STAGE_5_SELF_TRANSFORMING:
            return "Who are you when you let go of being the 'Author'?";
        default:
            return "What are you not saying?";
    }
};

export const getQuickActions = (stage: KeganStage): string[] => {
    const common = ["Something shifted today", "I noticed a pattern"];
    switch(stage) {
        case KeganStage.STAGE_2_IMPERIAL: return ["I'm blocked", "I want something", ...common];
        case KeganStage.STAGE_3_SOCIALIZED: return ["I feel misunderstood", "I'm worried about...", ...common];
        case KeganStage.STAGE_4_SELF_AUTHORING: return ["My system failed", "I need to redefine", ...common];
        case KeganStage.STAGE_5_SELF_TRANSFORMING: return ["I found a paradox", "Identity is fluid", ...common];
        default: return common;
    }
}
