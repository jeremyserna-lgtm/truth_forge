import { ImmunityMap, AssumptionTest } from '../types';

export const generateEmptyMap = (): ImmunityMap => ({
    id: Math.random().toString(36).substr(2, 9),
    title: 'New Immunity Map',
    createdAt: Date.now(),
    lastModified: Date.now(),
    status: 'DRAFT',
    commitment: { text: '' },
    doingNotDoing: { behaviors: [] },
    hiddenCommitments: { entries: [] },
    bigAssumptions: { entries: [] },
    tests: []
});

export const suggestTestingExperiment = (assumption: string): Partial<AssumptionTest> => {
    // Basic heuristic to generate a safe-to-fail experiment based on an assumption string
    // In a real app, this would use an LLM
    
    let experiment = "Observe yourself next time this situation arises.";
    let risk = 'SAFE';

    if (assumption.toLowerCase().includes("always") || assumption.toLowerCase().includes("everyone")) {
        experiment = "Find one small exception to this rule. Test it with one trusted person.";
        risk = 'SAFE';
    } else if (assumption.toLowerCase().includes("fail") || assumption.toLowerCase().includes("disaster")) {
        experiment = "Intentionally allow a small failure in a low-stakes environment and record what actually happens.";
        risk = 'MODERATE';
    } else if (assumption.toLowerCase().includes("reject") || assumption.toLowerCase().includes("leave")) {
        experiment = "Express a small part of your true thought to someone you trust.";
        risk = 'MODERATE';
    }

    return {
        hypothesis: `If I challenge this assumption, the catastrophe I fear will not happen, or will be manageable.`,
        experimentDesign: experiment,
        riskLevel: risk as 'SAFE' | 'MODERATE'
    };
};

export const analyzeImmunityPattern = (map: ImmunityMap): string => {
    // Simple analysis of the map structure
    if (map.hiddenCommitments.entries.length > 0 && map.bigAssumptions.entries.length === 0) {
        return "You have identified the 'Immune System' (Col 3), but not yet the fuel source (Col 4). Dig deeper into WHY you must keep that commitment.";
    }
    if (map.doingNotDoing.behaviors.length > 0 && map.hiddenCommitments.entries.length === 0) {
        return "You see the behaviors blocking you. Now, ask yourself: what is the worst thing that would happen if you stopped doing these things?";
    }
    if (map.tests.length > 0) {
        return "You are actively rewiring your mental model. Consistency in testing is key.";
    }
    return "Map initialized. Follow the columns to uncover your hidden competing commitments.";
};