import React, { useState, useEffect } from 'react';
import { User, AppContext, SubscriptionTier, KeganStage, NotMeCompanion, RitualEntry, TransitionEvent, Milestone, VerifiableCredential, NotMeMemory, CrisisEvent, FederationPartnerID } from './types';
import { Auth } from './components/Auth';
import { UserPortal } from './components/UserPortal';
import { DataSynthesis } from './components/DataSynthesis';
import { Observability } from './components/Observability';
import { Foundry } from './components/Foundry';
import { RelationshipDashboard } from './components/RelationshipDashboard';
import { CohortSpace } from './components/CohortSpace';
import { TopNav } from './components/TopNav';
import { CommandBar } from './components/CommandBar';
import { SystemAwareness } from './components/SystemAwareness';
import { NotMeInitialization } from './components/NotMeInitialization';
import { DailyRitual } from './components/DailyRitual';
import { TransitionCeremony } from './components/TransitionCeremony';
import { CrisisOverlay } from './components/CrisisOverlay';

const App: React.FC = () => {
  // Initialize from localStorage or null for real authentication flow
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('nexus_user');
      if (saved) {
        const parsed = JSON.parse(saved);
        // Migration: Ensure developmentProfile exists and has all fields
        if (!parsed.developmentProfile) {
            parsed.developmentProfile = {
                stage: KeganStage.STAGE_3_SOCIALIZED,
                score: 50,
                evidence: [],
                subjectObjectMap: [],
                shiftHistory: [],
                immunityMaps: [], // Add ITC maps
                journalEntries: [], // Add Journal
                holdingEnvironment: {
                    complexityLevel: 'MEDIUM',
                    supportLevel: 'MEDIUM',
                    inSafeMode: false,
                    struggleIndex: 0,
                    masteryIndex: 0
                }
            };
        } 
        
        // Deep merge / check for new fields
        if (!parsed.developmentProfile.subjectObjectMap) parsed.developmentProfile.subjectObjectMap = [];
        if (!parsed.developmentProfile.shiftHistory) parsed.developmentProfile.shiftHistory = [];
        if (!parsed.developmentProfile.immunityMaps) parsed.developmentProfile.immunityMaps = [];
        if (!parsed.developmentProfile.journalEntries) parsed.developmentProfile.journalEntries = [];
        if (!parsed.developmentProfile.metaCognitionLog) parsed.developmentProfile.metaCognitionLog = [];
        if (!parsed.developmentProfile.systemObservations) parsed.developmentProfile.systemObservations = [];
        if (!parsed.developmentProfile.emergentPatterns) parsed.developmentProfile.emergentPatterns = [];
        if (!parsed.developmentProfile.interfaceProposals) parsed.developmentProfile.interfaceProposals = [];
        if (!parsed.developmentProfile.dailyPractice) parsed.developmentProfile.dailyPractice = { streak: 0, lastPracticeDate: '', history: [] };
        if (!parsed.developmentProfile.milestones) parsed.developmentProfile.milestones = [
            { id: 'm1', type: 'STAGE_TRANSITION', title: 'Initiation', description: 'Entered the Truth Forge ecosystem.', date: '2023-08-01', fromStage: KeganStage.STAGE_2_IMPERIAL, toStage: KeganStage.STAGE_3_SOCIALIZED }
        ];
        if (!parsed.developmentProfile.crisisHistory) parsed.developmentProfile.crisisHistory = [];
        if (!parsed.developmentProfile.lifeContext) {
            parsed.developmentProfile.lifeContext = {
                domains: [
                    { id: 'd1', name: 'Work', description: 'Professional identity and career.', harmonyScore: 65, allowAiAccess: true, logs: [], keganRelevance: 'High potential for authorship challenge.' },
                    { id: 'd2', name: 'Family', description: 'Immediate relationships.', harmonyScore: 85, allowAiAccess: false, logs: [], keganRelevance: 'Strong socialized stability.' }
                ],
                interactions: []
            };
        }
        if (!parsed.developmentProfile.library) {
            parsed.developmentProfile.library = { interactions: [], savedResourceIds: [] };
        }
        if (!parsed.developmentProfile.narrativeHistory) {
            parsed.developmentProfile.narrativeHistory = [
                {
                    id: 'nar-1',
                    date: '2023-10-01',
                    periodLabel: 'The Season of Initiation',
                    content: 'You began by defining the boundaries of your self against the system. Early interactions showed a dependency on external validation, but the seeds of authorship were planted in the Foundry.',
                    notMeReflection: 'I watched you struggle to trust your own voice. You asked me for answers, and I offered you questions. Slowly, you began to answer them yourself.',
                    themes: ['Dependency', 'Curiosity', 'Definition']
                }
            ];
        }
        if (!parsed.developmentProfile.federationState) {
            parsed.developmentProfile.federationState = {
                connections: [
                    { partnerId: FederationPartnerID.CORE, name: 'Truth Forge Core', description: 'Primary Identity & System Access.', status: 'CONNECTED', lastSync: Date.now(), dataTypesAccessed: ['Identity', 'Auth'], userConsent: true },
                    { partnerId: FederationPartnerID.PRIMITIVE_ENGINE, name: 'Primitive Engine', description: 'Cognitive pattern recognition & analytics.', status: 'CONNECTED', lastSync: Date.now() - 300000, dataTypesAccessed: ['Metrics', 'Logs'], userConsent: true, healthLatency: 45 },
                    { partnerId: FederationPartnerID.CREDENTIAL_ATLAS, name: 'Credential Atlas', description: 'Decentralized verification ledger.', status: 'CONNECTED', lastSync: Date.now() - 3600000, dataTypesAccessed: ['Milestones', 'Attestations'], userConsent: true, healthLatency: 120 },
                    { partnerId: FederationPartnerID.NOT_ME_SERVICE, name: 'Not-Me Service', description: 'Companion AI logic processor.', status: 'CONNECTED', lastSync: Date.now() - 60000, dataTypesAccessed: ['Dialogue', 'Memories'], userConsent: true, healthLatency: 80 },
                    { partnerId: FederationPartnerID.COHORT_MESH, name: 'Cohort Mesh', description: 'Anonymized peer networking.', status: 'DISCONNECTED', lastSync: 0, dataTypesAccessed: ['Stage', 'Challenges'], userConsent: false }
                ],
                exchangeLog: [],
                globalConsent: true,
                dataExportStatus: 'NONE'
            };
        }
        if (!parsed.developmentProfile.assessmentHistory) {
            parsed.developmentProfile.assessmentHistory = [];
        }

        if (!parsed.developmentProfile.holdingEnvironment) {
            parsed.developmentProfile.holdingEnvironment = {
                complexityLevel: 'MEDIUM',
                supportLevel: 'MEDIUM',
                inSafeMode: false,
                struggleIndex: 0,
                masteryIndex: 0
            };
        }

        // Initialize Cognitive Metrics (Primitive Engine)
        if (!parsed.developmentProfile.cognitiveMetrics) {
            parsed.developmentProfile.cognitiveMetrics = {
                current: {
                    perspectiveBreadth: 45,
                    integrationDepth: 30,
                    temporalCoherence: 85
                },
                history: [
                    { date: '2023-09-01', perspectiveBreadth: 30, integrationDepth: 20, temporalCoherence: 80 },
                    { date: '2023-09-15', perspectiveBreadth: 35, integrationDepth: 22, temporalCoherence: 82 },
                    { date: '2023-10-01', perspectiveBreadth: 38, integrationDepth: 25, temporalCoherence: 78 },
                    { date: '2023-10-15', perspectiveBreadth: 42, integrationDepth: 28, temporalCoherence: 83 },
                    { date: '2023-11-01', perspectiveBreadth: 45, integrationDepth: 30, temporalCoherence: 85 }
                ]
            };
        }

        // Initialize Growth Reports
        if (!parsed.developmentProfile.growthReports) {
            parsed.developmentProfile.growthReports = [
                {
                    id: 'gr-001',
                    weekEnding: '2023-11-01',
                    summary: 'Significant expansion in Perspective Breadth observed. User demonstrated ability to hold "Self-Preservation" and "Community-Duty" as distinct but valid poles during conflict simulation.',
                    focusArea: 'BREADTH',
                    examples: [
                        'Construct Interaction #402: User acknowledged validity of opposing axiom without defensive regression.',
                        'Immunity Map #03: Identified "Safety" as a perspective rather than absolute truth.'
                    ],
                    status: 'GENERATED'
                },
                {
                    id: 'gr-002',
                    weekEnding: '2023-10-24',
                    summary: 'Integration Depth showing initial volatility. Attempts to synthesize conflicting data streams resulted in temporary coherence dip. This is a normal precursor to structural shifts.',
                    focusArea: 'DEPTH',
                    examples: [
                        'Foundry Session: User struggled to resolve "Efficiency" vs "Creativity" tension.',
                        'Temporal coherence dropped 5 points during high-stress simulation.'
                    ],
                    status: 'GENERATED'
                }
            ];
        }

        // Initialize Credential Atlas Portfolio
        if (!parsed.developmentProfile.credentials) {
            parsed.developmentProfile.credentials = [
                {
                    id: 'cred-001',
                    title: 'Socialized Mastery',
                    description: 'Demonstrated complete integration of external role expectations and social reciprocity.',
                    type: 'DEVELOPMENT_BADGE',
                    issuer: 'SYSTEM_CORE',
                    issueDate: '2023-08-15',
                    evidenceLinks: ['shift-401'],
                    status: 'VERIFIED',
                    credentialAtlasHash: '0x8f3...a1b2',
                    metadata: { stageContext: KeganStage.STAGE_3_SOCIALIZED, skillTags: ['Empathy', 'Role Fulfillment'] }
                },
                {
                    id: 'cred-002',
                    title: 'Paradox Integration',
                    description: 'Successfully synthesized a binary conflict into a dialectical framework during dialogue.',
                    type: 'SKILL_ATTESTATION',
                    issuer: 'NOT_ME_COMPANION',
                    issueDate: '2023-10-02',
                    evidenceLinks: ['dial-209'],
                    status: 'VERIFIED',
                    credentialAtlasHash: '0x9c2...b3c4',
                    metadata: { stageContext: KeganStage.STAGE_4_SELF_AUTHORING, skillTags: ['Dialectics', 'Conflict Resolution'] }
                }
            ];
        }

        // Initialize Not-Me Companion if missing (B2C Feature)
        if (!parsed.notMeCompanion) {
            parsed.notMeCompanion = {
                id: 'comp-001',
                name: 'Alter',
                stage: parsed.developmentProfile.stage, // Mirrors user initially
                resonance: { cognitive: 85, emotional: 72, structural: 90 },
                evolutionHistory: [
                    { date: '2023-10-01', userScore: 30, companionScore: 35 },
                    { date: '2023-10-15', userScore: 42, companionScore: 48 },
                    { date: '2023-11-01', userScore: 50, companionScore: 55 }
                ],
                dialogueJournal: [
                    { id: 'j1', date: Date.now() - 86400000, topic: 'Fear of conflict', userReflection: 'I noticed I agreed just to keep the peace.', companionInsight: 'Agreement without alignment is a form of self-erasure.', impact: 'HIGH' }
                ],
                sharedKnowledge: [
                    { id: 'sk1', label: 'Reciprocity', description: 'We grow together.', depth: 1, resonance: 100, type: 'axiom' as const, attribution: 'NOT_ME' as const }
                ],
                // Add default initialization status for older records
                isInitialized: false,
                memories: [] // Initialize empty memories
            };
        } else {
            // Migration: Ensure existing companions have memories array
            if (!parsed.notMeCompanion.memories) parsed.notMeCompanion.memories = [];
            
            // Populate initial dummy memories if empty for demo
            if (parsed.notMeCompanion.memories.length === 0 && parsed.notMeCompanion.isInitialized) {
                parsed.notMeCompanion.memories = [
                    {
                        id: 'mem-1',
                        type: 'MOMENT',
                        content: 'We established the "Reciprocity" axiom during our first session.',
                        timestamp: Date.now() - 2592000000, // 30 days ago
                        keganStage: KeganStage.STAGE_3_SOCIALIZED,
                        significance: 'Foundation of trust established.',
                        isCore: true
                    },
                    {
                        id: 'mem-2',
                        type: 'PATTERN',
                        content: 'You tend to Intellectualize emotions when discussing failure.',
                        timestamp: Date.now() - 1209600000, // 14 days ago
                        significance: 'Defense mechanism identified: Rationalization.',
                        isCore: false
                    },
                    {
                        id: 'mem-3',
                        type: 'CURIOSITY',
                        content: 'What would happen if you disappointed someone you admire?',
                        timestamp: Date.now() - 604800000, // 7 days ago
                        significance: 'Exploring the edge of the Socialized Mind.',
                        isCore: false
                    }
                ];
            }

            if (parsed.notMeCompanion.isInitialized === undefined) {
                // Migration for existing records without field
                parsed.notMeCompanion.isInitialized = true; // Assume old users are initialized or set false to force ritual
            }
        }

        // Initialize Safety Config
        if (!parsed.safetyConfig) {
            parsed.safetyConfig = {
                crisisDetectionEnabled: true,
                preferredSoothingMode: 'BREATHING'
            };
        }

        return parsed;
      }
      return null;
    } catch (e) {
      console.error("Failed to parse user from local storage", e);
      return null;
    }
  });

  const [currentContext, setCurrentContext] = useState<AppContext>(AppContext.PORTAL);
  const [showSystemAwareness, setShowSystemAwareness] = useState(false);
  
  // Daily Ritual State
  const [activeRitual, setActiveRitual] = useState<'MORNING' | 'EVENING' | null>(null);

  // Transition Ceremony State
  const [pendingTransition, setPendingTransition] = useState<TransitionEvent | null>(null);

  // Crisis Mode State
  const [activeCrisis, setActiveCrisis] = useState<CrisisEvent | null>(null);

  // Check for daily ritual requirement on load/login
  useEffect(() => {
      if (currentUser && currentUser.notMeCompanion?.isInitialized) {
          const today = new Date().toISOString().split('T')[0];
          const lastPractice = currentUser.developmentProfile.dailyPractice?.lastPracticeDate;
          const hasIntentionToday = currentUser.developmentProfile.dailyPractice?.todayIntention;

          // If no practice today, trigger Morning Intention
          if (lastPractice !== today && !hasIntentionToday) {
              setActiveRitual('MORNING');
          }
      }
  }, [currentUser]);

  const handleLogin = (user: User) => {
    // Ensure new logins have profile with defaults
    const userWithProfile = {
        ...user,
        developmentProfile: user.developmentProfile || {
            stage: KeganStage.STAGE_3_SOCIALIZED,
            score: 50,
            evidence: [],
            subjectObjectMap: [],
            shiftHistory: [],
            immunityMaps: [],
            journalEntries: [],
            cognitiveMetrics: {
                current: {
                    perspectiveBreadth: 45,
                    integrationDepth: 30,
                    temporalCoherence: 85
                },
                history: [
                    { date: '2023-11-01', perspectiveBreadth: 45, integrationDepth: 30, temporalCoherence: 85 }
                ]
            },
            growthReports: [],
            credentials: [
                {
                    id: 'cred-init',
                    title: 'Truth Forge Initiate',
                    description: 'Identity instantiation complete. Protocol access granted.',
                    type: 'DEVELOPMENT_BADGE',
                    issuer: 'SYSTEM_CORE',
                    issueDate: new Date().toISOString().split('T')[0],
                    evidenceLinks: [],
                    status: 'VERIFIED',
                    credentialAtlasHash: '0x00...00',
                    metadata: { stageContext: KeganStage.STAGE_3_SOCIALIZED, skillTags: ['System Access'] }
                }
            ],
            holdingEnvironment: {
                complexityLevel: 'MEDIUM',
                supportLevel: 'MEDIUM',
                inSafeMode: false,
                struggleIndex: 0,
                masteryIndex: 0
            },
            metaCognitionLog: [],
            systemObservations: [
                { id: 'obs-1', timestamp: Date.now(), observation: 'User exhibits high resistance to "Priority" modification.', patternType: 'BEHAVIORAL', status: 'UNREAD' }
            ],
            emergentPatterns: [],
            interfaceProposals: [],
            dailyPractice: { streak: 0, lastPracticeDate: '', history: [] },
            milestones: [
                { id: 'm1', type: 'STAGE_TRANSITION', title: 'Initiation', description: 'Entered the Truth Forge ecosystem.', date: '2023-08-01', fromStage: KeganStage.STAGE_2_IMPERIAL, toStage: KeganStage.STAGE_3_SOCIALIZED }
            ],
            crisisHistory: [],
            lifeContext: {
                domains: [
                    { id: 'd1', name: 'Work', description: 'Professional identity and career.', harmonyScore: 65, allowAiAccess: true, logs: [], keganRelevance: 'High potential for authorship challenge.' },
                    { id: 'd2', name: 'Family', description: 'Immediate relationships.', harmonyScore: 85, allowAiAccess: false, logs: [], keganRelevance: 'Strong socialized stability.' }
                ],
                interactions: []
            },
            library: { interactions: [], savedResourceIds: [] },
            narrativeHistory: [
                {
                    id: 'nar-1',
                    date: '2023-10-01',
                    periodLabel: 'The Season of Initiation',
                    content: 'You began by defining the boundaries of your self against the system. Early interactions showed a dependency on external validation, but the seeds of authorship were planted in the Foundry.',
                    notMeReflection: 'I watched you struggle to trust your own voice. You asked me for answers, and I offered you questions. Slowly, you began to answer them yourself.',
                    themes: ['Dependency', 'Curiosity', 'Definition']
                }
            ],
            federationState: {
                connections: [
                    { partnerId: FederationPartnerID.CORE, name: 'Truth Forge Core', description: 'Primary Identity & System Access.', status: 'CONNECTED', lastSync: Date.now(), dataTypesAccessed: ['Identity', 'Auth'], userConsent: true },
                    { partnerId: FederationPartnerID.PRIMITIVE_ENGINE, name: 'Primitive Engine', description: 'Cognitive pattern recognition & analytics.', status: 'CONNECTED', lastSync: Date.now() - 300000, dataTypesAccessed: ['Metrics', 'Logs'], userConsent: true, healthLatency: 45 },
                    { partnerId: FederationPartnerID.CREDENTIAL_ATLAS, name: 'Credential Atlas', description: 'Decentralized verification ledger.', status: 'CONNECTED', lastSync: Date.now() - 3600000, dataTypesAccessed: ['Milestones', 'Attestations'], userConsent: true, healthLatency: 120 },
                    { partnerId: FederationPartnerID.NOT_ME_SERVICE, name: 'Not-Me Service', description: 'Companion AI logic processor.', status: 'CONNECTED', lastSync: Date.now() - 60000, dataTypesAccessed: ['Dialogue', 'Memories'], userConsent: true, healthLatency: 80 },
                    { partnerId: FederationPartnerID.COHORT_MESH, name: 'Cohort Mesh', description: 'Anonymized peer networking.', status: 'DISCONNECTED', lastSync: 0, dataTypesAccessed: ['Stage', 'Challenges'], userConsent: false }
                ],
                exchangeLog: [],
                globalConsent: true,
                dataExportStatus: 'NONE'
            },
            assessmentHistory: []
        },
        notMeCompanion: {
            id: 'comp-001',
            name: 'Alter',
            stage: KeganStage.STAGE_3_SOCIALIZED,
            resonance: { cognitive: 85, emotional: 72, structural: 90 },
            evolutionHistory: [
                { date: '2023-10-01', userScore: 30, companionScore: 35 },
                { date: '2023-10-15', userScore: 42, companionScore: 48 },
                { date: '2023-11-01', userScore: 50, companionScore: 55 }
            ],
            dialogueJournal: [],
            sharedKnowledge: [
                { id: 'sk1', label: 'Reciprocity', description: 'We grow together.', depth: 1, resonance: 100, type: 'axiom' as const, attribution: 'NOT_ME' as const }
            ],
            isInitialized: false, // Default new users to uninitialized to trigger ritual
            memories: []
        },
        safetyConfig: {
            crisisDetectionEnabled: true,
            preferredSoothingMode: 'BREATHING'
        }
    };
    setCurrentUser(userWithProfile);
    localStorage.setItem('nexus_user', JSON.stringify(userWithProfile));
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('nexus_user');
    setCurrentContext(AppContext.PORTAL); // Reset context on logout
  };

  const handleUpdateUser = (updatedUser: User) => {
    setCurrentUser(updatedUser);
    localStorage.setItem('nexus_user', JSON.stringify(updatedUser));
  };

  const handleInitializationComplete = (companionData: Partial<NotMeCompanion>) => {
      if (!currentUser || !currentUser.notMeCompanion) return;
      const updatedUser = {
          ...currentUser,
          notMeCompanion: {
              ...currentUser.notMeCompanion,
              ...companionData
          }
      };
      handleUpdateUser(updatedUser);
  };

  const handleRitualComplete = (entry: RitualEntry) => {
      if (!currentUser) return;
      
      const today = new Date().toISOString().split('T')[0];
      const currentPractice = currentUser.developmentProfile.dailyPractice || { streak: 0, lastPracticeDate: '', history: [] };
      
      // Calculate Streak
      let newStreak = currentPractice.streak;
      const lastDate = new Date(currentPractice.lastPracticeDate);
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      
      // Only increment streak once per day (checking against lastPracticeDate)
      if (currentPractice.lastPracticeDate !== today) {
          if (lastDate.toISOString().split('T')[0] === yesterday.toISOString().split('T')[0]) {
              newStreak += 1;
          } else {
              newStreak = 1; // Reset or Start new
          }
      }

      const updatedUser: User = {
          ...currentUser,
          developmentProfile: {
              ...currentUser.developmentProfile,
              dailyPractice: {
                  streak: newStreak,
                  lastPracticeDate: today,
                  history: [entry, ...currentPractice.history],
                  todayIntention: entry.type === 'MORNING_INTENTION' ? entry.response : currentPractice.todayIntention
              }
          }
      };
      
      handleUpdateUser(updatedUser);
      setActiveRitual(null);
  };

  const handleTransitionComplete = (reflection: string, shared: boolean) => {
      if (!currentUser || !pendingTransition) return;

      const newMilestone: Milestone = {
          id: `m-${Date.now()}`,
          type: 'STAGE_TRANSITION',
          title: 'Developmental Leap',
          description: `Transcended ${pendingTransition.fromStage} structures. New operating system: ${pendingTransition.toStage}.`,
          date: new Date().toISOString(),
          fromStage: pendingTransition.fromStage,
          toStage: pendingTransition.toStage,
          userReflection: reflection,
          notMeWitness: `I witnessed the shift during ${pendingTransition.triggerContext}.`
      };

      const newCredential: VerifiableCredential = {
          id: `cred-${Date.now()}`,
          title: `${pendingTransition.toStage.replace('STAGE_', '')} Emergence`,
          description: 'Official recognition of structural transition in consciousness.',
          type: 'DEVELOPMENT_BADGE',
          issuer: 'SYSTEM_CORE',
          issueDate: new Date().toISOString().split('T')[0],
          evidenceLinks: [newMilestone.id],
          status: 'VERIFIED',
          credentialAtlasHash: `0x${Math.random().toString(36).substr(2, 9)}...`,
          metadata: { stageContext: pendingTransition.toStage, skillTags: ['Evolution', 'Self-Transcendence'] }
      };

      // Determine new tier
      let newTier = currentUser.tier;
      if (pendingTransition.toStage === KeganStage.STAGE_4_SELF_AUTHORING) newTier = SubscriptionTier.STAGE_4_FLUID;
      if (pendingTransition.toStage === KeganStage.STAGE_5_SELF_TRANSFORMING) newTier = SubscriptionTier.STAGE_5_STRUCTURAL;

      const updatedUser: User = {
          ...currentUser,
          tier: newTier,
          developmentProfile: {
              ...currentUser.developmentProfile,
              stage: pendingTransition.toStage,
              milestones: [newMilestone, ...(currentUser.developmentProfile.milestones || [])],
              credentials: [newCredential, ...(currentUser.developmentProfile.credentials || [])]
          }
      };

      handleUpdateUser(updatedUser);
      setPendingTransition(null);
  };
  
  const handleTierChange = (tier: SubscriptionTier) => {
      if (currentUser) {
          const updatedUser = { ...currentUser, tier };
          setCurrentUser(updatedUser);
          localStorage.setItem('nexus_user', JSON.stringify(updatedUser));
      }
  };

  const handleSafeModeToggle = () => {
      if (currentUser) {
          const currentSafeMode = currentUser.developmentProfile.holdingEnvironment.inSafeMode;
          const updatedUser = {
              ...currentUser,
              developmentProfile: {
                  ...currentUser.developmentProfile,
                  holdingEnvironment: {
                      ...currentUser.developmentProfile.holdingEnvironment,
                      inSafeMode: !currentSafeMode,
                      // When entering safe mode, boost support and lower complexity
                      supportLevel: !currentSafeMode ? 'HIGH' : currentUser.developmentProfile.holdingEnvironment.supportLevel,
                      complexityLevel: !currentSafeMode ? 'LOW' : currentUser.developmentProfile.holdingEnvironment.complexityLevel
                  }
              }
          };
          // TypeScript cast specific string literals if needed, but the object matches interface
          handleUpdateUser(updatedUser as User);
      }
  };

  const handleTriggerCrisis = (event: CrisisEvent) => {
      setActiveCrisis(event);
      // Auto-enable Safe Mode if not already active
      if (currentUser && !currentUser.developmentProfile.holdingEnvironment.inSafeMode) {
          handleSafeModeToggle(); 
      }
  };

  const handleResolveCrisis = () => {
      if (!currentUser || !activeCrisis) return;
      
      const resolvedEvent: CrisisEvent = { ...activeCrisis, status: 'RESOLVED' };
      
      const updatedUser = {
          ...currentUser,
          developmentProfile: {
              ...currentUser.developmentProfile,
              crisisHistory: [resolvedEvent, ...(currentUser.developmentProfile.crisisHistory || [])]
          }
      };
      
      handleUpdateUser(updatedUser);
      setActiveCrisis(null);
  };

  if (!currentUser) {
      return (
        <div className="min-h-screen bg-[#0D0D0D] text-[#F5F0E6]">
            <Auth onLogin={handleLogin} />
        </div>
      );
  }

  // Check for Not-Me Initialization Ritual
  if (currentUser.notMeCompanion && !currentUser.notMeCompanion.isInitialized) {
      return (
          <div className="min-h-screen bg-[#0D0D0D] text-[#F5F0E6]">
              <NotMeInitialization user={currentUser} onComplete={handleInitializationComplete} />
          </div>
      );
  }

  return (
    <div className={`h-screen bg-[#0D0D0D] text-[#F5F0E6] flex flex-col overflow-hidden ${currentUser.developmentProfile.holdingEnvironment.inSafeMode ? 'border-4 border-[#10B981]' : ''}`}>
      {/* Meta Layer - System Awareness Overlay */}
      {showSystemAwareness && (
          <SystemAwareness 
              user={currentUser} 
              onUpdateUser={handleUpdateUser} 
              onClose={() => setShowSystemAwareness(false)} 
          />
      )}

      {/* Daily Ritual Overlay */}
      {activeRitual && (
          <DailyRitual 
              user={currentUser} 
              type={activeRitual} 
              onComplete={handleRitualComplete} 
              onClose={() => setActiveRitual(null)} 
          />
      )}

      {/* Transition Ceremony Overlay */}
      {pendingTransition && (
          <TransitionCeremony 
              user={currentUser} 
              event={pendingTransition} 
              onComplete={handleTransitionComplete} 
              onClose={() => setPendingTransition(null)} 
          />
      )}

      {/* Crisis Support Overlay */}
      {activeCrisis && (
          <CrisisOverlay 
              user={currentUser} 
              event={activeCrisis} 
              onResolve={handleResolveCrisis} 
              onEscalate={() => { /* Simulated escalation hook */ }}
          />
      )}

      {/* Top Global Navigation */}
      <TopNav 
        currentContext={currentContext} 
        onContextChange={setCurrentContext} 
        user={currentUser} 
        onTierChange={handleTierChange}
        onSafeModeToggle={handleSafeModeToggle}
        onToggleAwareness={() => setShowSystemAwareness(true)}
      />

      {/* Main Application Area - Dynamic Switching */}
      <div className="flex-1 overflow-hidden relative">
          {currentUser.developmentProfile.holdingEnvironment.supportLevel === 'HIGH' && (
              <div className="absolute top-4 right-4 z-50 animate-in fade-in slide-in-from-right-10 duration-700 pointer-events-none">
                  <div className="bg-[#10B981]/10 border border-[#10B981] text-[#10B981] px-4 py-2 rounded-sm text-xs font-mono uppercase tracking-wide backdrop-blur-sm shadow-[0_0_15px_rgba(16,185,129,0.2)]">
                      Support Pillar Active
                  </div>
              </div>
          )}

          {currentContext === AppContext.PORTAL && (
              <UserPortal 
                  user={currentUser} 
                  onLogout={handleLogout} 
                  onUpdateUser={handleUpdateUser} 
                  onTriggerCeremony={setPendingTransition}
              />
          )}
          {currentContext === AppContext.RELATIONSHIP && (
              <RelationshipDashboard 
                  user={currentUser} 
                  onUpdateUser={handleUpdateUser}
                  onTriggerCrisis={handleTriggerCrisis}
              />
          )}
          {currentContext === AppContext.DATA_SYNTHESIS && (
              <DataSynthesis user={currentUser} />
          )}
          {currentContext === AppContext.FOUNDRY && (
              <Foundry user={currentUser} />
          )}
          {currentContext === AppContext.OBSERVABILITY && (
              <Observability user={currentUser} />
          )}
          {currentContext === AppContext.COMMUNITY && (
              <CohortSpace 
                  user={currentUser} 
                  onUpdateUser={handleUpdateUser} 
              />
          )}
      </div>

      {/* Persistent Command Bar */}
      <CommandBar 
          tier={currentUser.tier} 
          keganStage={currentUser.developmentProfile?.stage || KeganStage.STAGE_3_SOCIALIZED} 
      />
    </div>
  );
};

export default App;