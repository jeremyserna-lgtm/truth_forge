export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  username: string;
  address: string;
  avatar?: string;
  tier: SubscriptionTier;
  developmentProfile: DevelopmentProfile;
  notMeCompanion?: NotMeCompanion; // New Companion Data
  safetyConfig?: SafetyConfig; // Crisis Support Preferences
}

export interface SafetyConfig {
  crisisDetectionEnabled: boolean;
  emergencyContact?: string;
  preferredSoothingMode: 'BREATHING' | 'VISUAL' | 'AUDIO' | 'TEXT';
}

export interface CrisisEvent {
  id: string;
  timestamp: number;
  triggerType: 'KEYWORD' | 'PATTERN' | 'MANUAL';
  severity: 'LOW' | 'MEDIUM' | 'HIGH';
  context: string;
  status: 'ACTIVE' | 'RESOLVED' | 'ESCALATED';
}

export enum KeganStage {
  STAGE_1_IMPULSIVE = 'IMPULSIVE',
  STAGE_2_IMPERIAL = 'IMPERIAL',
  STAGE_3_SOCIALIZED = 'SOCIALIZED',
  STAGE_4_SELF_AUTHORING = 'SELF_AUTHORING',
  STAGE_5_SELF_TRANSFORMING = 'SELF_TRANSFORMING'
}

export type MemoryType = 'MOMENT' | 'PATTERN' | 'GROWTH' | 'CURIOSITY';

export interface NotMeMemory {
  id: string;
  type: MemoryType;
  content: string;
  timestamp: number;
  keganStage?: KeganStage; // Contextual stage when memory was formed
  significance: string; // "Why I remember this" - Meta-commentary
  isCore?: boolean; // Foundational memories defining the relationship
}

export interface NotMeMessage {
  id: string;
  role: 'user' | 'companion';
  content: string;
  timestamp: number;
  developmentalSignal?: string; // Metadata about what triggered this response
  type?: 'TEXT' | 'REFLECTION_PROMPT' | 'INSIGHT';
}

export interface ConversationThread {
  id: string;
  startedAt: number;
  messages: NotMeMessage[];
  currentTheme?: string;
  stageContext: KeganStage;
}

export interface DevelopmentalMoment {
  id: string;
  timestamp: number;
  insight: string;
  trigger: string;
  stage: KeganStage;
}

export interface NotMeCompanion {
  id: string;
  name: string;
  stage: KeganStage;
  resonance: {
    cognitive: number;
    emotional: number;
    structural: number;
  };
  evolutionHistory: { date: string; userScore: number; companionScore: number }[];
  dialogueJournal: DialogueEntry[];
  sharedKnowledge: KnowledgeAtom[];
  memories: NotMeMemory[]; // New Memory Store
  activeConversation?: ConversationThread; // Current active chat
  developmentalMoments?: DevelopmentalMoment[];
  // Initialization Ritual Fields
  isInitialized: boolean;
  coreQuality?: string; // The quality the Not-Me perceives in the user (e.g., "Relentless Seeker")
  covenant?: string; // The mutual agreement text
}

export interface DialogueEntry {
  id: string;
  date: number;
  topic: string;
  userReflection: string;
  companionInsight: string;
  impact: 'LOW' | 'MEDIUM' | 'HIGH';
}

export interface SubjectObjectItem {
  id: string;
  label: string; // e.g., "Interpersonal Relationships", "Personal Ideology"
  status: 'SUBJECT' | 'OBJECT'; // SUBJECT = "I am this", OBJECT = "I have this"
  category: 'IMPULSE' | 'NEED' | 'RELATIONSHIP' | 'IDEOLOGY' | 'PROCESS';
  stability: number; // 0-100, how firmly held it is
}

export interface ObjectificationEvent {
  id: string;
  timestamp: number;
  trigger: string;
  shiftedItemLabel: string; // What moved from Subject to Object
  insight: string;
}

export interface Experiment {
  id: string;
  description: string;
  riskLevel: 'SAFE' | 'MODERATE' | 'EDGE';
  status: 'PLANNED' | 'IN_PROGRESS' | 'COMPLETED';
  outcome?: string;
  assumptionInvalidated: boolean;
}

// --- Immunity Map Types ---
export interface AssumptionTest {
  id: string;
  hypothesis: string;
  experimentDesign: string; // What will I do?
  outcome: string; // What happened?
  reflection: string; // What did I learn?
  status: 'PLANNED' | 'IN_PROGRESS' | 'COMPLETED';
  dateStarted: number;
  riskLevel?: 'SAFE' | 'MODERATE' | 'EDGE';
}

export interface ImmunityMap {
  id: string;
  title: string;
  createdAt: number;
  lastModified: number;
  status: 'DRAFT' | 'ACTIVE' | 'RESOLVED';
  
  // Column 1: Commitment
  commitment: {
    text: string; // "I am committed to..."
    importance?: string;
  };
  
  // Column 2: Doing / Not Doing
  doingNotDoing: {
    behaviors: string[];
  };
  
  // Column 3: Hidden Commitments
  hiddenCommitments: {
    entries: {
      id: string;
      text: string; // "I am committed to NOT..."
      worry: string; // "To avoid feeling..."
    }[];
  };
  
  // Column 4: Big Assumptions
  bigAssumptions: {
    entries: {
      id: string;
      text: string; // "I assume that if..."
      certainty: number; // 0-100
      relatedCommitmentId?: string; // Connects to Col 3 entry
    }[];
  };

  tests: AssumptionTest[];
}

// --- Reflection Journal Types ---
export interface SubjectObjectShift {
  id: string;
  subjectContent: string; // What I was subject to (controlled by)
  objectContent: string; // What I can now see as object (can manipulate)
  triggerMoment: string;
  dateObserved: number;
}

export interface JournalEntry {
  id: string;
  timestamp: number;
  lastModified: number;
  title: string;
  content: string; // Free form text
  stageContext: KeganStage;
  
  // Structured Kegan Reflection
  subjectAnalysis?: string; // "I was Subject to..."
  objectAnalysis?: string; // "I am now seeing X as Object..."
  
  // Metadata
  tags: string[];
  linkedConversationId?: string;
  linkedImmunityMapId?: string;
  mood?: 'CLARITY' | 'CONFUSION' | 'STUCK' | 'FLOW';
}

export interface ReflectionPattern {
  id: string;
  theme: string;
  frequency: number;
  developmentalRelevance: string;
}

export interface GrowthArc {
  timespan: string; // "Last 3 Months"
  shiftCount: number;
  trajectory: 'STABILIZING' | 'SHIFTING' | 'INTEGRATING';
}

export interface HoldingEnvironment {
  complexityLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  supportLevel: 'HIGH' | 'MEDIUM' | 'LOW';
  inSafeMode: boolean;
  struggleIndex: number; // 0-100, higher means more struggle
  masteryIndex: number; // 0-100, higher means ready for challenge
}

export interface CognitiveMetricPoint {
  date: string;
  perspectiveBreadth: number; // 0-100: Distinct viewpoints held simultaneously
  integrationDepth: number;   // 0-100: Synthesis of contradictions
  temporalCoherence: number;  // 0-100: Consistency over time
}

export interface GrowthReport {
  id: string;
  weekEnding: string;
  summary: string;
  focusArea: 'BREADTH' | 'DEPTH' | 'COHERENCE';
  examples: string[];
  status: 'GENERATED' | 'PENDING';
}

// --- Content Library ---
export type ResourceType = 'ARTICLE' | 'VIDEO' | 'EXERCISE' | 'REFLECTION' | 'CASE_STUDY';

export interface DevelopmentalResource {
  id: string;
  title: string;
  author: string;
  type: ResourceType;
  targetStages: KeganStage[]; // Applicable stages
  topics: string[];
  duration: string; // e.g. "5 min read", "15 min video"
  difficultyLevel: 'BEGINNER' | 'INTERMEDIATE' | 'ADVANCED';
  contentPreview: string; // Short blurb
  whyRelevant?: string; // Dynamic reason ("Because you are navigating Stage 3")
}

export interface ResourceInteraction {
  resourceId: string;
  startedAt: number;
  completedAt?: number;
  userReflection?: string;
  helpful?: boolean;
}

export interface LibraryState {
  interactions: ResourceInteraction[];
  savedResourceIds: string[];
}

// --- Life Context & External Integration ---
export interface LifeLogEntry {
  id: string;
  content: string;
  timestamp: number;
  type: 'CHALLENGE' | 'WIN' | 'OBSERVATION';
}

export interface LifeDomain {
  id: string;
  name: string;
  description: string;
  icon?: string;
  harmonyScore: number; // 0-100 (Subjective feeling of balance/success)
  allowAiAccess: boolean; // Privacy control
  logs: LifeLogEntry[];
  keganRelevance: string; // Not-Me's interpretation of why this matters developmentally
}

export interface DomainInteraction {
  id: string;
  sourceDomainId: string;
  targetDomainId: string;
  interactionType: 'POSITIVE' | 'TENSION' | 'BLOCKING';
  description: string;
}

export interface LifeContextState {
  domains: LifeDomain[];
  interactions: DomainInteraction[];
  lastWeeklyReview?: number;
}

// --- Narrative & Journey Visualization ---
export type JourneyViewMode = 'MOUNTAIN' | 'RIVER' | 'GARDEN' | 'CONSTELLATION';

export interface NarrativeSummary {
  id: string;
  date: string;
  periodLabel: string; // e.g., "The Season of Definition"
  content: string; // The story text
  notMeReflection: string; // The companion's perspective
  themes: string[]; // e.g., "Autonomy", "Loss", "Integration"
}

// --- Federation & Architecture ---
export enum FederationPartnerID {
  CORE = 'TRUTH_FORGE_CORE',
  PRIMITIVE_ENGINE = 'PRIMITIVE_ENGINE',
  CREDENTIAL_ATLAS = 'CREDENTIAL_ATLAS',
  NOT_ME_SERVICE = 'NOT_ME_SERVICE',
  COHORT_MESH = 'COHORT_MESH'
}

export type ConnectionStatus = 'CONNECTED' | 'DISCONNECTED' | 'DEGRADED' | 'MAINTENANCE';

export interface FederationConnection {
  partnerId: FederationPartnerID;
  name: string;
  description: string;
  status: ConnectionStatus;
  lastSync: number;
  dataTypesAccessed: string[]; // e.g., ["Identity", "Journal", "Metrics"]
  userConsent: boolean; // Is data sharing enabled?
  healthLatency?: number; // ms
}

export interface DataExchangeLog {
  id: string;
  timestamp: number;
  direction: 'INBOUND' | 'OUTBOUND';
  partnerId: FederationPartnerID;
  dataType: string;
  status: 'SUCCESS' | 'FAILURE' | 'PENDING';
  description: string;
}

export interface FederationState {
  connections: FederationConnection[];
  exchangeLog: DataExchangeLog[];
  globalConsent: boolean;
  dataExportStatus?: 'READY' | 'PROCESSING' | 'NONE';
}

// --- Assessment ---
export interface AssessmentQuestion {
  id: string;
  scenario: string;
  options: {
    text: string;
    stageIndicator: KeganStage;
  }[];
}

export interface AssessmentResult {
  id: string;
  timestamp: number;
  calculatedStage: KeganStage;
  stageConfidence: number; // 0-100
  growthEdge: string; // Description of the immediate next step
  responses: { questionId: string; stage: KeganStage }[];
}

// --- Credential Atlas Integration ---
export type CredentialType = 'DEVELOPMENT_BADGE' | 'SKILL_ATTESTATION' | 'PEER_VALIDATION';

export interface CredentialEvidence {
  type: 'JOURNAL_ENTRY' | 'CHAT_CONVERSATION' | 'IMMUNITY_MAP' | 'SYSTEM_OBSERVATION';
  referenceId: string;
  excerpt?: string;
  description: string;
}

export interface VerifiableCredential {
  id: string;
  title: string;
  description: string;
  type: CredentialType;
  issuer: 'SYSTEM_CORE' | 'NOT_ME_COMPANION' | 'PEER_NETWORK';
  issueDate: string;
  evidenceLinks: string[]; // Legacy ID references
  evidenceDetail?: CredentialEvidence[]; // Rich evidence
  credentialAtlasHash?: string; // Blockchain Hash
  status: 'VERIFIED' | 'PENDING' | 'REVOKED';
  metadata: {
    stageContext: KeganStage;
    skillTags: string[];
  };
}

export interface CredentialRequest {
  id: string;
  achievement: string;
  evidenceSubmitted: CredentialEvidence[];
  requestedAt: number;
  status: 'SUBMITTED' | 'ANALYZING' | 'APPROVED' | 'REJECTED';
}

export interface CredentialAtlasConnection {
  status: ConnectionStatus;
  lastSync: number;
  credentialsCount: number;
}

// --- Truth Engine Semantics ---
export interface MeaningPattern {
  id: string;
  theme: string;
  strength: number; // 0-100
  description: string;
  relatedAtoms: string[]; // IDs
}

export interface SemanticResonance {
  score: number; // 0-100
  alignment: 'HIGH' | 'MODERATE' | 'LOW' | 'DISSONANT';
  dissonanceFlags: string[];
  resonancePoints: string[];
}

export interface MeaningNode {
  id: string;
  label: string;
  x: number;
  y: number;
  cluster: string;
  value: number;
}

export interface TruthEngineAnalysis {
  resonance: SemanticResonance;
  patterns: MeaningPattern[];
  coherenceScore: number; // 0-100
  coherenceTrend: 'RISING' | 'STABLE' | 'FALLING';
  meaningMap: MeaningNode[];
}

// --- Emergent Architecture ---
export interface InterfaceProposal {
  id: string;
  component: string;
  proposal: string;
  reasoning: string;
  status: 'PROPOSED' | 'ANALYZING' | 'ACCEPTED' | 'REJECTED';
  systemResponse?: string;
  timestamp: number;
}

export interface MetaCognitionEntry {
  id: string;
  timestamp: number;
  trigger: string;
  reflection: string;
  depthScore: number;
}

export interface SystemObservation {
  id: string;
  timestamp: number;
  observation: string;
  patternType: 'BEHAVIORAL' | 'LINGUISTIC' | 'STRUCTURAL';
  status: 'UNREAD' | 'ACKNOWLEDGED' | 'INTEGRATED';
}

export interface EmergentPattern {
  id: string;
  name: string;
  description: string;
  noveltyScore: number; // 0-100
  componentsInvolved: string[];
  detectedAt: number;
}

// --- Daily Developmental Practice ---
export interface RitualEntry {
  id: string;
  date: string; // YYYY-MM-DD
  type: 'MORNING_INTENTION' | 'EVENING_REFLECTION';
  prompt: string;
  response: string;
  completedAt: number;
}

export interface DailyPracticeState {
  streak: number;
  lastPracticeDate: string; // YYYY-MM-DD
  history: RitualEntry[];
  todayIntention?: string;
}

// --- Cohort & Community ---
export interface ForumPost {
  id: string;
  authorAlias: string; // Anonymous alias e.g., "Seeker-492"
  stageContext: KeganStage;
  type: 'REFLECTION' | 'CONTRADICTION' | 'CHALLENGE_UPDATE';
  content: string;
  timestamp: number;
  likes: number;
  replies: number;
}

export interface GrowthPartner {
  id: string;
  alias: string;
  stage: KeganStage;
  connectionDate: string;
  sharedGoal: string;
  status: 'ACTIVE' | 'PENDING' | 'PAUSED';
}

export interface CohortChallenge {
  id: string;
  title: string;
  description: string;
  participants: number;
  durationDays: number;
  stageFocus: KeganStage;
}

// --- Milestones & Journey ---
export interface Milestone {
  id: string;
  type: 'STAGE_TRANSITION' | 'MAJOR_INSIGHT' | 'HOSTING_CAPACITY';
  title: string;
  description: string;
  date: string;
  fromStage?: KeganStage;
  toStage?: KeganStage;
  userReflection?: string;
  notMeWitness?: string;
  icon?: string;
}

export interface TransitionEvent {
  fromStage: KeganStage;
  toStage: KeganStage;
  triggerContext: string;
}

export interface DevelopmentProfile {
  stage: KeganStage;
  score: number; // 0-100 float representing progress within current stage or towards next
  evidence: DevelopmentEvidence[];
  subjectObjectMap: SubjectObjectItem[];
  shiftHistory: ObjectificationEvent[];
  immunityMaps: ImmunityMap[]; 
  journalEntries?: JournalEntry[]; // New Journal History
  holdingEnvironment: HoldingEnvironment;
  cognitiveMetrics?: {
      current: {
          perspectiveBreadth: number;
          integrationDepth: number;
          temporalCoherence: number;
      };
      history: CognitiveMetricPoint[];
  };
  growthReports?: GrowthReport[];
  credentials?: VerifiableCredential[]; // Credential Atlas Portfolio
  credentialRequests?: CredentialRequest[]; // Pending requests
  // Emergent Architecture Fields
  metaCognitionLog?: MetaCognitionEntry[];
  systemObservations?: SystemObservation[];
  emergentPatterns?: EmergentPattern[];
  interfaceProposals?: InterfaceProposal[];
  // Daily Practice
  dailyPractice?: DailyPracticeState;
  // Community / Cohort
  cohortId?: string; // ID of the anonymous group
  growthPartner?: GrowthPartner;
  isMentor?: boolean; // If true (and Stage 5), can mentor others
  // Milestones
  milestones?: Milestone[];
  // Crisis History
  crisisHistory?: CrisisEvent[];
  // Life Context
  lifeContext?: LifeContextState;
  // Content Library
  library?: LibraryState;
  // Narrative History
  narrativeHistory?: NarrativeSummary[];
  // Federation
  federationState?: FederationState;
  // Assessment
  assessmentHistory?: AssessmentResult[];
}

export interface DevelopmentEvidence {
  id: string;
  timestamp: number;
  actionType: 'CONSUMPTION' | 'CRITIQUE' | 'SYNTHESIS' | 'META_ANALYSIS';
  description: string;
  impact: number; // Positive or negative impact on score
}

export enum SubscriptionTier {
  STAGE_3_FROZEN = 'STAGE_3',
  STAGE_4_FLUID = 'STAGE_4',
  STAGE_5_STRUCTURAL = 'STAGE_5'
}

export enum AppContext {
  PORTAL = 'PORTAL',
  DATA_SYNTHESIS = 'DATA_SYNTHESIS',
  FOUNDRY = 'FOUNDRY',
  OBSERVABILITY = 'OBSERVABILITY',
  RELATIONSHIP = 'RELATIONSHIP',
  COMMUNITY = 'COMMUNITY'
}

export enum AppView {
  AUTH = 'AUTH',
  DASHBOARD = 'DASHBOARD'
}

export enum DashboardTab {
  ACCOUNT = 'ACCOUNT',
  BILLING = 'BILLING',
  SECURITY = 'SECURITY',
  NOTIFICATIONS = 'NOTIFICATIONS',
  PSYCHOMETRICS = 'PSYCHOMETRICS',
  GROWTH_PORTFOLIO = 'GROWTH_PORTFOLIO',
  JOURNEY = 'JOURNEY',
  LIFE_CONTEXT = 'LIFE_CONTEXT',
  LIBRARY = 'LIBRARY',
  FEDERATION = 'FEDERATION',
  ASSESSMENT = 'ASSESSMENT',
  NOT_ME_CHAT = 'NOT_ME_CHAT',
  IMMUNITY_MAP = 'IMMUNITY_MAP',
  REFLECTION_JOURNAL = 'REFLECTION_JOURNAL'
}

export enum DataLayer {
  RAW = 'RAW',
  SEMANTIC = 'SEMANTIC',
  PATTERN = 'PATTERN'
}

export enum SourceCategory {
  DOCUMENTS = 'DOCUMENTS',
  IMAGES = 'IMAGES',
  VIDEOS = 'VIDEOS',
  AUDIO = 'AUDIO',
  OTHER = 'OTHER',
  ARCHITECTURE = 'ARCHITECTURE'
}

export enum SynthesisPattern {
  SUMMARIZE = 'SUMMARIZE',
  KEY_POINTS = 'KEY_POINTS',
  CRITIQUE = 'CRITIQUE',
  DEBATE = 'DEBATE',
  DEEP_DIVE = 'DEEP_DIVE'
}

export enum SynthesisView {
  SOURCES = 'SOURCES',
  ARCHITECTURE = 'ARCHITECTURE',
  CHAT = 'CHAT',
  SYNTHESIZE = 'SYNTHESIZE'
}

export enum ChatMode {
  ENGAGE = 'ENGAGE',
  ORGANIZE = 'ORGANIZE',
  ASK = 'ASK'
}

export interface KnowledgeAtom {
  id: string;
  label: string;
  description: string;
  depth: number; // 1-10 indicating system depth
  resonance: number; // 0-100 indicating relevance
  type: 'axiom' | 'concept' | 'derivative';
  attribution?: 'USER' | 'NOT_ME'; // New field for Shared Knowledge Space
}

export interface DialecticalTension {
  id: string;
  atomAId: string;
  atomBId: string;
  description: string;
  intensity: number; // 1-10
  status: 'UNRESOLVED' | 'RESOLVED' | 'TRANSCENDED';
  stageContext: string; // The specific message generated for the user's stage
}