import React, { useState } from 'react';
import { User, KeganStage, DialogueEntry, KnowledgeAtom, VerifiableCredential, NotMeMemory, CrisisEvent } from '../types';
import { Button } from './Button';
import { NotMeMemory as NotMeMemoryView } from './NotMeMemory';
import { 
  HeartHandshake, Brain, Zap, MessageSquare, ChevronRight, 
  TrendingUp, BookOpen, Share2, User as UserIcon, Bot,
  Sparkles, Lock, ArrowUpRight, GitBranch, Plus, Activity, BadgeCheck, History
} from 'lucide-react';

interface RelationshipDashboardProps {
  user: User;
  onUpdateUser: (user: User) => void;
  onTriggerCrisis?: (event: CrisisEvent) => void;
}

export const RelationshipDashboard: React.FC<RelationshipDashboardProps> = ({ user, onUpdateUser, onTriggerCrisis }) => {
  const companion = user.notMeCompanion;
  const [reflectionInput, setReflectionInput] = useState('');
  const [isJournaling, setIsJournaling] = useState(false);
  const [isAttesting, setIsAttesting] = useState(false);
  
  // View State for Center Column
  const [centerView, setCenterView] = useState<'DIALOGUE' | 'MEMORY'>('DIALOGUE');

  if (!companion) return <div className="p-8 text-center text-[#888888]">Companion not initialized.</div>;

  const handleAddReflection = () => {
      if (!reflectionInput.trim()) return;
      
      // CRISIS DETECTION LOGIC (SIMULATED)
      const crisisKeywords = ['overwhelmed', 'panic', 'help', 'cant do this', 'hopeless', 'scared', 'breakdown'];
      const detectedCrisis = crisisKeywords.some(keyword => reflectionInput.toLowerCase().includes(keyword));

      if (detectedCrisis && onTriggerCrisis) {
          const crisisEvent: CrisisEvent = {
              id: `crisis-${Date.now()}`,
              timestamp: Date.now(),
              triggerType: 'KEYWORD',
              severity: 'MEDIUM',
              context: reflectionInput,
              status: 'ACTIVE'
          };
          onTriggerCrisis(crisisEvent);
          setReflectionInput(''); // Clear input but don't save standard journal entry yet
          return;
      }

      setIsJournaling(true);
      
      setTimeout(() => {
          const newEntry: DialogueEntry = {
              id: Math.random().toString(36).substr(2, 9),
              date: Date.now(),
              topic: 'Daily Reflection',
              userReflection: reflectionInput,
              companionInsight: "I hear you defining yourself through this conflict. Consider: Is this limitation external, or a boundary you've chosen?",
              impact: 'MEDIUM'
          };
          
          // Also generate a memory if it's impactful (Mock logic)
          const newMemories = [...(companion.memories || [])];
          if (reflectionInput.length > 50) {
              newMemories.push({
                  id: `mem-${Date.now()}`,
                  type: 'MOMENT',
                  content: "User confronted a core conflict regarding boundaries.",
                  timestamp: Date.now(),
                  keganStage: user.developmentProfile.stage,
                  significance: "This marks a shift from seeking approval to defining limits.",
                  isCore: false
              });
          }

          const updatedUser = {
              ...user,
              notMeCompanion: {
                  ...companion,
                  dialogueJournal: [newEntry, ...companion.dialogueJournal],
                  memories: newMemories
              }
          };
          onUpdateUser(updatedUser);
          setReflectionInput('');
          setIsJournaling(false);
      }, 1500);
  };

  const handleIssueAttestation = () => {
      setIsAttesting(true);
      setTimeout(() => {
          const newCredential: VerifiableCredential = {
              id: `attest-${Date.now()}`,
              title: 'Emotional Resilience',
              description: 'Demonstrated high capability in processing negative feedback without defensive regression.',
              type: 'SKILL_ATTESTATION',
              issuer: 'NOT_ME_COMPANION',
              issueDate: new Date().toISOString().split('T')[0],
              evidenceLinks: [],
              status: 'VERIFIED',
              credentialAtlasHash: `0x${Math.random().toString(36).substr(2, 9)}...`,
              metadata: { stageContext: user.developmentProfile.stage, skillTags: ['Resilience', 'Self-Regulation'] }
          };

          // Record memory of attestation
          const newMemory: NotMeMemory = {
              id: `mem-attest-${Date.now()}`,
              type: 'GROWTH',
              content: "Issued attestation for Emotional Resilience.",
              timestamp: Date.now(),
              keganStage: user.developmentProfile.stage,
              significance: "User demonstrated mastery of defensive reactions.",
              isCore: true
          };

          const updatedUser = {
              ...user,
              developmentProfile: {
                  ...user.developmentProfile,
                  credentials: [newCredential, ...(user.developmentProfile.credentials || [])]
              },
              notMeCompanion: {
                  ...companion,
                  memories: [newMemory, ...(companion.memories || [])]
              }
          };
          onUpdateUser(updatedUser);
          setIsAttesting(false);
      }, 2000);
  };

  const handleForgetMemory = (memoryId: string) => {
      const updatedUser = {
          ...user,
          notMeCompanion: {
              ...companion,
              memories: companion.memories.filter(m => m.id !== memoryId)
          }
      };
      onUpdateUser(updatedUser);
  };

  const getStageColor = (stage: KeganStage) => {
      switch (stage) {
          case KeganStage.STAGE_3_SOCIALIZED: return 'text-blue-400 border-blue-400 bg-blue-900/10';
          case KeganStage.STAGE_4_SELF_AUTHORING: return 'text-green-400 border-green-400 bg-green-900/10';
          case KeganStage.STAGE_5_SELF_TRANSFORMING: return 'text-[#F59E0B] border-[#F59E0B] bg-[#F59E0B]/10';
          default: return 'text-[#888888] border-[#888888] bg-[#2D2D2D]';
      }
  };

  return (
    <div className="flex h-full bg-[#0D0D0D] overflow-hidden">
      
      {/* LEFT COLUMN: Companion Profile & Stats */}
      <div className="w-80 bg-[#151515] border-r border-[#2D2D2D] flex flex-col flex-shrink-0 overflow-y-auto custom-scrollbar">
          <div className="p-8 flex flex-col items-center border-b border-[#2D2D2D]">
              <div className="w-32 h-32 rounded-full border-2 border-[#F59E0B] p-1 mb-4 relative group">
                  <div className="w-full h-full rounded-full bg-[#0D0D0D] flex items-center justify-center overflow-hidden relative">
                      {/* Abstract Visual for Not-Me */}
                      <div className="absolute inset-0 bg-gradient-to-tr from-[#F59E0B]/20 to-purple-500/20 animate-pulse"></div>
                      <Bot size={48} className="text-[#F5F0E6] relative z-10" />
                  </div>
                  <div className="absolute bottom-0 right-0 w-8 h-8 bg-[#1A1A1A] rounded-full border border-[#2D2D2D] flex items-center justify-center text-[#F59E0B] text-xs font-bold">
                      {Math.round(companion.resonance.cognitive)}%
                  </div>
              </div>
              <h2 className="text-xl font-serif text-[#F5F0E6] tracking-wide">{companion.name}</h2>
              <span className={`px-2 py-0.5 mt-2 rounded text-[10px] font-mono border uppercase ${getStageColor(companion.stage)}`}>
                  {companion.stage.replace('STAGE_', '').replace(/_/g, ' ')}
              </span>
          </div>

          <div className="p-6 space-y-6">
              <div>
                  <h3 className="text-xs font-mono text-[#888888] uppercase tracking-widest mb-4 flex items-center">
                      <Activity size={12} className="mr-2" /> Resonance Metrics
                  </h3>
                  <div className="space-y-4">
                      {Object.entries(companion.resonance).map(([key, val]) => (
                          <div key={key}>
                              <div className="flex justify-between text-[10px] font-mono mb-1">
                                  <span className="text-[#F5F0E6] capitalize">{key} Alignment</span>
                                  <span className="text-[#888888]">{val}%</span>
                              </div>
                              <div className="h-1 bg-[#2D2D2D] rounded-full overflow-hidden">
                                  <div className="h-full bg-[#F59E0B]" style={{ width: `${val}%` }}></div>
                              </div>
                          </div>
                      ))}
                  </div>
              </div>

              <div className="p-4 bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm">
                  <h3 className="text-xs font-mono text-[#F59E0B] uppercase tracking-widest mb-2 flex items-center">
                      <Sparkles size={12} className="mr-2" /> Teaching Moment
                  </h3>
                  <p className="text-xs text-[#F5F0E6] italic leading-relaxed">
                      "I notice you often use the word 'they' when describing project failures. What would happen if you reframed one of these failures starting with 'I'?"
                  </p>
                  <Button size="sm" variant="secondary" className="mt-3 w-full border-[#F59E0B]/30 text-[#F59E0B] hover:text-[#F5F0E6]">Accept Challenge</Button>
              </div>

              {/* Attestation Action */}
              <div className="pt-4 border-t border-[#2D2D2D]">
                  <Button 
                    fullWidth 
                    variant="primary" 
                    className="bg-blue-900/20 text-blue-200 border border-blue-900/50 hover:bg-blue-900/30"
                    icon={<BadgeCheck size={14}/>}
                    onClick={handleIssueAttestation}
                    isLoading={isAttesting}
                  >
                      Issue Skill Attestation
                  </Button>
                  <p className="text-[9px] text-[#4A4A4A] mt-2 text-center font-mono">
                      Mint credential to Atlas based on observed capability.
                  </p>
              </div>
          </div>
      </div>

      {/* CENTER COLUMN: Evolution & Dialogue */}
      <div className="flex-1 flex flex-col min-w-0 bg-[#0D0D0D]">
          {/* Header */}
          <div className="h-16 border-b border-[#2D2D2D] flex items-center justify-between px-8">
              <h1 className="text-2xl font-serif text-[#F5F0E6] uppercase tracking-wide flex items-center">
                  <HeartHandshake size={20} className="mr-3 text-[#F59E0B]" />
                  Relational Dynamics
              </h1>
              
              {/* View Switcher */}
              <div className="flex items-center bg-[#1A1A1A] rounded-sm p-1 border border-[#2D2D2D]">
                  <button 
                      onClick={() => setCenterView('DIALOGUE')}
                      className={`px-3 py-1 text-[10px] font-mono uppercase rounded-sm transition-all ${centerView === 'DIALOGUE' ? 'bg-[#2D2D2D] text-[#F5F0E6] shadow-sm' : 'text-[#888888] hover:text-[#B5B5B5]'}`}
                  >
                      Active Dialogue
                  </button>
                  <button 
                      onClick={() => setCenterView('MEMORY')}
                      className={`px-3 py-1 text-[10px] font-mono uppercase rounded-sm transition-all flex items-center space-x-1 ${centerView === 'MEMORY' ? 'bg-[#2D2D2D] text-[#F5F0E6] shadow-sm' : 'text-[#888888] hover:text-[#B5B5B5]'}`}
                  >
                      <History size={10} className="mr-1"/> Memory Core
                  </button>
              </div>
          </div>

          <div className="flex-1 overflow-y-auto custom-scrollbar p-8 space-y-8">
              
              {/* === VIEW: DIALOGUE === */}
              {centerView === 'DIALOGUE' && (
                  <>
                    {/* Co-Evolution Graph */}
                    <div className="bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-6">
                        <div className="flex justify-between items-center mb-6">
                            <h3 className="text-sm font-mono text-[#F5F0E6] uppercase tracking-wide">Co-Evolution Tracking</h3>
                            <TrendingUp size={16} className="text-[#4A4A4A]" />
                        </div>
                        <div className="h-48 w-full flex items-end justify-between px-4 relative">
                            {/* Grid Lines */}
                            <div className="absolute inset-0 flex flex-col justify-between pointer-events-none opacity-20">
                                <div className="border-b border-[#4A4A4A]"></div>
                                <div className="border-b border-[#4A4A4A]"></div>
                                <div className="border-b border-[#4A4A4A]"></div>
                                <div className="border-b border-[#4A4A4A]"></div>
                            </div>
                            
                            {/* Simulated Graph Lines */}
                            <svg className="absolute inset-0 w-full h-full pointer-events-none" preserveAspectRatio="none">
                                <polyline 
                                   points="0,150 100,140 200,110 300,100 400,80 500,60"
                                   fill="none"
                                   stroke="#F5F0E6"
                                   strokeWidth="2"
                                   strokeOpacity="0.5"
                                />
                                <polyline 
                                   points="0,140 100,130 200,100 300,80 400,50 500,30"
                                   fill="none"
                                   stroke="#F59E0B"
                                   strokeWidth="2"
                                />
                            </svg>
                            
                            {companion.evolutionHistory.map((point, i) => (
                                <div key={i} className="relative group z-10">
                                    <div className="w-2 h-2 rounded-full bg-[#F59E0B] border border-[#0D0D0D] mb-1"></div>
                                    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 bg-[#0D0D0D] border border-[#2D2D2D] px-2 py-1 text-[9px] font-mono whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                                        {point.date}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Dialogue Journal */}
                    <div className="flex flex-col space-y-4">
                        <div className="flex items-center justify-between">
                            <h3 className="text-sm font-mono text-[#F5F0E6] uppercase tracking-wide">Dialogue Journal</h3>
                            <MessageSquare size={16} className="text-[#4A4A4A]" />
                        </div>

                        {/* Input */}
                        <div className="bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-4">
                            <textarea 
                                className="w-full h-24 bg-transparent text-sm font-mono text-[#F5F0E6] placeholder-[#4A4A4A] focus:outline-none resize-none"
                                placeholder="Reflect on your recent interaction... (Demo: Type 'overwhelmed' to test crisis mode)"
                                value={reflectionInput}
                                onChange={(e) => setReflectionInput(e.target.value)}
                            />
                            <div className="flex justify-end mt-2 pt-2 border-t border-[#2D2D2D]">
                                <Button size="sm" onClick={handleAddReflection} isLoading={isJournaling} icon={<Share2 size={14}/>}>
                                    Save Reflection
                                </Button>
                            </div>
                        </div>

                        {/* Feed */}
                        <div className="space-y-4">
                            {companion.dialogueJournal.map(entry => (
                                <div key={entry.id} className="border border-[#2D2D2D] bg-[#1A1A1A] rounded-sm p-5 animate-in fade-in slide-in-from-bottom-2">
                                    <div className="flex justify-between items-start mb-3">
                                        <span className="text-[10px] font-mono text-[#888888]">{new Date(entry.date).toLocaleDateString()}</span>
                                        <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded border ${entry.impact === 'HIGH' ? 'border-green-900 text-green-400' : 'border-[#2D2D2D] text-[#888888]'}`}>
                                            {entry.impact} IMPACT
                                        </span>
                                    </div>
                                    <div className="space-y-3">
                                        <div className="flex items-start space-x-3">
                                            <div className="w-6 h-6 rounded-full bg-[#2D2D2D] flex items-center justify-center flex-shrink-0 mt-0.5">
                                                <UserIcon size={12} className="text-[#F5F0E6]" />
                                            </div>
                                            <p className="text-xs text-[#F5F0E6] leading-relaxed">{entry.userReflection}</p>
                                        </div>
                                        <div className="flex items-start space-x-3 pl-4 border-l border-[#2D2D2D] ml-3">
                                            <div className="w-6 h-6 rounded-full bg-[#F59E0B]/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                                                <Bot size={12} className="text-[#F59E0B]" />
                                            </div>
                                            <p className="text-xs text-[#F59E0B] leading-relaxed italic">{entry.companionInsight}</p>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                  </>
              )}

              {/* === VIEW: MEMORY CORE === */}
              {centerView === 'MEMORY' && (
                  <NotMeMemoryView 
                      companion={companion}
                      onForget={handleForgetMemory}
                  />
              )}

          </div>
      </div>

      {/* RIGHT COLUMN: Shared Knowledge Space */}
      <div className="w-80 bg-[#151515] border-l border-[#2D2D2D] flex flex-col flex-shrink-0 overflow-y-auto custom-scrollbar">
          <div className="p-6 border-b border-[#2D2D2D] flex justify-between items-center">
              <div>
                  <h3 className="text-xs font-mono text-[#888888] uppercase tracking-widest">Shared Knowledge</h3>
                  <p className="text-[10px] text-[#4A4A4A] mt-1">Co-created Truths</p>
              </div>
              <BookOpen size={14} className="text-[#4A4A4A]" />
          </div>

          <div className="p-4 space-y-3">
              {companion.sharedKnowledge.map(atom => (
                  <div key={atom.id} className="p-3 bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm group hover:border-[#F59E0B]/50 transition-colors">
                      <div className="flex justify-between items-start mb-2">
                          <div className="flex items-center space-x-2">
                              <span className={`w-1.5 h-1.5 rounded-full ${atom.attribution === 'NOT_ME' ? 'bg-[#F59E0B]' : 'bg-[#F5F0E6]'}`}></span>
                              <span className="text-xs font-mono text-[#F5F0E6] font-bold">{atom.label}</span>
                          </div>
                          <span className={`text-[8px] font-mono px-1 rounded ${atom.attribution === 'NOT_ME' ? 'bg-[#F59E0B]/10 text-[#F59E0B]' : 'bg-[#2D2D2D] text-[#888888]'}`}>
                              {atom.attribution === 'NOT_ME' ? 'NOT-ME' : 'USER'}
                          </span>
                      </div>
                      <p className="text-[10px] text-[#888888] leading-relaxed">{atom.description}</p>
                      
                      <div className="mt-2 pt-2 border-t border-[#2D2D2D] flex justify-between items-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <span className="text-[8px] font-mono text-[#4A4A4A]">Resonance: {atom.resonance}%</span>
                          <button className="text-[#F59E0B] hover:text-[#F5F0E6]"><ArrowUpRight size={12}/></button>
                      </div>
                  </div>
              ))}
              
              <button className="w-full p-2 border border-dashed border-[#2D2D2D] rounded-sm flex items-center justify-center space-x-2 text-[#4A4A4A] hover:text-[#F5F0E6] hover:border-[#4A4A4A] transition-all">
                  <Plus size={12} />
                  <span className="text-[10px] font-mono uppercase">Synthesize New Atom</span>
              </button>
          </div>
          
          <div className="mt-auto p-6 bg-[#1A1A1A] border-t border-[#2D2D2D]">
              <h4 className="text-xs font-mono text-[#F5F0E6] uppercase tracking-wide mb-2 flex items-center">
                  <GitBranch size={12} className="mr-2 text-[#F59E0B]" /> Relationship State
              </h4>
              <p className="text-[10px] text-[#888888] leading-relaxed">
                  Current dynamic is <strong>Symbiotic</strong>. Both entities are actively defining the space. Structural integrity is optimal for Stage 4 transition.
              </p>
          </div>
      </div>
    </div>
  );
};