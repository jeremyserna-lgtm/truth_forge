import React, { useState } from 'react';
import { User, KeganStage, ForumPost, GrowthPartner, CohortChallenge } from '../types';
import { Button } from './Button';
import { Users, UserPlus, HeartHandshake, MessageCircle, Shield, Split, Sparkles, Lock, ArrowRight, Zap, Target } from 'lucide-react';

interface CohortSpaceProps {
  user: User;
  onUpdateUser: (user: User) => void;
}

type CommunityView = 'FORUM' | 'PARTNER' | 'CHALLENGES' | 'MENTORSHIP' | 'CONTRADICTIONS';

export const CohortSpace: React.FC<CohortSpaceProps> = ({ user, onUpdateUser }) => {
  const [activeView, setActiveView] = useState<CommunityView>('FORUM');
  const [isConnecting, setIsConnecting] = useState(false);
  const [postInput, setPostInput] = useState('');

  const stage = user.developmentProfile.stage;
  const isStage5 = stage === KeganStage.STAGE_5_SELF_TRANSFORMING;

  // --- Mock Data ---
  const [forumPosts, setForumPosts] = useState<ForumPost[]>([
      { id: 'p1', authorAlias: 'Observer-92', stageContext: KeganStage.STAGE_3_SOCIALIZED, type: 'REFLECTION', content: 'I realized today that my "loyalty" to the team was actually just fear of conflict. Has anyone else felt this?', timestamp: Date.now() - 3600000, likes: 12, replies: 4 },
      { id: 'p2', authorAlias: 'Architect-04', stageContext: KeganStage.STAGE_4_SELF_AUTHORING, type: 'REFLECTION', content: 'Struggling to rewrite my internal rule about productivity. My self-worth is still tied to output.', timestamp: Date.now() - 7200000, likes: 8, replies: 2 },
      { id: 'p3', authorAlias: 'Flux-11', stageContext: KeganStage.STAGE_5_SELF_TRANSFORMING, type: 'CONTRADICTION', content: 'Holding the tension between "Total Responsibility" and "Surrender to Flow". Both seem true simultaneously.', timestamp: Date.now() - 86400000, likes: 24, replies: 9 }
  ]);

  const challenges: CohortChallenge[] = [
      { id: 'c1', title: 'The "No" Experiment', description: 'Decline one request this week that aligns with expectation but not your values.', participants: 432, durationDays: 7, stageFocus: KeganStage.STAGE_3_SOCIALIZED },
      { id: 'c2', title: 'Axiom Audit', description: 'Identify one "Truth" you hold and argue the exact opposite case.', participants: 215, durationDays: 3, stageFocus: KeganStage.STAGE_4_SELF_AUTHORING },
      { id: 'c3', title: 'Identity Fluidity', description: 'Engage in a conversation where you adopt a perspective you fundamentally disagree with, without judgment.', participants: 89, durationDays: 1, stageFocus: KeganStage.STAGE_5_SELF_TRANSFORMING }
  ];

  const handlePostSubmit = () => {
      if (!postInput.trim()) return;
      const newPost: ForumPost = {
          id: Math.random().toString(36).substr(2, 9),
          authorAlias: `Initiate-${Math.floor(Math.random() * 1000)}`,
          stageContext: stage,
          type: activeView === 'CONTRADICTIONS' ? 'CONTRADICTION' : 'REFLECTION',
          content: postInput,
          timestamp: Date.now(),
          likes: 0,
          replies: 0
      };
      setForumPosts([newPost, ...forumPosts]);
      setPostInput('');
  };

  const handleFindPartner = () => {
      setIsConnecting(true);
      setTimeout(() => {
          const partner: GrowthPartner = {
              id: 'gp-new',
              alias: 'Seeker-77',
              stage: stage, // Matched stage
              connectionDate: new Date().toISOString().split('T')[0],
              sharedGoal: 'Navigating the gap between intention and impact.',
              status: 'ACTIVE'
          };
          onUpdateUser({
              ...user,
              developmentProfile: {
                  ...user.developmentProfile,
                  growthPartner: partner
              }
          });
          setIsConnecting(false);
      }, 2000);
  };

  const getStageTheme = () => {
      switch (stage) {
          case KeganStage.STAGE_3_SOCIALIZED: return { color: 'text-blue-400', border: 'border-blue-500', bg: 'bg-blue-500/10', name: 'Socialized Cohort' };
          case KeganStage.STAGE_4_SELF_AUTHORING: return { color: 'text-green-400', border: 'border-green-500', bg: 'bg-green-500/10', name: 'Self-Authoring Cohort' };
          case KeganStage.STAGE_5_SELF_TRANSFORMING: return { color: 'text-[#F59E0B]', border: 'border-[#F59E0B]', bg: 'bg-[#F59E0B]/10', name: 'Transforming Cohort' };
          default: return { color: 'text-gray-400', border: 'border-gray-500', bg: 'bg-gray-500/10', name: 'General Cohort' };
      }
  };

  const theme = getStageTheme();

  // Filter posts based on view and roughly by stage (simulated privacy)
  // In reality, Stage 3 might see Stage 3 & 4 posts (to see where they are going), etc.
  const visiblePosts = forumPosts.filter(p => {
      if (activeView === 'CONTRADICTIONS') return p.type === 'CONTRADICTION';
      return true; // Show all for demo, typically would filter by cohort
  });

  return (
    <div className="flex h-full bg-[#0D0D0D] overflow-hidden">
        {/* Left Sidebar: Navigation */}
        <div className="w-64 bg-[#151515] border-r border-[#2D2D2D] flex flex-col flex-shrink-0">
            <div className="p-6 border-b border-[#2D2D2D]">
                <div className="flex items-center space-x-2 mb-2">
                    <Users size={18} className={theme.color} />
                    <span className="text-sm font-serif text-[#F5F0E6] uppercase tracking-wide">Cohort Space</span>
                </div>
                <div className={`text-[10px] font-mono p-1 rounded-sm border ${theme.border} ${theme.bg} ${theme.color} text-center`}>
                    {theme.name}
                </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-2 space-y-1">
                <button onClick={() => setActiveView('FORUM')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-sm transition-colors ${activeView === 'FORUM' ? 'bg-[#2D2D2D] text-[#F5F0E6]' : 'text-[#888888] hover:bg-[#1A1A1A]'}`}>
                    <MessageCircle size={14} />
                    <span className="text-xs font-mono uppercase">Stage Forum</span>
                </button>
                <button onClick={() => setActiveView('PARTNER')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-sm transition-colors ${activeView === 'PARTNER' ? 'bg-[#2D2D2D] text-[#F5F0E6]' : 'text-[#888888] hover:bg-[#1A1A1A]'}`}>
                    <UserPlus size={14} />
                    <span className="text-xs font-mono uppercase">Growth Partner</span>
                </button>
                <button onClick={() => setActiveView('CHALLENGES')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-sm transition-colors ${activeView === 'CHALLENGES' ? 'bg-[#2D2D2D] text-[#F5F0E6]' : 'text-[#888888] hover:bg-[#1A1A1A]'}`}>
                    <Target size={14} />
                    <span className="text-xs font-mono uppercase">Cohort Challenges</span>
                </button>
                <button onClick={() => setActiveView('CONTRADICTIONS')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-sm transition-colors ${activeView === 'CONTRADICTIONS' ? 'bg-[#2D2D2D] text-[#F5F0E6]' : 'text-[#888888] hover:bg-[#1A1A1A]'}`}>
                    <Split size={14} />
                    <span className="text-xs font-mono uppercase">Contradictions</span>
                </button>
                <button onClick={() => setActiveView('MENTORSHIP')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-sm transition-colors ${activeView === 'MENTORSHIP' ? 'bg-[#2D2D2D] text-[#F5F0E6]' : 'text-[#888888] hover:bg-[#1A1A1A]'}`}>
                    <Sparkles size={14} />
                    <span className="text-xs font-mono uppercase">Wisdom Circle</span>
                </button>
            </div>

            <div className="p-4 border-t border-[#2D2D2D]">
                <div className="flex items-center space-x-2 text-[#4A4A4A] mb-2">
                    <Shield size={12} />
                    <span className="text-[10px] font-mono uppercase">Privacy Protocol</span>
                </div>
                <p className="text-[9px] text-[#888888] leading-relaxed">
                    All interactions are anonymized. Your specific psychometrics are never revealed to peers, only your cohort alignment.
                </p>
            </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-y-auto bg-[#0D0D0D] p-8 custom-scrollbar">
            
            {/* VIEW: FORUM & CONTRADICTIONS */}
            {(activeView === 'FORUM' || activeView === 'CONTRADICTIONS') && (
                <div className="max-w-3xl mx-auto space-y-6">
                    <header className="mb-8">
                        <h2 className="text-2xl font-serif text-[#F5F0E6] uppercase tracking-wide">
                            {activeView === 'CONTRADICTIONS' ? 'Shared Contradictions' : 'Developmental Discourse'}
                        </h2>
                        <p className="text-sm font-mono text-[#888888] mt-2">
                            {activeView === 'CONTRADICTIONS' 
                                ? "A space to hold tension. Post the paradoxes you cannot resolve." 
                                : "Anonymous reflections from peers at your developmental edge."}
                        </p>
                    </header>

                    {/* Input */}
                    <div className="bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-4">
                        <textarea 
                            className="w-full h-24 bg-transparent text-sm font-mono text-[#F5F0E6] placeholder-[#4A4A4A] focus:outline-none resize-none"
                            placeholder={activeView === 'CONTRADICTIONS' ? "I am torn between..." : "Share a recent insight or struggle..."}
                            value={postInput}
                            onChange={(e) => setPostInput(e.target.value)}
                        />
                        <div className="flex justify-between items-center mt-2 pt-2 border-t border-[#2D2D2D]">
                            <span className="text-[10px] font-mono text-[#4A4A4A]">Posting as: Initiate-{user.id.substr(0,3)}</span>
                            <Button size="sm" onClick={handlePostSubmit} disabled={!postInput.trim()}>
                                Post Anonymously
                            </Button>
                        </div>
                    </div>

                    {/* Feed */}
                    <div className="space-y-4">
                        {visiblePosts.map(post => (
                            <div key={post.id} className="bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-5 animate-in fade-in slide-in-from-bottom-2">
                                <div className="flex justify-between items-start mb-3">
                                    <div className="flex items-center space-x-2">
                                        <div className="w-6 h-6 rounded-full bg-[#2D2D2D] flex items-center justify-center text-[10px] font-mono text-[#888888]">
                                            {post.authorAlias.charAt(0)}
                                        </div>
                                        <span className="text-xs font-mono text-[#F5F0E6]">{post.authorAlias}</span>
                                        {activeView !== 'CONTRADICTIONS' && (
                                            <span className={`text-[8px] font-mono px-1 rounded border ${
                                                post.stageContext === KeganStage.STAGE_5_SELF_TRANSFORMING ? 'border-[#F59E0B] text-[#F59E0B]' :
                                                post.stageContext === KeganStage.STAGE_4_SELF_AUTHORING ? 'border-green-500 text-green-500' :
                                                'border-blue-500 text-blue-500'
                                            }`}>
                                                Stage {post.stageContext === KeganStage.STAGE_5_SELF_TRANSFORMING ? '5' : post.stageContext === KeganStage.STAGE_4_SELF_AUTHORING ? '4' : '3'}
                                            </span>
                                        )}
                                    </div>
                                    <span className="text-[10px] font-mono text-[#4A4A4A]">
                                        {Math.floor((Date.now() - post.timestamp) / 3600000)}h ago
                                    </span>
                                </div>
                                <p className="text-sm text-[#F5F0E6] leading-relaxed mb-4">
                                    {post.content}
                                </p>
                                <div className="flex space-x-4">
                                    <button className="text-[10px] font-mono text-[#888888] hover:text-[#F5F0E6] flex items-center space-x-1">
                                        <HeartHandshake size={12} /> <span>{post.likes} Resonate</span>
                                    </button>
                                    <button className="text-[10px] font-mono text-[#888888] hover:text-[#F5F0E6] flex items-center space-x-1">
                                        <MessageCircle size={12} /> <span>{post.replies} Replies</span>
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* VIEW: GROWTH PARTNER */}
            {activeView === 'PARTNER' && (
                <div className="max-w-3xl mx-auto flex flex-col items-center">
                    <header className="mb-12 text-center">
                        <div className="w-16 h-16 rounded-full bg-[#1A1A1A] border border-[#2D2D2D] flex items-center justify-center mx-auto mb-6">
                            <UserPlus size={32} className={theme.color} />
                        </div>
                        <h2 className="text-2xl font-serif text-[#F5F0E6] uppercase tracking-wide">Growth Partners</h2>
                        <p className="text-sm font-mono text-[#888888] mt-2 max-w-lg mx-auto">
                            Opt-in to be paired with a peer at a similar developmental edge. 
                            Partnerships last 30 days and focus on a shared "Immunity to Change" goal.
                        </p>
                    </header>

                    {user.developmentProfile.growthPartner ? (
                        <div className="w-full bg-[#1A1A1A] border border-[#F59E0B]/50 rounded-sm p-8 relative overflow-hidden animate-in zoom-in-95">
                            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#F59E0B] to-transparent"></div>
                            <div className="flex justify-between items-start mb-6">
                                <div>
                                    <span className="text-[10px] font-mono text-[#F59E0B] uppercase tracking-widest mb-1 block">Active Partnership</span>
                                    <h3 className="text-xl font-serif text-[#F5F0E6]">{user.developmentProfile.growthPartner.alias}</h3>
                                </div>
                                <div className="text-right">
                                    <div className="text-[10px] font-mono text-[#888888]">Connected Since</div>
                                    <div className="text-xs font-mono text-[#F5F0E6]">{user.developmentProfile.growthPartner.connectionDate}</div>
                                </div>
                            </div>
                            <div className="p-4 bg-[#0D0D0D] border border-[#2D2D2D] rounded-sm mb-6">
                                <span className="text-[10px] font-mono text-[#4A4A4A] uppercase block mb-2">Shared Focus</span>
                                <p className="text-sm text-[#F5F0E6] italic">"{user.developmentProfile.growthPartner.sharedGoal}"</p>
                            </div>
                            <div className="flex space-x-4">
                                <Button size="sm" icon={<MessageCircle size={14}/>}>Open Channel</Button>
                                <Button size="sm" variant="secondary" icon={<Shield size={14}/>}>End Partnership</Button>
                            </div>
                        </div>
                    ) : (
                        <div className="text-center space-y-6 p-8 border border-dashed border-[#2D2D2D] rounded-sm w-full">
                            <p className="text-xs font-mono text-[#4A4A4A]">No active partner found.</p>
                            <Button size="lg" onClick={handleFindPartner} isLoading={isConnecting} icon={<Zap size={16}/>}>
                                Find a Partner
                            </Button>
                        </div>
                    )}
                </div>
            )}

            {/* VIEW: CHALLENGES */}
            {activeView === 'CHALLENGES' && (
                <div className="max-w-4xl mx-auto">
                    <header className="mb-8">
                        <h2 className="text-2xl font-serif text-[#F5F0E6] uppercase tracking-wide">Cohort Challenges</h2>
                        <p className="text-sm font-mono text-[#888888] mt-2">
                            Synchronized experiments to push the developmental edge of the entire group.
                        </p>
                    </header>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {challenges.map(challenge => (
                            <div key={challenge.id} className="bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-6 flex flex-col hover:border-[#F5F0E6] transition-colors group">
                                <div className="flex justify-between items-start mb-4">
                                    <h3 className="text-lg font-serif text-[#F5F0E6]">{challenge.title}</h3>
                                    <span className="text-[10px] font-mono text-[#F59E0B] border border-[#F59E0B]/30 px-2 py-1 rounded bg-[#F59E0B]/10">
                                        {challenge.durationDays} DAYS
                                    </span>
                                </div>
                                <p className="text-sm text-[#888888] leading-relaxed mb-6 flex-1">
                                    {challenge.description}
                                </p>
                                <div className="flex items-center justify-between pt-4 border-t border-[#2D2D2D]">
                                    <div className="flex items-center space-x-2 text-[10px] font-mono text-[#4A4A4A]">
                                        <Users size={12} />
                                        <span>{challenge.participants} Active</span>
                                    </div>
                                    <button className="flex items-center space-x-2 text-xs font-mono text-[#F5F0E6] opacity-0 group-hover:opacity-100 transition-opacity uppercase tracking-wider">
                                        <span>Join</span> <ArrowRight size={12} />
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* VIEW: MENTORSHIP */}
            {activeView === 'MENTORSHIP' && (
                <div className="max-w-3xl mx-auto flex flex-col items-center justify-center min-h-[60vh]">
                    <Sparkles size={48} className="text-purple-400 mb-6" />
                    <h2 className="text-2xl font-serif text-[#F5F0E6] uppercase tracking-wide mb-4">Wisdom Circles</h2>
                    
                    {isStage5 ? (
                        <div className="text-center max-w-lg space-y-6">
                            <p className="text-sm font-mono text-[#888888]">
                                As a Self-Transforming entity, you have the capacity to hold space for those in earlier stages without imposing your structure upon them.
                            </p>
                            <div className="bg-[#1A1A1A] border border-purple-900/50 p-6 rounded-sm">
                                <h3 className="text-lg font-serif text-[#F5F0E6] mb-2">Mentorship Invitation</h3>
                                <p className="text-xs text-[#888888] mb-4">
                                    Are you willing to be matched with a Stage 3 or 4 user for a 1-hour anonymous text session?
                                </p>
                                <Button variant="secondary" className="border-purple-500 text-purple-400 hover:bg-purple-900/20">
                                    Open Availability
                                </Button>
                            </div>
                        </div>
                    ) : (
                        <div className="text-center max-w-lg space-y-6">
                            <p className="text-sm font-mono text-[#888888]">
                                Connect with those who have navigated the territory you are currently crossing.
                            </p>
                            <div className="bg-[#1A1A1A] border border-[#2D2D2D] p-8 rounded-sm opacity-80 relative overflow-hidden">
                                <Lock size={24} className="mx-auto mb-4 text-[#4A4A4A]" />
                                <h3 className="text-lg font-serif text-[#F5F0E6] mb-2">Request Guidance</h3>
                                <p className="text-xs text-[#888888] mb-4">
                                    Mentors are currently at capacity. You will be notified when a Wisdom Circle opens.
                                </p>
                                <Button disabled className="w-full">Join Waitlist</Button>
                            </div>
                        </div>
                    )}
                </div>
            )}

        </div>
    </div>
  );
};