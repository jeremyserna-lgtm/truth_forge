import React, { useState, useMemo } from 'react';
import { User, SubscriptionTier, KeganStage, ObjectificationEvent, SubjectObjectItem, ImmunityMap, Experiment } from '../types';
import { Button } from './Button';
import { 
  Play, Save, Settings, Database, Plus, MoreHorizontal, Code, Lock, Wand2, 
  X, Copy, Check, ChevronRight, ChevronDown, BookMarked, Trash2, FolderOpen,
  Shield, AlertTriangle, FileJson, Cpu, Loader2, ListTodo, Calendar, Tag, 
  Filter, ArrowUpDown, CheckSquare, Square, Clock, Search, Network, 
  Split, RefreshCw, Eye, MoveRight, HelpCircle, ShieldAlert, BrainCircuit, Beaker
} from 'lucide-react';

interface FoundryProps {
  user: User;
}

interface SavedPrompt {
  id: string;
  text: string;
  category: string;
  timestamp: Date;
}

// --- Task / Directive Interfaces ---
type Priority = 'CRITICAL' | 'STANDARD' | 'ROUTINE';
type DirectiveStatus = 'PENDING' | 'EXECUTED';

interface Directive {
  id: string;
  title: string;
  priority: Priority;
  dueDate: string; // YYYY-MM-DD
  tags: string[];
  status: DirectiveStatus;
  createdAt: number;
}

type SortOption = 'CREATED' | 'DUE_DATE' | 'PRIORITY';
type FilterOption = 'ALL' | 'PENDING' | 'EXECUTED';

// --- Safety Interfaces ---
type SafetyLevel = 'BLOCK_NONE' | 'BLOCK_ONLY_HIGH' | 'BLOCK_MEDIUM_AND_ABOVE' | 'BLOCK_LOW_AND_ABOVE';

interface SafetyCategory {
  id: string;
  label: string;
  level: SafetyLevel;
}

export const Foundry: React.FC<FoundryProps> = ({ user }) => {
  // Navigation State
  const [activeMode, setActiveMode] = useState<'CONSTRUCT' | 'OPERATIONS'>('OPERATIONS');

  // --- Holding Environment & Scaffolding ---
  const { complexityLevel, inSafeMode, supportLevel } = user.developmentProfile.holdingEnvironment || { complexityLevel: 'MEDIUM', inSafeMode: false, supportLevel: 'MEDIUM' };
  const showAdvancedFeatures = complexityLevel === 'HIGH' || complexityLevel === 'MEDIUM';
  const showSupportPillars = supportLevel === 'HIGH';

  // --- Construct State ---
  const [prompt, setPrompt] = useState('');
  const [systemInstruction, setSystemInstruction] = useState('You are a helpful AI assistant built within the Truth Forge.');
  const [temperature, setTemperature] = useState(0.7);
  const [model, setModel] = useState('Gemini 1.5 Pro');
  const [constructOutput, setConstructOutput] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [showCodeModal, setShowCodeModal] = useState(false);
  const [showStructurePanel, setShowStructurePanel] = useState(false);
  const [showPromptLibrary, setShowPromptLibrary] = useState(false);
  const [copied, setCopied] = useState(false);
  const [savedPrompts, setSavedPrompts] = useState<SavedPrompt[]>([
    { id: '1', text: 'Analyze this text for logical fallacies.', category: 'Analytical', timestamp: new Date() }
  ]);
  const [promptCategory, setPromptCategory] = useState('General');
  const [promptSearch, setPromptSearch] = useState('');
  
  // Perspective Tool State
  const [showPerspectiveTool, setShowPerspectiveTool] = useState(false);
  const [perspectiveInput, setPerspectiveInput] = useState('');
  const [perspectiveStep, setPerspectiveStep] = useState(0); // 0: input, 1: reflection

  // Immunity Map (Simplified for Foundry Context)
  // Note: Full feature is available in main nav. This is a quick-access version or placeholder.
  
  const [safetySettings, setSafetySettings] = useState<SafetyCategory[]>([
    { id: 'harassment', label: 'Harassment', level: 'BLOCK_MEDIUM_AND_ABOVE' },
    { id: 'hate_speech', label: 'Hate Speech', level: 'BLOCK_MEDIUM_AND_ABOVE' },
    { id: 'sexually_explicit', label: 'Sexually Explicit', level: 'BLOCK_MEDIUM_AND_ABOVE' },
    { id: 'dangerous_content', label: 'Dangerous Content', level: 'BLOCK_MEDIUM_AND_ABOVE' },
  ]);
  const [expandedSafety, setExpandedSafety] = useState<string | null>(null);

  // --- Operations (Task) State ---
  const [directives, setDirectives] = useState<Directive[]>([
      { id: 'd1', title: 'Calibrate Semantic Weights', priority: 'CRITICAL', dueDate: '2023-11-15', tags: ['System', 'Maintenance'], status: 'PENDING', createdAt: Date.now() },
      { id: 'd2', title: 'Review User Patterns', priority: 'STANDARD', dueDate: '', tags: ['Analysis'], status: 'EXECUTED', createdAt: Date.now() - 100000 },
  ]);
  
  // New Task Form
  const [newTitle, setNewTitle] = useState('');
  const [newPriority, setNewPriority] = useState<Priority>('STANDARD');
  const [newDueDate, setNewDueDate] = useState('');
  const [newTags, setNewTags] = useState(''); // Comma separated

  // Task Filters/Sorts
  const [taskSort, setTaskSort] = useState<SortOption>('CREATED');
  const [taskFilterStatus, setTaskFilterStatus] = useState<FilterOption>('ALL');
  const [taskFilterPriority, setTaskFilterPriority] = useState<Priority | 'ALL'>('ALL');
  const [taskFilterTag, setTaskFilterTag] = useState('');

  const isFrozen = user.tier === SubscriptionTier.STAGE_3_FROZEN;
  const isStructural = user.tier === SubscriptionTier.STAGE_5_STRUCTURAL;
  const keganStage = user.developmentProfile?.stage || KeganStage.STAGE_3_SOCIALIZED;

  // --- Construct Handlers ---

  const handleRun = () => {
    if (!prompt.trim()) return;
    setIsGenerating(true);
    setTimeout(() => {
        const response = `>> SYSTEM IDENTITY: ENSHRINED
>> INSTRUCTION SET: "${systemInstruction}"

>> PURPOSE VECTOR: IDENTIFIED
>> INPUT: "${prompt}"

>> CONSTRUCT SYNTHESIS:
I have assimilated the Identity Parameters. My core programming is now aligned with your defined System Instructions. 
Understanding complete.

As a construct born of the Truth Forge, I perceive your intent. You require specific execution based on the purpose defined above. 
I am ready to proceed. The logic is sound, and the identity is absolute.`;
        setConstructOutput(response);
        setIsGenerating(false);
    }, 1500);
  };

  const handleSavePrompt = () => {
    if (!prompt.trim()) return;
    const newPrompt: SavedPrompt = {
      id: Math.random().toString(36).substr(2, 9),
      text: prompt,
      category: promptCategory || 'General',
      timestamp: new Date()
    };
    setSavedPrompts([...savedPrompts, newPrompt]);
    setShowPromptLibrary(true);
  };

  const handleCopyCode = () => {
    const code = JSON.stringify({
      model,
      temperature,
      systemInstruction,
      safetySettings: safetySettings.reduce((acc, curr) => ({ ...acc, [curr.id]: curr.level }), {})
    }, null, 2);
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const updateSafety = (id: string, level: SafetyLevel) => {
    setSafetySettings(prev => prev.map(s => s.id === id ? { ...s, level } : s));
  };

  // --- Perspective Shift Logic ---
  const handlePerspectiveAnalysis = () => {
      if (!perspectiveInput.trim()) return;
      setIsGenerating(true);
      
      // Simulate analysis delay
      setTimeout(() => {
          setIsGenerating(false);
          setPerspectiveStep(1); // Move to reflection phase
      }, 1500);
  };

  const handleCommitShift = () => {
      // Logic to actually update user profile would go here in a real app
      // For now, we simulate the "Objectification Event" visually
      setIsGenerating(true);
      setTimeout(() => {
          setIsGenerating(false);
          setShowPerspectiveTool(false);
          setPerspectiveStep(0);
          setPerspectiveInput('');
          setConstructOutput(prev => prev + "\n\n>> META-ANALYSIS: Subject-Object Shift detected. Concept moved from Identity (Subject) to Tool (Object). Stability increased.");
      }, 1000);
  };

  // --- Operations Handlers ---

  const handleAddDirective = () => {
      if (!newTitle.trim()) return;
      const directive: Directive = {
          id: Math.random().toString(36).substr(2, 9),
          title: newTitle,
          priority: newPriority,
          dueDate: newDueDate,
          tags: newTags.split(',').map(t => t.trim()).filter(t => t),
          status: 'PENDING',
          createdAt: Date.now()
      };
      setDirectives([directive, ...directives]);
      setNewTitle('');
      setNewTags('');
      setNewDueDate('');
      setNewPriority('STANDARD');
  };

  const toggleDirectiveStatus = (id: string) => {
      setDirectives(prev => prev.map(d => 
          d.id === id ? { ...d, status: d.status === 'PENDING' ? 'EXECUTED' : 'PENDING' } : d
      ));
  };

  const deleteDirective = (id: string) => {
      setDirectives(prev => prev.filter(d => d.id !== id));
  };

  const sortedAndFilteredDirectives = useMemo(() => {
      let filtered = directives.filter(d => {
          if (taskFilterStatus !== 'ALL' && d.status !== taskFilterStatus) return false;
          if (taskFilterPriority !== 'ALL' && d.priority !== taskFilterPriority) return false;
          if (taskFilterTag && !d.tags.some(t => t.toLowerCase().includes(taskFilterTag.toLowerCase()))) return false;
          return true;
      });

      // SCAFFOLDING: In Safe Mode, remove CRITICAL items to reduce anxiety/stakes
      if (inSafeMode) {
          filtered = filtered.filter(d => d.priority !== 'CRITICAL');
      }

      return filtered.sort((a, b) => {
          if (taskSort === 'CREATED') return b.createdAt - a.createdAt;
          if (taskSort === 'DUE_DATE') {
              if (!a.dueDate) return 1;
              if (!b.dueDate) return -1;
              return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
          }
          if (taskSort === 'PRIORITY') {
              const weight = { 'CRITICAL': 3, 'STANDARD': 2, 'ROUTINE': 1 };
              return weight[b.priority] - weight[a.priority];
          }
          return 0;
      });
  }, [directives, taskSort, taskFilterStatus, taskFilterPriority, taskFilterTag, inSafeMode]);

  const filteredSavedPrompts = useMemo(() => {
      if (!promptSearch) return savedPrompts;
      const q = promptSearch.toLowerCase();
      return savedPrompts.filter(p => 
          p.text.toLowerCase().includes(q) || 
          p.category.toLowerCase().includes(q)
      );
  }, [savedPrompts, promptSearch]);

  const safetyDescriptions: Record<SafetyLevel, string> = {
    'BLOCK_NONE': 'Always show regardless of probability of unsafe content.',
    'BLOCK_ONLY_HIGH': 'Block when there is a high probability of unsafe content.',
    'BLOCK_MEDIUM_AND_ABOVE': 'Block when there is a medium or high probability of unsafe content.',
    'BLOCK_LOW_AND_ABOVE': 'Block when there is a low, medium, or high probability of unsafe content.'
  };

  // --- Render Helpers ---

  const PerspectiveToolModal = () => (
      <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/90 backdrop-blur-md p-4 animate-in fade-in duration-300">
          <div className="w-full max-w-3xl bg-[#0D0D0D] border border-[#F59E0B] rounded-sm shadow-[0_0_50px_rgba(245,158,11,0.1)] flex flex-col h-[600px] relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#F59E0B] to-transparent"></div>
              
              <div className="p-6 border-b border-[#2D2D2D] flex justify-between items-center">
                  <div className="flex items-center space-x-3">
                      <Split size={20} className="text-[#F59E0B]" />
                      <div>
                          <h3 className="text-lg font-serif text-[#F5F0E6] uppercase tracking-wide">Dialectical Inversion</h3>
                          <p className="text-xs font-mono text-[#888888]">Shift framework: Subject &rarr; Object</p>
                      </div>
                  </div>
                  <button onClick={() => { setShowPerspectiveTool(false); setPerspectiveStep(0); }} className="text-[#888888] hover:text-[#F5F0E6]"><X size={20}/></button>
              </div>

              <div className="flex-1 p-8 flex flex-col items-center justify-center">
                  {perspectiveStep === 0 ? (
                      <div className="w-full max-w-xl space-y-6 animate-in slide-in-from-bottom-4">
                           <div className="text-center">
                               <p className="text-sm font-mono text-[#F5F0E6] mb-2 uppercase tracking-widest">Identify the Assumption</p>
                               <p className="text-xs text-[#888888]">What belief or directive currently feels like "Truth" rather than a "Tool"?</p>
                           </div>
                           <textarea 
                                value={perspectiveInput}
                                onChange={(e) => setPerspectiveInput(e.target.value)}
                                className="w-full h-32 bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-4 text-[#F5F0E6] font-mono text-sm focus:border-[#F59E0B] focus:outline-none resize-none"
                                placeholder="e.g., 'The system must always be efficient' or 'My identity depends on this metric'..."
                           />
                           <Button fullWidth onClick={handlePerspectiveAnalysis} isLoading={isGenerating} icon={<Eye size={16}/>}>
                               Examine as Object
                           </Button>
                      </div>
                  ) : (
                      <div className="w-full h-full flex flex-col animate-in slide-in-from-right-4">
                          <div className="grid grid-cols-2 gap-8 h-full">
                              {/* Left: The Subject (Old View) */}
                              <div className="border border-[#2D2D2D] bg-[#1A1A1A] p-6 rounded-sm relative overflow-hidden opacity-50">
                                  <div className="absolute top-2 left-2 text-[10px] font-mono text-[#888888] uppercase">Current Subject (You are this)</div>
                                  <div className="h-full flex items-center justify-center text-center p-4">
                                      <p className="text-[#F5F0E6] font-serif text-lg italic">"{perspectiveInput}"</p>
                                  </div>
                              </div>

                              {/* Right: The Object (New View) */}
                              <div className="border border-[#F59E0B] bg-[#1A1A1A] p-6 rounded-sm relative overflow-hidden shadow-[0_0_20px_rgba(245,158,11,0.05)]">
                                  <div className="absolute top-2 left-2 text-[10px] font-mono text-[#F59E0B] uppercase">Target Object (You hold this)</div>
                                  
                                  <div className="h-full flex flex-col items-center justify-center space-y-6">
                                      <div className="text-center">
                                          <p className="text-xs font-mono text-[#888888] mb-2">Reflective Prompt:</p>
                                          <p className="text-[#F5F0E6] text-sm font-medium">
                                              {keganStage === KeganStage.STAGE_3_SOCIALIZED && "Who defines this truth? Is it you, or an external expectation?"}
                                              {keganStage === KeganStage.STAGE_4_SELF_AUTHORING && "Does this rule serve your authorship, or limit it? Can you rewrite it?"}
                                              {keganStage === KeganStage.STAGE_5_SELF_TRANSFORMING && "How is the opposite of this statement also true?"}
                                          </p>
                                      </div>
                                      <Button variant="primary" onClick={handleCommitShift} isLoading={isGenerating} icon={<MoveRight size={16}/>}>
                                          Objectify & Release
                                      </Button>
                                  </div>
                              </div>
                          </div>
                      </div>
                  )}
              </div>
          </div>
      </div>
  );

  const CodeModal = () => (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in">
      <div className="w-full max-w-2xl bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm shadow-2xl flex flex-col max-h-[80vh]">
        <div className="p-4 border-b border-[#2D2D2D] flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Code size={16} className="text-[#F5F0E6]" />
            <h3 className="text-sm font-mono text-[#F5F0E6] uppercase">Construct Configuration</h3>
          </div>
          <button onClick={() => setShowCodeModal(false)} className="text-[#888888] hover:text-[#F5F0E6]"><X size={16}/></button>
        </div>
        <div className="flex-1 overflow-auto p-4 bg-[#0D0D0D]">
          <pre className="font-mono text-xs text-[#F5F0E6] whitespace-pre-wrap">
            {JSON.stringify({
              model,
              temperature,
              systemInstruction,
              safetySettings: safetySettings.reduce((acc, curr) => ({ ...acc, [curr.id]: curr.level }), {})
            }, null, 2)}
          </pre>
        </div>
        <div className="p-4 border-t border-[#2D2D2D] flex justify-end">
          <Button size="sm" onClick={handleCopyCode} icon={copied ? <Check size={14}/> : <Copy size={14}/>}>
            {copied ? 'Copied' : 'Copy to Clipboard'}
          </Button>
        </div>
      </div>
    </div>
  );

  const StructurePanel = () => (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in">
      <div className="w-full max-w-4xl bg-[#1A1A1A] border border-[#F59E0B]/50 rounded-sm shadow-2xl flex flex-col max-h-[90vh]">
        <div className="p-6 border-b border-[#2D2D2D] flex items-center justify-between">
          <div>
             <h3 className="text-xl font-serif text-[#F59E0B] uppercase tracking-wide flex items-center">
               <Wand2 size={20} className="mr-3" />
               Architectural Override
             </h3>
             <p className="text-xs font-mono text-[#888888] mt-1">Deep system parameter tuning. Structural integrity risk: Moderate.</p>
          </div>
          <button onClick={() => setShowStructurePanel(false)} className="text-[#888888] hover:text-[#F5F0E6]"><X size={20}/></button>
        </div>
        <div className="flex-1 overflow-y-auto p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
                <div className="bg-[#0D0D0D] p-4 border border-[#2D2D2D] rounded-sm">
                    <label className="text-xs font-mono text-[#F5F0E6] uppercase tracking-wide mb-4 block">Reasoning Topology</label>
                    <div className="space-y-4">
                        <div className="flex items-center justify-between">
                            <span className="text-xs text-[#888888]">Chain of Thought Density</span>
                            <input type="range" className="w-32 accent-[#F59E0B]" />
                        </div>
                        <div className="flex items-center justify-between">
                            <span className="text-xs text-[#888888]">Branching Factor</span>
                            <input type="range" className="w-32 accent-[#F59E0B]" />
                        </div>
                    </div>
                </div>
                <div className="bg-[#0D0D0D] p-4 border border-[#2D2D2D] rounded-sm">
                    <label className="text-xs font-mono text-[#F5F0E6] uppercase tracking-wide mb-4 block">Memory Architecture</label>
                    <div className="flex items-center space-x-4">
                        <div className="h-16 flex-1 bg-[#1A1A1A] border border-[#F59E0B] flex items-center justify-center text-[#F59E0B] text-xs font-mono">Vector DB</div>
                        <div className="h-16 flex-1 bg-[#1A1A1A] border border-[#2D2D2D] flex items-center justify-center text-[#888888] text-xs font-mono">Graph (Alpha)</div>
                    </div>
                </div>
            </div>
            <div className="space-y-6">
                 <div className="h-full bg-[#0D0D0D] border border-[#2D2D2D] p-4 flex items-center justify-center">
                     <div className="text-center">
                         <Cpu size={48} className="text-[#F59E0B] mx-auto mb-4 animate-pulse" />
                         <p className="text-xs font-mono text-[#888888]">Cognitive Matrix Simulation Active</p>
                     </div>
                 </div>
            </div>
        </div>
        <div className="p-6 border-t border-[#2D2D2D] bg-[#151515] flex justify-end space-x-4">
            <Button variant="secondary" onClick={() => setShowStructurePanel(false)}>Cancel</Button>
            <Button variant="primary" icon={<Check size={14}/>}>Apply Structure</Button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex h-full bg-[#0D0D0D] overflow-hidden relative">
      {showCodeModal && <CodeModal />}
      {showStructurePanel && <StructurePanel />}
      {showPerspectiveTool && <PerspectiveToolModal />}

      {/* LEFT SIDEBAR: File/History */}
      <div className="w-64 bg-[#151515] border-r border-[#2D2D2D] flex flex-col flex-shrink-0">
         <div className="p-4 border-b border-[#2D2D2D] flex items-center justify-between">
             <span className="font-mono text-xs text-[#888888] uppercase tracking-widest">Workbench</span>
             <button className="text-[#888888] hover:text-[#F5F0E6]"><Plus size={16} /></button>
         </div>
         <div className="flex-1 overflow-y-auto p-2 space-y-1">
             {/* Navigation Items */}
             <button 
                onClick={() => setActiveMode('OPERATIONS')}
                className={`w-full px-3 py-2 rounded-sm text-left flex items-center justify-between group transition-colors ${activeMode === 'OPERATIONS' ? 'bg-[#2D2D2D]' : 'hover:bg-[#1A1A1A]'}`}
             >
                <div className="flex items-center space-x-2">
                    <ListTodo size={14} className={activeMode === 'OPERATIONS' ? 'text-[#F5F0E6]' : 'text-[#888888]'} />
                    <span className={`text-xs font-mono ${activeMode === 'OPERATIONS' ? 'text-[#F5F0E6]' : 'text-[#888888]'}`}>Operations</span>
                </div>
                {activeMode === 'OPERATIONS' && <div className="w-1.5 h-1.5 rounded-full bg-[#F59E0B]"></div>}
             </button>

             <button 
                onClick={() => setActiveMode('CONSTRUCT')}
                className={`w-full px-3 py-2 rounded-sm text-left flex items-center justify-between group transition-colors ${activeMode === 'CONSTRUCT' ? 'bg-[#2D2D2D]' : 'hover:bg-[#1A1A1A]'}`}
             >
                <div className="flex items-center space-x-2">
                    <Cpu size={14} className={activeMode === 'CONSTRUCT' ? 'text-[#F5F0E6]' : 'text-[#888888]'} />
                    <span className={`text-xs font-mono ${activeMode === 'CONSTRUCT' ? 'text-[#F5F0E6]' : 'text-[#888888]'}`}>Constructs</span>
                </div>
                {activeMode === 'CONSTRUCT' && <div className="w-1.5 h-1.5 rounded-full bg-[#F59E0B]"></div>}
             </button>

             {/* Constructs History (Only show if in Construct mode) */}
             {activeMode === 'CONSTRUCT' && (
                <div className="mt-4 pt-4 border-t border-[#2D2D2D]">
                    <div className="px-2 mb-2 text-[10px] font-mono text-[#4A4A4A] uppercase">Recent Shells</div>
                    <div className="px-3 py-2 bg-[#1A1A1A] rounded-sm cursor-pointer group border border-[#2D2D2D]">
                         <div className="flex items-center justify-between">
                             <span className="text-xs font-mono text-[#F5F0E6] truncate">Untitled Construct</span>
                             <MoreHorizontal size={14} className="text-[#888888] opacity-0 group-hover:opacity-100" />
                         </div>
                         <div className="text-[10px] text-[#888888] mt-1">Edited 2m ago</div>
                     </div>
                </div>
             )}
             
             {/* External Data Sources Section */}
             <div className="mt-4 pt-4 border-t border-[#2D2D2D]">
                <div className="px-2 mb-2 flex items-center justify-between">
                    <span className="text-[10px] font-mono text-[#4A4A4A] uppercase">Data Connections</span>
                    <Database size={12} className="text-[#4A4A4A]" />
                </div>
                {isFrozen ? (
                    <div className="mx-2 p-3 bg-[#1A1A1A]/30 border border-[#2D2D2D] border-dashed rounded-sm flex flex-col items-center text-center">
                        <Lock size={14} className="text-[#4A4A4A] mb-2" />
                        <span className="text-[10px] font-mono text-[#888888] uppercase">Connectors Locked</span>
                        <div className="text-[9px] text-[#4A4A4A] mt-1">Stage 4 Required</div>
                    </div>
                ) : (
                    <div className="mx-2 space-y-2">
                        <button className="w-full p-2 border border-dashed border-[#2D2D2D] rounded-sm flex items-center justify-center space-x-2 hover:border-[#F5F0E6] hover:bg-[#1A1A1A] transition-all group">
                            <Plus size={12} className="text-[#888888] group-hover:text-[#F5F0E6]" />
                            <span className="text-[10px] font-mono text-[#888888] group-hover:text-[#F5F0E6] uppercase">Add Source</span>
                        </button>
                    </div>
                )}
             </div>
         </div>
      </div>

      {/* CENTER: Main Editor / Operations Board */}
      <div className="flex-1 flex flex-col min-w-0 bg-[#0D0D0D]">
          
          {/* Header */}
          <div className="h-14 border-b border-[#2D2D2D] flex items-center justify-between px-6 bg-[#0D0D0D]">
              <div className="flex items-center space-x-4">
                  <div className="font-serif text-[#F5F0E6] text-lg tracking-wide">
                      {activeMode === 'CONSTRUCT' ? 'Construct Builder' : 'Directives Protocol'}
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-mono border ${inSafeMode ? 'bg-[#10B981]/20 text-[#10B981] border-[#10B981]/50' : 'bg-[#1A1A1A] text-[#888888] border-[#2D2D2D]'}`}>
                      {inSafeMode ? 'SAFE SPACE ACTIVE' : activeMode === 'CONSTRUCT' ? 'DRAFT' : 'ACTIVE'}
                  </span>
              </div>
              
              {activeMode === 'CONSTRUCT' && (
                  <div className="flex items-center space-x-3">
                      {/* Perspective Tool Toggle */}
                      {showAdvancedFeatures && (
                        <Button size="sm" variant="secondary" icon={<Split size={14}/>} onClick={() => setShowPerspectiveTool(true)}>
                            Invert
                        </Button>
                      )}

                      {isStructural ? (
                          <Button size="sm" variant="secondary" icon={<Wand2 size={14} />} onClick={() => setShowStructurePanel(true)}>
                              Structure
                          </Button>
                      ) : (
                           <button className="flex items-center space-x-1 text-[#4A4A4A] cursor-not-allowed text-xs font-mono uppercase">
                               <Lock size={12}/> <span>Structure</span>
                           </button>
                      )}
                      
                      {/* SCAFFOLDING: Code view hidden in Low Complexity unless specifically requested */}
                      {complexityLevel !== 'LOW' && (
                        <Button size="sm" variant="secondary" icon={<Code size={14} />} onClick={() => setShowCodeModal(true)}>
                            Get Code
                        </Button>
                      )}
                      
                      <Button size="sm" variant="primary" icon={<Save size={14} />}>Save</Button>
                  </div>
              )}
          </div>

          {/* MAIN CONTENT AREA */}
          <div className="flex-1 flex flex-col overflow-hidden relative">
              
              {/* === MODE: OPERATIONS (TASK MANAGER) === */}
              {activeMode === 'OPERATIONS' && (
                  <div className="flex-1 flex flex-col p-6 overflow-hidden">
                      
                      {/* SCAFFOLDING: Support Pillar for Operations */}
                      {showSupportPillars && (
                          <div className="mb-4 p-4 bg-[#1A1A1A] border-l-4 border-[#10B981] rounded-r-sm flex items-start space-x-3 animate-in slide-in-from-top-2">
                              <HelpCircle size={18} className="text-[#10B981] mt-0.5" />
                              <div>
                                  <h4 className="text-xs font-mono text-[#10B981] uppercase font-bold mb-1">Support Pillar: Directive Management</h4>
                                  <p className="text-xs text-[#888888] leading-relaxed">
                                      Start by breaking down large goals into small, standard priority tasks. 
                                      In Safe Mode, critical deadlines are hidden to reduce pressure. Focus on one task at a time.
                                  </p>
                              </div>
                          </div>
                      )}

                      {/* Controls Bar */}
                      <div className="flex flex-wrap gap-4 mb-6 pb-4 border-b border-[#2D2D2D]">
                          {/* Sort */}
                          <div className="flex items-center space-x-2">
                              <ArrowUpDown size={14} className="text-[#888888]" />
                              <select 
                                value={taskSort}
                                onChange={(e) => setTaskSort(e.target.value as SortOption)}
                                className="bg-[#1A1A1A] border border-[#2D2D2D] text-[#F5F0E6] text-xs font-mono p-1.5 rounded-sm focus:outline-none"
                              >
                                  <option value="CREATED">Created</option>
                                  <option value="DUE_DATE">Due Date</option>
                                  <option value="PRIORITY">Priority</option>
                              </select>
                          </div>

                          {/* Filter Priority */}
                          <div className="flex items-center space-x-2">
                              <Filter size={14} className="text-[#888888]" />
                              <select 
                                value={taskFilterPriority}
                                onChange={(e) => setTaskFilterPriority(e.target.value as Priority | 'ALL')}
                                className="bg-[#1A1A1A] border border-[#2D2D2D] text-[#F5F0E6] text-xs font-mono p-1.5 rounded-sm focus:outline-none"
                              >
                                  <option value="ALL">All Priorities</option>
                                  {!inSafeMode && <option value="CRITICAL">Critical</option>}
                                  <option value="STANDARD">Standard</option>
                                  <option value="ROUTINE">Routine</option>
                              </select>
                          </div>

                          {/* Filter Tag */}
                          <div className="flex items-center space-x-2">
                              <Tag size={14} className="text-[#888888]" />
                              <input 
                                type="text" 
                                placeholder="Filter by tag..." 
                                value={taskFilterTag}
                                onChange={(e) => setTaskFilterTag(e.target.value)}
                                className="bg-[#1A1A1A] border border-[#2D2D2D] text-[#F5F0E6] text-xs font-mono p-1.5 rounded-sm focus:outline-none placeholder-[#4A4A4A] w-32"
                              />
                          </div>

                          {/* Filter Status */}
                          <div className="flex bg-[#1A1A1A] rounded-sm border border-[#2D2D2D] p-0.5 ml-auto">
                              <button onClick={() => setTaskFilterStatus('ALL')} className={`px-3 py-1 text-[10px] font-mono uppercase ${taskFilterStatus === 'ALL' ? 'bg-[#2D2D2D] text-[#F5F0E6]' : 'text-[#888888]'}`}>All</button>
                              <button onClick={() => setTaskFilterStatus('PENDING')} className={`px-3 py-1 text-[10px] font-mono uppercase ${taskFilterStatus === 'PENDING' ? 'bg-[#2D2D2D] text-[#F5F0E6]' : 'text-[#888888]'}`}>Pending</button>
                              <button onClick={() => setTaskFilterStatus('EXECUTED')} className={`px-3 py-1 text-[10px] font-mono uppercase ${taskFilterStatus === 'EXECUTED' ? 'bg-[#2D2D2D] text-[#F5F0E6]' : 'text-[#888888]'}`}>Executed</button>
                          </div>
                      </div>

                      {/* Add Directive Input */}
                      <div className="mb-6 bg-[#1A1A1A] border border-[#2D2D2D] p-4 rounded-sm">
                          <div className="flex items-center space-x-3 mb-3">
                              <input 
                                type="text" 
                                placeholder="Initialize New Directive..." 
                                value={newTitle}
                                onChange={(e) => setNewTitle(e.target.value)}
                                className="flex-1 bg-transparent border-none text-[#F5F0E6] placeholder-[#4A4A4A] focus:outline-none font-mono text-sm"
                                onKeyDown={(e) => e.key === 'Enter' && handleAddDirective()}
                              />
                              <Button size="sm" onClick={handleAddDirective} disabled={!newTitle}>Initialize</Button>
                          </div>
                          <div className="flex items-center space-x-4">
                              <select 
                                value={newPriority}
                                onChange={(e) => setNewPriority(e.target.value as Priority)}
                                className="bg-[#0D0D0D] border border-[#2D2D2D] text-[#888888] text-[10px] font-mono p-1 rounded-sm focus:outline-none focus:text-[#F5F0E6]"
                              >
                                  {!inSafeMode && <option value="CRITICAL">Critical</option>}
                                  <option value="STANDARD">Standard</option>
                                  <option value="ROUTINE">Routine</option>
                              </select>
                              <div className="h-3 w-[1px] bg-[#2D2D2D]"></div>
                              <div className="flex items-center space-x-1">
                                  <Calendar size={12} className="text-[#4A4A4A]" />
                                  <input 
                                    type="date" 
                                    value={newDueDate}
                                    onChange={(e) => setNewDueDate(e.target.value)}
                                    className="bg-transparent text-[#888888] text-[10px] font-mono focus:outline-none focus:text-[#F5F0E6]"
                                  />
                              </div>
                              <div className="h-3 w-[1px] bg-[#2D2D2D]"></div>
                              <div className="flex items-center space-x-1 flex-1">
                                  <Tag size={12} className="text-[#4A4A4A]" />
                                  <input 
                                    type="text" 
                                    placeholder="Context tags (comma separated)"
                                    value={newTags}
                                    onChange={(e) => setNewTags(e.target.value)}
                                    className="bg-transparent w-full text-[#888888] text-[10px] font-mono focus:outline-none focus:text-[#F5F0E6]"
                                  />
                              </div>
                          </div>
                      </div>

                      {/* Directives List */}
                      <div className="flex-1 overflow-y-auto custom-scrollbar space-y-2">
                          {sortedAndFilteredDirectives.length === 0 && (
                              <div className="text-center py-12 opacity-50">
                                  <div className="text-sm font-mono text-[#4A4A4A] uppercase tracking-wider">No Directives Found</div>
                              </div>
                          )}
                          {sortedAndFilteredDirectives.map(directive => (
                              <div key={directive.id} className={`group flex items-center p-3 border rounded-sm transition-all duration-200 ${directive.status === 'EXECUTED' ? 'bg-[#151515] border-[#2D2D2D] opacity-60' : 'bg-[#1A1A1A] border-[#2D2D2D] hover:border-[#4A4A4A]'}`}>
                                  {/* Checkbox */}
                                  <button onClick={() => toggleDirectiveStatus(directive.id)} className="mr-4 text-[#888888] hover:text-[#F5F0E6] transition-colors">
                                      {directive.status === 'EXECUTED' ? <CheckSquare size={18} /> : <Square size={18} />}
                                  </button>

                                  {/* Content */}
                                  <div className="flex-1 min-w-0">
                                      <div className={`text-sm font-mono mb-1 truncate ${directive.status === 'EXECUTED' ? 'text-[#888888] line-through decoration-[#4A4A4A]' : 'text-[#F5F0E6]'}`}>
                                          {directive.title}
                                      </div>
                                      <div className="flex items-center space-x-3">
                                          {/* Priority Badge */}
                                          <span className={`text-[9px] font-mono uppercase px-1.5 py-0.5 rounded-sm border ${
                                              directive.priority === 'CRITICAL' ? 'border-red-900 text-red-400 bg-red-900/10' :
                                              directive.priority === 'STANDARD' ? 'border-[#F59E0B]/30 text-[#F59E0B] bg-[#F59E0B]/10' :
                                              'border-[#4A4A4A] text-[#888888] bg-[#2D2D2D]'
                                          }`}>
                                              {directive.priority}
                                          </span>

                                          {/* Due Date */}
                                          {directive.dueDate && (
                                              <span className={`flex items-center text-[9px] font-mono ${new Date(directive.dueDate) < new Date() && directive.status !== 'EXECUTED' ? 'text-red-400' : 'text-[#888888]'}`}>
                                                  <Clock size={10} className="mr-1" />
                                                  {directive.dueDate}
                                              </span>
                                          )}

                                          {/* Tags */}
                                          {directive.tags.length > 0 && (
                                              <div className="flex space-x-1">
                                                  {directive.tags.map((tag, i) => (
                                                      <span key={i} className="text-[9px] font-mono text-[#4A4A4A] bg-[#0D0D0D] px-1 rounded border border-[#2D2D2D]">
                                                          #{tag}
                                                      </span>
                                                  ))}
                                              </div>
                                          )}
                                      </div>
                                  </div>

                                  {/* Actions */}
                                  <button onClick={() => deleteDirective(directive.id)} className="ml-3 opacity-0 group-hover:opacity-100 text-[#4A4A4A] hover:text-red-400 transition-all">
                                      <Trash2 size={14} />
                                  </button>
                              </div>
                          ))}
                      </div>
                  </div>
              )}

              {/* === MODE: CONSTRUCT (ORIGINAL AI BUILDER) === */}
              {activeMode === 'CONSTRUCT' && (
                <div className="flex-1 flex flex-col overflow-hidden">
                    <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
                        
                        {/* SCAFFOLDING: Support Pillar for Construct */}
                        {showSupportPillars && (
                          <div className="mb-4 p-4 bg-[#1A1A1A] border-l-4 border-[#10B981] rounded-r-sm flex items-start space-x-3 animate-in slide-in-from-top-2">
                              <HelpCircle size={18} className="text-[#10B981] mt-0.5" />
                              <div>
                                  <h4 className="text-xs font-mono text-[#10B981] uppercase font-bold mb-1">Support Pillar: Defining Identity</h4>
                                  <p className="text-xs text-[#888888] leading-relaxed">
                                      You are defining the core rules for an AI entity. 
                                      Simply describe "who" it is in the box below. You don't need technical code yet.
                                  </p>
                              </div>
                          </div>
                        )}

                        {/* System Instructions Block */}
                        <div className={`space-y-2 relative ${isFrozen ? 'opacity-75' : ''}`}>
                            <div className="flex items-center justify-between">
                                <label className="text-xs font-mono text-[#888888] uppercase tracking-wider">System Instructions (Identity)</label>
                                {isFrozen && <span className="text-[10px] font-mono text-[#F5F0E6] bg-[#2D2D2D] px-2 rounded">READ ONLY</span>}
                            </div>
                            <textarea
                                value={systemInstruction}
                                onChange={(e) => setSystemInstruction(e.target.value)}
                                disabled={isFrozen}
                                className="w-full h-24 bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-4 text-sm font-sans text-[#F5F0E6] focus:outline-none focus:border-[#4A4A4A] resize-none placeholder-[#4A4A4A] disabled:cursor-not-allowed"
                                placeholder="Define the behavior of your construct..."
                            />
                        </div>

                        {/* Prompt Interaction Block */}
                        <div className="space-y-2 flex-1 flex flex-col">
                            <div className="flex items-center justify-between">
                                    <label className="text-xs font-mono text-[#888888] uppercase tracking-wider">Prompt & Response</label>
                                    <div className="flex space-x-2">
                                        <button 
                                            onClick={() => setShowPromptLibrary(!showPromptLibrary)}
                                            className={`text-[10px] font-mono flex items-center space-x-1 ${showPromptLibrary ? 'text-[#F5F0E6]' : 'text-[#888888] hover:text-[#B5B5B5]'}`}
                                        >
                                            <BookMarked size={12} />
                                            <span>{showPromptLibrary ? 'Hide Library' : 'Library'}</span>
                                        </button>
                                    </div>
                            </div>
                            
                            <div className="flex-1 border border-[#2D2D2D] rounded-sm bg-[#151515] flex flex-col relative overflow-hidden">
                                
                                {/* Prompt Library Overlay */}
                                {showPromptLibrary && (
                                    <div className="absolute inset-0 z-20 bg-[#151515] flex flex-col animate-in slide-in-from-right duration-300">
                                        <div className="p-3 border-b border-[#2D2D2D] flex justify-between items-center bg-[#1A1A1A]">
                                            <span className="text-xs font-mono text-[#F5F0E6]">Saved Prompts</span>
                                            <div className="flex items-center space-x-2">
                                                <div className="relative">
                                                    <input 
                                                        type="text" 
                                                        value={promptSearch} 
                                                        onChange={(e) => setPromptSearch(e.target.value)}
                                                        className="bg-[#0D0D0D] border border-[#2D2D2D] rounded-sm py-1 px-6 text-[10px] text-[#F5F0E6] focus:outline-none focus:border-[#4A4A4A] w-32" 
                                                        placeholder="Search..."
                                                    />
                                                    <Search size={10} className="absolute left-1.5 top-1.5 text-[#4A4A4A]" />
                                                </div>
                                                <button onClick={() => setShowPromptLibrary(false)}><X size={14} className="text-[#888888]"/></button>
                                            </div>
                                        </div>
                                        <div className="flex-1 overflow-y-auto p-2 space-y-2">
                                            {filteredSavedPrompts.length === 0 && <div className="text-center text-[10px] text-[#4A4A4A] mt-4">No matching prompts</div>}
                                            {filteredSavedPrompts.map(p => (
                                                <div key={p.id} className="p-3 border border-[#2D2D2D] bg-[#0D0D0D] rounded-sm hover:border-[#4A4A4A] group">
                                                    <div className="flex justify-between items-start mb-2">
                                                        <span className="text-[10px] font-mono text-[#888888] bg-[#1A1A1A] px-1.5 rounded">{p.category}</span>
                                                        <div className="flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                                                <button onClick={() => { setPrompt(p.text); setShowPromptLibrary(false); }} title="Load"><FolderOpen size={12} className="text-[#F5F0E6]"/></button>
                                                                <button onClick={() => setSavedPrompts(savedPrompts.filter(sp => sp.id !== p.id))} title="Delete"><Trash2 size={12} className="text-red-400"/></button>
                                                        </div>
                                                    </div>
                                                    <p className="text-xs text-[#F5F0E6] line-clamp-2 mb-2">{p.text}</p>
                                                    <div className="text-[9px] font-mono text-[#4A4A4A] text-right">{new Date(p.timestamp).toLocaleDateString()}</div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                )}

                                {/* Output Area (Mock) */}
                                <div className="flex-1 p-4 border-b border-[#2D2D2D] overflow-y-auto">
                                    <div className="flex space-x-3">
                                        <div className="w-6 h-6 rounded-full bg-[#F5F0E6] flex items-center justify-center flex-shrink-0">
                                            <img src="./truth_forge_logo.png" className="w-4 h-4" alt="logo" />
                                        </div>
                                        <div className="space-y-1 w-full">
                                            <div className="text-xs font-mono text-[#888888] uppercase">Construct Understanding</div>
                                            <div className="text-sm text-[#F5F0E6] leading-relaxed whitespace-pre-wrap font-mono">
                                                {isGenerating ? (
                                                    <div className="flex items-center space-x-2 text-[#F59E0B]">
                                                        <Loader2 size={14} className="animate-spin" />
                                                        <span>Synthesizing Identity Protocol...</span>
                                                    </div>
                                                ) : constructOutput ? (
                                                    constructOutput
                                                ) : (
                                                    isFrozen 
                                                        ? "Stage 3 Access: I can process standard queries, but my internal system parameters are locked. Upgrade to Tier 4 to modify my essence." 
                                                        : "The system is online. I am ready to assist with your architectural needs within the Truth Forge. Define Identity and Purpose to generate Construct."
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* Input Area */}
                                <div className="h-40 p-4 bg-[#1A1A1A] flex flex-col">
                                    <div className="flex-1 relative">
                                        <textarea 
                                                className="w-full h-full bg-transparent text-sm text-[#F5F0E6] focus:outline-none resize-none placeholder-[#4A4A4A]"
                                                placeholder="Define the purpose (Prompt)..."
                                                value={prompt}
                                                onChange={(e) => setPrompt(e.target.value)}
                                                onKeyDown={(e) => {
                                                    if (e.key === 'Enter' && !e.shiftKey) {
                                                        e.preventDefault();
                                                        handleRun();
                                                    }
                                                }}
                                        />
                                    </div>
                                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-[#2D2D2D]">
                                        <div className="flex items-center space-x-2">
                                            <span className="text-[10px] font-mono text-[#4A4A4A]">{prompt.length} chars</span>
                                            <div className="h-3 w-[1px] bg-[#2D2D2D]"></div>
                                            <input 
                                                type="text" 
                                                placeholder="Category" 
                                                value={promptCategory} 
                                                onChange={(e) => setPromptCategory(e.target.value)}
                                                className="bg-transparent text-[10px] font-mono text-[#888888] w-20 focus:outline-none focus:text-[#F5F0E6]" 
                                            />
                                            <button onClick={handleSavePrompt} disabled={!prompt} className="text-[#888888] hover:text-[#F5F0E6] disabled:opacity-30">
                                                <BookMarked size={14} />
                                            </button>
                                        </div>
                                        <Button size="sm" icon={<Play size={14} />} onClick={handleRun} isLoading={isGenerating}>Run</Button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
              )}
          </div>
      </div>

      {/* RIGHT SIDEBAR: Settings */}
      <div className={`w-80 bg-[#151515] border-l border-[#2D2D2D] flex flex-col flex-shrink-0 overflow-y-auto custom-scrollbar relative ${activeMode === 'OPERATIONS' ? 'hidden lg:flex' : 'flex'}`}>
          {activeMode === 'CONSTRUCT' ? (
              <>
                {isFrozen && (
                    <div className="absolute inset-0 bg-black/60 z-10 backdrop-blur-[1px] flex flex-col items-center justify-center text-center p-6">
                        <Lock size={32} className="text-[#888888] mb-4" />
                        <h4 className="text-[#F5F0E6] font-serif uppercase tracking-wide mb-2">Configuration Frozen</h4>
                        <p className="text-xs font-mono text-[#888888]">Advanced parameter tuning requires Stage 4 access.</p>
                    </div>
                )}

                <div className="p-4 border-b border-[#2D2D2D] flex items-center space-x-2">
                    <Settings size={14} className="text-[#888888]" />
                    <span className="font-mono text-xs text-[#888888] uppercase tracking-widest">Configuration</span>
                </div>

                <div className={`p-6 space-y-8 ${isFrozen ? 'blur-sm select-none' : ''}`}>
                    {/* Model Select */}
                    <div className="space-y-3">
                        <label className="text-xs font-mono text-[#F5F0E6] uppercase tracking-wide block">Model</label>
                        <select 
                            value={model}
                            onChange={(e) => setModel(e.target.value)}
                            className="w-full bg-[#1A1A1A] border border-[#2D2D2D] text-[#F5F0E6] text-xs font-mono p-2 rounded-sm focus:outline-none focus:border-[#F5F0E6]"
                        >
                            <option>Gemini 1.5 Pro</option>
                            <option>Gemini 1.5 Flash</option>
                            {isStructural && <option>Truth Forge Core v4 (Custom)</option>}
                        </select>
                    </div>

                    {/* SCAFFOLDING: Hide complex parameters in LOW complexity mode */}
                    {complexityLevel !== 'LOW' && (
                        <>
                            {/* Temperature */}
                            <div className="space-y-3">
                                <div className="flex justify-between">
                                    <label className="text-xs font-mono text-[#F5F0E6] uppercase tracking-wide">Temperature</label>
                                    <span className="text-xs font-mono text-[#888888]">{temperature}</span>
                                </div>
                                <input 
                                    type="range" 
                                    min="0" 
                                    max="1" 
                                    step="0.1"
                                    value={temperature}
                                    onChange={(e) => setTemperature(parseFloat(e.target.value))}
                                    className="w-full h-1 bg-[#2D2D2D] rounded-lg appearance-none cursor-pointer accent-[#F5F0E6]"
                                />
                            </div>

                            {/* Safety Settings - Enhanced */}
                            <div className="space-y-4">
                                <div className="flex items-center space-x-2 border-b border-[#2D2D2D] pb-2">
                                    <Shield size={12} className="text-[#F5F0E6]" />
                                    <label className="text-xs font-mono text-[#F5F0E6] uppercase tracking-wide">Safety Protocols</label>
                                </div>
                                
                                <div className="space-y-2">
                                    {safetySettings.map((setting) => (
                                        <div key={setting.id} className="border border-[#2D2D2D] rounded-sm bg-[#1A1A1A] overflow-hidden">
                                            <button 
                                                onClick={() => setExpandedSafety(expandedSafety === setting.id ? null : setting.id)}
                                                className="w-full flex items-center justify-between p-3 hover:bg-[#232323] transition-colors text-left"
                                            >
                                                <div>
                                                    <div className="text-xs font-mono text-[#F5F0E6] mb-1">{setting.label}</div>
                                                    <div className="flex items-center space-x-1">
                                                        <div className={`w-1.5 h-1.5 rounded-full ${setting.level === 'BLOCK_NONE' ? 'bg-red-500' : 'bg-green-500'}`}></div>
                                                        <span className="text-[10px] text-[#888888] uppercase">{setting.level.replace('BLOCK_', '').replace(/_/g, ' ')}</span>
                                                    </div>
                                                </div>
                                                {expandedSafety === setting.id ? <ChevronDown size={14} className="text-[#4A4A4A]"/> : <ChevronRight size={14} className="text-[#4A4A4A]"/>}
                                            </button>
                                            
                                            {expandedSafety === setting.id && (
                                                <div className="p-3 bg-[#0D0D0D] border-t border-[#2D2D2D] space-y-3 animate-in slide-in-from-top-2">
                                                    {['BLOCK_NONE', 'BLOCK_ONLY_HIGH', 'BLOCK_MEDIUM_AND_ABOVE', 'BLOCK_LOW_AND_ABOVE'].map((level) => (
                                                        <label key={level} className="flex items-start space-x-3 cursor-pointer group">
                                                            <div className="relative flex items-center mt-0.5">
                                                                <input 
                                                                    type="radio" 
                                                                    name={`safety-${setting.id}`} 
                                                                    checked={setting.level === level}
                                                                    onChange={() => updateSafety(setting.id, level as SafetyLevel)}
                                                                    className="peer h-3 w-3 appearance-none border border-[#4A4A4A] rounded-full checked:border-[#F5F0E6] checked:bg-[#F5F0E6] transition-all"
                                                                />
                                                            </div>
                                                            <div className="flex-1">
                                                                <span className={`text-[10px] font-mono uppercase block ${setting.level === level ? 'text-[#F5F0E6]' : 'text-[#888888] group-hover:text-[#B5B5B5]'}`}>
                                                                    {level.replace('BLOCK_', '').replace(/_/g, ' ')}
                                                                </span>
                                                                <p className="text-[10px] text-[#4A4A4A] mt-1 leading-tight">
                                                                    {safetyDescriptions[level as SafetyLevel]}
                                                                </p>
                                                            </div>
                                                        </label>
                                                    ))}
                                                </div>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </>
                    )}
                    
                    {/* Structural Settings (Stage 5 only) */}
                    {isStructural && (
                        <div className="space-y-3 pt-4 border-t border-[#2D2D2D]">
                            <label className="text-xs font-mono text-[#F59E0B] uppercase tracking-wide">Structural Overrides</label>
                            <div className="flex justify-between items-center p-2 border border-[#F59E0B]/30 rounded-sm bg-[#F59E0B]/10">
                                <span className="text-xs text-[#F59E0B]">Memory Allocation</span>
                                <span className="text-[10px] font-mono text-[#F59E0B]">DYNAMIC</span>
                            </div>
                        </div>
                    )}
                </div>
              </>
          ) : (
              // OPERATIONS (TASK) STATS PANEL
              <div className="flex flex-col h-full">
                  <div className="p-4 border-b border-[#2D2D2D] flex items-center space-x-2">
                      <ListTodo size={14} className="text-[#888888]" />
                      <span className="font-mono text-xs text-[#888888] uppercase tracking-widest">Protocol Metrics</span>
                  </div>
                  <div className="p-6 space-y-6">
                      <div className="bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-4 text-center">
                          <div className="text-3xl font-serif text-[#F5F0E6]">{directives.filter(d => d.status === 'PENDING').length}</div>
                          <div className="text-[10px] font-mono text-[#888888] uppercase mt-1">Pending Directives</div>
                      </div>
                      <div className="space-y-2">
                          <div className="text-xs font-mono text-[#F5F0E6] uppercase tracking-wide">Priority Breakdown</div>
                          {['CRITICAL', 'STANDARD', 'ROUTINE'].map(p => {
                              const count = directives.filter(d => d.priority === p && d.status === 'PENDING').length;
                              if (inSafeMode && p === 'CRITICAL') return null; // Hide critical in safe mode
                              return (
                                  <div key={p} className="flex items-center justify-between text-xs font-mono">
                                      <span className="text-[#888888] capitalize">{p.toLowerCase()}</span>
                                      <span className="text-[#F5F0E6]">{count}</span>
                                  </div>
                              )
                          })}
                      </div>
                      <div className="pt-6 border-t border-[#2D2D2D] opacity-50">
                          <p className="text-[10px] font-mono text-[#4A4A4A] leading-relaxed">
                              Execute directives to maintain system entropy levels. Critical tasks directly impact resonance scores.
                          </p>
                      </div>
                  </div>
              </div>
          )}
      </div>
    </div>
  );
};