import React, { useState, useEffect } from 'react';
import { User, FederationState, FederationPartnerID, DataExchangeLog, ConnectionStatus } from '../types';
import { Button } from './Button';
import { 
  Globe, Database, Shield, Zap, Lock, Unlock, Activity, 
  ArrowUpRight, ArrowDownLeft, RefreshCw, Power, Server, 
  HardDrive, AlertTriangle, FileCode, CheckCircle2 
} from 'lucide-react';

interface FederationBridgeProps {
  user: User;
  onUpdateUser: (user: User) => void;
}

export const FederationBridge: React.FC<FederationBridgeProps> = ({ user, onUpdateUser }) => {
  const [selectedPartnerId, setSelectedPartnerId] = useState<FederationPartnerID | null>(null);
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);

  const federation = user.developmentProfile.federationState || { 
      connections: [], 
      exchangeLog: [], 
      globalConsent: true,
      dataExportStatus: 'NONE'
  };

  const partners = federation.connections;
  const logs = federation.exchangeLog;

  const getPartnerIcon = (id: FederationPartnerID) => {
      switch(id) {
          case FederationPartnerID.CORE: return <Shield size={20} className="text-[#F5F0E6]" />;
          case FederationPartnerID.PRIMITIVE_ENGINE: return <Zap size={20} className="text-[#F59E0B]" />;
          case FederationPartnerID.CREDENTIAL_ATLAS: return <Database size={20} className="text-blue-400" />;
          case FederationPartnerID.NOT_ME_SERVICE: return <Activity size={20} className="text-green-400" />;
          case FederationPartnerID.COHORT_MESH: return <Globe size={20} className="text-purple-400" />;
          default: return <Server size={20} className="text-[#888888]" />;
      }
  };

  const getStatusColor = (status: ConnectionStatus) => {
      switch(status) {
          case 'CONNECTED': return 'text-green-400 bg-green-900/20 border-green-900';
          case 'DISCONNECTED': return 'text-[#888888] bg-[#2D2D2D] border-[#4A4A4A]';
          case 'DEGRADED': return 'text-[#F59E0B] bg-[#F59E0B]/20 border-[#F59E0B]';
          case 'MAINTENANCE': return 'text-red-400 bg-red-900/20 border-red-900';
      }
  };

  const toggleConsent = (partnerId: FederationPartnerID) => {
      const updatedConnections = partners.map(p => {
          if (p.partnerId === partnerId) {
              return { ...p, userConsent: !p.userConsent };
          }
          return p;
      });
      
      onUpdateUser({
          ...user,
          developmentProfile: {
              ...user.developmentProfile,
              federationState: {
                  ...federation,
                  connections: updatedConnections
              }
          }
      });
  };

  const handleExportData = () => {
      setIsExporting(true);
      setExportProgress(0);
      const interval = setInterval(() => {
          setExportProgress(prev => {
              if (prev >= 100) {
                  clearInterval(interval);
                  setIsExporting(false);
                  return 100;
              }
              return prev + 10;
          });
      }, 300);
  };

  // Mock live data update
  useEffect(() => {
      const interval = setInterval(() => {
          if (Math.random() > 0.7) {
              const activePartners = partners.filter(p => p.status === 'CONNECTED' && p.userConsent);
              if (activePartners.length > 0) {
                  const randomPartner = activePartners[Math.floor(Math.random() * activePartners.length)];
                  const newLog: DataExchangeLog = {
                      id: Math.random().toString(36).substr(2, 9),
                      timestamp: Date.now(),
                      direction: Math.random() > 0.5 ? 'OUTBOUND' : 'INBOUND',
                      partnerId: randomPartner.partnerId,
                      dataType: randomPartner.dataTypesAccessed[Math.floor(Math.random() * randomPartner.dataTypesAccessed.length)],
                      status: 'SUCCESS',
                      description: Math.random() > 0.5 ? 'Routine sync pulse' : 'Delta update processed'
                  };
                  
                  onUpdateUser({
                      ...user,
                      developmentProfile: {
                          ...user.developmentProfile,
                          federationState: {
                              ...federation,
                              exchangeLog: [newLog, ...federation.exchangeLog].slice(0, 50) // Keep last 50
                          }
                      }
                  });
              }
          }
      }, 5000);
      return () => clearInterval(interval);
  }, [partners, user, federation, onUpdateUser]);

  return (
    <div className="flex h-full animate-in fade-in duration-500">
        
        {/* Left: Partner Grid & Health */}
        <div className="flex-1 p-8 overflow-y-auto custom-scrollbar border-r border-[#2D2D2D] bg-[#0D0D0D]">
            <header className="mb-8">
                <div className="flex items-center justify-between mb-2">
                    <h2 className="text-2xl font-serif text-[#F5F0E6] uppercase tracking-wide flex items-center">
                        <Globe className="mr-3 text-[#F59E0B]" size={24} />
                        Federation Bridge
                    </h2>
                    <div className="flex items-center space-x-2 px-3 py-1 bg-[#1A1A1A] border border-[#2D2D2D] rounded-full">
                        <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                        <span className="text-[10px] font-mono text-[#F5F0E6] uppercase">System Optimal</span>
                    </div>
                </div>
                <p className="text-sm font-mono text-[#888888]">
                    Manage contracts and data flows with autonomous Truth Forge sub-systems.
                </p>
            </header>

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
                {partners.map(partner => (
                    <div 
                        key={partner.partnerId}
                        className={`p-5 border rounded-sm transition-all duration-300 relative group overflow-hidden ${partner.status === 'CONNECTED' ? 'bg-[#1A1A1A] border-[#2D2D2D] hover:border-[#4A4A4A]' : 'bg-[#0D0D0D] border-[#2D2D2D] opacity-70'}`}
                    >
                        <div className="flex justify-between items-start mb-4 relative z-10">
                            <div className="flex items-center space-x-3">
                                <div className={`p-2 rounded-full border bg-[#0D0D0D] ${partner.status === 'CONNECTED' ? 'border-[#4A4A4A]' : 'border-[#2D2D2D]'}`}>
                                    {getPartnerIcon(partner.partnerId)}
                                </div>
                                <div>
                                    <h3 className="text-sm font-serif text-[#F5F0E6]">{partner.name}</h3>
                                    <div className="flex items-center space-x-2 mt-1">
                                        <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded border uppercase ${getStatusColor(partner.status)}`}>
                                            {partner.status}
                                        </span>
                                        {partner.healthLatency && (
                                            <span className="text-[9px] font-mono text-[#4A4A4A]">{partner.healthLatency}ms</span>
                                        )}
                                    </div>
                                </div>
                            </div>
                            
                            {/* Toggle */}
                            <button 
                                onClick={() => toggleConsent(partner.partnerId)}
                                className={`relative w-10 h-5 rounded-full transition-colors duration-200 focus:outline-none ${partner.userConsent ? 'bg-[#F59E0B]' : 'bg-[#2D2D2D] border border-[#4A4A4A]'}`}
                                title="Toggle Data Sharing"
                            >
                                <div className={`absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white shadow-sm transform transition-transform duration-200 ${partner.userConsent ? 'translate-x-5' : 'translate-x-0'}`}></div>
                            </button>
                        </div>

                        <p className="text-xs text-[#888888] mb-4 min-h-[2.5em] relative z-10">
                            {partner.description}
                        </p>

                        <div className="pt-4 border-t border-[#2D2D2D] flex flex-wrap gap-2 relative z-10">
                            {partner.dataTypesAccessed.map(type => (
                                <span key={type} className="text-[9px] font-mono text-[#4A4A4A] border border-[#2D2D2D] bg-[#0D0D0D] px-1.5 py-0.5 rounded">
                                    {type}
                                </span>
                            ))}
                        </div>

                        {/* Background Pulse for Connected Services */}
                        {partner.status === 'CONNECTED' && partner.userConsent && (
                            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-transparent to-[#F59E0B]/5 rounded-bl-full pointer-events-none"></div>
                        )}
                    </div>
                ))}
            </div>

            {/* Emergent Architecture Section */}
            <div className="mt-8 pt-8 border-t border-[#2D2D2D]">
                <div className="flex items-center space-x-2 mb-4">
                    <FileCode size={16} className="text-[#F5F0E6]" />
                    <h3 className="text-sm font-mono text-[#F5F0E6] uppercase tracking-wide">Emergent Capabilities</h3>
                </div>
                <div className="p-4 bg-[#151515] border border-[#2D2D2D] rounded-sm">
                    <div className="flex justify-between items-center mb-2">
                        <span className="text-xs font-serif text-[#F5F0E6]">Self-Modifying Interface</span>
                        <span className="text-[9px] font-mono text-purple-400 bg-purple-900/10 border border-purple-900/30 px-2 py-0.5 rounded">BETA</span>
                    </div>
                    <p className="text-xs text-[#888888] mb-4">
                        Allows the System Awareness module to propose real-time UI mutations based on your usage patterns.
                    </p>
                    <div className="flex items-center space-x-2">
                        <div className="h-1 flex-1 bg-[#2D2D2D] rounded-full overflow-hidden">
                            <div className="h-full bg-purple-500 w-3/4"></div>
                        </div>
                        <span className="text-[9px] font-mono text-[#4A4A4A]">75% Stability</span>
                    </div>
                </div>
            </div>
        </div>

        {/* Right: Data Stream & Controls */}
        <div className="w-96 bg-[#151515] border-l border-[#2D2D2D] flex flex-col flex-shrink-0">
            {/* Header */}
            <div className="p-6 border-b border-[#2D2D2D] bg-[#1A1A1A]">
                <h3 className="text-xs font-mono text-[#888888] uppercase tracking-widest flex items-center mb-1">
                    <Activity size={14} className="mr-2 text-[#F5F0E6]" /> Data Telemetry
                </h3>
                <div className="text-[10px] text-[#4A4A4A]">Real-time exchange log</div>
            </div>

            {/* Log Stream */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar bg-[#0D0D0D]">
                {logs.length === 0 && (
                    <div className="text-center py-12 text-[#4A4A4A] text-xs font-mono">
                        No data exchanges recorded.
                    </div>
                )}
                {logs.map(log => (
                    <div key={log.id} className="p-3 border border-[#2D2D2D] bg-[#151515] rounded-sm animate-in slide-in-from-right-2">
                        <div className="flex justify-between items-start mb-2">
                            <div className="flex items-center space-x-2">
                                {log.direction === 'OUTBOUND' ? <ArrowUpRight size={12} className="text-[#F59E0B]" /> : <ArrowDownLeft size={12} className="text-green-400" />}
                                <span className="text-[10px] font-mono text-[#F5F0E6]">{log.partnerId.split('_')[0]}</span>
                            </div>
                            <span className="text-[9px] font-mono text-[#4A4A4A]">
                                {new Date(log.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', second:'2-digit'})}
                            </span>
                        </div>
                        <p className="text-xs text-[#888888] mb-1">{log.description}</p>
                        <div className="flex items-center justify-between">
                            <span className="text-[9px] font-mono text-[#4A4A4A] uppercase bg-[#0D0D0D] px-1 rounded">{log.dataType}</span>
                            {log.status === 'SUCCESS' && <CheckCircle2 size={10} className="text-green-500" />}
                        </div>
                    </div>
                ))}
            </div>

            {/* Footer Controls */}
            <div className="p-6 border-t border-[#2D2D2D] bg-[#1A1A1A] space-y-6">
                
                {/* Data Sovereignty */}
                <div>
                    <h4 className="text-xs font-mono text-[#F5F0E6] uppercase tracking-wide mb-3 flex items-center">
                        <HardDrive size={14} className="mr-2 text-[#F59E0B]" /> Data Sovereignty
                    </h4>
                    
                    {isExporting ? (
                        <div className="space-y-2">
                            <div className="flex justify-between text-[10px] font-mono text-[#F5F0E6]">
                                <span>Packaging Archive...</span>
                                <span>{exportProgress}%</span>
                            </div>
                            <div className="h-1 bg-[#2D2D2D] rounded-full overflow-hidden">
                                <div className="h-full bg-[#F59E0B] transition-all duration-300" style={{ width: `${exportProgress}%` }}></div>
                            </div>
                        </div>
                    ) : (
                        <div className="space-y-2">
                            <Button fullWidth variant="secondary" size="sm" onClick={handleExportData} icon={<ArrowDownLeft size={14}/>}>
                                Export Personal Archive
                            </Button>
                            <p className="text-[9px] text-[#4A4A4A] text-center">
                                Download all profile data, logs, and artifacts in JSON format.
                            </p>
                        </div>
                    )}
                </div>

                {/* Kill Switch */}
                <div className="pt-4 border-t border-[#2D2D2D]">
                    <button className="w-full flex items-center justify-center space-x-2 text-red-400 hover:text-red-300 hover:bg-red-900/10 p-2 rounded-sm transition-colors text-xs font-mono uppercase border border-transparent hover:border-red-900/30">
                        <Power size={14} />
                        <span>Emergency Severance</span>
                    </button>
                    <p className="text-[9px] text-[#4A4A4A] text-center mt-2">
                        Instantly disconnect all federation partners.
                    </p>
                </div>
            </div>
        </div>
    </div>
  );
};