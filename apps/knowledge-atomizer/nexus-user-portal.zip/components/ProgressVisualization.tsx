import React, { useState } from 'react';
import { User, JourneyViewMode, KeganStage, Milestone, NarrativeSummary } from '../types';
import { Button } from './Button';
import { Mountain, Waves, Sprout, Share2, MapPin, Flag, Star, Compass, Wind, Layers, CloudFog, Cloud, Sun, Calendar, BookOpen, Quote } from 'lucide-react';

interface ProgressVisualizationProps {
  user: User;
}

export const ProgressVisualization: React.FC<ProgressVisualizationProps> = ({ user }) => {
  const [activeMode, setActiveMode] = useState<JourneyViewMode>('MOUNTAIN');
  const [selectedMilestone, setSelectedMilestone] = useState<Milestone | null>(null);
  const [showNarrative, setShowNarrative] = useState(false);

  const milestones = user.developmentProfile.milestones || [];
  const narratives = user.developmentProfile.narrativeHistory || [];
  const domains = user.developmentProfile.lifeContext?.domains || [];
  const stage = user.developmentProfile.stage;

  // --- VIEW RENDERERS ---

  const MountainView = () => {
      // Logic to place milestones on a "mountain" path
      // Mocking SVG path logic for visual impact
      const sortedMilestones = [...milestones].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      
      return (
          <div className="relative w-full h-[600px] bg-[#0D0D0D] overflow-hidden rounded-sm border border-[#2D2D2D] p-8 flex items-end justify-center group">
              {/* Background Elements */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#151515] to-[#0D0D0D]"></div>
              <CloudFog size={200} className="absolute top-10 right-10 text-[#2D2D2D] opacity-20" />
              <Cloud size={120} className="absolute top-32 left-20 text-[#2D2D2D] opacity-10" />
              <Sun size={80} className="absolute top-10 left-1/2 -translate-x-1/2 text-[#F59E0B] opacity-10 animate-pulse" />

              {/* The Mountain Shape */}
              <svg className="absolute inset-0 w-full h-full" preserveAspectRatio="none">
                  <path d="M0,600 L200,400 L350,500 L500,200 L650,350 L800,100 L1000,600 Z" fill="#1A1A1A" stroke="#2D2D2D" strokeWidth="2" />
                  <path d="M0,600 L150,450 L300,550 L450,250 L600,400 L750,150 L950,600 Z" fill="none" stroke="#F5F0E6" strokeWidth="2" strokeDasharray="5,5" className="opacity-30" />
              </svg>

              {/* Milestones on the Path */}
              {sortedMilestones.map((m, i) => {
                  // Fake positioning based on index
                  const left = 10 + (i * (80 / Math.max(1, sortedMilestones.length - 1)));
                  const bottom = 10 + (i * (70 / Math.max(1, sortedMilestones.length - 1)));
                  
                  return (
                      <div 
                        key={m.id}
                        className="absolute cursor-pointer group/marker transition-all duration-300 hover:scale-125 hover:z-50"
                        style={{ left: `${left}%`, bottom: `${bottom}%` }}
                        onClick={() => setSelectedMilestone(m)}
                      >
                          <div className={`w-3 h-3 rounded-full border-2 ${selectedMilestone?.id === m.id ? 'bg-[#F59E0B] border-[#F59E0B]' : 'bg-[#0D0D0D] border-[#F5F0E6]'}`}></div>
                          
                          {/* Tooltip */}
                          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 w-48 bg-[#1A1A1A] border border-[#2D2D2D] p-3 rounded-sm opacity-0 group-hover/marker:opacity-100 transition-opacity pointer-events-none z-50">
                              <div className="text-[10px] font-mono text-[#888888]">{new Date(m.date).toLocaleDateString()}</div>
                              <div className="text-xs font-serif text-[#F5F0E6] mt-1">{m.title}</div>
                          </div>
                      </div>
                  )
              })}

              {/* Current Position Flag */}
              <div className="absolute" style={{ left: `${10 + ((sortedMilestones.length - 1) * (80 / Math.max(1, sortedMilestones.length - 1)))}%`, bottom: `${10 + ((sortedMilestones.length - 1) * (70 / Math.max(1, sortedMilestones.length - 1))) + 5}%` }}>
                  <Flag size={20} className="text-[#F59E0B] animate-bounce" fill="#F59E0B" fillOpacity={0.2} />
              </div>
          </div>
      );
  };

  const RiverView = () => {
      // Flow metaphor for integration
      return (
          <div className="relative w-full h-[600px] bg-[#050505] overflow-hidden rounded-sm border border-[#2D2D2D] p-8">
              {/* River Bed */}
              <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle, #2D2D2D 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
              
              {/* The River */}
              <svg className="absolute inset-0 w-full h-full">
                  <defs>
                      <linearGradient id="riverGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                          <stop offset="0%" stopColor="#1e3a8a" stopOpacity="0.2" />
                          <stop offset="50%" stopColor="#3b82f6" stopOpacity="0.5" />
                          <stop offset="100%" stopColor="#60a5fa" stopOpacity="0.8" />
                      </linearGradient>
                  </defs>
                  {/* Main Flow */}
                  <path 
                    d="M0,300 C150,300 150,100 400,100 C650,100 650,500 900,500 L1200,300" 
                    fill="none" 
                    stroke="url(#riverGradient)" 
                    strokeWidth="40" 
                    className="animate-pulse" 
                    style={{ animationDuration: '5s' }}
                  />
                  
                  {/* Tributaries (Life Domains) */}
                  {domains.map((d, i) => (
                      <path 
                        key={d.id}
                        d={`M${100 + i * 200},${i % 2 === 0 ? 0 : 600} Q${100 + i * 200},300 ${250 + i * 200},${i % 2 === 0 ? 150 : 450}`}
                        fill="none"
                        stroke={d.harmonyScore > 70 ? "#10B981" : d.harmonyScore < 40 ? "#EF4444" : "#F59E0B"}
                        strokeWidth="4"
                        strokeDasharray="5,5"
                        opacity="0.6"
                      />
                  ))}
              </svg>

              {/* Labels */}
              {domains.map((d, i) => (
                  <div key={d.id} className="absolute text-[10px] font-mono text-[#F5F0E6] bg-[#0D0D0D] px-2 py-1 rounded border border-[#2D2D2D]" style={{ left: `${10 + i * 20}%`, top: i % 2 === 0 ? '5%' : '90%' }}>
                      {d.name} ({d.harmonyScore}%)
                  </div>
              ))}
              
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-[#0D0D0D]/80 p-4 border border-[#2D2D2D] rounded-sm text-center">
                  <div className="text-xs font-mono text-[#888888] uppercase tracking-widest">Current Flow</div>
                  <div className="text-xl font-serif text-[#F5F0E6] mt-1">Integration Phase</div>
              </div>
          </div>
      );
  };

  const GardenView = () => {
      // Grid of plants representing domains
      return (
          <div className="w-full h-[600px] bg-[#0D0D0D] overflow-y-auto custom-scrollbar border border-[#2D2D2D] rounded-sm p-8">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
                  {domains.map(d => {
                      const scale = 0.5 + (d.harmonyScore / 200); // 0.5 to 1.0
                      const color = d.harmonyScore > 80 ? 'text-green-400' : d.harmonyScore > 50 ? 'text-[#F59E0B]' : 'text-red-400';
                      
                      return (
                          <div key={d.id} className="flex flex-col items-center justify-end h-64 bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-6 relative group overflow-hidden">
                              <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                                  <span className={`text-xs font-mono ${color}`}>{d.harmonyScore}% Growth</span>
                              </div>
                              
                              <div style={{ transform: `scale(${scale})` }} className={`transition-transform duration-1000 ${color}`}>
                                  <Sprout size={64} strokeWidth={1.5} />
                              </div>
                              
                              <div className="mt-6 w-full text-center border-t border-[#2D2D2D] pt-4">
                                  <h4 className="text-lg font-serif text-[#F5F0E6]">{d.name}</h4>
                                  <p className="text-[10px] font-mono text-[#888888] mt-1 line-clamp-2">{d.keganRelevance}</p>
                              </div>
                          </div>
                      )
                  })}
                  {domains.length === 0 && (
                      <div className="col-span-full flex flex-col items-center justify-center h-64 text-[#4A4A4A]">
                          <Sprout size={48} className="mb-4 opacity-50" />
                          <p className="text-sm font-mono">No domains planted yet.</p>
                      </div>
                  )}
              </div>
          </div>
      );
  };

  const ConstellationView = () => {
      // Connect milestones like stars
      return (
          <div className="relative w-full h-[600px] bg-[#050505] overflow-hidden rounded-sm border border-[#2D2D2D] flex items-center justify-center">
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[#1A1A1A] to-[#000000]"></div>
              
              <svg className="absolute inset-0 w-full h-full pointer-events-none">
                  {/* Connections */}
                  {milestones.map((m, i) => {
                      if (i === 0) return null;
                      const prev = milestones[i-1];
                      // Simple radial layout logic
                      const angle1 = ((i-1) / milestones.length) * Math.PI * 2;
                      const angle2 = (i / milestones.length) * Math.PI * 2;
                      const r = 200;
                      const x1 = 50 + (Math.cos(angle1) * 20) + "%"; // Mock percent coords
                      const y1 = 50 + (Math.sin(angle1) * 20) + "%";
                      const x2 = 50 + (Math.cos(angle2) * 20) + "%";
                      const y2 = 50 + (Math.sin(angle2) * 20) + "%";
                      
                      return (
                          <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#4A4A4A" strokeWidth="1" opacity="0.5" />
                      )
                  })}
              </svg>

              <div className="relative w-full h-full">
                  {milestones.map((m, i) => {
                      const angle = (i / milestones.length) * Math.PI * 2;
                      const radius = 25 + (Math.random() * 15); // Percentage
                      const top = 50 + Math.sin(angle) * radius;
                      const left = 50 + Math.cos(angle) * radius;

                      return (
                          <div 
                            key={m.id} 
                            className="absolute transform -translate-x-1/2 -translate-y-1/2 group cursor-pointer"
                            style={{ top: `${top}%`, left: `${left}%` }}
                            onClick={() => setSelectedMilestone(m)}
                          >
                              <Star size={12} className={`text-[#F5F0E6] group-hover:text-[#F59E0B] transition-colors ${selectedMilestone?.id === m.id ? 'fill-[#F59E0B] text-[#F59E0B]' : 'fill-white'}`} />
                              <div className="absolute top-4 left-1/2 -translate-x-1/2 w-32 text-center opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                                  <span className="text-[10px] font-mono text-[#F5F0E6] bg-black/50 px-1 rounded">{m.title}</span>
                              </div>
                          </div>
                      )
                  })}
                  
                  {/* Center Star (Current Self) */}
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                      <div className="w-16 h-16 bg-[#F59E0B]/10 rounded-full flex items-center justify-center border border-[#F59E0B]/30 animate-pulse">
                          <Compass size={32} className="text-[#F59E0B]" />
                      </div>
                  </div>
              </div>
          </div>
      );
  };

  return (
    <div className="flex h-full bg-[#0D0D0D] overflow-hidden animate-in fade-in duration-500">
        {/* Left Sidebar: Controls & Narrative */}
        <div className="w-80 bg-[#151515] border-r border-[#2D2D2D] flex flex-col flex-shrink-0">
            <div className="p-6 border-b border-[#2D2D2D]">
                <h2 className="text-xl font-serif text-[#F5F0E6] uppercase tracking-wide flex items-center">
                    <MapPin size={20} className="mr-3 text-[#F59E0B]" />
                    My Journey
                </h2>
                <p className="text-xs font-mono text-[#888888] mt-2">
                    Visualizing the trajectory of your becoming.
                </p>
            </div>

            {/* View Switcher */}
            <div className="p-2 grid grid-cols-4 gap-1 bg-[#1A1A1A] border-b border-[#2D2D2D]">
                <button onClick={() => setActiveMode('MOUNTAIN')} className={`p-2 rounded-sm flex justify-center ${activeMode === 'MOUNTAIN' ? 'bg-[#2D2D2D] text-[#F5F0E6]' : 'text-[#888888] hover:bg-[#232323]'}`} title="Elevation"><Mountain size={16}/></button>
                <button onClick={() => setActiveMode('RIVER')} className={`p-2 rounded-sm flex justify-center ${activeMode === 'RIVER' ? 'bg-[#2D2D2D] text-[#F5F0E6]' : 'text-[#888888] hover:bg-[#232323]'}`} title="Flow"><Waves size={16}/></button>
                <button onClick={() => setActiveMode('GARDEN')} className={`p-2 rounded-sm flex justify-center ${activeMode === 'GARDEN' ? 'bg-[#2D2D2D] text-[#F5F0E6]' : 'text-[#888888] hover:bg-[#232323]'}`} title="Growth"><Sprout size={16}/></button>
                <button onClick={() => setActiveMode('CONSTELLATION')} className={`p-2 rounded-sm flex justify-center ${activeMode === 'CONSTELLATION' ? 'bg-[#2D2D2D] text-[#F5F0E6]' : 'text-[#888888] hover:bg-[#232323]'}`} title="Connection"><Star size={16}/></button>
            </div>

            {/* Recent Narratives */}
            <div className="flex-1 overflow-y-auto p-4 custom-scrollbar space-y-4">
                <div className="flex items-center space-x-2 text-[#F59E0B] mb-2">
                    <BookOpen size={14} />
                    <span className="text-xs font-mono uppercase tracking-widest">Narrative Synthesis</span>
                </div>
                
                {narratives.length > 0 ? narratives.map(n => (
                    <div key={n.id} className="bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-4 hover:border-[#F59E0B]/50 transition-colors cursor-pointer group">
                        <div className="flex justify-between items-start mb-2">
                            <span className="text-[10px] font-mono text-[#888888] uppercase">{n.date}</span>
                            <span className="text-[10px] font-mono text-[#F59E0B] opacity-0 group-hover:opacity-100 transition-opacity">READ</span>
                        </div>
                        <h4 className="text-sm font-serif text-[#F5F0E6] mb-2">{n.periodLabel}</h4>
                        <p className="text-xs text-[#888888] line-clamp-3 leading-relaxed">{n.content}</p>
                    </div>
                )) : (
                    <div className="text-center p-6 border border-dashed border-[#2D2D2D] rounded-sm">
                        <p className="text-xs text-[#4A4A4A] font-mono">No narratives generated yet. Continue your journey.</p>
                    </div>
                )}
            </div>

            {/* Footer Action */}
            <div className="p-4 border-t border-[#2D2D2D] bg-[#1A1A1A]">
                <Button fullWidth variant="secondary" icon={<Share2 size={14}/>}>Share Anonymized Map</Button>
            </div>
        </div>

        {/* Main Visualization Area */}
        <div className="flex-1 flex flex-col relative overflow-hidden bg-[#0D0D0D] p-8">
            <header className="flex justify-between items-start mb-6">
                <div>
                    <h1 className="text-3xl font-serif text-[#F5F0E6] uppercase tracking-wide">
                        {activeMode === 'MOUNTAIN' ? 'The Ascent' : activeMode === 'RIVER' ? 'The Stream' : activeMode === 'GARDEN' ? 'Cultivation' : 'Constellation'}
                    </h1>
                    <div className="h-1 w-12 bg-[#F59E0B] mt-2"></div>
                </div>
                <div className="flex items-center space-x-2">
                    <span className="text-[10px] font-mono text-[#888888] uppercase border border-[#2D2D2D] px-2 py-1 rounded-full">
                        Current Stage: {stage.replace('STAGE_', '').replace(/_/g, ' ')}
                    </span>
                </div>
            </header>

            {/* Rendering the active view */}
            <div className="flex-1 border border-[#2D2D2D] rounded-sm bg-[#0A0A0A] relative overflow-hidden shadow-2xl">
                {activeMode === 'MOUNTAIN' && <MountainView />}
                {activeMode === 'RIVER' && <RiverView />}
                {activeMode === 'GARDEN' && <GardenView />}
                {activeMode === 'CONSTELLATION' && <ConstellationView />}
            </div>

            {/* Selected Milestone Detail Panel (Bottom Overlay) */}
            {selectedMilestone && (
                <div className="absolute bottom-8 left-8 right-8 bg-[#1A1A1A] border-t-4 border-[#F59E0B] shadow-2xl p-6 animate-in slide-in-from-bottom-10 flex justify-between items-start">
                    <div className="flex-1 pr-8">
                        <div className="flex items-center space-x-2 mb-2">
                            <Calendar size={14} className="text-[#F59E0B]" />
                            <span className="text-xs font-mono text-[#F5F0E6] uppercase">{new Date(selectedMilestone.date).toLocaleDateString()}</span>
                            <span className="text-[10px] font-mono text-[#4A4A4A] px-2 py-0.5 border border-[#2D2D2D] rounded">{selectedMilestone.type}</span>
                        </div>
                        <h3 className="text-2xl font-serif text-[#F5F0E6] mb-2">{selectedMilestone.title}</h3>
                        <p className="text-sm text-[#888888] leading-relaxed">{selectedMilestone.description}</p>
                        {selectedMilestone.notMeWitness && (
                            <div className="mt-4 p-3 bg-[#0D0D0D] border-l-2 border-[#F59E0B] flex items-start space-x-3">
                                <Quote size={16} className="text-[#F59E0B] mt-1 flex-shrink-0" />
                                <p className="text-xs text-[#F5F0E6] italic">"{selectedMilestone.notMeWitness}"</p>
                            </div>
                        )}
                    </div>
                    <button onClick={() => setSelectedMilestone(null)} className="text-[#888888] hover:text-[#F5F0E6] uppercase text-xs font-mono">Close</button>
                </div>
            )}
        </div>
    </div>
  );
};