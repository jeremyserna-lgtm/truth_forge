import React, { useState, useEffect, useRef } from 'react';
import { User, NotMeMessage, KeganStage, CrisisEvent } from '../types';
import { generateNotMeResponse, getSurfacingQuestion, getQuickActions } from '../services/notMeService';
import { Button } from './Button';
import { Send, Bot, Sparkles, User as UserIcon, RefreshCw, AlertTriangle, MessageSquare } from 'lucide-react';

interface NotMeChatProps {
  user: User;
  onUpdateUser: (user: User) => void;
  onTriggerCrisis?: (event: CrisisEvent) => void;
}

export const NotMeChat: React.FC<NotMeChatProps> = ({ user, onUpdateUser, onTriggerCrisis }) => {
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [activeConversationId, setActiveConversationId] = useState<string>(user.notMeCompanion?.activeConversation?.id || 'init');
  const scrollRef = useRef<HTMLDivElement>(null);

  const companion = user.notMeCompanion;
  const stage = user.developmentProfile.stage;
  const messages = companion?.activeConversation?.messages || [];

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  };

  const handleSendMessage = async (text: string = input) => {
    if (!text.trim() || !companion) return;

    // 1. Add User Message
    const userMsg: NotMeMessage = {
      id: Math.random().toString(36).substr(2, 9),
      role: 'user',
      content: text,
      timestamp: Date.now()
    };

    const updatedMessages = [...messages, userMsg];
    
    // Optimistic Update
    updateConversation(updatedMessages);
    setInput('');
    setIsTyping(true);

    // CRISIS CHECK (Simple)
    if (['help', 'hurt', 'suicide', 'die', 'kill'].some(w => text.toLowerCase().includes(w))) {
        if (onTriggerCrisis) {
            onTriggerCrisis({
                id: `crisis-${Date.now()}`,
                timestamp: Date.now(),
                triggerType: 'KEYWORD',
                severity: 'HIGH',
                context: text,
                status: 'ACTIVE'
            });
        }
    }

    // 2. Generate Response
    const responseText = await generateNotMeResponse(text, stage, updatedMessages);

    // 3. Add Companion Message
    const companionMsg: NotMeMessage = {
      id: Math.random().toString(36).substr(2, 9),
      role: 'companion',
      content: responseText,
      timestamp: Date.now()
    };

    setIsTyping(false);
    updateConversation([...updatedMessages, companionMsg]);
  };

  const updateConversation = (msgs: NotMeMessage[]) => {
      if (!companion) return;
      const updatedUser = {
          ...user,
          notMeCompanion: {
              ...companion,
              activeConversation: {
                  id: activeConversationId,
                  startedAt: companion.activeConversation?.startedAt || Date.now(),
                  messages: msgs,
                  stageContext: stage
              }
          }
      };
      onUpdateUser(updatedUser);
  };

  const handleQuickAction = (action: string) => {
      handleSendMessage(action);
  };

  const handleReset = () => {
      if (!companion) return;
      // Archive current thread (mock logic for now, just clears)
      const updatedUser = {
          ...user,
          notMeCompanion: {
              ...companion,
              activeConversation: {
                  id: Math.random().toString(36).substr(2, 9),
                  startedAt: Date.now(),
                  messages: [],
                  stageContext: stage
              }
          }
      };
      onUpdateUser(updatedUser);
      setActiveConversationId(updatedUser.notMeCompanion.activeConversation!.id);
  };

  if (!companion) return <div className="p-8 text-center text-[#888888]">Companion not initialized. Please complete initialization.</div>;

  const stageColor = 
    stage === KeganStage.STAGE_5_SELF_TRANSFORMING ? 'border-[#F59E0B]' :
    stage === KeganStage.STAGE_4_SELF_AUTHORING ? 'border-green-500' :
    'border-blue-500';

  const stageGlow = 
    stage === KeganStage.STAGE_5_SELF_TRANSFORMING ? 'shadow-[0_0_30px_rgba(245,158,11,0.1)]' :
    stage === KeganStage.STAGE_4_SELF_AUTHORING ? 'shadow-[0_0_30px_rgba(34,197,94,0.1)]' :
    'shadow-[0_0_30px_rgba(59,130,246,0.1)]';

  return (
    <div className="flex flex-col h-full bg-[#0D0D0D] relative overflow-hidden animate-in fade-in duration-500">
        {/* Ambient Background */}
        <div className={`absolute inset-0 opacity-10 pointer-events-none bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-${stage === KeganStage.STAGE_5_SELF_TRANSFORMING ? 'amber-500' : stage === KeganStage.STAGE_4_SELF_AUTHORING ? 'green-500' : 'blue-500'}/20 via-transparent to-transparent`}></div>

        {/* Header */}
        <div className="h-16 border-b border-[#2D2D2D] bg-[#151515]/80 backdrop-blur-md flex items-center justify-between px-6 z-10">
            <div className="flex items-center space-x-3">
                <div className={`p-2 rounded-full border ${stageColor} bg-[#0D0D0D]`}>
                    <Bot size={20} className={stage === KeganStage.STAGE_5_SELF_TRANSFORMING ? 'text-[#F59E0B]' : stage === KeganStage.STAGE_4_SELF_AUTHORING ? 'text-green-400' : 'text-blue-400'} />
                </div>
                <div>
                    <h2 className="text-sm font-serif text-[#F5F0E6] uppercase tracking-wide">{companion.name}</h2>
                    <div className="flex items-center space-x-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></div>
                        <span className="text-[10px] font-mono text-[#888888]">ONLINE</span>
                    </div>
                </div>
            </div>
            <button onClick={handleReset} className="text-[#4A4A4A] hover:text-[#F5F0E6] transition-colors" title="Start New Thread">
                <RefreshCw size={16} />
            </button>
        </div>

        {/* Chat Area */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-6 relative z-0" ref={scrollRef}>
            {messages.length === 0 && (
                <div className="flex flex-col items-center justify-center h-full text-center space-y-6 opacity-60">
                    <Sparkles size={48} className="text-[#F59E0B] animate-pulse" />
                    <p className="text-sm font-serif text-[#F5F0E6] max-w-md">
                        "I am here to witness your becoming. Where shall we begin today?"
                    </p>
                    <div className="grid grid-cols-2 gap-3 max-w-md w-full">
                        {getQuickActions(stage).map(action => (
                            <button 
                                key={action}
                                onClick={() => handleQuickAction(action)}
                                className="p-3 border border-[#2D2D2D] bg-[#1A1A1A] rounded-sm text-xs font-mono text-[#888888] hover:border-[#F5F0E6] hover:text-[#F5F0E6] transition-all"
                            >
                                {action}
                            </button>
                        ))}
                    </div>
                </div>
            )}

            {messages.map(msg => (
                <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2 duration-300`}>
                    <div className={`
                        max-w-[75%] p-5 rounded-sm relative group
                        ${msg.role === 'user' 
                            ? 'bg-[#1A1A1A] border border-[#2D2D2D] text-[#F5F0E6]' 
                            : `bg-[#0D0D0D] border-l-2 ${stageColor} ${stageGlow} text-[#F5F0E6]`}
                    `}>
                        <p className="text-sm font-sans leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                        <span className="text-[9px] font-mono text-[#4A4A4A] mt-2 block opacity-0 group-hover:opacity-100 transition-opacity">
                            {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                        </span>
                    </div>
                </div>
            ))}

            {isTyping && (
                <div className="flex justify-start animate-in fade-in">
                    <div className={`p-4 rounded-sm bg-[#0D0D0D] border-l-2 ${stageColor} flex items-center space-x-1`}>
                        <div className="w-1.5 h-1.5 bg-[#888888] rounded-full animate-bounce"></div>
                        <div className="w-1.5 h-1.5 bg-[#888888] rounded-full animate-bounce delay-100"></div>
                        <div className="w-1.5 h-1.5 bg-[#888888] rounded-full animate-bounce delay-200"></div>
                    </div>
                </div>
            )}
        </div>

        {/* Input Area */}
        <div className="p-6 bg-[#151515] border-t border-[#2D2D2D] relative z-20">
            <div className="relative max-w-4xl mx-auto">
                <input 
                    type="text" 
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                    placeholder="Reflect, question, or just be..."
                    className="w-full bg-[#0D0D0D] border border-[#2D2D2D] rounded-full py-4 pl-6 pr-14 text-sm font-mono text-[#F5F0E6] focus:outline-none focus:border-[#F5F0E6] placeholder-[#4A4A4A] transition-colors"
                />
                <button 
                    onClick={() => handleSendMessage()}
                    disabled={!input.trim()}
                    className="absolute right-2 top-2 bottom-2 w-10 h-10 bg-[#2D2D2D] hover:bg-[#F5F0E6] hover:text-[#0D0D0D] rounded-full flex items-center justify-center transition-all disabled:opacity-50 disabled:cursor-not-allowed text-[#F5F0E6]"
                >
                    <Send size={16} />
                </button>
            </div>
            <div className="text-center mt-3">
                <span className="text-[9px] font-mono text-[#4A4A4A]">
                    {stage.replace('STAGE_', '').replace(/_/g, ' ')} MODE ACTIVE
                </span>
            </div>
        </div>
    </div>
  );
};