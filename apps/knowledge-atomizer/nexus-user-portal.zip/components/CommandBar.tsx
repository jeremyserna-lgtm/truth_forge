import React, { useState } from 'react';
import { Mic, Send, Sparkles } from 'lucide-react';
import { SubscriptionTier, KeganStage } from '../types';

interface CommandBarProps {
  tier: SubscriptionTier;
  keganStage: KeganStage;
}

export const CommandBar: React.FC<CommandBarProps> = ({ tier, keganStage }) => {
  const [input, setInput] = useState('');

  const getPlaceholder = () => {
    // Stage 3: External validation, seeking confirmation
    if (keganStage === KeganStage.STAGE_3_SOCIALIZED || keganStage === KeganStage.STAGE_2_IMPERIAL || keganStage === KeganStage.STAGE_1_IMPULSIVE) {
        return "System standby. Awaiting external command parameters...";
    }
    // Stage 4: Self-Authoring, internal drive
    if (keganStage === KeganStage.STAGE_4_SELF_AUTHORING) {
        return "I define the intent. The system executes my will...";
    }
    // Stage 5: Self-Transforming, dialectical
    if (keganStage === KeganStage.STAGE_5_SELF_TRANSFORMING) {
        return "Manifest the paradox. Explore the space between truths...";
    }
    return "Awaiting input...";
  };

  return (
    <div className="h-16 bg-[#0D0D0D] border-t border-[#2D2D2D] flex items-center justify-center px-4 relative z-50">
      <div className={`max-w-3xl w-full relative ${tier === SubscriptionTier.STAGE_3_FROZEN ? 'opacity-80' : ''}`}>
        <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
          {keganStage === KeganStage.STAGE_5_SELF_TRANSFORMING ? (
            <Sparkles size={18} className="text-[#F59E0B] animate-pulse" />
          ) : (
            <Mic size={18} className="text-[#4A4A4A]" />
          )}
        </div>
        <input 
          type="text" 
          value={input}
          onChange={(e) => setInput(e.target.value)}
          disabled={tier === SubscriptionTier.STAGE_3_FROZEN && keganStage === KeganStage.STAGE_1_IMPULSIVE} // Just an example lock
          className={`
            w-full bg-[#1A1A1A] border rounded-full py-3 pl-10 pr-12 text-sm font-mono text-[#F5F0E6] focus:outline-none focus:ring-1 transition-all placeholder-[#4A4A4A]
            ${keganStage === KeganStage.STAGE_5_SELF_TRANSFORMING 
                ? 'border-[#F59E0B]/50 focus:border-[#F59E0B] focus:ring-[#F59E0B]' 
                : keganStage === KeganStage.STAGE_4_SELF_AUTHORING 
                    ? 'border-[#F5F0E6]/50 focus:border-[#F5F0E6] focus:ring-[#F5F0E6]'
                    : 'border-[#2D2D2D] focus:border-[#4A4A4A] focus:ring-[#4A4A4A]'
            }
          `}
          placeholder={getPlaceholder()}
        />
        <button 
          className={`absolute inset-y-0 right-2 flex items-center justify-center w-8 h-8 my-auto rounded-full transition-colors ${
              keganStage === KeganStage.STAGE_5_SELF_TRANSFORMING 
              ? 'bg-[#F59E0B] text-[#0D0D0D] hover:bg-white'
              : 'bg-[#2D2D2D] text-[#F5F0E6] hover:bg-[#F5F0E6] hover:text-[#0D0D0D]'
          }`}
        >
          <Send size={14} />
        </button>
      </div>
    </div>
  );
};