import React, { useState } from 'react';
import { Milestone, User, KeganStage } from '../types';
import { CheckCircle2, Circle, ArrowUp, Star, Scroll, Calendar, MapPin, Footprints } from 'lucide-react';

interface MilestoneJourneyProps {
  user: User;
}

export const MilestoneJourney: React.FC<MilestoneJourneyProps> = ({ user }) => {
  const [selectedMilestone, setSelectedMilestone] = useState<Milestone | null>(null);
  
  const milestones = user.developmentProfile.milestones || [];
  const currentStage = user.developmentProfile.stage;

  // Generate "Future" milestones based on current stage for the UI
  const getFutureMilestones = (): Partial<Milestone>[] => {
      const futures: Partial<Milestone>[] = [];
      if (currentStage === KeganStage.STAGE_3_SOCIALIZED) {
          futures.push({ title: 'Internal Authority', description: 'Defining values independent of external expectation.' });
          futures.push({ title: 'Self-Authorship', description: 'Full transition to Stage 4.' });
      } else if (currentStage === KeganStage.STAGE_4_SELF_AUTHORING) {
          futures.push({ title: 'Paradox Integration', description: 'Holding opposing truths simultaneously.' });
          futures.push({ title: 'Self-Transformation', description: 'Full transition to Stage 5.' });
      }
      return futures;
  };

  const futures = getFutureMilestones();

  return (
    <div className="flex h-full gap-8 animate-in fade-in duration-700">
        
        {/* Timeline Column */}
        <div className="flex-1 overflow-y-auto custom-scrollbar pr-4 relative">
            <div className="absolute top-0 left-6 bottom-0 w-0.5 bg-[#2D2D2D]"></div>
            
            <div className="space-y-12 py-8">
                
                {/* PAST MILESTONES */}
                {milestones.map((m, idx) => (
                    <div 
                        key={m.id} 
                        className="relative pl-16 group cursor-pointer"
                        onClick={() => setSelectedMilestone(m)}
                    >
                        <div className={`absolute left-[19px] top-1 w-3 h-3 rounded-full border-2 bg-[#0D0D0D] z-10 transition-all duration-300 ${selectedMilestone?.id === m.id ? 'border-[#F59E0B] scale-125' : 'border-[#F5F0E6] group-hover:border-[#F59E0B]'}`}></div>
                        
                        <div className={`p-4 rounded-sm border transition-all duration-300 ${selectedMilestone?.id === m.id ? 'bg-[#1A1A1A] border-[#F59E0B]/50' : 'bg-transparent border-transparent hover:bg-[#1A1A1A]/50'}`}>
                            <div className="text-[10px] font-mono text-[#888888] mb-1 flex items-center space-x-2">
                                <Calendar size={10} />
                                <span>{new Date(m.date).toLocaleDateString()}</span>
                            </div>
                            <h3 className={`text-lg font-serif ${selectedMilestone?.id === m.id ? 'text-[#F59E0B]' : 'text-[#F5F0E6]'}`}>{m.title}</h3>
                            <p className="text-xs text-[#888888] line-clamp-2 mt-1">{m.description}</p>
                        </div>
                    </div>
                ))}

                {/* CURRENT EDGE */}
                <div className="relative pl-16">
                    <div className="absolute left-[15px] top-0 w-5 h-5 rounded-full border-2 border-[#F59E0B] bg-[#0D0D0D] z-10 flex items-center justify-center">
                        <div className="w-2 h-2 bg-[#F59E0B] rounded-full animate-pulse"></div>
                    </div>
                    
                    <div className="p-6 bg-[#F59E0B]/5 border border-[#F59E0B]/30 rounded-sm">
                        <div className="flex items-center space-x-2 mb-2">
                            <MapPin size={14} className="text-[#F59E0B]" />
                            <span className="text-xs font-mono text-[#F59E0B] uppercase tracking-widest">The Developmental Edge</span>
                        </div>
                        <h3 className="text-xl font-serif text-[#F5F0E6] mb-2">Navigating {currentStage.replace('STAGE_', '').replace(/_/g, ' ')}</h3>
                        <p className="text-sm text-[#F5F0E6] leading-relaxed opacity-80">
                            You are currently mapping the territory of this stage. The work here involves stabilizing your current way of knowing while beginning to perceive its limits.
                        </p>
                    </div>
                </div>

                {/* FUTURE HORIZON */}
                {futures.map((f, idx) => (
                    <div key={idx} className="relative pl-16 opacity-50">
                        <div className="absolute left-[19px] top-1 w-3 h-3 rounded-full border border-dashed border-[#4A4A4A] bg-[#0D0D0D] z-10"></div>
                        <div className="p-4 rounded-sm border border-dashed border-[#2D2D2D]">
                            <h3 className="text-base font-serif text-[#888888]">{f.title}</h3>
                            <p className="text-xs text-[#4A4A4A] mt-1">{f.description}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>

        {/* Details Column */}
        <div className="w-96 bg-[#151515] border border-[#2D2D2D] rounded-sm p-8 flex flex-col relative overflow-hidden">
            {selectedMilestone ? (
                <div className="animate-in slide-in-from-right duration-500 h-full flex flex-col">
                    <div className="mb-6 border-b border-[#2D2D2D] pb-6">
                        <div className="text-[10px] font-mono text-[#888888] uppercase tracking-widest mb-2 flex items-center space-x-2">
                            <Footprints size={12} />
                            <span>Milestone Record</span>
                        </div>
                        <h2 className="text-2xl font-serif text-[#F5F0E6]">{selectedMilestone.title}</h2>
                        <span className="inline-block mt-2 px-2 py-1 bg-[#F59E0B]/10 text-[#F59E0B] text-[10px] font-mono rounded border border-[#F59E0B]/30 uppercase">
                            {selectedMilestone.type.replace('_', ' ')}
                        </span>
                    </div>

                    <div className="space-y-6 flex-1 overflow-y-auto custom-scrollbar">
                        <div className="space-y-2">
                            <h4 className="text-xs font-mono text-[#F5F0E6] uppercase">The Shift</h4>
                            <p className="text-sm text-[#888888] leading-relaxed bg-[#0D0D0D] p-3 rounded-sm border border-[#2D2D2D]">
                                {selectedMilestone.description}
                            </p>
                        </div>

                        {selectedMilestone.userReflection && (
                            <div className="space-y-2">
                                <h4 className="text-xs font-mono text-[#F5F0E6] uppercase">Your Reflection</h4>
                                <p className="text-sm text-[#F5F0E6] italic leading-relaxed border-l-2 border-[#4A4A4A] pl-3">
                                    "{selectedMilestone.userReflection}"
                                </p>
                            </div>
                        )}

                        {selectedMilestone.notMeWitness && (
                            <div className="space-y-2">
                                <h4 className="text-xs font-mono text-[#F59E0B] uppercase">Not-Me Witness</h4>
                                <div className="p-3 bg-[#F59E0B]/5 border border-[#F59E0B]/20 rounded-sm">
                                    <p className="text-sm text-[#F5F0E6] leading-relaxed">
                                        "{selectedMilestone.notMeWitness}"
                                    </p>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            ) : (
                <div className="h-full flex flex-col items-center justify-center text-center opacity-30">
                    <Scroll size={48} className="mb-4 text-[#F5F0E6]" />
                    <p className="text-sm font-mono text-[#F5F0E6]">Select a milestone to view the archive.</p>
                </div>
            )}
        </div>
    </div>
  );
};