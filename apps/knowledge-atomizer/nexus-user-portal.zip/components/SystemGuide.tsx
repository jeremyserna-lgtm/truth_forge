import React, { useState } from 'react';
import { SubscriptionTier, KeganStage } from '../types';
import { Sparkles, Brain, Boxes, ChevronUp, ChevronDown, Info, Activity, AlertCircle } from 'lucide-react';

interface SystemGuideProps {
  tier: SubscriptionTier;
  keganStage: KeganStage;
}

export const SystemGuide: React.FC<SystemGuideProps> = ({ tier, keganStage }) => {
  const [isExpanded, setIsExpanded] = useState(true);

  const getContent = () => {
    switch (keganStage) {
      case KeganStage.STAGE_1_IMPULSIVE:
      case KeganStage.STAGE_2_IMPERIAL:
      case KeganStage.STAGE_3_SOCIALIZED:
        return {
          title: "Socialized Mind",
          icon: <Boxes size={12} className="text-blue-400" />,
          intro: "Perception: External Definition",
          body: "The system detects you are seeking validation from external sources. You likely treat the AI's output as an authority to be followed rather than a tool to be wielded. The interface is currently structured to provide clear, rigid guidance.",
          instruction: "Evolution: Critique the output. Find the flaw in the system."
        };
      case KeganStage.STAGE_4_SELF_AUTHORING:
        return {
          title: "Self-Authoring Mind",
          icon: <Brain size={12} className="text-green-400" />,
          intro: "Perception: Internal Authority",
          body: "You have begun to define the system's purpose yourself. You treat the AI as a subordinate function of your own will. The interface has unlocked 'My' prefixes to reflect your ownership of the construct.",
          instruction: "Evolution: Seek the paradox. Where is your own ideology incomplete?"
        };
      case KeganStage.STAGE_5_SELF_TRANSFORMING:
        return {
          title: "Self-Transforming Mind",
          icon: <Sparkles size={12} className="text-amber-400" />,
          intro: "Perception: Dialectical",
          body: "You see the system as a distinct entity with which you are in dialogue. You recognize that neither you nor the AI holds the complete truth, but that truth emerges from the friction between you. The interface is now fluid and structural.",
          instruction: "Evolution: Maintain the state of play."
        };
      default: return null;
    }
  };

  const content = getContent();
  if (!content) return null;

  return (
    <div className="mx-3 mt-auto mb-4 border border-[#2D2D2D] bg-[#151515] rounded-sm overflow-hidden transition-all duration-300 shadow-lg">
      <button 
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full px-3 py-2 flex items-center justify-between bg-[#1A1A1A] hover:bg-[#232323] transition-colors border-b border-[#2D2D2D]"
      >
        <div className="flex items-center space-x-2">
           {content.icon}
           <span className="text-[10px] font-mono text-[#F5F0E6] uppercase tracking-wider">{content.title}</span>
        </div>
        {isExpanded ? <ChevronDown size={12} className="text-[#888888]" /> : <ChevronUp size={12} className="text-[#888888]" />}
      </button>
      
      {isExpanded && (
        <div className="p-3 animate-in slide-in-from-top-2 duration-200 bg-[#0D0D0D]">
          <div className="flex items-start space-x-2 mb-2">
            <Activity size={12} className="text-[#888888] flex-shrink-0 mt-0.5" />
            <p className="text-[10px] font-mono text-[#F5F0E6] uppercase">{content.intro}</p>
          </div>
          <p className="text-xs text-[#888888] leading-relaxed font-sans mb-3 pl-5 border-l border-[#2D2D2D] ml-1">
            {content.body}
          </p>
          <div className="text-[10px] font-mono text-[#F5F0E6] bg-[#1A1A1A] p-2 rounded-sm border border-[#2D2D2D]">
            {content.instruction}
          </div>
        </div>
      )}
    </div>
  );
};