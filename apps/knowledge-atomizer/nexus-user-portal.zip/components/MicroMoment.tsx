import React, { useEffect, useState } from 'react';
import { Sparkles, X, BrainCircuit, MessageSquare, Lightbulb } from 'lucide-react';
import { KeganStage } from '../types';

interface MicroMomentProps {
  stage: KeganStage;
  trigger: string;
  onClose: () => void;
}

export const MicroMoment: React.FC<MicroMomentProps> = ({ stage, trigger, onClose }) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    // Small delay for natural appearance
    const timer = setTimeout(() => setVisible(true), 500);
    return () => clearTimeout(timer);
  }, []);

  const getPrompt = () => {
    // Stage 3: Socialized (Relationships / Validation)
    if (stage === KeganStage.STAGE_3_SOCIALIZED || stage === KeganStage.STAGE_2_IMPERIAL) {
        if (trigger === 'SYNTHESIS') return "Who would validate this conclusion?";
        if (trigger === 'REFLECTION') return "How does this align with group expectations?";
        return "Does this choice connect you to others?";
    }
    // Stage 4: Self-Authoring (Identity / Ideology)
    if (stage === KeganStage.STAGE_4_SELF_AUTHORING) {
        if (trigger === 'SYNTHESIS') return "Is this conclusion truly yours, or inherited?";
        if (trigger === 'REFLECTION') return "Does this serve your core mission?";
        return "Are you authoring this moment?";
    }
    // Stage 5: Self-Transforming (Paradox / Dialectic)
    if (stage === KeganStage.STAGE_5_SELF_TRANSFORMING) {
        if (trigger === 'SYNTHESIS') return "What is the opposite truth here?";
        if (trigger === 'REFLECTION') return "Where is the tension in your thinking?";
        return "Can you hold the paradox?";
    }
    return "What did you notice just now?";
  };

  const getIcon = () => {
      switch(trigger) {
          case 'SYNTHESIS': return <BrainCircuit size={14} className="text-[#F59E0B]" />;
          case 'REFLECTION': return <MessageSquare size={14} className="text-blue-400" />;
          default: return <Lightbulb size={14} className="text-purple-400" />;
      }
  };

  return (
    <div className={`fixed bottom-8 right-8 z-50 transition-all duration-700 transform ${visible ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'}`}>
        <div className="bg-[#1A1A1A] border-l-4 border-[#F59E0B] rounded-r-sm shadow-2xl p-4 w-72 relative">
            <button 
                onClick={onClose}
                className="absolute top-2 right-2 text-[#4A4A4A] hover:text-[#F5F0E6] transition-colors"
            >
                <X size={12} />
            </button>
            
            <div className="flex items-start space-x-3">
                <div className="mt-0.5 p-1.5 bg-[#0D0D0D] rounded-full border border-[#2D2D2D]">
                    {getIcon()}
                </div>
                <div>
                    <span className="text-[9px] font-mono text-[#888888] uppercase tracking-widest block mb-1">
                        Developmental Nudge
                    </span>
                    <p className="text-xs font-serif text-[#F5F0E6] leading-relaxed italic">
                        "{getPrompt()}"
                    </p>
                </div>
            </div>
        </div>
    </div>
  );
};