import React, { useState, useEffect, useRef } from 'react';
import { CrisisEvent, User } from '../types';
import { Button } from './Button';
import { ShieldAlert, Heart, Phone, X, Wind, Music, EyeOff, CheckCircle, ArrowRight } from 'lucide-react';

interface CrisisOverlayProps {
  user: User;
  event: CrisisEvent;
  onResolve: () => void;
  onEscalate: () => void;
}

type SupportStep = 'ACKNOWLEDGE' | 'GROUNDING' | 'RESOURCES' | 'ESCALATION';

export const CrisisOverlay: React.FC<CrisisOverlayProps> = ({ user, event, onResolve, onEscalate }) => {
  const [step, setStep] = useState<SupportStep>('ACKNOWLEDGE');
  const [breathCount, setBreathCount] = useState(0);
  const [isBreathing, setIsBreathing] = useState(false);
  const breathInterval = useRef<number | null>(null);

  const companionName = user.notMeCompanion?.name || 'Not-Me';

  // Breathing Exercise Logic
  const startBreathing = () => {
    setIsBreathing(true);
    setBreathCount(4); // Inhale 4
    let phase = 'INHALE';
    let count = 4;

    breathInterval.current = window.setInterval(() => {
        count--;
        if (count === 0) {
            if (phase === 'INHALE') {
                phase = 'HOLD';
                count = 4;
            } else if (phase === 'HOLD') {
                phase = 'EXHALE';
                count = 4;
            } else {
                phase = 'INHALE';
                count = 4;
            }
        }
        setBreathCount(count);
    }, 1000);
  };

  const stopBreathing = () => {
      if (breathInterval.current) clearInterval(breathInterval.current);
      setIsBreathing(false);
  };

  useEffect(() => {
      return () => { if (breathInterval.current) clearInterval(breathInterval.current); };
  }, []);

  const renderAcknowledge = () => (
      <div className="max-w-lg mx-auto text-center space-y-8 animate-in fade-in duration-700">
          <div className="w-20 h-20 bg-teal-900/30 rounded-full flex items-center justify-center mx-auto border border-teal-500/50">
              <ShieldAlert size={40} className="text-teal-400" />
          </div>
          <div>
              <h2 className="text-2xl font-serif text-[#F5F0E6] mb-4">I notice things feel heavy right now.</h2>
              <p className="text-sm font-mono text-[#888888] leading-relaxed">
                  The patterns in our conversation suggest high distress. Developmental work is intense, but safety is the priority.
              </p>
              <p className="text-sm font-mono text-teal-400 mt-4">
                  Let's pause the work and stabilize.
              </p>
          </div>
          <div className="flex flex-col space-y-3">
              <Button size="lg" onClick={() => setStep('GROUNDING')} className="bg-teal-900/40 border-teal-500 hover:bg-teal-900/60 text-teal-100">
                  Help me Ground
              </Button>
              <Button size="lg" variant="secondary" onClick={() => setStep('RESOURCES')}>
                  I need Support Resources
              </Button>
              <button onClick={onResolve} className="text-xs text-[#4A4A4A] hover:text-[#888888] mt-4 underline">
                  I'm okay, return to portal
              </button>
          </div>
      </div>
  );

  const renderGrounding = () => (
      <div className="max-w-lg mx-auto text-center space-y-8 animate-in slide-in-from-right duration-500">
          <div className="flex items-center justify-center space-x-2 text-teal-400 mb-4">
              <Wind size={20} />
              <span className="text-xs font-mono uppercase tracking-widest">Box Breathing</span>
          </div>

          <div className="relative w-64 h-64 mx-auto flex items-center justify-center">
              {isBreathing && (
                  <div className="absolute inset-0 border-4 border-teal-500/20 rounded-full animate-ping opacity-20" style={{ animationDuration: '4s' }}></div>
              )}
              <div className={`w-48 h-48 rounded-full border-2 border-teal-500 flex items-center justify-center transition-all duration-1000 ${isBreathing ? 'scale-110 bg-teal-900/20' : 'bg-transparent'}`}>
                  <span className="text-4xl font-mono text-[#F5F0E6]">{isBreathing ? breathCount : 'Start'}</span>
              </div>
          </div>

          <p className="text-sm font-mono text-[#888888]">
              {isBreathing ? "Inhale... Hold... Exhale..." : "Focus on the sensation of air moving. Click start when ready."}
          </p>

          <div className="flex justify-center space-x-4">
              {!isBreathing ? (
                  <Button onClick={startBreathing}>Start Exercise</Button>
              ) : (
                  <Button onClick={stopBreathing} variant="secondary">Stop</Button>
              )}
          </div>
          
          <div className="pt-8 border-t border-[#2D2D2D]">
              <button onClick={() => setStep('RESOURCES')} className="text-xs text-[#888888] hover:text-[#F5F0E6] flex items-center justify-center mx-auto">
                  It's not helping, show me resources <ArrowRight size={12} className="ml-1"/>
              </button>
          </div>
      </div>
  );

  const renderResources = () => (
      <div className="max-w-2xl mx-auto animate-in slide-in-from-right duration-500">
          <h2 className="text-2xl font-serif text-[#F5F0E6] mb-6 text-center">Support Resources</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
              <div className="p-4 bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm flex items-start space-x-3">
                  <Phone size={20} className="text-teal-400 mt-1" />
                  <div>
                      <h4 className="text-sm font-mono text-[#F5F0E6] uppercase">Crisis Text Line</h4>
                      <p className="text-xs text-[#888888] mt-1">Text HOME to 741741</p>
                      <p className="text-[10px] text-[#4A4A4A] mt-2">Free, 24/7 support for those in crisis.</p>
                  </div>
              </div>
              <div className="p-4 bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm flex items-start space-x-3">
                  <Heart size={20} className="text-red-400 mt-1" />
                  <div>
                      <h4 className="text-sm font-mono text-[#F5F0E6] uppercase">Peer Support</h4>
                      <p className="text-xs text-[#888888] mt-1">Connect with a trained peer.</p>
                      <Button size="sm" variant="secondary" className="mt-2 text-[10px] h-8" onClick={() => setStep('ESCALATION')}>
                          Request Human Connection
                      </Button>
                  </div>
              </div>
          </div>

          <div className="bg-teal-900/10 border border-teal-900/30 p-6 rounded-sm text-center">
              <p className="text-sm text-teal-200 mb-4">
                  "{user.firstName}, there is no shame in pausing. Growth requires safety first. I am here to hold the boundary until you are ready." — {companionName}
              </p>
              <Button onClick={onResolve} className="bg-teal-800 text-white hover:bg-teal-700 border-none">
                  I feel stable enough to continue
              </Button>
          </div>
      </div>
  );

  const renderEscalation = () => (
      <div className="max-w-lg mx-auto text-center space-y-6 animate-in slide-in-from-right duration-500">
          <div className="w-16 h-16 bg-[#F59E0B]/10 rounded-full flex items-center justify-center mx-auto border border-[#F59E0B]/30 animate-pulse">
              <Phone size={32} className="text-[#F59E0B]" />
          </div>
          <h2 className="text-xl font-serif text-[#F5F0E6]">Connecting to Human Support...</h2>
          <p className="text-sm font-mono text-[#888888]">
              We have signaled the Federation Console. A human operator from the safety team will join this channel shortly.
          </p>
          <div className="p-4 bg-[#1A1A1A] rounded-sm border border-[#2D2D2D] text-left">
              <div className="flex items-center space-x-2 mb-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-xs font-mono text-[#F5F0E6]">Operator Status: <span className="text-green-400">ONLINE</span></span>
              </div>
              <p className="text-xs text-[#4A4A4A]">Queue position: 1</p>
          </div>
          <Button variant="secondary" onClick={() => setStep('RESOURCES')}>Cancel Request</Button>
      </div>
  );

  return (
    <div className="fixed inset-0 z-[300] bg-[#050505]/95 backdrop-blur-md flex flex-col items-center justify-center p-6">
        {/* Ambient background specific to crisis mode - calming teal/dark */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-teal-900/10 via-[#000000] to-[#000000] pointer-events-none"></div>
        
        <div className="relative z-10 w-full">
            {step === 'ACKNOWLEDGE' && renderAcknowledge()}
            {step === 'GROUNDING' && renderGrounding()}
            {step === 'RESOURCES' && renderResources()}
            {step === 'ESCALATION' && renderEscalation()}
        </div>
    </div>
  );
};