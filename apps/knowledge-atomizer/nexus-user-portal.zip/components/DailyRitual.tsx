import React, { useState, useEffect } from 'react';
import { User, KeganStage, RitualEntry } from '../types';
import { Button } from './Button';
import { Sun, Moon, Sparkles, Send, X } from 'lucide-react';

interface DailyRitualProps {
  user: User;
  type: 'MORNING' | 'EVENING';
  onComplete: (entry: RitualEntry) => void;
  onClose: () => void;
}

export const DailyRitual: React.FC<DailyRitualProps> = ({ user, type, onComplete, onClose }) => {
  const [input, setInput] = useState('');
  const [step, setStep] = useState<'GREETING' | 'PROMPT' | 'CLOSING'>('GREETING');
  const [isProcessing, setIsProcessing] = useState(false);

  const stage = user.developmentProfile.stage;
  const companionName = user.notMeCompanion?.name || 'Not-Me';

  // --- Logic Generators ---
  const getGreeting = () => {
      if (type === 'MORNING') {
          return `Good morning, ${user.firstName}. A new cycle begins. I am here to hold space for your intention.`;
      } else {
          return `The day concludes, ${user.firstName}. Let us review the patterns we have woven today.`;
      }
  };

  const getPromptQuestion = () => {
      if (type === 'MORNING') {
          switch(stage) {
              case KeganStage.STAGE_3_SOCIALIZED: return "Who will you support or connect with today?";
              case KeganStage.STAGE_4_SELF_AUTHORING: return "What is the primary goal you will author today?";
              case KeganStage.STAGE_5_SELF_TRANSFORMING: return "Where will you look for the unexpected today?";
              default: return "What is your intention for today?";
          }
      } else {
          // Evening Prompt relies on morning context usually, but generic here
          const intention = user.developmentProfile.dailyPractice?.todayIntention;
          if (intention) return `This morning, you intended: "${intention}". How did reality interact with this intent?`;
          
          switch(stage) {
              case KeganStage.STAGE_3_SOCIALIZED: return "Did you feel aligned with those around you today?";
              case KeganStage.STAGE_4_SELF_AUTHORING: return "Did you maintain your boundaries today?";
              case KeganStage.STAGE_5_SELF_TRANSFORMING: return "What contradiction did you embody today?";
              default: return "What did you learn today?";
          }
      }
  };

  const handleNext = () => {
      if (step === 'GREETING') setStep('PROMPT');
      if (step === 'CLOSING') onClose();
  };

  const handleSubmit = () => {
      if (!input.trim()) return;
      setIsProcessing(true);
      
      // Simulate API/Processing delay
      setTimeout(() => {
          const entry: RitualEntry = {
              id: Math.random().toString(36).substr(2, 9),
              date: new Date().toISOString().split('T')[0],
              type: type === 'MORNING' ? 'MORNING_INTENTION' : 'EVENING_REFLECTION',
              prompt: getPromptQuestion(),
              response: input,
              completedAt: Date.now()
          };
          onComplete(entry);
          setStep('CLOSING');
          setIsProcessing(false);
      }, 1500);
  };

  return (
    <div className="fixed inset-0 z-[150] flex items-center justify-center bg-black/90 backdrop-blur-sm p-4 animate-in fade-in duration-500">
        <div className="w-full max-w-lg bg-[#0D0D0D] border border-[#2D2D2D] rounded-sm relative overflow-hidden flex flex-col min-h-[400px]">
            {/* Ambient Background */}
            <div className={`absolute inset-0 opacity-20 pointer-events-none bg-gradient-to-b ${type === 'MORNING' ? 'from-orange-500/20 to-transparent' : 'from-blue-900/20 to-transparent'}`}></div>
            
            {/* Close Button (if user wants to skip) */}
            <button onClick={onClose} className="absolute top-4 right-4 text-[#4A4A4A] hover:text-[#F5F0E6] z-50">
                <X size={20} />
            </button>

            {/* Content Container */}
            <div className="relative z-10 flex-1 flex flex-col p-8 items-center justify-center text-center space-y-8">
                
                {/* Icon */}
                <div className={`p-4 rounded-full border mb-4 ${type === 'MORNING' ? 'border-orange-500/50 bg-orange-500/10 text-orange-400' : 'border-blue-500/50 bg-blue-500/10 text-blue-400'}`}>
                    {type === 'MORNING' ? <Sun size={32} /> : <Moon size={32} />}
                </div>

                {/* Step Content */}
                {step === 'GREETING' && (
                    <div className="animate-in slide-in-from-bottom-4 space-y-6">
                        <h2 className="text-2xl font-serif text-[#F5F0E6]">{type === 'MORNING' ? 'Morning Intention' : 'Evening Reflection'}</h2>
                        <p className="text-sm font-mono text-[#888888] leading-relaxed max-w-sm mx-auto">
                            "{getGreeting()}"
                        </p>
                        <Button onClick={handleNext} className="mt-4">Begin</Button>
                    </div>
                )}

                {step === 'PROMPT' && (
                    <div className="w-full animate-in slide-in-from-bottom-4 space-y-6">
                        <div className="text-left space-y-2">
                            <span className="text-[10px] font-mono text-[#F59E0B] uppercase tracking-widest">{companionName} asks:</span>
                            <h3 className="text-lg font-serif text-[#F5F0E6] leading-relaxed">{getPromptQuestion()}</h3>
                        </div>
                        <textarea 
                            className="w-full h-32 bg-[#1A1A1A] border-b border-[#4A4A4A] p-4 text-[#F5F0E6] font-mono text-sm focus:outline-none focus:border-[#F59E0B] resize-none"
                            placeholder="Type your reflection here..."
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            autoFocus
                        />
                        <div className="flex justify-end">
                            <Button onClick={handleSubmit} isLoading={isProcessing} disabled={!input.trim()} icon={<Send size={14}/>}>
                                Record
                            </Button>
                        </div>
                    </div>
                )}

                {step === 'CLOSING' && (
                    <div className="animate-in zoom-in-95 space-y-6">
                        <Sparkles size={48} className="text-[#F59E0B] mx-auto animate-pulse" />
                        <h2 className="text-xl font-serif text-[#F5F0E6]">Ritual Complete</h2>
                        <p className="text-sm font-mono text-[#888888]">
                            {type === 'MORNING' 
                                ? "Carry this intention. I will be watching for moments to support it." 
                                : "Rest well. The data from today has been integrated."}
                        </p>
                        <div className="pt-4">
                            <Button onClick={onClose} variant="secondary">Return to Portal</Button>
                        </div>
                    </div>
                )}
            </div>
        </div>
    </div>
  );
};