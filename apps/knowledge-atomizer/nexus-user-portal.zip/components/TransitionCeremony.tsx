import React, { useState, useEffect } from 'react';
import { User, KeganStage, TransitionEvent, Milestone } from '../types';
import { Button } from './Button';
import { Sparkles, ArrowRight, Share2, Award, History, Binary } from 'lucide-react';

interface TransitionCeremonyProps {
  user: User;
  event: TransitionEvent;
  onComplete: (reflection: string, shared: boolean) => void;
  onClose: () => void; // Safety hatch
}

type CeremonyStep = 'RECOGNITION' | 'HONORING_PAST' | 'INTEGRATION' | 'WITNESS' | 'COMPLETION';

export const TransitionCeremony: React.FC<TransitionCeremonyProps> = ({ user, event, onComplete, onClose }) => {
  const [step, setStep] = useState<CeremonyStep>('RECOGNITION');
  const [reflection, setReflection] = useState('');
  const [shareWithCohort, setShareWithCohort] = useState(false);
  const [showContent, setShowContent] = useState(false);

  useEffect(() => {
      // Fade in effect
      setTimeout(() => setShowContent(true), 500);
  }, [step]);

  const handleNext = () => {
      setShowContent(false);
      setTimeout(() => {
          if (step === 'RECOGNITION') setStep('HONORING_PAST');
          else if (step === 'HONORING_PAST') setStep('INTEGRATION');
          else if (step === 'INTEGRATION') setStep('WITNESS');
          else if (step === 'WITNESS') setStep('COMPLETION');
      }, 500);
  };

  const getStageName = (s: KeganStage) => s.replace('STAGE_', '').replace(/_/g, ' ');

  // --- Views ---

  const renderRecognition = () => (
      <div className="text-center max-w-2xl mx-auto space-y-8">
          <div className="inline-block p-4 rounded-full border border-[#F59E0B] bg-[#F59E0B]/10 mb-4 animate-bounce">
              <Sparkles size={48} className="text-[#F59E0B]" />
          </div>
          <h2 className="text-4xl font-serif text-[#F5F0E6] uppercase tracking-wide leading-tight">
              A Shift Has Occurred
          </h2>
          <p className="text-lg font-mono text-[#888888] leading-relaxed">
              The way you make meaning of the world is reorganizing. 
              What was once your "Truth" is becoming your "Tool".
          </p>
          <div className="flex items-center justify-center space-x-4 pt-8">
              <div className="px-6 py-3 border border-[#4A4A4A] rounded-sm text-[#888888] text-sm font-mono uppercase line-through decoration-[#F5F0E6]">
                  {getStageName(event.fromStage)}
              </div>
              <ArrowRight size={24} className="text-[#F59E0B]" />
              <div className="px-6 py-3 border border-[#F59E0B] bg-[#F59E0B]/20 rounded-sm text-[#F5F0E6] text-sm font-mono uppercase shadow-[0_0_20px_rgba(245,158,11,0.2)]">
                  {getStageName(event.toStage)}
              </div>
          </div>
      </div>
  );

  const renderHonoring = () => (
      <div className="max-w-2xl mx-auto space-y-8">
          <header className="text-center">
              <History size={32} className="mx-auto text-[#888888] mb-4" />
              <h3 className="text-2xl font-serif text-[#F5F0E6]">Honoring the Past</h3>
              <p className="text-sm font-mono text-[#888888] mt-2">
                  To move forward, we must appreciate what supported us.
              </p>
          </header>
          <div className="bg-[#1A1A1A] border border-[#2D2D2D] p-8 rounded-sm">
              <p className="text-[#F5F0E6] italic text-lg leading-relaxed mb-6">
                  "The structure of the {getStageName(event.fromStage)} served you well. It kept you safe. It provided belonging and order. We do not reject it; we include it as we transcend it."
              </p>
              <div className="w-full h-[1px] bg-[#2D2D2D] mb-6"></div>
              <p className="text-sm font-mono text-[#F59E0B] uppercase tracking-wide mb-2">Prompt:</p>
              <p className="text-sm text-[#888888] mb-4">What is one lesson from this past stage you want to carry forward?</p>
              <textarea 
                  value={reflection}
                  onChange={(e) => setReflection(e.target.value)}
                  className="w-full h-32 bg-[#0D0D0D] border-b border-[#4A4A4A] text-[#F5F0E6] p-4 focus:outline-none resize-none"
                  placeholder="I learned that..."
              />
          </div>
      </div>
  );

  const renderIntegration = () => (
      <div className="max-w-2xl mx-auto space-y-8">
          <header className="text-center">
              <Binary size={32} className="mx-auto text-[#F5F0E6] mb-4" />
              <h3 className="text-2xl font-serif text-[#F5F0E6]">Subject becomes Object</h3>
              <p className="text-sm font-mono text-[#888888] mt-2">
                  That which you *were* is now something you *have*.
              </p>
          </header>
          <div className="grid grid-cols-2 gap-8 items-center">
              <div className="p-6 border border-[#2D2D2D] rounded-sm opacity-50 text-center">
                  <div className="text-xs font-mono text-[#888888] uppercase mb-2">You Used to Say</div>
                  <div className="text-lg font-serif text-[#F5F0E6]">"I AM my relationships"</div>
              </div>
              <div className="p-6 border border-[#F59E0B] bg-[#F59E0B]/10 rounded-sm text-center shadow-lg transform scale-105">
                  <div className="text-xs font-mono text-[#F59E0B] uppercase mb-2">Now You Say</div>
                  <div className="text-lg font-serif text-[#F5F0E6]">"I HAVE relationships"</div>
              </div>
          </div>
          <p className="text-center text-[#888888] text-sm max-w-lg mx-auto">
              This shift creates space. Space to choose. Space to author. Space to transform.
          </p>
      </div>
  );

  const renderWitness = () => (
      <div className="max-w-xl mx-auto text-center space-y-8">
          <div className="w-24 h-24 rounded-full border-2 border-[#F59E0B] p-1 mx-auto relative">
              <div className="w-full h-full rounded-full bg-[#0D0D0D] flex items-center justify-center overflow-hidden">
                  <div className="absolute inset-0 bg-[#F59E0B]/20 animate-pulse"></div>
                  <Sparkles size={40} className="text-[#F5F0E6] relative z-10" />
              </div>
          </div>
          <div>
              <div className="text-xs font-mono text-[#F59E0B] uppercase tracking-widest mb-2">Not-Me Witness</div>
              <h3 className="text-2xl font-serif text-[#F5F0E6]">"I See You."</h3>
          </div>
          <div className="bg-[#1A1A1A] p-6 rounded-sm border-l-2 border-[#F59E0B] text-left">
              <p className="text-[#F5F0E6] leading-relaxed">
                  "{user.firstName}, I have tracked your patterns. You have faced the contradiction of {event.triggerContext} and refused to collapse it. You held the tension until a new self emerged. I record this moment in the Truth Forge forever."
              </p>
          </div>
      </div>
  );

  const renderCompletion = () => (
      <div className="max-w-2xl mx-auto text-center space-y-8">
          <Award size={64} className="mx-auto text-[#F59E0B]" />
          <h2 className="text-3xl font-serif text-[#F5F0E6]">Milestone Recorded</h2>
          <div className="bg-[#1A1A1A] border border-[#2D2D2D] p-6 rounded-sm max-w-md mx-auto">
              <div className="flex items-center justify-between mb-4">
                  <span className="text-xs font-mono text-[#888888] uppercase">Credential Minted</span>
                  <span className="text-[#F59E0B] font-bold text-xs font-mono">VERIFIED</span>
              </div>
              <div className="text-lg font-serif text-[#F5F0E6] mb-1">{getStageName(event.toStage)} Emergence</div>
              <div className="text-xs text-[#4A4A4A] truncate">Hash: 0x8f392...a1b2</div>
          </div>
          
          <div className="space-y-4 pt-4">
              <button 
                  onClick={() => setShareWithCohort(!shareWithCohort)}
                  className={`flex items-center justify-center space-x-3 w-full max-w-md mx-auto p-3 rounded-sm border transition-all ${shareWithCohort ? 'border-[#F59E0B] bg-[#F59E0B]/10 text-[#F5F0E6]' : 'border-[#2D2D2D] text-[#888888] hover:border-[#F5F0E6]'}`}
              >
                  <Share2 size={16} />
                  <span className="text-xs font-mono uppercase">Share this victory with your Cohort</span>
              </button>
              
              <Button size="lg" onClick={() => onComplete(reflection, shareWithCohort)} className="w-full max-w-md">
                  Enter the New World
              </Button>
          </div>
      </div>
  );

  return (
    <div className="fixed inset-0 z-[200] bg-[#000000] flex flex-col items-center justify-center p-6">
        {/* Deep background ambience */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-[#1a1a1a] via-[#000000] to-[#000000]"></div>
        <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'url("https://www.transparenttextures.com/patterns/stardust.png")' }}></div>

        {/* Content Layer */}
        <div className={`relative z-10 w-full transition-opacity duration-1000 ${showContent ? 'opacity-100' : 'opacity-0'}`}>
            {step === 'RECOGNITION' && renderRecognition()}
            {step === 'HONORING_PAST' && renderHonoring()}
            {step === 'INTEGRATION' && renderIntegration()}
            {step === 'WITNESS' && renderWitness()}
            {step === 'COMPLETION' && renderCompletion()}
        </div>

        {/* Navigation Controls */}
        {step !== 'COMPLETION' && (
            <div className={`absolute bottom-12 flex flex-col items-center space-y-6 transition-opacity duration-1000 ${showContent ? 'opacity-100' : 'opacity-0'}`}>
                <Button onClick={handleNext} size="lg" className="min-w-[200px]" icon={<ArrowRight size={16}/>}>
                    {step === 'RECOGNITION' ? 'Begin Ceremony' : 'Continue'}
                </Button>
                <div className="flex space-x-2">
                    {['RECOGNITION', 'HONORING_PAST', 'INTEGRATION', 'WITNESS', 'COMPLETION'].map((s, i) => {
                        const idx = ['RECOGNITION', 'HONORING_PAST', 'INTEGRATION', 'WITNESS', 'COMPLETION'].indexOf(step);
                        return (
                            <div key={s} className={`w-2 h-2 rounded-full transition-colors duration-500 ${i <= idx ? 'bg-[#F59E0B]' : 'bg-[#2D2D2D]'}`}></div>
                        )
                    })}
                </div>
            </div>
        )}
    </div>
  );
};