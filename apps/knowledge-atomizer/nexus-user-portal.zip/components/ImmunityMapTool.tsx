import React, { useState } from 'react';
import { User, ImmunityMap, AssumptionTest } from '../types';
import { generateEmptyMap, suggestTestingExperiment, analyzeImmunityPattern } from '../services/immunityMapService';
import { Button } from './Button';
import { ShieldAlert, Plus, ArrowRight, X, BrainCircuit, Beaker, CheckCircle2, ChevronRight, Lock, Unlock, AlertTriangle, Save, Edit3, Trash2 } from 'lucide-react';

interface ImmunityMapToolProps {
  user: User;
  onUpdateUser: (user: User) => void;
}

type WizardStep = 0 | 1 | 2 | 3 | 4; // 0=List, 1-4=Columns

export const ImmunityMapTool: React.FC<ImmunityMapToolProps> = ({ user, onUpdateUser }) => {
  const [activeMapId, setActiveMapId] = useState<string | null>(null);
  const [wizardStep, setWizardStep] = useState<WizardStep>(0);
  
  // Local edit state
  const [currentMap, setCurrentMap] = useState<ImmunityMap | null>(null);
  const [inputText, setInputText] = useState('');
  
  // Experiment State
  const [showExperimentModal, setShowExperimentModal] = useState(false);
  const [selectedAssumptionId, setSelectedAssumptionId] = useState<string | null>(null);
  const [experimentDraft, setExperimentDraft] = useState<Partial<AssumptionTest>>({});

  const maps = user.developmentProfile.immunityMaps || [];

  const handleCreateNew = () => {
      const newMap = generateEmptyMap();
      setCurrentMap(newMap);
      setActiveMapId(newMap.id);
      setWizardStep(1); // Start at Col 1
  };

  const handleSelectMap = (map: ImmunityMap) => {
      setCurrentMap(map);
      setActiveMapId(map.id);
      setWizardStep(0); // View mode
  };

  const handleSaveMap = () => {
      if (!currentMap) return;
      const updatedMap = { ...currentMap, lastModified: Date.now() };
      
      const existingIndex = maps.findIndex(m => m.id === updatedMap.id);
      let newMaps = [...maps];
      if (existingIndex >= 0) {
          newMaps[existingIndex] = updatedMap;
      } else {
          newMaps = [updatedMap, ...newMaps];
      }

      onUpdateUser({
          ...user,
          developmentProfile: {
              ...user.developmentProfile,
              immunityMaps: newMaps
          }
      });
      setInputText('');
  };

  const handleAddItem = (column: 1 | 2 | 3 | 4) => {
      if (!inputText.trim() || !currentMap) return;
      
      const updatedMap = { ...currentMap };
      
      if (column === 1) {
          updatedMap.commitment.text = inputText;
          updatedMap.title = inputText.length > 30 ? inputText.substring(0, 30) + '...' : inputText;
      } else if (column === 2) {
          updatedMap.doingNotDoing.behaviors.push(inputText);
      } else if (column === 3) {
          updatedMap.hiddenCommitments.entries.push({
              id: Math.random().toString(36).substr(2, 9),
              text: inputText,
              worry: ''
          });
      } else if (column === 4) {
          updatedMap.bigAssumptions.entries.push({
              id: Math.random().toString(36).substr(2, 9),
              text: inputText,
              certainty: 100
          });
      }
      
      setCurrentMap(updatedMap);
      setInputText('');
      handleSaveMap(); // Auto-save for smooth UX
  };

  const handleDeleteItem = (column: 2 | 3 | 4, id?: string, index?: number) => {
      if (!currentMap) return;
      const updatedMap = { ...currentMap };
      
      if (column === 2 && typeof index === 'number') {
          updatedMap.doingNotDoing.behaviors.splice(index, 1);
      } else if (column === 3 && id) {
          updatedMap.hiddenCommitments.entries = updatedMap.hiddenCommitments.entries.filter(e => e.id !== id);
      } else if (column === 4 && id) {
          updatedMap.bigAssumptions.entries = updatedMap.bigAssumptions.entries.filter(e => e.id !== id);
      }
      
      setCurrentMap(updatedMap);
      handleSaveMap();
  };

  const handleOpenExperiment = (assumptionText: string, assumptionId: string) => {
      const suggestion = suggestTestingExperiment(assumptionText);
      setExperimentDraft(suggestion);
      setSelectedAssumptionId(assumptionId);
      setShowExperimentModal(true);
  };

  const handleSaveExperiment = () => {
      if (!currentMap || !experimentDraft.experimentDesign) return;
      
      const newTest: AssumptionTest = {
          id: Math.random().toString(36).substr(2, 9),
          hypothesis: experimentDraft.hypothesis || '',
          experimentDesign: experimentDraft.experimentDesign,
          outcome: '',
          reflection: '',
          status: 'PLANNED',
          dateStarted: Date.now(),
          riskLevel: experimentDraft.riskLevel
      };

      const updatedMap = {
          ...currentMap,
          tests: [newTest, ...currentMap.tests]
      };
      
      setCurrentMap(updatedMap);
      handleSaveMap();
      setShowExperimentModal(false);
  };

  // --- RENDERERS ---

  const renderMapList = () => (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-in fade-in">
          <div 
            onClick={handleCreateNew}
            className="border-2 border-dashed border-[#2D2D2D] rounded-sm p-8 flex flex-col items-center justify-center cursor-pointer hover:border-[#F5F0E6] hover:bg-[#1A1A1A] transition-all min-h-[200px]"
          >
              <Plus size={32} className="text-[#4A4A4A] mb-4" />
              <h3 className="text-sm font-mono text-[#F5F0E6] uppercase tracking-wide">New Map</h3>
              <p className="text-xs text-[#888888] mt-2">Diagnose a new immunity</p>
          </div>

          {maps.map(map => (
              <div 
                key={map.id}
                onClick={() => handleSelectMap(map)}
                className="bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-6 cursor-pointer hover:border-[#F5F0E6]/50 transition-all relative group min-h-[200px] flex flex-col"
              >
                  <div className="flex justify-between items-start mb-4">
                      <ShieldAlert size={20} className="text-[#F59E0B]" />
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${map.status === 'ACTIVE' ? 'border-green-900 text-green-400' : 'border-[#2D2D2D] text-[#888888]'}`}>
                          {map.status}
                      </span>
                  </div>
                  <h3 className="text-lg font-serif text-[#F5F0E6] mb-2 line-clamp-2">{map.title || 'Untitled Map'}</h3>
                  <p className="text-xs text-[#888888] mb-4">
                      Last modified: {new Date(map.lastModified).toLocaleDateString()}
                  </p>
                  <div className="mt-auto pt-4 border-t border-[#2D2D2D] flex items-center justify-between">
                      <div className="flex items-center space-x-2 text-[10px] font-mono text-[#4A4A4A]">
                          <Beaker size={12} />
                          <span>{map.tests.length} Tests</span>
                      </div>
                      <ChevronRight size={16} className="text-[#4A4A4A] group-hover:text-[#F5F0E6]" />
                  </div>
              </div>
          ))}
      </div>
  );

  const renderColumn = (colNum: 1 | 2 | 3 | 4) => {
      if (!currentMap) return null;
      
      const config = {
          1: { title: "Improvement Goal", color: "text-green-400", border: "border-green-500", desc: "What are you committed to improving?" },
          2: { title: "Doing / Not Doing", color: "text-yellow-400", border: "border-yellow-500", desc: "What behaviors work against your goal?" },
          3: { title: "Hidden Commitment", color: "text-red-400", border: "border-red-500", desc: "I am committed to NOT..." },
          4: { title: "Big Assumption", color: "text-purple-400", border: "border-purple-500", desc: "I assume that if I..." }
      }[colNum];

      return (
          <div className={`flex flex-col h-full bg-[#151515] border-t-4 ${config.border} rounded-sm relative group`}>
              <div className="p-4 border-b border-[#2D2D2D]">
                  <span className={`text-[10px] font-mono ${config.color} uppercase block mb-1`}>Column {colNum}</span>
                  <h3 className="text-sm font-serif text-[#F5F0E6]">{config.title}</h3>
              </div>
              
              <div className="flex-1 p-4 overflow-y-auto custom-scrollbar space-y-3">
                  {colNum === 1 && currentMap.commitment.text && (
                      <div className="p-3 bg-[#0D0D0D] border border-[#2D2D2D] rounded-sm text-sm text-[#F5F0E6]">
                          {currentMap.commitment.text}
                          <button onClick={() => setWizardStep(1)} className="float-right text-[#4A4A4A] hover:text-[#F5F0E6]"><Edit3 size={12}/></button>
                      </div>
                  )}
                  {colNum === 2 && currentMap.doingNotDoing.behaviors.map((item, i) => (
                      <div key={i} className="p-3 bg-[#0D0D0D] border border-[#2D2D2D] rounded-sm text-sm text-[#F5F0E6] flex justify-between group/item">
                          <span>{item}</span>
                          <button onClick={() => handleDeleteItem(2, undefined, i)} className="text-[#4A4A4A] hover:text-red-400 opacity-0 group-hover/item:opacity-100"><X size={12}/></button>
                      </div>
                  ))}
                  {colNum === 3 && currentMap.hiddenCommitments.entries.map(item => (
                      <div key={item.id} className="p-3 bg-[#0D0D0D] border border-[#2D2D2D] rounded-sm text-sm text-[#F5F0E6] flex justify-between group/item">
                          <span>{item.text}</span>
                          <button onClick={() => handleDeleteItem(3, item.id)} className="text-[#4A4A4A] hover:text-red-400 opacity-0 group-hover/item:opacity-100"><X size={12}/></button>
                      </div>
                  ))}
                  {colNum === 4 && currentMap.bigAssumptions.entries.map(item => (
                      <div key={item.id} className="p-3 bg-[#0D0D0D] border border-[#2D2D2D] rounded-sm flex flex-col group/item relative">
                          <div className="flex justify-between items-start mb-2">
                              <span className="text-sm text-[#F5F0E6]">{item.text}</span>
                              <button onClick={() => handleDeleteItem(4, item.id)} className="text-[#4A4A4A] hover:text-red-400 opacity-0 group-hover/item:opacity-100"><X size={12}/></button>
                          </div>
                          <div className="mt-2 pt-2 border-t border-[#2D2D2D] flex justify-end">
                              <button 
                                onClick={() => handleOpenExperiment(item.text, item.id)}
                                className="text-[10px] font-mono text-[#F59E0B] flex items-center hover:underline"
                              >
                                  <Beaker size={10} className="mr-1"/> Test Assumption
                              </button>
                          </div>
                      </div>
                  ))}
                  
                  {/* Quick Add (Visible in View Mode) */}
                  {wizardStep === 0 && (
                      <div className="mt-2">
                          <button 
                            onClick={() => setWizardStep(colNum as WizardStep)}
                            className="w-full py-2 border border-dashed border-[#2D2D2D] rounded-sm text-[#4A4A4A] hover:text-[#F5F0E6] hover:border-[#4A4A4A] flex items-center justify-center transition-all"
                          >
                              <Plus size={12} className="mr-1"/> Add Item
                          </button>
                      </div>
                  )}
              </div>
          </div>
      );
  };

  const renderWizard = () => {
      if (!currentMap) return null;
      
      const prompts = {
          1: { title: "Improvement Goal", desc: "What is the one thing you care most about improving? (e.g., 'I am committed to being a better listener')", placeholder: "I am committed to..." },
          2: { title: "Fearless Inventory", desc: "What are you doing (or not doing) that works against this goal?", placeholder: "I interrupt people..." },
          3: { title: "Hidden Commitment", desc: "Imagine doing the opposite of Col 2. What is the scariest part? Fill in: 'I am committed to NOT...'", placeholder: "I am committed to NOT looking stupid..." },
          4: { title: "Big Assumption", desc: "What bad thing do you assume will happen if you violate your hidden commitment?", placeholder: "I assume that if I listen, I will lose control..." }
      }[wizardStep as 1|2|3|4];

      return (
          <div className="flex flex-col h-full max-w-2xl mx-auto p-8 animate-in slide-in-from-bottom-4">
              <div className="mb-8 text-center">
                  <div className="inline-block p-2 rounded-full border border-[#F59E0B]/30 bg-[#F59E0B]/10 mb-4">
                      <BrainCircuit size={32} className="text-[#F59E0B]" />
                  </div>
                  <h3 className="text-2xl font-serif text-[#F5F0E6] mb-2">{prompts.title}</h3>
                  <p className="text-sm font-mono text-[#888888]">{prompts.desc}</p>
              </div>

              <textarea 
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  className="w-full h-40 bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-4 text-[#F5F0E6] font-mono text-sm focus:outline-none focus:border-[#F59E0B] resize-none mb-4"
                  placeholder={prompts.placeholder}
                  autoFocus
              />

              <div className="flex justify-between items-center">
                  <Button variant="secondary" onClick={() => setWizardStep(0)}>Cancel</Button>
                  <div className="flex space-x-2">
                      <Button 
                        onClick={() => handleAddItem(wizardStep as 1|2|3|4)} 
                        disabled={!inputText.trim()}
                        icon={<Plus size={14}/>}
                      >
                          Add to Map
                      </Button>
                      <Button onClick={() => setWizardStep(wizardStep < 4 ? (wizardStep + 1) as WizardStep : 0)} variant="secondary">
                          {wizardStep === 4 ? 'Finish' : 'Next Column'} <ChevronRight size={14}/>
                      </Button>
                  </div>
              </div>
          </div>
      );
  };

  return (
    <div className="flex flex-col h-full bg-[#0D0D0D] relative overflow-hidden">
        
        {/* Header */}
        <div className="h-16 border-b border-[#2D2D2D] flex items-center justify-between px-8 bg-[#151515]">
            <div className="flex items-center space-x-3">
                <ShieldAlert size={20} className="text-[#F59E0B]" />
                <h2 className="text-lg font-serif text-[#F5F0E6] uppercase tracking-wide">
                    {activeMapId ? (currentMap?.title || 'Untitled Map') : 'Immunity to Change Maps'}
                </h2>
            </div>
            {activeMapId && (
                <div className="flex items-center space-x-4">
                    <div className="text-[10px] font-mono text-[#888888] uppercase hidden md:block">
                        {analyzeImmunityPattern(currentMap!)}
                    </div>
                    <Button size="sm" variant="secondary" onClick={() => { setActiveMapId(null); setCurrentMap(null); }}>
                        Back to List
                    </Button>
                </div>
            )}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-hidden relative">
            {!activeMapId ? (
                <div className="h-full overflow-y-auto custom-scrollbar p-8">
                    {renderMapList()}
                </div>
            ) : wizardStep > 0 ? (
                renderWizard()
            ) : (
                <div className="h-full flex flex-col p-6 animate-in fade-in">
                    {/* Columns */}
                    <div className="flex-1 grid grid-cols-1 md:grid-cols-4 gap-4 h-full">
                        {renderColumn(1)}
                        {renderColumn(2)}
                        {renderColumn(3)}
                        {renderColumn(4)}
                    </div>
                    
                    {/* Experiments Section */}
                    {currentMap && currentMap.tests.length > 0 && (
                        <div className="mt-6 border-t border-[#2D2D2D] pt-6">
                            <h3 className="text-xs font-mono text-[#F5F0E6] uppercase tracking-wide mb-4 flex items-center">
                                <Beaker size={14} className="mr-2 text-[#F59E0B]"/> Active Experiments
                            </h3>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                {currentMap.tests.map(test => (
                                    <div key={test.id} className="bg-[#1A1A1A] border border-[#2D2D2D] p-4 rounded-sm">
                                        <div className="flex justify-between items-start mb-2">
                                            <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded border ${test.riskLevel === 'SAFE' ? 'border-green-900 text-green-400' : 'border-yellow-900 text-yellow-400'}`}>
                                                {test.riskLevel}
                                            </span>
                                            <span className="text-[10px] text-[#4A4A4A]">{new Date(test.dateStarted).toLocaleDateString()}</span>
                                        </div>
                                        <p className="text-xs text-[#F5F0E6] mb-2">{test.experimentDesign}</p>
                                        <p className="text-[10px] text-[#888888] italic">Hypothesis: {test.hypothesis}</p>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            )}
        </div>

        {/* Experiment Modal */}
        {showExperimentModal && (
            <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-sm flex items-center justify-center p-6 animate-in fade-in">
                <div className="bg-[#151515] border border-[#F59E0B]/50 w-full max-w-lg rounded-sm p-6 shadow-2xl">
                    <div className="flex justify-between items-start mb-6">
                        <h3 className="text-xl font-serif text-[#F5F0E6]">Design Experiment</h3>
                        <button onClick={() => setShowExperimentModal(false)} className="text-[#888888] hover:text-[#F5F0E6]"><X size={20}/></button>
                    </div>
                    
                    <div className="space-y-4 mb-6">
                        <div>
                            <label className="text-[10px] font-mono text-[#888888] uppercase block mb-1">Assumption</label>
                            <p className="text-sm text-[#F5F0E6] p-2 bg-[#0D0D0D] border border-[#2D2D2D] rounded-sm">
                                {currentMap?.bigAssumptions.entries.find(e => e.id === selectedAssumptionId)?.text}
                            </p>
                        </div>
                        <div>
                            <label className="text-[10px] font-mono text-[#F59E0B] uppercase block mb-1">Experiment (Action)</label>
                            <textarea 
                                className="w-full h-20 bg-[#0D0D0D] border border-[#2D2D2D] p-3 text-sm text-[#F5F0E6] focus:outline-none focus:border-[#F59E0B]"
                                value={experimentDraft.experimentDesign || ''}
                                onChange={(e) => setExperimentDraft({...experimentDraft, experimentDesign: e.target.value})}
                            />
                        </div>
                        <div>
                            <label className="text-[10px] font-mono text-[#F59E0B] uppercase block mb-1">Hypothesis (Prediction)</label>
                            <textarea 
                                className="w-full h-20 bg-[#0D0D0D] border border-[#2D2D2D] p-3 text-sm text-[#F5F0E6] focus:outline-none focus:border-[#F59E0B]"
                                value={experimentDraft.hypothesis || ''}
                                onChange={(e) => setExperimentDraft({...experimentDraft, hypothesis: e.target.value})}
                            />
                        </div>
                        <div className="flex items-center space-x-4">
                            <span className="text-[10px] font-mono text-[#888888] uppercase">Risk Level:</span>
                            <div className="flex space-x-2">
                                {['SAFE', 'MODERATE', 'EDGE'].map(lvl => (
                                    <button 
                                        key={lvl}
                                        onClick={() => setExperimentDraft({...experimentDraft, riskLevel: lvl as any})}
                                        className={`px-3 py-1 text-[10px] font-mono border rounded-sm ${experimentDraft.riskLevel === lvl ? 'bg-[#F59E0B] text-[#0D0D0D] border-[#F59E0B]' : 'bg-[#0D0D0D] text-[#888888] border-[#2D2D2D]'}`}
                                    >
                                        {lvl}
                                    </button>
                                ))}
                            </div>
                        </div>
                    </div>

                    <div className="flex justify-end space-x-3">
                        <Button variant="secondary" onClick={() => setShowExperimentModal(false)}>Cancel</Button>
                        <Button onClick={handleSaveExperiment} icon={<Beaker size={14}/>}>Launch Experiment</Button>
                    </div>
                </div>
            </div>
        )}
    </div>
  );
};