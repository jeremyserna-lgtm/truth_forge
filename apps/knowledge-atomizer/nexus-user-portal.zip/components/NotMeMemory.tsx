import React, { useState } from 'react';
import { NotMeCompanion, NotMeMemory as NotMeMemoryType, MemoryType, KeganStage } from '../types';
import { Clock, TrendingUp, HelpCircle, Fingerprint, Trash2, MapPin, Eye, Lock } from 'lucide-react';
import { Button } from './Button';

interface NotMeMemoryProps {
  companion: NotMeCompanion;
  onForget: (memoryId: string) => void;
}

export const NotMeMemory: React.FC<NotMeMemoryProps> = ({ companion, onForget }) => {
  const [activeTab, setActiveTab] = useState<'TIMELINE' | 'PATTERNS' | 'CURIOSITY'>('TIMELINE');
  const [selectedMemory, setSelectedMemory] = useState<NotMeMemoryType | null>(null);

  const memories = companion.memories || [];

  const getIcon = (type: MemoryType) => {
      switch(type) {
          case 'MOMENT': return <Clock size={16} className="text-blue-400" />;
          case 'PATTERN': return <Fingerprint size={16} className="text-[#F59E0B]" />;
          case 'GROWTH': return <TrendingUp size={16} className="text-green-400" />;
          case 'CURIOSITY': return <HelpCircle size={16} className="text-purple-400" />;
      }
  };

  const getStageBadge = (stage?: KeganStage) => {
      if (!stage) return null;
      const num = stage === KeganStage.STAGE_3_SOCIALIZED ? '3' : stage === KeganStage.STAGE_4_SELF_AUTHORING ? '4' : '5';
      const color = stage === KeganStage.STAGE_3_SOCIALIZED ? 'text-blue-400 border-blue-900' : stage === KeganStage.STAGE_4_SELF_AUTHORING ? 'text-green-400 border-green-900' : 'text-[#F59E0B] border-[#F59E0B]/50';
      return (
          <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded border ${color}`}>
              STG {num}
          </span>
      );
  };

  const renderTimeline = () => (
      <div className="space-y-6 relative pl-6">
          <div className="absolute left-3 top-0 bottom-0 w-[1px] bg-[#2D2D2D]"></div>
          
          {memories.sort((a, b) => b.timestamp - a.timestamp).map(mem => (
              <div key={mem.id} className="relative group">
                  {/* Timeline Node */}
                  <div className="absolute left-[-16px] top-4 w-2 h-2 rounded-full bg-[#1A1A1A] border border-[#4A4A4A] group-hover:border-[#F5F0E6] group-hover:scale-125 transition-all z-10"></div>
                  
                  <div 
                    className={`p-4 bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm hover:border-[#4A4A4A] transition-colors cursor-pointer ${selectedMemory?.id === mem.id ? 'border-[#F5F0E6]' : ''}`}
                    onClick={() => setSelectedMemory(selectedMemory?.id === mem.id ? null : mem)}
                  >
                      <div className="flex justify-between items-start mb-2">
                          <div className="flex items-center space-x-2">
                              {getIcon(mem.type)}
                              <span className="text-xs font-mono text-[#888888] uppercase tracking-wide">{mem.type}</span>
                          </div>
                          <div className="flex items-center space-x-2">
                              {getStageBadge(mem.keganStage)}
                              <span className="text-[10px] font-mono text-[#4A4A4A]">{new Date(mem.timestamp).toLocaleDateString()}</span>
                          </div>
                      </div>
                      <p className="text-sm text-[#F5F0E6] font-serif leading-relaxed line-clamp-2 group-hover:line-clamp-none transition-all">
                          "{mem.content}"
                      </p>
                      
                      {/* Expanded Details */}
                      {selectedMemory?.id === mem.id && (
                          <div className="mt-4 pt-4 border-t border-[#2D2D2D] animate-in fade-in">
                              <div className="mb-3">
                                  <span className="text-[10px] font-mono text-[#F59E0B] uppercase tracking-widest block mb-1">Reason for Retention</span>
                                  <p className="text-xs text-[#888888] italic">{mem.significance}</p>
                              </div>
                              <div className="flex justify-end">
                                  {mem.isCore ? (
                                      <span className="text-[10px] font-mono text-[#4A4A4A] flex items-center"><Lock size={10} className="mr-1"/> Core Memory</span>
                                  ) : (
                                      <button 
                                        onClick={(e) => { e.stopPropagation(); onForget(mem.id); }}
                                        className="text-[10px] font-mono text-red-400 hover:text-red-300 flex items-center"
                                      >
                                          <Trash2 size={12} className="mr-1" /> Forget This
                                      </button>
                                  )}
                              </div>
                          </div>
                      )}
                  </div>
              </div>
          ))}
          {memories.length === 0 && (
              <div className="text-center py-12 text-[#4A4A4A] text-xs font-mono">
                  No memories recorded yet. Engage in dialogue to build narrative.
              </div>
          )}
      </div>
  );

  const renderPatterns = () => (
      <div className="grid grid-cols-1 gap-4">
          {memories.filter(m => m.type === 'PATTERN').map(mem => (
              <div key={mem.id} className="p-5 border border-[#2D2D2D] bg-[#1A1A1A] rounded-sm hover:border-[#F59E0B]/50 transition-colors">
                  <div className="flex items-start space-x-4">
                      <div className="p-2 bg-[#F59E0B]/10 rounded-full border border-[#F59E0B]/30">
                          <Fingerprint size={20} className="text-[#F59E0B]" />
                      </div>
                      <div>
                          <h4 className="text-sm font-serif text-[#F5F0E6] mb-1">Detected Pattern</h4>
                          <p className="text-xs text-[#F5F0E6] leading-relaxed mb-2">{mem.content}</p>
                          <p className="text-[10px] text-[#888888] font-mono border-l-2 border-[#4A4A4A] pl-2">{mem.significance}</p>
                      </div>
                  </div>
              </div>
          ))}
          {memories.filter(m => m.type === 'PATTERN').length === 0 && (
              <div className="text-center py-12 border border-dashed border-[#2D2D2D] rounded-sm">
                  <Eye size={24} className="mx-auto text-[#4A4A4A] mb-2" />
                  <p className="text-[#4A4A4A] text-xs font-mono">Not-Me is still observing your baseline.</p>
              </div>
          )}
      </div>
  );

  const renderCuriosities = () => (
      <div className="space-y-4">
          <div className="p-4 bg-purple-900/10 border border-purple-900/30 rounded-sm">
              <h3 className="text-sm font-mono text-purple-400 uppercase tracking-wide mb-2">Active Questions</h3>
              <p className="text-xs text-[#888888]">
                  These are the questions I am holding about your development. I may ask them when the timing is right.
              </p>
          </div>
          <div className="grid grid-cols-1 gap-3">
              {memories.filter(m => m.type === 'CURIOSITY').map(mem => (
                  <div key={mem.id} className="p-4 bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm flex items-start space-x-3">
                      <HelpCircle size={16} className="text-purple-400 mt-0.5 flex-shrink-0" />
                      <div>
                          <p className="text-sm text-[#F5F0E6] italic">"{mem.content}"</p>
                          <div className="mt-2 text-[10px] text-[#4A4A4A] font-mono uppercase">
                              Formed: {new Date(mem.timestamp).toLocaleDateString()}
                          </div>
                      </div>
                  </div>
              ))}
          </div>
      </div>
  );

  return (
    <div className="flex flex-col h-full animate-in fade-in duration-500">
        {/* Header Tabs */}
        <div className="flex items-center space-x-1 mb-6 border-b border-[#2D2D2D] pb-1">
            <button 
                onClick={() => setActiveTab('TIMELINE')}
                className={`px-4 py-2 text-xs font-mono uppercase tracking-wider border-b-2 transition-all ${activeTab === 'TIMELINE' ? 'border-[#F5F0E6] text-[#F5F0E6]' : 'border-transparent text-[#888888] hover:text-[#B5B5B5]'}`}
            >
                Our Story
            </button>
            <button 
                onClick={() => setActiveTab('PATTERNS')}
                className={`px-4 py-2 text-xs font-mono uppercase tracking-wider border-b-2 transition-all ${activeTab === 'PATTERNS' ? 'border-[#F59E0B] text-[#F59E0B]' : 'border-transparent text-[#888888] hover:text-[#B5B5B5]'}`}
            >
                Observed Patterns
            </button>
            <button 
                onClick={() => setActiveTab('CURIOSITY')}
                className={`px-4 py-2 text-xs font-mono uppercase tracking-wider border-b-2 transition-all ${activeTab === 'CURIOSITY' ? 'border-purple-400 text-purple-400' : 'border-transparent text-[#888888] hover:text-[#B5B5B5]'}`}
            >
                Curiosities
            </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto custom-scrollbar pr-2">
            {activeTab === 'TIMELINE' && renderTimeline()}
            {activeTab === 'PATTERNS' && renderPatterns()}
            {activeTab === 'CURIOSITY' && renderCuriosities()}
        </div>
    </div>
  );
};