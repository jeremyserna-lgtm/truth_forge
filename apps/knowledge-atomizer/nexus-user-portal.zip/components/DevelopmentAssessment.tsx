import React, { useState, useEffect } from 'react';
import { User, KeganStage, AssessmentResult } from '../types';
import { ASSESSMENT_QUESTIONS, calculateAssessmentResult, generateNotMePrompt } from '../services/assessmentService';
import { Button } from './Button';
import { Brain, ArrowRight, Check, Activity, Sparkles, Bot, Loader2 } from 'lucide-react';

interface DevelopmentAssessmentProps {
  user: User;
  onComplete: (result: AssessmentResult) => void;
}

type AssessmentState = 'INTRO' | 'QUESTION' | 'ANALYZING' | 'RESULT';

export const DevelopmentAssessment: React.FC<DevelopmentAssessmentProps> = ({ user, onComplete }) => {
  const [viewState, setViewState] = useState<AssessmentState>('INTRO');
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [responses, setResponses] = useState<{ questionId: string; stage: KeganStage }[]>([]);
  const [result, setResult] = useState<AssessmentResult | null>(null);

  const currentQuestion = ASSESSMENT_QUESTIONS[currentQuestionIdx];
  const companionName = user.notMeCompanion?.name || "Not-Me";

  // Progress calculations
  const progress = ((currentQuestionIdx) / ASSESSMENT_QUESTIONS.length) * 100;

  const handleStart = () => {
      setViewState('QUESTION');
  };

  const handleOptionSelect = (stage: KeganStage) => {
      const newResponses = [...responses, { questionId: currentQuestion.id, stage }];
      setResponses(newResponses);

      if (currentQuestionIdx < ASSESSMENT_QUESTIONS.length - 1) {
          // Add a small delay for smooth transition
          setTimeout(() => setCurrentQuestionIdx(prev => prev + 1), 300);
      } else {
          setViewState('ANALYZING');
          setTimeout(() => {
              const calcResult = calculateAssessmentResult(newResponses);
              setResult(calcResult);
              onComplete(calcResult); // Save to parent/DB
              setViewState('RESULT');
          }, 2500);
      }
  };

  const getStageDescription = (stage: KeganStage) => {
      switch(stage) {
          case KeganStage.STAGE_2_IMPERIAL: return "The Imperial Mind: Focused on concrete needs and interests.";
          case KeganStage.STAGE_3_SOCIALIZED: return "The Socialized Mind: Defined by relationships and external expectations.";
          case KeganStage.STAGE_4_SELF_AUTHORING: return "The Self-Authoring Mind: Defined by internal values and systems.";
          case KeganStage.STAGE_5_SELF_TRANSFORMING: return "The Self-Transforming Mind: Defined by the capacity to hold multiplicity.";
          default: return "Impulsive Mind.";
      }
  };

  if (viewState === 'INTRO') {
      return (
          <div className="h-full flex flex-col items-center justify-center p-8 text-center animate-in fade-in duration-700">
              <div className="w-24 h-24 bg-[#1A1A1A] border border-[#F59E0B] rounded-full flex items-center justify-center mb-8 relative">
                  <div className="absolute inset-0 rounded-full border border-[#F59E0B] animate-ping opacity-20"></div>
                  <Brain size={48} className="text-[#F59E0B]" />
              </div>
              <h2 className="text-3xl font-serif text-[#F5F0E6] mb-4">Developmental Mapping</h2>
              <p className="text-sm font-mono text-[#888888] max-w-lg mb-8 leading-relaxed">
                  To serve your evolution, we must map the structure of your meaning-making. 
                  This is not a test of intelligence, but a calibration of your current reality tunnel.
              </p>
              <div className="bg-[#1A1A1A] border-l-4 border-[#F59E0B] p-4 max-w-md text-left mb-8 rounded-r-sm">
                  <span className="text-[10px] font-mono text-[#F59E0B] uppercase tracking-widest block mb-2">{companionName} says:</span>
                  <p className="text-sm text-[#F5F0E6] italic">"Be honest. I cannot help you navigate a map if we do not know where you truly stand."</p>
              </div>
              <Button size="lg" onClick={handleStart} icon={<ArrowRight size={16}/>}>Begin Calibration</Button>
          </div>
      );
  }

  if (viewState === 'QUESTION') {
      return (
          <div className="h-full flex flex-col max-w-4xl mx-auto p-8 animate-in fade-in duration-500">
              {/* Header / Progress */}
              <div className="mb-12">
                  <div className="flex justify-between items-center mb-4">
                      <span className="text-xs font-mono text-[#888888] uppercase tracking-widest">Scenario {currentQuestionIdx + 1} of {ASSESSMENT_QUESTIONS.length}</span>
                      <span className="text-xs font-mono text-[#F59E0B]">{Math.round(progress)}% Calibration</span>
                  </div>
                  <div className="h-1 w-full bg-[#1A1A1A] rounded-full overflow-hidden">
                      <div className="h-full bg-[#F59E0B] transition-all duration-500 ease-out" style={{ width: `${progress}%` }}></div>
                  </div>
              </div>

              {/* Question Card */}
              <div className="flex-1 flex flex-col justify-center">
                  <h3 className="text-2xl font-serif text-[#F5F0E6] mb-8 leading-relaxed">
                      {currentQuestion.scenario}
                  </h3>

                  <div className="grid grid-cols-1 gap-4">
                      {currentQuestion.options.map((option, idx) => (
                          <button
                              key={idx}
                              onClick={() => handleOptionSelect(option.stageIndicator)}
                              className="text-left p-6 border border-[#2D2D2D] bg-[#1A1A1A] rounded-sm hover:border-[#F59E0B] hover:bg-[#F59E0B]/5 transition-all group relative overflow-hidden"
                          >
                              <div className="relative z-10 flex items-start space-x-4">
                                  <div className="mt-1 w-4 h-4 rounded-full border border-[#4A4A4A] group-hover:border-[#F59E0B] flex-shrink-0"></div>
                                  <span className="text-sm font-sans text-[#F5F0E6] group-hover:text-white leading-relaxed">{option.text}</span>
                              </div>
                          </button>
                      ))}
                  </div>
              </div>
          </div>
      );
  }

  if (viewState === 'ANALYZING') {
      return (
          <div className="h-full flex flex-col items-center justify-center p-8 text-center animate-in fade-in">
              <Loader2 size={64} className="text-[#F59E0B] animate-spin mb-6" />
              <h3 className="text-xl font-mono text-[#F5F0E6] uppercase tracking-widest mb-2">Analyzing Structures</h3>
              <p className="text-sm text-[#888888]">Mapping subject-object relationships...</p>
          </div>
      );
  }

  if (viewState === 'RESULT' && result) {
      return (
          <div className="h-full flex flex-col overflow-y-auto custom-scrollbar p-8 animate-in slide-in-from-bottom-8 duration-700">
              <div className="max-w-3xl mx-auto w-full space-y-8">
                  
                  {/* Header Result */}
                  <div className="text-center space-y-4 border-b border-[#2D2D2D] pb-8">
                      <div className="inline-flex items-center justify-center p-3 bg-[#F59E0B]/10 rounded-full border border-[#F59E0B]/30 mb-2">
                          <Activity size={32} className="text-[#F59E0B]" />
                      </div>
                      <h2 className="text-4xl font-serif text-[#F5F0E6]">
                          {result.calculatedStage.replace('STAGE_', '').replace(/_/g, ' ')}
                      </h2>
                      <p className="text-sm font-mono text-[#888888] uppercase tracking-widest">
                          Current Operating System • {result.stageConfidence}% Confidence
                      </p>
                  </div>

                  {/* Description Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="p-6 bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm">
                          <h4 className="text-xs font-mono text-[#F5F0E6] uppercase tracking-wide mb-3 flex items-center">
                              <Brain size={14} className="mr-2" /> Structural Definition
                          </h4>
                          <p className="text-sm text-[#888888] leading-relaxed">
                              {getStageDescription(result.calculatedStage)}
                          </p>
                      </div>
                      
                      <div className="p-6 bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm">
                          <h4 className="text-xs font-mono text-[#F5F0E6] uppercase tracking-wide mb-3 flex items-center">
                              <Sparkles size={14} className="mr-2" /> The Growth Edge
                          </h4>
                          <p className="text-sm text-[#F5F0E6] leading-relaxed">
                              {result.growthEdge}
                          </p>
                      </div>
                  </div>

                  {/* Not-Me Response */}
                  <div className="bg-[#0D0D0D] border-l-4 border-[#F59E0B] p-6 rounded-r-sm">
                      <div className="flex items-center space-x-2 mb-3">
                          <Bot size={16} className="text-[#F59E0B]" />
                          <span className="text-xs font-mono text-[#F59E0B] uppercase">{companionName}'s Protocol</span>
                      </div>
                      <p className="text-lg font-serif text-[#F5F0E6] italic leading-relaxed">
                          "{generateNotMePrompt(result.calculatedStage)}"
                      </p>
                  </div>

                  <div className="flex justify-center pt-8">
                      <Button onClick={() => console.log("Navigate to Dashboard")} icon={<Check size={16}/>}>
                          Enter Portal
                      </Button>
                  </div>
              </div>
          </div>
      );
  }

  return null;
};