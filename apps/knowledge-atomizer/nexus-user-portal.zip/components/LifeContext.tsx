import React, { useState } from 'react';
import { LifeDomain, LifeLogEntry, LifeContextState, User } from '../types';
import { Button } from './Button';
import { Briefcase, Heart, Palette, Sparkles, Activity, Shield, Plus, X, ArrowRight, MessageSquare, Lock, Unlock, TrendingUp, AlertTriangle } from 'lucide-react';

interface LifeContextProps {
  user: User;
  onUpdateUser: (user: User) => void;
}

type DomainIconType = 'WORK' | 'FAMILY' | 'CREATIVE' | 'SPIRITUAL' | 'HEALTH' | 'OTHER';

export const LifeContext: React.FC<LifeContextProps> = ({ user, onUpdateUser }) => {
  const [selectedDomainId, setSelectedDomainId] = useState<string | null>(null);
  const [isAddingDomain, setIsAddingDomain] = useState(false);
  const [newDomainName, setNewDomainName] = useState('');
  const [newDomainType, setNewDomainType] = useState<DomainIconType>('OTHER');
  
  // Log Entry State
  const [logContent, setLogContent] = useState('');
  const [logType, setLogType] = useState<'CHALLENGE' | 'WIN'>('CHALLENGE');
  const [isSavingLog, setIsSavingLog] = useState(false);

  const context = user.developmentProfile.lifeContext || { domains: [], interactions: [] };
  const domains = context.domains;

  const getIcon = (type: string | undefined) => {
      // Simple mapping based on name or explicit icon field if we had one
      // For now, heuristic based on name for existing, or explicit for new
      const name = type?.toUpperCase() || '';
      if (name.includes('WORK') || name.includes('CAREER')) return <Briefcase size={20} className="text-blue-400" />;
      if (name.includes('FAMILY') || name.includes('RELATIONSHIP')) return <Heart size={20} className="text-red-400" />;
      if (name.includes('CREAT') || name.includes('ART')) return <Palette size={20} className="text-purple-400" />;
      if (name.includes('SPIRIT') || name.includes('SOUL')) return <Sparkles size={20} className="text-[#F59E0B]" />;
      if (name.includes('HEALTH') || name.includes('BODY')) return <Activity size={20} className="text-green-400" />;
      return <Shield size={20} className="text-[#888888]" />;
  };

  const handleAddDomain = () => {
      if (!newDomainName.trim()) return;
      const newDomain: LifeDomain = {
          id: Math.random().toString(36).substr(2, 9),
          name: newDomainName,
          description: 'New area of focus.',
          harmonyScore: 70,
          allowAiAccess: true,
          logs: [],
          keganRelevance: 'Developmental edge unmapped.'
      };

      const updatedUser = {
          ...user,
          developmentProfile: {
              ...user.developmentProfile,
              lifeContext: {
                  ...context,
                  domains: [...domains, newDomain]
              }
          }
      };
      onUpdateUser(updatedUser);
      setIsAddingDomain(false);
      setNewDomainName('');
  };

  const handleAddLog = (domainId: string) => {
      if (!logContent.trim()) return;
      setIsSavingLog(true);
      
      setTimeout(() => {
          const newLog: LifeLogEntry = {
              id: Math.random().toString(36).substr(2, 9),
              content: logContent,
              type: logType,
              timestamp: Date.now()
          };

          const updatedDomains = domains.map(d => {
              if (d.id === domainId) {
                  return { ...d, logs: [newLog, ...d.logs] };
              }
              return d;
          });

          const updatedUser = {
              ...user,
              developmentProfile: {
                  ...user.developmentProfile,
                  lifeContext: {
                      ...context,
                      domains: updatedDomains
                  }
              }
          };
          onUpdateUser(updatedUser);
          setLogContent('');
          setIsSavingLog(false);
      }, 800);
  };

  const toggleAiAccess = (domainId: string) => {
      const updatedDomains = domains.map(d => {
          if (d.id === domainId) {
              return { ...d, allowAiAccess: !d.allowAiAccess };
          }
          return d;
      });
      const updatedUser = {
          ...user,
          developmentProfile: {
              ...user.developmentProfile,
              lifeContext: { ...context, domains: updatedDomains }
          }
      };
      onUpdateUser(updatedUser);
  };

  const selectedDomain = domains.find(d => d.id === selectedDomainId);

  return (
    <div className="flex h-full animate-in fade-in duration-500">
        {/* Left: Domain Grid */}
        <div className={`flex-1 p-8 overflow-y-auto custom-scrollbar border-r border-[#2D2D2D] transition-all ${selectedDomain ? 'w-1/2' : 'w-full'}`}>
            <header className="mb-8 flex justify-between items-center">
                <div>
                    <h2 className="text-2xl font-serif text-[#F5F0E6] uppercase tracking-wide">Life Architecture</h2>
                    <p className="text-sm font-mono text-[#888888] mt-2">Map the context of your development.</p>
                </div>
                <Button size="sm" onClick={() => setIsAddingDomain(true)} icon={<Plus size={14}/>}>Add Domain</Button>
            </header>

            {isAddingDomain && (
                <div className="mb-6 p-4 bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm animate-in slide-in-from-top-2">
                    <h3 className="text-xs font-mono text-[#F5F0E6] uppercase mb-3">Define New Domain</h3>
                    <div className="flex space-x-3 mb-3">
                        <input 
                            type="text" 
                            value={newDomainName}
                            onChange={(e) => setNewDomainName(e.target.value)}
                            placeholder="Domain Name (e.g. Career, Family)"
                            className="flex-1 bg-[#0D0D0D] border border-[#2D2D2D] p-2 text-sm text-[#F5F0E6] focus:outline-none focus:border-[#F5F0E6] rounded-sm"
                        />
                    </div>
                    <div className="flex justify-end space-x-2">
                        <Button size="sm" variant="secondary" onClick={() => setIsAddingDomain(false)}>Cancel</Button>
                        <Button size="sm" onClick={handleAddDomain} disabled={!newDomainName}>Create</Button>
                    </div>
                </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {domains.map(domain => (
                    <div 
                        key={domain.id} 
                        onClick={() => setSelectedDomainId(domain.id)}
                        className={`p-6 border rounded-sm cursor-pointer transition-all hover:bg-[#1A1A1A] group relative overflow-hidden ${selectedDomainId === domain.id ? 'border-[#F5F0E6] bg-[#1A1A1A]' : 'border-[#2D2D2D] bg-[#0D0D0D]'}`}
                    >
                        <div className="flex justify-between items-start mb-4 relative z-10">
                            <div className="flex items-center space-x-3">
                                <div className="p-2 bg-[#2D2D2D] rounded-full border border-[#4A4A4A]">
                                    {getIcon(domain.name)}
                                </div>
                                <div>
                                    <h3 className="text-lg font-serif text-[#F5F0E6]">{domain.name}</h3>
                                    <div className="text-[10px] font-mono text-[#888888] flex items-center space-x-2">
                                        <span>{domain.logs.length} Entries</span>
                                        {!domain.allowAiAccess && <span className="text-[#4A4A4A] flex items-center"><Lock size={10} className="mr-1"/> Private</span>}
                                    </div>
                                </div>
                            </div>
                            <div className="text-right">
                                <div className={`text-2xl font-mono ${domain.harmonyScore > 80 ? 'text-green-400' : domain.harmonyScore < 50 ? 'text-red-400' : 'text-[#F59E0B]'}`}>
                                    {domain.harmonyScore}%
                                </div>
                                <div className="text-[8px] uppercase text-[#4A4A4A] tracking-wider">Harmony</div>
                            </div>
                        </div>
                        
                        {/* Harmony Bar */}
                        <div className="h-1 bg-[#2D2D2D] rounded-full overflow-hidden relative z-10">
                            <div 
                                className={`h-full ${domain.harmonyScore > 80 ? 'bg-green-500' : domain.harmonyScore < 50 ? 'bg-red-500' : 'bg-[#F59E0B]'}`} 
                                style={{ width: `${domain.harmonyScore}%` }}
                            ></div>
                        </div>

                        {/* Hover Overlay Gradient */}
                        <div className="absolute inset-0 bg-gradient-to-br from-transparent to-[#F5F0E6]/5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
                    </div>
                ))}
                
                {domains.length === 0 && !isAddingDomain && (
                    <div className="col-span-2 p-12 border border-dashed border-[#2D2D2D] rounded-sm text-center">
                        <Activity size={32} className="text-[#4A4A4A] mx-auto mb-4" />
                        <p className="text-sm text-[#888888] font-mono">No domains configured.</p>
                        <p className="text-xs text-[#4A4A4A] mt-2">Add a life domain to begin mapping your context.</p>
                    </div>
                )}
            </div>
        </div>

        {/* Right: Domain Details */}
        {selectedDomain && (
            <div className="w-96 bg-[#151515] flex flex-col h-full border-l border-[#2D2D2D] animate-in slide-in-from-right duration-500">
                <div className="p-6 border-b border-[#2D2D2D] flex justify-between items-start">
                    <div>
                        <div className="flex items-center space-x-2 mb-1">
                            {getIcon(selectedDomain.name)}
                            <h2 className="text-xl font-serif text-[#F5F0E6]">{selectedDomain.name}</h2>
                        </div>
                        <p className="text-xs text-[#888888] font-mono line-clamp-1">{selectedDomain.description}</p>
                    </div>
                    <button onClick={() => setSelectedDomainId(null)} className="text-[#4A4A4A] hover:text-[#F5F0E6]">
                        <X size={20} />
                    </button>
                </div>

                {/* AI Privacy Control */}
                <div className="px-6 py-3 border-b border-[#2D2D2D] bg-[#1A1A1A] flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                        {selectedDomain.allowAiAccess ? <Unlock size={14} className="text-green-400" /> : <Lock size={14} className="text-red-400" />}
                        <span className="text-xs font-mono text-[#F5F0E6] uppercase tracking-wide">Not-Me Access</span>
                    </div>
                    <button 
                        onClick={() => toggleAiAccess(selectedDomain.id)}
                        className={`text-[10px] font-mono px-2 py-1 rounded border ${selectedDomain.allowAiAccess ? 'border-green-900 text-green-400 bg-green-900/10' : 'border-red-900 text-red-400 bg-red-900/10'}`}
                    >
                        {selectedDomain.allowAiAccess ? 'ENABLED' : 'BLOCKED'}
                    </button>
                </div>

                <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
                    {/* Not-Me Insight */}
                    {selectedDomain.allowAiAccess && (
                        <div className="p-4 bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm relative overflow-hidden">
                            <div className="flex items-center space-x-2 mb-2">
                                <Sparkles size={14} className="text-[#F59E0B]" />
                                <span className="text-xs font-mono text-[#F59E0B] uppercase tracking-wide">Developmental Insight</span>
                            </div>
                            <p className="text-xs text-[#F5F0E6] italic leading-relaxed">
                                "{selectedDomain.keganRelevance}"
                            </p>
                        </div>
                    )}

                    {/* Add Log */}
                    <div className="space-y-3">
                        <div className="flex space-x-2">
                            <button 
                                onClick={() => setLogType('CHALLENGE')}
                                className={`flex-1 py-1 text-[10px] font-mono uppercase rounded-sm border ${logType === 'CHALLENGE' ? 'bg-red-900/20 border-red-900 text-red-400' : 'border-[#2D2D2D] text-[#888888]'}`}
                            >
                                Log Challenge
                            </button>
                            <button 
                                onClick={() => setLogType('WIN')}
                                className={`flex-1 py-1 text-[10px] font-mono uppercase rounded-sm border ${logType === 'WIN' ? 'bg-green-900/20 border-green-900 text-green-400' : 'border-[#2D2D2D] text-[#888888]'}`}
                            >
                                Log Win
                            </button>
                        </div>
                        <textarea 
                            className="w-full h-24 bg-[#0D0D0D] border border-[#2D2D2D] rounded-sm p-3 text-xs text-[#F5F0E6] focus:outline-none focus:border-[#F5F0E6] resize-none"
                            placeholder={logType === 'CHALLENGE' ? "What is the current friction?" : "What growth occurred?"}
                            value={logContent}
                            onChange={(e) => setLogContent(e.target.value)}
                        />
                        <div className="flex justify-end">
                            <Button size="sm" onClick={() => handleAddLog(selectedDomain.id)} isLoading={isSavingLog} icon={<ArrowRight size={12}/>}>Save Entry</Button>
                        </div>
                    </div>

                    {/* Log History */}
                    <div className="space-y-4">
                        <h4 className="text-xs font-mono text-[#888888] uppercase tracking-wide border-b border-[#2D2D2D] pb-2">Recent Activity</h4>
                        {selectedDomain.logs.length === 0 && (
                            <div className="text-center text-[#4A4A4A] text-xs py-4">No entries recorded.</div>
                        )}
                        {selectedDomain.logs.map(log => (
                            <div key={log.id} className="group">
                                <div className="flex items-start space-x-3">
                                    <div className={`mt-1 p-1 rounded-full ${log.type === 'WIN' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                                        {log.type === 'WIN' ? <TrendingUp size={10} /> : <AlertTriangle size={10} />}
                                    </div>
                                    <div className="flex-1">
                                        <p className="text-xs text-[#F5F0E6] leading-relaxed">{log.content}</p>
                                        <div className="mt-1 text-[9px] text-[#4A4A4A] font-mono">
                                            {new Date(log.timestamp).toLocaleDateString()}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        )}
    </div>
  );
};