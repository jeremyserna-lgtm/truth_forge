import React, { useState, useMemo } from 'react';
import { User, JournalEntry, KeganStage } from '../types';
import { generateReflectionPrompts, analyzePatterns, calculateGrowthArc, createEmptyEntry } from '../services/journalService';
import { Button } from './Button';
import { BookOpen, Plus, Calendar, Save, Trash2, Tag, ChevronRight, Eye, Layers, Sparkles, TrendingUp, ArrowRight, Lightbulb } from 'lucide-react';

interface ReflectionJournalProps {
  user: User;
  onUpdateUser: (user: User) => void;
}

export const ReflectionJournal: React.FC<ReflectionJournalProps> = ({ user, onUpdateUser }) => {
  const [activeEntry, setActiveEntry] = useState<JournalEntry | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [showPatterns, setShowPatterns] = useState(false);

  const entries = user.developmentProfile.journalEntries || [];
  const stage = user.developmentProfile.stage;
  
  // Analysis
  const patterns = useMemo(() => analyzePatterns(entries), [entries]);
  const growthArc = useMemo(() => calculateGrowthArc(entries), [entries]);
  const prompts = useMemo(() => generateReflectionPrompts(stage), [stage]);

  const handleCreateNew = () => {
      const newEntry = createEmptyEntry(stage);
      setActiveEntry(newEntry);
      setIsEditing(true);
  };

  const handleSave = () => {
      if (!activeEntry) return;
      
      const updatedEntry = { ...activeEntry, lastModified: Date.now() };
      
      // Update or Add
      const existingIdx = entries.findIndex(e => e.id === updatedEntry.id);
      let newEntries = [...entries];
      if (existingIdx >= 0) {
          newEntries[existingIdx] = updatedEntry;
      } else {
          newEntries = [updatedEntry, ...newEntries];
      }

      onUpdateUser({
          ...user,
          developmentProfile: {
              ...user.developmentProfile,
              journalEntries: newEntries
          }
      });
      setIsEditing(false);
  };

  const handleDelete = (id: string) => {
      const newEntries = entries.filter(e => e.id !== id);
      onUpdateUser({
          ...user,
          developmentProfile: {
              ...user.developmentProfile,
              journalEntries: newEntries
          }
      });
      if (activeEntry?.id === id) {
          setActiveEntry(null);
          setIsEditing(false);
      }
  };

  const updateEntryField = (field: keyof JournalEntry, value: any) => {
      if (!activeEntry) return;
      setActiveEntry({ ...activeEntry, [field]: value });
  };

  // --- RENDERERS ---

  const renderTimeline = () => (
      <div className="w-80 bg-[#151515] border-r border-[#2D2D2D] flex flex-col flex-shrink-0">
          <div className="p-6 border-b border-[#2D2D2D]">
              <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-serif text-[#F5F0E6] uppercase tracking-wide">Journal</h2>
                  <Button size="sm" onClick={handleCreateNew} icon={<Plus size={14}/>}>New</Button>
              </div>
              
              {/* Growth Arc Mini-Viz */}
              <div className="bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-3">
                  <div className="flex justify-between items-center mb-2">
                      <span className="text-[10px] font-mono text-[#888888] uppercase">Growth Arc</span>
                      <span className={`text-[10px] font-mono px-1 rounded ${growthArc.trajectory === 'SHIFTING' ? 'text-[#F59E0B] bg-[#F59E0B]/10' : 'text-green-400 bg-green-900/10'}`}>
                          {growthArc.trajectory}
                      </span>
                  </div>
                  <div className="flex items-end space-x-1 h-8">
                      {entries.slice(0, 10).map((e, i) => (
                          <div 
                            key={i} 
                            className={`flex-1 rounded-t-sm ${e.objectAnalysis ? 'bg-[#F59E0B]' : 'bg-[#2D2D2D]'}`}
                            style={{ height: e.objectAnalysis ? '100%' : '30%' }}
                          ></div>
                      ))}
                  </div>
                  <div className="mt-2 text-[9px] text-[#4A4A4A] text-right">
                      {growthArc.shiftCount} Major Shifts
                  </div>
              </div>
          </div>

          <div className="flex-1 overflow-y-auto custom-scrollbar p-2 space-y-2">
              {entries.length === 0 && (
                  <div className="text-center py-8 text-[#4A4A4A] text-xs font-mono">No entries yet.</div>
              )}
              {entries.sort((a, b) => b.timestamp - a.timestamp).map(entry => (
                  <div 
                    key={entry.id}
                    onClick={() => { setActiveEntry(entry); setIsEditing(false); }}
                    className={`p-3 rounded-sm cursor-pointer border transition-all group ${activeEntry?.id === entry.id ? 'bg-[#1A1A1A] border-[#F59E0B]/50' : 'bg-transparent border-transparent hover:bg-[#1A1A1A] hover:border-[#2D2D2D]'}`}
                  >
                      <div className="flex justify-between items-start mb-1">
                          <span className="text-xs font-mono text-[#888888]">{new Date(entry.timestamp).toLocaleDateString()}</span>
                          {entry.subjectAnalysis && <Layers size={12} className="text-[#F59E0B]" />}
                      </div>
                      <h3 className={`text-sm font-serif ${!entry.title ? 'text-[#4A4A4A] italic' : 'text-[#F5F0E6]'}`}>
                          {entry.title || 'Untitled Reflection'}
                      </h3>
                      <p className="text-[10px] text-[#888888] line-clamp-2 mt-1">{entry.content}</p>
                  </div>
              ))}
          </div>
      </div>
  );

  const renderEditor = () => {
      if (!activeEntry) {
          return (
              <div className="flex-1 flex flex-col items-center justify-center text-[#4A4A4A] space-y-4">
                  <BookOpen size={48} />
                  <p className="text-sm font-mono">Select an entry or create a new one to reflect.</p>
              </div>
          );
      }

      return (
          <div className="flex-1 flex flex-col bg-[#0D0D0D] relative">
              {/* Header */}
              <div className="h-16 border-b border-[#2D2D2D] flex items-center justify-between px-8 bg-[#151515]">
                  <div className="flex-1 mr-4">
                      {isEditing ? (
                          <input 
                            type="text" 
                            className="bg-transparent text-xl font-serif text-[#F5F0E6] focus:outline-none placeholder-[#4A4A4A] w-full"
                            placeholder="Title your reflection..."
                            value={activeEntry.title}
                            onChange={(e) => updateEntryField('title', e.target.value)}
                          />
                      ) : (
                          <h2 className="text-xl font-serif text-[#F5F0E6]">{activeEntry.title || 'Untitled Reflection'}</h2>
                      )}
                  </div>
                  <div className="flex items-center space-x-3">
                      {isEditing ? (
                          <Button size="sm" onClick={handleSave} icon={<Save size={14}/>}>Save Entry</Button>
                      ) : (
                          <>
                            <button onClick={() => handleDelete(activeEntry.id)} className="text-[#4A4A4A] hover:text-red-400 p-2"><Trash2 size={16}/></button>
                            <Button size="sm" variant="secondary" onClick={() => setIsEditing(true)}>Edit</Button>
                          </>
                      )}
                  </div>
              </div>

              {/* Main Content */}
              <div className="flex-1 overflow-y-auto custom-scrollbar p-8">
                  <div className="max-w-3xl mx-auto space-y-8">
                      
                      {/* Reflection Area */}
                      <div className="space-y-2">
                          <label className="text-xs font-mono text-[#888888] uppercase tracking-widest flex items-center">
                              <Sparkles size={12} className="mr-2 text-purple-400" /> Free Reflection
                          </label>
                          {isEditing ? (
                              <textarea 
                                className="w-full h-64 bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-6 text-sm font-serif text-[#F5F0E6] leading-relaxed focus:outline-none focus:border-[#F59E0B] resize-none"
                                placeholder="What is happening? Pour it out here..."
                                value={activeEntry.content}
                                onChange={(e) => updateEntryField('content', e.target.value)}
                              />
                          ) : (
                              <div className="bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-6 text-sm font-serif text-[#F5F0E6] leading-relaxed whitespace-pre-wrap">
                                  {activeEntry.content || <span className="text-[#4A4A4A] italic">No content.</span>}
                              </div>
                          )}
                      </div>

                      {/* Not-Me Prompts (Only in Edit) */}
                      {isEditing && (
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                              {prompts.map((p, i) => (
                                  <button 
                                    key={i} 
                                    onClick={() => updateEntryField('content', activeEntry.content + (activeEntry.content ? '\n\n' : '') + p)}
                                    className="p-3 bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm text-[10px] text-[#888888] text-left hover:border-[#F59E0B] hover:text-[#F5F0E6] transition-all"
                                  >
                                      "{p}"
                                  </button>
                              ))}
                          </div>
                      )}

                      {/* Subject-Object Analysis (The Core Mechanism) */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-8 border-t border-[#2D2D2D]">
                          {/* Subject Column */}
                          <div className="space-y-3">
                              <label className="text-xs font-mono text-red-400 uppercase tracking-widest flex items-center">
                                  <Eye size={12} className="mr-2" /> Subject (I AM)
                              </label>
                              <p className="text-[10px] text-[#888888] h-8">What has you? What filter are you looking through that you cannot see?</p>
                              {isEditing ? (
                                  <textarea 
                                    className="w-full h-32 bg-[#1A1A1A] border-l-2 border-l-red-500 border-y border-r border-[#2D2D2D] p-4 text-xs font-mono text-[#F5F0E6] focus:outline-none focus:border-red-500 resize-none"
                                    placeholder="I was subject to the need for approval..."
                                    value={activeEntry.subjectAnalysis || ''}
                                    onChange={(e) => updateEntryField('subjectAnalysis', e.target.value)}
                                  />
                              ) : (
                                  <div className="w-full h-32 bg-[#1A1A1A] border-l-2 border-l-red-500 border-y border-r border-[#2D2D2D] p-4 text-xs font-mono text-[#F5F0E6]">
                                      {activeEntry.subjectAnalysis || <span className="text-[#4A4A4A] italic">Not analyzed.</span>}
                                  </div>
                              )}
                          </div>

                          {/* Object Column */}
                          <div className="space-y-3">
                              <label className="text-xs font-mono text-green-400 uppercase tracking-widest flex items-center">
                                  <Layers size={12} className="mr-2" /> Object (I HAVE)
                              </label>
                              <p className="text-[10px] text-[#888888] h-8">What can you now look AT? What can you manipulate and critique?</p>
                              {isEditing ? (
                                  <textarea 
                                    className="w-full h-32 bg-[#1A1A1A] border-l-2 border-l-green-500 border-y border-r border-[#2D2D2D] p-4 text-xs font-mono text-[#F5F0E6] focus:outline-none focus:border-green-500 resize-none"
                                    placeholder="I can now see that need as a sensation, not a command..."
                                    value={activeEntry.objectAnalysis || ''}
                                    onChange={(e) => updateEntryField('objectAnalysis', e.target.value)}
                                  />
                              ) : (
                                  <div className="w-full h-32 bg-[#1A1A1A] border-l-2 border-l-green-500 border-y border-r border-[#2D2D2D] p-4 text-xs font-mono text-[#F5F0E6]">
                                      {activeEntry.objectAnalysis || <span className="text-[#4A4A4A] italic">Not analyzed.</span>}
                                  </div>
                              )}
                          </div>
                      </div>

                      {/* Visual Shift Arrow */}
                      <div className="flex justify-center -mt-4 opacity-50">
                          <ArrowRight size={24} className="text-[#F59E0B]" />
                      </div>

                  </div>
              </div>
          </div>
      );
  };

  const renderPatternsPanel = () => (
      <div className="w-72 bg-[#151515] border-l border-[#2D2D2D] flex flex-col flex-shrink-0 p-6 overflow-y-auto">
          <div className="flex items-center space-x-2 mb-6">
              <Lightbulb size={16} className="text-[#F59E0B]" />
              <h3 className="text-sm font-mono text-[#F5F0E6] uppercase tracking-wide">Pattern Recognition</h3>
          </div>
          <div className="space-y-4">
              {patterns.map(pat => (
                  <div key={pat.id} className="bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-4 hover:border-[#F59E0B]/30 transition-colors">
                      <div className="flex justify-between items-start mb-2">
                          <span className="text-xs font-serif text-[#F5F0E6] font-bold">{pat.theme}</span>
                          <span className="text-[9px] font-mono bg-[#2D2D2D] px-1.5 py-0.5 rounded text-[#888888]">{pat.frequency}x</span>
                      </div>
                      <p className="text-[10px] text-[#888888] leading-relaxed">{pat.developmentalRelevance}</p>
                  </div>
              ))}
              {patterns.length === 0 && (
                  <div className="text-center text-[#4A4A4A] text-xs font-mono">Not enough data to extract patterns.</div>
              )}
          </div>
          
          <div className="mt-auto pt-6 border-t border-[#2D2D2D]">
              <div className="flex items-center space-x-2 mb-2 text-[#888888]">
                  <TrendingUp size={14} />
                  <span className="text-xs font-mono uppercase tracking-wide">Shift Velocity</span>
              </div>
              <p className="text-[10px] text-[#4A4A4A] leading-relaxed">
                  You are identifying {growthArc.shiftCount} shifts per month. This indicates a {growthArc.trajectory} trajectory.
              </p>
          </div>
      </div>
  );

  return (
    <div className="flex h-full animate-in fade-in duration-500">
        {renderTimeline()}
        {renderEditor()}
        {renderPatternsPanel()}
    </div>
  );
};