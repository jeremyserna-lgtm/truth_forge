import React, { useState } from 'react';
import { User, SubscriptionTier, CognitiveMetricPoint, EmergentPattern } from '../types';
import { Lock, Settings2, BarChart3, Network, Zap, BrainCircuit, Layers, Activity, FileText, ChevronRight, ChevronDown, CheckCircle2, Radar, Sparkles } from 'lucide-react';
import { Button } from './Button';

interface ObservabilityProps {
  user: User;
}

export const Observability: React.FC<ObservabilityProps> = ({ user }) => {
  const isStage3 = user.tier === SubscriptionTier.STAGE_3_FROZEN;
  const isStage5 = user.tier === SubscriptionTier.STAGE_5_STRUCTURAL;
  
  const [expandedReport, setExpandedReport] = useState<string | null>(null);

  const metrics = user.developmentProfile.cognitiveMetrics || {
      current: { perspectiveBreadth: 0, integrationDepth: 0, temporalCoherence: 0 },
      history: []
  };
  const reports = user.developmentProfile.growthReports || [];
  const patterns = user.developmentProfile.emergentPatterns || [
      // Mock data if empty
      { id: 'pat-1', name: 'Recursive Self-Reflexivity', description: 'User applied "Perspective Tool" to the Perspective Tool itself.', noveltyScore: 92, componentsInvolved: ['Foundry', 'Psychometrics'], detectedAt: Date.now() - 86400000 },
      { id: 'pat-2', name: 'Cross-Domain Metaphor', description: 'User linked "Financial Billing" concepts to "Emotional Debt".', noveltyScore: 78, componentsInvolved: ['Billing', 'Chat'], detectedAt: Date.now() - 172800000 }
  ];

  const MetricCard = ({ title, value, icon, color, description }: { title: string, value: number, icon: React.ReactNode, color: string, description: string }) => (
      <div className="bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-6 relative overflow-hidden group">
          <div className={`absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity ${color}`}>
              {icon}
          </div>
          <div className="flex items-center space-x-2 mb-2">
              <span className={`p-1 rounded-sm bg-[#0D0D0D] border border-[#2D2D2D] ${color}`}>
                  {React.cloneElement(icon as React.ReactElement<any>, { size: 14 })}
              </span>
              <h3 className="text-xs font-mono text-[#888888] uppercase tracking-widest">{title}</h3>
          </div>
          <div className="mt-4 flex items-end justify-between">
              <span className="text-3xl font-serif text-[#F5F0E6]">{value}<span className="text-sm text-[#4A4A4A] ml-1">/100</span></span>
              <div className="flex flex-col items-end">
                  <span className={`text-[10px] font-mono ${value > 50 ? 'text-green-400' : 'text-[#F59E0B]'}`}>
                      {value > 50 ? 'OPTIMAL' : 'DEVELOPING'}
                  </span>
              </div>
          </div>
          <div className="mt-4 h-1 bg-[#2D2D2D] rounded-full overflow-hidden">
              <div className={`h-full ${color.replace('text-', 'bg-')}`} style={{ width: `${value}%` }}></div>
          </div>
          <p className="mt-3 text-[10px] text-[#888888] leading-tight">{description}</p>
      </div>
  );

  const CognitiveTrendChart = ({ history }: { history: CognitiveMetricPoint[] }) => {
      // Mock chart normalization
      const width = 600;
      const height = 200;
      const padding = 20;
      
      const getPoints = (key: keyof CognitiveMetricPoint) => {
          if (history.length === 0) return "";
          return history.map((point, i) => {
              const x = (i / (history.length - 1)) * (width - padding * 2) + padding;
              const val = point[key] as number;
              const y = height - ((val / 100) * (height - padding * 2)) - padding;
              return `${x},${y}`;
          }).join(" ");
      };

      return (
          <div className="w-full h-64 bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-6 relative overflow-hidden">
              <div className="absolute top-4 left-6 z-10 flex space-x-4">
                  <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 rounded-full bg-[#F59E0B]"></div>
                      <span className="text-[10px] font-mono text-[#888888]">Breadth</span>
                  </div>
                  <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 rounded-full bg-blue-400"></div>
                      <span className="text-[10px] font-mono text-[#888888]">Depth</span>
                  </div>
                  <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 rounded-full bg-purple-400"></div>
                      <span className="text-[10px] font-mono text-[#888888]">Coherence</span>
                  </div>
              </div>
              
              <div className="w-full h-full flex items-center justify-center">
                  <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full overflow-visible">
                      {/* Grid Lines */}
                      <line x1={padding} y1={height - padding} x2={width - padding} y2={height - padding} stroke="#2D2D2D" strokeWidth="1" />
                      <line x1={padding} y1={padding} x2={width - padding} y2={padding} stroke="#2D2D2D" strokeWidth="1" strokeDasharray="4 4" />
                      
                      {history.length > 1 && (
                          <>
                              <polyline points={getPoints('perspectiveBreadth')} fill="none" stroke="#F59E0B" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                              <polyline points={getPoints('integrationDepth')} fill="none" stroke="#60A5FA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                              <polyline points={getPoints('temporalCoherence')} fill="none" stroke="#C084FC" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                          </>
                      )}
                  </svg>
              </div>
          </div>
      );
  };

  return (
    <div className="flex h-full bg-[#0D0D0D] overflow-hidden">
        {/* Sidebar */}
        <div className="w-64 bg-[#151515] border-r border-[#2D2D2D] flex flex-col">
            <div className="p-4 border-b border-[#2D2D2D]">
                <div className="flex items-center space-x-2 mb-1">
                    <Zap size={14} className="text-[#F59E0B]" />
                    <h3 className="text-xs font-mono text-[#F5F0E6] uppercase tracking-widest">Primitive Engine</h3>
                </div>
                <p className="text-[10px] text-[#888888]">Cognitive Analytics Core</p>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-6">
                <div>
                    <h4 className="text-[10px] font-mono text-[#4A4A4A] uppercase tracking-widest mb-3">Live Telemetry</h4>
                    <div className="space-y-2">
                        <div className="px-3 py-2 bg-[#2D2D2D] rounded-sm text-xs font-mono text-[#F5F0E6] flex items-center justify-between">
                            <span>Processing</span>
                            <div className="flex space-x-1">
                                <div className="w-1 h-1 bg-[#F59E0B] rounded-full animate-bounce"></div>
                                <div className="w-1 h-1 bg-[#F59E0B] rounded-full animate-bounce delay-100"></div>
                                <div className="w-1 h-1 bg-[#F59E0B] rounded-full animate-bounce delay-200"></div>
                            </div>
                        </div>
                        <div className="px-3 py-2 rounded-sm text-xs font-mono flex items-center justify-between text-[#888888] border border-[#2D2D2D]">
                            <span>Pattern Match</span>
                            <span>98.2%</span>
                        </div>
                    </div>
                </div>

                <div>
                    <h4 className="text-[10px] font-mono text-[#4A4A4A] uppercase tracking-widest mb-3">System Status</h4>
                    <div className="space-y-2">
                        <div className={`px-3 py-2 rounded-sm text-xs font-mono flex items-center justify-between ${isStage3 ? 'opacity-50 text-[#4A4A4A]' : 'text-[#888888] hover:bg-[#1A1A1A]'}`}>
                            <span>Recursive Depth</span>
                            {isStage3 ? <Lock size={12} /> : <span>Lvl 4</span>}
                        </div>
                        <div className={`px-3 py-2 rounded-sm text-xs font-mono flex items-center justify-between ${!isStage5 ? 'opacity-50 text-[#4A4A4A]' : 'text-[#888888] hover:bg-[#1A1A1A]'}`}>
                            <span>Meta-Analysis</span>
                            {!isStage5 ? <Lock size={12} /> : <span className="text-green-400">ACTIVE</span>}
                        </div>
                    </div>
                </div>
            </div>

            {isStage5 && (
                <div className="p-4 border-t border-[#2D2D2D]">
                    <Button fullWidth size="sm" variant="secondary" icon={<Settings2 size={14}/>}>
                        Engine Config
                    </Button>
                </div>
            )}
        </div>

        {/* Main Dashboard */}
        <div className="flex-1 p-8 overflow-y-auto custom-scrollbar bg-[#0D0D0D]">
            <header className="mb-8 flex items-end justify-between">
                <div>
                    <h1 className="text-2xl font-serif text-[#F5F0E6] uppercase tracking-wide flex items-center">
                        Cognitive Complexity Metrics
                    </h1>
                    <p className="text-xs font-mono text-[#888888] mt-2 max-w-2xl">
                        Quantified developmental analysis derived from Truth Forge interactions. 
                        Metrics are calculated weekly by the Primitive Engine.
                    </p>
                </div>
                <div className="text-right">
                    <div className="text-[10px] font-mono text-[#4A4A4A] uppercase mb-1">Last Analysis</div>
                    <div className="text-xs font-mono text-[#F5F0E6]">{metrics.history[metrics.history.length - 1]?.date || 'N/A'}</div>
                </div>
            </header>

            {/* Top Row: Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <MetricCard 
                    title="Perspective Breadth" 
                    value={metrics.current.perspectiveBreadth}
                    icon={<BrainCircuit />}
                    color="text-[#F59E0B]"
                    description="Capacity to hold distinct, simultaneous viewpoints without collapsing into binary thinking."
                />
                <MetricCard 
                    title="Integration Depth" 
                    value={metrics.current.integrationDepth}
                    icon={<Layers />}
                    color="text-blue-400"
                    description="Ability to synthesize contradictory information into higher-order conceptual frameworks."
                />
                <MetricCard 
                    title="Temporal Coherence" 
                    value={metrics.current.temporalCoherence}
                    icon={<Activity />}
                    color="text-purple-400"
                    description="Consistency of reasoning structure and axiomatic alignment across time."
                />
            </div>

            {/* Emergence Detector (NEW) */}
            <div className="mb-8">
                <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-2">
                        <div className="p-2 bg-purple-900/10 border border-purple-500/50 rounded-full">
                            <Sparkles size={16} className="text-purple-400" />
                        </div>
                        <h3 className="text-sm font-mono text-[#F5F0E6] uppercase tracking-wide">Emergence Detector</h3>
                    </div>
                    <span className="text-[10px] font-mono text-[#888888]">Detecting novel system-user interaction patterns</span>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {patterns.map(pattern => (
                        <div key={pattern.id} className="bg-[#1A1A1A] border border-[#2D2D2D] hover:border-purple-500/50 p-4 rounded-sm transition-all group relative overflow-hidden">
                            <div className="absolute top-0 right-0 p-3 opacity-10">
                                <Radar size={48} className="text-purple-500" />
                            </div>
                            <div className="flex justify-between items-start mb-2 relative z-10">
                                <h4 className="text-sm font-serif text-[#F5F0E6]">{pattern.name}</h4>
                                <span className="text-[9px] font-mono text-purple-400 border border-purple-900/50 px-1.5 py-0.5 rounded bg-purple-900/10">NOVELTY {pattern.noveltyScore}%</span>
                            </div>
                            <p className="text-xs text-[#888888] mb-3 leading-relaxed relative z-10">{pattern.description}</p>
                            <div className="flex items-center space-x-2 relative z-10">
                                <span className="text-[9px] font-mono text-[#4A4A4A] uppercase">Vectors:</span>
                                {pattern.componentsInvolved.map(comp => (
                                    <span key={comp} className="text-[9px] font-mono text-[#888888] bg-[#0D0D0D] px-1.5 rounded">{comp}</span>
                                ))}
                            </div>
                        </div>
                    ))}
                    {patterns.length === 0 && (
                        <div className="col-span-2 p-8 border border-dashed border-[#2D2D2D] rounded-sm flex items-center justify-center text-[#4A4A4A] text-xs font-mono">
                            No emergent patterns detected yet. Continue interaction to generate novel data.
                        </div>
                    )}
                </div>
            </div>

            {/* Middle Row: Trend Analysis */}
            <div className="mb-8">
                <div className="flex items-center justify-between mb-4">
                    <h3 className="text-sm font-mono text-[#F5F0E6] uppercase tracking-wide flex items-center">
                        <BarChart3 size={16} className="mr-2 text-[#888888]" />
                        Developmental Velocity
                    </h3>
                    <div className="text-[10px] font-mono text-[#4A4A4A]">3-Month Window</div>
                </div>
                <CognitiveTrendChart history={metrics.history} />
            </div>

            {/* Bottom Row: Growth Reports */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Reports List */}
                <div className="lg:col-span-2">
                    <div className="flex items-center justify-between mb-4">
                        <h3 className="text-sm font-mono text-[#F5F0E6] uppercase tracking-wide flex items-center">
                            <FileText size={16} className="mr-2 text-[#888888]" />
                            Growth Reports
                        </h3>
                    </div>
                    <div className="space-y-4">
                        {reports.map(report => (
                            <div key={report.id} className="bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm overflow-hidden">
                                <button 
                                    onClick={() => setExpandedReport(expandedReport === report.id ? null : report.id)}
                                    className="w-full p-4 flex items-center justify-between hover:bg-[#232323] transition-colors text-left"
                                >
                                    <div className="flex items-center space-x-4">
                                        <div className={`p-2 rounded-full bg-[#0D0D0D] border border-[#2D2D2D] ${
                                            report.focusArea === 'BREADTH' ? 'text-[#F59E0B]' : 
                                            report.focusArea === 'DEPTH' ? 'text-blue-400' : 'text-purple-400'
                                        }`}>
                                            {report.focusArea === 'BREADTH' ? <BrainCircuit size={16}/> : 
                                             report.focusArea === 'DEPTH' ? <Layers size={16}/> : <Activity size={16}/>}
                                        </div>
                                        <div>
                                            <div className="text-sm font-serif text-[#F5F0E6] tracking-wide">Weekly Analysis: {report.weekEnding}</div>
                                            <div className="text-[10px] font-mono text-[#888888] uppercase mt-0.5">Focus: {report.focusArea}</div>
                                        </div>
                                    </div>
                                    {expandedReport === report.id ? <ChevronDown size={16} className="text-[#888888]"/> : <ChevronRight size={16} className="text-[#888888]"/>}
                                </button>
                                
                                {expandedReport === report.id && (
                                    <div className="p-4 border-t border-[#2D2D2D] bg-[#0D0D0D]/50 animate-in slide-in-from-top-2">
                                        <p className="text-xs text-[#F5F0E6] leading-relaxed mb-4 font-sans border-l-2 border-[#4A4A4A] pl-3">
                                            {report.summary}
                                        </p>
                                        <div className="space-y-2">
                                            <span className="text-[10px] font-mono text-[#888888] uppercase tracking-wider block">Observed Evidence</span>
                                            {report.examples.map((ex, i) => (
                                                <div key={i} className="flex items-start space-x-2 text-xs text-[#888888]">
                                                    <CheckCircle2 size={12} className="mt-0.5 text-[#4A4A4A] flex-shrink-0" />
                                                    <span>{ex}</span>
                                                </div>
                                            ))}
                                        </div>
                                        <div className="mt-4 pt-3 border-t border-[#2D2D2D] flex justify-end">
                                            <Button size="sm" variant="secondary">Download PDF</Button>
                                        </div>
                                    </div>
                                )}
                            </div>
                        ))}
                        {reports.length === 0 && (
                            <div className="p-8 text-center border border-dashed border-[#2D2D2D] rounded-sm text-[#4A4A4A] text-xs font-mono">
                                No reports generated yet. Primitive Engine requires min. 7 days of activity.
                            </div>
                        )}
                    </div>
                </div>

                {/* Status/Context Sidebar */}
                <div>
                    <div className="bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-6 mb-6">
                        <h4 className="text-xs font-mono text-[#F5F0E6] uppercase tracking-wide mb-4">Primitive Engine Status</h4>
                        <div className="space-y-4">
                            <div>
                                <div className="flex justify-between text-[10px] font-mono text-[#888888] mb-1">
                                    <span>Data Ingestion</span>
                                    <span>Active</span>
                                </div>
                                <div className="w-full bg-[#0D0D0D] h-1 rounded-full overflow-hidden">
                                    <div className="h-full bg-green-500 w-full animate-pulse"></div>
                                </div>
                            </div>
                            <div>
                                <div className="flex justify-between text-[10px] font-mono text-[#888888] mb-1">
                                    <span>Pattern Recognition</span>
                                    <span>Processing</span>
                                </div>
                                <div className="w-full bg-[#0D0D0D] h-1 rounded-full overflow-hidden">
                                    <div className="h-full bg-[#F59E0B] w-3/4"></div>
                                </div>
                            </div>
                        </div>
                        <div className="mt-6 p-3 bg-[#0D0D0D] border border-[#2D2D2D] rounded-sm text-[10px] text-[#888888] leading-relaxed">
                            <span className="text-[#F59E0B] font-bold">NOTE:</span> Integration Depth metric is showing high variance. Recommended action: Engage with "Not-Me" companion on topics of ambiguity to stabilize score.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};