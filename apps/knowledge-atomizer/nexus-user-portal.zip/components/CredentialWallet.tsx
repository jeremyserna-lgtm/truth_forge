import React, { useState } from 'react';
import { User, VerifiableCredential, CredentialRequest, CredentialEvidence, KeganStage } from '../types';
import { requestCredential, issueCredential, generateShareableLink, syncWithCredentialAtlas } from '../services/credentialService';
import { Button } from './Button';
import { BadgeCheck, Shield, Clock, ExternalLink, Plus, Fingerprint, Database, CheckCircle2, FileText, Share2, Copy, X, Loader2, RefreshCw } from 'lucide-react';

interface CredentialWalletProps {
  user: User;
  onUpdateUser: (user: User) => void;
}

export const CredentialWallet: React.FC<CredentialWalletProps> = ({ user, onUpdateUser }) => {
  const [activeTab, setActiveTab] = useState<'WALLET' | 'REQUESTS' | 'ATLAS'>('WALLET');
  const [isSyncing, setIsSyncing] = useState(false);
  const [showRequestModal, setShowRequestModal] = useState(false);
  
  // Request Form State
  const [achievementTitle, setAchievementTitle] = useState('');
  const [evidenceText, setEvidenceText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const credentials = user.developmentProfile.credentials || [];
  const requests = user.developmentProfile.credentialRequests || [];

  const handleSync = async () => {
      setIsSyncing(true);
      await syncWithCredentialAtlas();
      setIsSyncing(false);
  };

  const handleSubmitRequest = async () => {
      if (!achievementTitle || !evidenceText) return;
      setIsSubmitting(true);

      const evidence: CredentialEvidence[] = [{
          type: 'JOURNAL_ENTRY',
          referenceId: 'manual-entry',
          excerpt: evidenceText,
          description: 'Self-reported reflection'
      }];

      const newRequest = await requestCredential(user, achievementTitle, evidence);
      
      const updatedUser = {
          ...user,
          developmentProfile: {
              ...user.developmentProfile,
              credentialRequests: [newRequest, ...requests]
          }
      };
      
      onUpdateUser(updatedUser);
      setIsSubmitting(false);
      setShowRequestModal(false);
      setAchievementTitle('');
      setEvidenceText('');

      // Simulate async verification process
      setTimeout(() => {
          const verifiedCred = issueCredential(newRequest, user);
          const finalUser = {
              ...updatedUser,
              developmentProfile: {
                  ...updatedUser.developmentProfile,
                  credentials: [verifiedCred, ...credentials],
                  credentialRequests: updatedUser.developmentProfile.credentialRequests?.map(r => 
                      r.id === newRequest.id ? { ...r, status: 'APPROVED' } : r
                  ) as CredentialRequest[] // Explicit cast safely
              }
          };
          onUpdateUser(finalUser);
      }, 5000);
  };

  const copyLink = (id: string) => {
      const link = generateShareableLink(id);
      navigator.clipboard.writeText(link);
      alert("Verification link copied to clipboard.");
  };

  const renderWallet = () => (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-in fade-in">
          {/* Add New Card */}
          <div 
            onClick={() => setShowRequestModal(true)}
            className="border-2 border-dashed border-[#2D2D2D] rounded-sm p-8 flex flex-col items-center justify-center cursor-pointer hover:border-[#F5F0E6] hover:bg-[#1A1A1A] transition-all min-h-[200px]"
          >
              <Plus size={32} className="text-[#4A4A4A] mb-4" />
              <h3 className="text-sm font-mono text-[#F5F0E6] uppercase tracking-wide">Request Credential</h3>
              <p className="text-xs text-[#888888] mt-2 text-center">Submit evidence for verification</p>
          </div>

          {credentials.map(cred => (
              <div key={cred.id} className="bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-6 relative group hover:border-[#F59E0B]/50 transition-colors">
                  <div className="absolute top-4 right-4 text-[#F59E0B] opacity-50 group-hover:opacity-100">
                      <BadgeCheck size={20} />
                  </div>
                  
                  <div className="flex flex-col h-full">
                      <div className="mb-4">
                          <span className="text-[9px] font-mono text-[#888888] uppercase tracking-wider">{cred.type.replace('_', ' ')}</span>
                          <h3 className="text-lg font-serif text-[#F5F0E6] mt-1">{cred.title}</h3>
                      </div>
                      
                      <p className="text-xs text-[#888888] leading-relaxed mb-4 flex-1">
                          {cred.description}
                      </p>

                      <div className="space-y-3 pt-4 border-t border-[#2D2D2D]">
                          <div className="flex justify-between items-center text-[10px] font-mono text-[#4A4A4A]">
                              <span>Issued: {cred.issueDate}</span>
                              <span className="uppercase">{cred.issuer.replace('_', ' ')}</span>
                          </div>
                          
                          {cred.credentialAtlasHash && (
                              <div className="bg-[#0D0D0D] p-2 rounded-sm border border-[#2D2D2D] flex items-center justify-between">
                                  <div className="flex items-center space-x-2 text-[10px] font-mono text-[#F59E0B]">
                                      <Database size={10} />
                                      <span className="truncate w-24">{cred.credentialAtlasHash}</span>
                                  </div>
                                  <button onClick={() => copyLink(cred.id)} className="text-[#888888] hover:text-[#F5F0E6]" title="Copy Verification Link">
                                      <Share2 size={12} />
                                  </button>
                              </div>
                          )}
                      </div>
                  </div>
              </div>
          ))}
      </div>
  );

  const renderRequests = () => (
      <div className="space-y-4 animate-in fade-in">
          {requests.length === 0 && (
              <div className="text-center py-12 text-[#4A4A4A] text-sm font-mono border border-dashed border-[#2D2D2D] rounded-sm">
                  No pending credential requests.
              </div>
          )}
          {requests.map(req => (
              <div key={req.id} className="bg-[#1A1A1A] border border-[#2D2D2D] p-4 rounded-sm flex justify-between items-center">
                  <div>
                      <h4 className="text-sm font-serif text-[#F5F0E6]">{req.achievement}</h4>
                      <p className="text-xs text-[#888888] mt-1">Submitted: {new Date(req.requestedAt).toLocaleDateString()}</p>
                  </div>
                  <div className="flex items-center space-x-4">
                      {req.status === 'APPROVED' ? (
                          <span className="text-xs font-mono text-green-400 flex items-center bg-green-900/10 px-2 py-1 rounded border border-green-900/50">
                              <CheckCircle2 size={12} className="mr-1" /> Approved
                          </span>
                      ) : req.status === 'REJECTED' ? (
                          <span className="text-xs font-mono text-red-400 bg-red-900/10 px-2 py-1 rounded border border-red-900/50">Rejected</span>
                      ) : (
                          <span className="text-xs font-mono text-[#F59E0B] flex items-center bg-[#F59E0B]/10 px-2 py-1 rounded border border-[#F59E0B]/30">
                              <Clock size={12} className="mr-1 animate-spin-slow" /> Analyzing
                          </span>
                      )}
                  </div>
              </div>
          ))}
      </div>
  );

  return (
    <div className="flex flex-col h-full bg-[#0D0D0D]">
        {/* Header */}
        <div className="h-16 border-b border-[#2D2D2D] bg-[#151515] flex items-center justify-between px-8">
            <div className="flex items-center space-x-3">
                <Shield size={20} className="text-blue-400" />
                <h2 className="text-lg font-serif text-[#F5F0E6] uppercase tracking-wide">Credential Atlas Wallet</h2>
            </div>
            <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2 text-[10px] font-mono text-[#888888]">
                    <div className={`w-2 h-2 rounded-full ${isSyncing ? 'bg-[#F59E0B] animate-pulse' : 'bg-green-500'}`}></div>
                    <span>{isSyncing ? 'SYNCING CHAIN...' : 'ATLAS CONNECTED'}</span>
                </div>
                <Button size="sm" variant="secondary" onClick={handleSync} disabled={isSyncing} icon={<RefreshCw size={12} className={isSyncing ? 'animate-spin' : ''}/>}>
                    Sync
                </Button>
            </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-[#2D2D2D] bg-[#1A1A1A] px-8">
            <button 
                onClick={() => setActiveTab('WALLET')} 
                className={`py-4 px-4 text-xs font-mono uppercase tracking-wider border-b-2 transition-all ${activeTab === 'WALLET' ? 'border-[#F5F0E6] text-[#F5F0E6]' : 'border-transparent text-[#888888] hover:text-[#B5B5B5]'}`}
            >
                My Credentials ({credentials.length})
            </button>
            <button 
                onClick={() => setActiveTab('REQUESTS')} 
                className={`py-4 px-4 text-xs font-mono uppercase tracking-wider border-b-2 transition-all ${activeTab === 'REQUESTS' ? 'border-[#F5F0E6] text-[#F5F0E6]' : 'border-transparent text-[#888888] hover:text-[#B5B5B5]'}`}
            >
                Requests ({requests.length})
            </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-8">
            {activeTab === 'WALLET' && renderWallet()}
            {activeTab === 'REQUESTS' && renderRequests()}
        </div>

        {/* Request Modal */}
        {showRequestModal && (
            <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-center justify-center p-4">
                <div className="bg-[#151515] border border-[#2D2D2D] rounded-sm w-full max-w-lg shadow-2xl animate-in fade-in zoom-in-95">
                    <div className="p-6 border-b border-[#2D2D2D] flex justify-between items-center">
                        <h3 className="text-lg font-serif text-[#F5F0E6]">Request Verification</h3>
                        <button onClick={() => setShowRequestModal(false)} className="text-[#888888] hover:text-[#F5F0E6]"><X size={20}/></button>
                    </div>
                    <div className="p-6 space-y-4">
                        <p className="text-xs text-[#888888] font-mono leading-relaxed">
                            Credentials are verifiable proofs of developmental milestones. Submit evidence from your journal, chat history, or real-life application.
                        </p>
                        
                        <div>
                            <label className="text-[10px] font-mono text-[#F5F0E6] uppercase mb-1 block">Achievement Name</label>
                            <input 
                                type="text" 
                                className="w-full bg-[#0D0D0D] border border-[#2D2D2D] p-3 text-sm text-[#F5F0E6] focus:border-[#F59E0B] focus:outline-none rounded-sm"
                                placeholder="e.g. Challenged Core Assumption"
                                value={achievementTitle}
                                onChange={(e) => setAchievementTitle(e.target.value)}
                            />
                        </div>

                        <div>
                            <label className="text-[10px] font-mono text-[#F5F0E6] uppercase mb-1 block">Evidence / Reflection</label>
                            <textarea 
                                className="w-full h-32 bg-[#0D0D0D] border border-[#2D2D2D] p-3 text-sm text-[#F5F0E6] focus:border-[#F59E0B] focus:outline-none resize-none rounded-sm"
                                placeholder="Describe the moment of growth or paste relevant journal excerpt..."
                                value={evidenceText}
                                onChange={(e) => setEvidenceText(e.target.value)}
                            />
                        </div>
                    </div>
                    <div className="p-6 border-t border-[#2D2D2D] flex justify-end space-x-3 bg-[#1A1A1A]">
                        <Button variant="secondary" onClick={() => setShowRequestModal(false)}>Cancel</Button>
                        <Button onClick={handleSubmitRequest} isLoading={isSubmitting} disabled={!achievementTitle || !evidenceText}>Submit Request</Button>
                    </div>
                </div>
            </div>
        )}
    </div>
  );
};