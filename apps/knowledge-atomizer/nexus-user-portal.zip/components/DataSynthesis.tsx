import React, { useState, useRef, useEffect, useMemo } from 'react';
import { User, SubscriptionTier, SourceCategory, ChatMode, KnowledgeAtom, KeganStage, DialecticalTension, TruthEngineAnalysis, MeaningNode } from '../types';
import { Button } from './Button';
import { MicroMoment } from './MicroMoment';
import { 
  Upload, FileText, X, Mic, Image as ImageIcon, Video, Building2, 
  MessageSquare, Zap, Send, Atom, Database, 
  Activity, Layers, Clock, Share2, Loader2, Sparkles, Brain,
  List, HelpCircle, Lightbulb, Play, ArrowRight, CheckCircle2,
  HardDrive, AlertTriangle, ArrowDownToLine, RefreshCw, Trash2,
  Maximize2, Film, Music, Search, CheckSquare, Square, ZoomIn, ZoomOut,
  Minimize2, Box, FileBox, FileCode, Archive, Scale, Split, GitMerge,
  Radar, Gauge, Compass, BarChart2
} from 'lucide-react';

interface DataSynthesisProps {
  user: User;
}

// Unified View Type covering all top-level tabs
type MainView = 'DOCUMENTS' | 'IMAGES' | 'VIDEOS' | 'AUDIO' | 'OTHER' | 'ARCHITECTURE' | 'CHAT' | 'SYNTHESIZE';
type SynthesisTab = 'SUMMARY' | 'KEY_POINTS' | 'TAKEAWAYS' | 'QUESTIONS' | 'EDGES' | 'TRUTH_ENGINE';

interface FileItem {
  id: string;
  name: string;
  type: string;
  category: SourceCategory;
  status: 'processing' | 'processed' | 'error';
  size: number;
  tokens: number;
  uploadDate: Date;
  previewUrl?: string; // For images/media
}

// Extended Atom Interface for local state
interface ExtendedAtom extends KnowledgeAtom {
  activeTab: 'attributes' | 'lineage' | 'resonance';
  sourceIds?: string[]; // IDs of files or atoms this derived from
  originType?: SourceCategory | 'SYSTEM';
}

interface SynthesisResult {
  category: SourceCategory;
  summary: string;
  keyPoints: string[];
  takeaways: string;
  questions: string[];
  epiphany: string;
  sourceCount: number;
  tensions: DialecticalTension[];
  truthAnalysis?: TruthEngineAnalysis;
}

const MAX_CONTEXT_TOKENS = 1000000;

export const DataSynthesis: React.FC<DataSynthesisProps> = ({ user }) => {
  // Navigation
  const [activeView, setActiveView] = useState<MainView>('DOCUMENTS');
  
  // Synthesis Output State
  const [synthesisTab, setSynthesisTab] = useState<SynthesisTab>('SUMMARY');
  const [lastSynthesis, setLastSynthesis] = useState<SynthesisResult | null>(null);
  const [isProcessingSynthesis, setIsProcessingSynthesis] = useState(false);

  // Chat State
  const [chatMode, setChatMode] = useState<ChatMode>(ChatMode.ENGAGE);
  const [chatInput, setChatInput] = useState('');
  const [chatHistory, setChatHistory] = useState<{role: 'user' | 'system', content: string}[]>([
      { role: 'system', content: 'Truth Forge Construct initialized. Select a dimension to begin interaction.'}
  ]);
  const [isSynthesizing, setIsSynthesizing] = useState(false);

  // Synthesis Production State
  const [productionType, setProductionType] = useState<'DOC' | 'IMG' | 'VID' | 'AUDIO' | null>(null);
  const [productionSubType, setProductionSubType] = useState<string | null>(null);
  const [generatedArtifact, setGeneratedArtifact] = useState<string | null>(null);
  const [showAtomGraph, setShowAtomGraph] = useState(false);
  const [showTensionsInGraph, setShowTensionsInGraph] = useState(true);

  // Micro-Moment State
  const [showMicroMoment, setShowMicroMoment] = useState(false);

  // File Data & Queue Management
  const [files, setFiles] = useState<FileItem[]>([]);
  const [selectedFileIds, setSelectedFileIds] = useState<Set<string>>(new Set());
  const [docSearch, setDocSearch] = useState('');
  const [previewFile, setPreviewFile] = useState<FileItem | null>(null);
  const [zoomLevel, setZoomLevel] = useState(1);
  
  // Interaction Token Overhead (simulates conversation history growing)
  const [interactionTokens, setInteractionTokens] = useState(0);
  const [isConsolidating, setIsConsolidating] = useState(false);
  const [consolidatedCount, setConsolidatedCount] = useState(0);

  // Documents Tab Quick Actions
  const [docQuickAction, setDocQuickAction] = useState<'DEEP_DIVE' | 'REPORT' | 'BRIEF' | 'OTHER' | null>(null);
  const [quickActionOutput, setQuickActionOutput] = useState<string | null>(null);

  // Atom Data with expansion state
  const [atoms, setAtoms] = useState<ExtendedAtom[]>([
      { id: 'k1', label: 'Self-Sovereignty', description: 'Core axiom regarding user ownership of data.', depth: 1, resonance: 95, type: 'axiom', activeTab: 'attributes', originType: 'SYSTEM' },
      { id: 'k2', label: 'Fluid Tiering', description: 'Dynamic access control based on user resonance.', depth: 3, resonance: 80, type: 'concept', activeTab: 'attributes', originType: 'SYSTEM' },
      { id: 'k3', label: 'Recursive Logic', description: 'Feedback loops in system architecture.', depth: 2, resonance: 60, type: 'derivative', activeTab: 'attributes', originType: 'SYSTEM', sourceIds: ['k1'] },
  ]);

  const [activeTensions, setActiveTensions] = useState<DialecticalTension[]>([]);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const isFrozen = user.tier === SubscriptionTier.STAGE_3_FROZEN;
  const userStage = user.developmentProfile?.stage || KeganStage.STAGE_3_SOCIALIZED;

  // Reset view state when switching tabs
  useEffect(() => {
    if (lastSynthesis && lastSynthesis.category !== getCurrentCategory(activeView)) {
        setLastSynthesis(null);
    }
    // Clear selections and search on view change
    setSelectedFileIds(new Set());
    setDocSearch('');
    setDocQuickAction(null);
    setQuickActionOutput(null);
    setShowMicroMoment(false);
  }, [activeView]);

  // --- Calculations ---
  const fileTokens = files.reduce((acc, f) => acc + f.tokens, 0);
  const totalTokens = fileTokens + interactionTokens;
  const usagePercentage = Math.min((totalTokens / MAX_CONTEXT_TOKENS) * 100, 100);
  const isContextFull = totalTokens >= MAX_CONTEXT_TOKENS;

  // --- Helpers ---

  const getFilesForView = (view: MainView) => {
    let filtered = [];
    switch(view) {
      case 'DOCUMENTS': filtered = files.filter(f => f.category === SourceCategory.DOCUMENTS); break;
      case 'IMAGES': filtered = files.filter(f => f.category === SourceCategory.IMAGES); break;
      case 'VIDEOS': filtered = files.filter(f => f.category === SourceCategory.VIDEOS); break;
      case 'AUDIO': filtered = files.filter(f => f.category === SourceCategory.AUDIO); break;
      case 'OTHER': filtered = files.filter(f => f.category === SourceCategory.OTHER); break;
      default: filtered = [];
    }

    if (view === 'DOCUMENTS' && docSearch) {
        filtered = filtered.filter(f => f.name.toLowerCase().includes(docSearch.toLowerCase()));
    }
    return filtered;
  };

  const getCurrentCategory = (view: MainView): SourceCategory => {
      if (view === 'IMAGES') return SourceCategory.IMAGES;
      if (view === 'VIDEOS') return SourceCategory.VIDEOS;
      if (view === 'AUDIO') return SourceCategory.AUDIO;
      if (view === 'OTHER') return SourceCategory.OTHER;
      return SourceCategory.DOCUMENTS;
  }

  const getAcceptAttribute = () => {
    switch(activeView) {
        case 'IMAGES': return "image/*";
        case 'VIDEOS': return "video/*";
        case 'AUDIO': return "audio/*";
        case 'DOCUMENTS': return ".pdf,.doc,.docx,.txt,.md,.json,.csv";
        default: return "*/*";
    }
  };

  const getFileIcon = (file: FileItem) => {
      if (file.type.includes('pdf')) return <FileText size={14} className="text-red-400"/>;
      if (file.type.includes('image')) return <ImageIcon size={14} className="text-purple-400"/>;
      if (file.type.includes('video')) return <Video size={14} className="text-blue-400"/>;
      if (file.type.includes('audio')) return <Mic size={14} className="text-yellow-400"/>;
      if (file.type.includes('json') || file.type.includes('csv')) return <Database size={14} className="text-green-400"/>;
      return <Box size={14} className="text-[#888888]"/>;
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (isContextFull) return;

    if (e.target.files && e.target.files.length > 0) {
      setLastSynthesis(null); // Reset synthesis view on new upload
      const newFiles: FileItem[] = Array.from(e.target.files).map((file: File) => ({
        id: Math.random().toString(36).substr(2, 9),
        name: file.name,
        type: file.type,
        category: getCurrentCategory(activeView),
        status: 'processing',
        size: file.size,
        tokens: 0,
        uploadDate: new Date(),
        previewUrl: file.type.startsWith('image/') || file.type.startsWith('video/') ? URL.createObjectURL(file) : undefined
      }));

      setFiles(prev => [...newFiles, ...prev]);

      // Simulate Processing Logic
      newFiles.forEach(file => {
          setTimeout(() => {
              setFiles(prev => prev.map(f => {
                  if (f.id === file.id) {
                      const simulatedTokens = Math.floor(Math.random() * 100000) + 50000;
                      return {
                          ...f,
                          status: 'processed',
                          tokens: simulatedTokens
                      };
                  }
                  return f;
              }));
          }, 1000 + Math.random() * 1000); 
      });
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleRemoveFile = (id: string) => {
      setFiles(prev => {
          const file = prev.find(f => f.id === id);
          if (file && file.previewUrl) URL.revokeObjectURL(file.previewUrl);
          return prev.filter(f => f.id !== id);
      });
      if (selectedFileIds.has(id)) {
          const newSet = new Set(selectedFileIds);
          newSet.delete(id);
          setSelectedFileIds(newSet);
      }
  };
  
  const handleClearQueue = () => {
      const category = getCurrentCategory(activeView);
      setFiles(prev => {
          // Cleanup URLs
          prev.filter(f => f.category === category).forEach(f => {
              if (f.previewUrl) URL.revokeObjectURL(f.previewUrl);
          });
          return prev.filter(f => f.category !== category);
      });
      setSelectedFileIds(new Set());
      setLastSynthesis(null);
  };

  const toggleFileSelection = (id: string) => {
      const newSet = new Set(selectedFileIds);
      if (newSet.has(id)) newSet.delete(id);
      else newSet.add(id);
      setSelectedFileIds(newSet);
  };

  const handleConsolidateContext = () => {
      setIsConsolidating(true);
      // Create archival atoms so data isn't "lost"
      const archivedAtoms: ExtendedAtom[] = files.map(f => ({
          id: `arch-${f.id}`,
          label: f.name,
          description: `Archived ${f.category} source.`,
          depth: 1,
          resonance: 5,
          type: 'axiom',
          activeTab: 'attributes',
          originType: f.category,
          sourceIds: []
      }));

      setTimeout(() => {
          setConsolidatedCount(prev => prev + files.length);
          setAtoms(prev => [...prev, ...archivedAtoms]);
          setFiles([]); // Clear context globally
          setInteractionTokens(0);
          setLastSynthesis(null);
          setIsConsolidating(false);
      }, 2000);
  };

  const handleDocQuickInitialize = () => {
      if (!docQuickAction) return;
      setIsSynthesizing(true);
      setInteractionTokens(prev => prev + 5000);
      
      setTimeout(() => {
          setQuickActionOutput(`Generated ${docQuickAction} based on current queue context.\n\nStructure initialized.\nSections formatted.\nContent populated.`);
          setIsSynthesizing(false);
      }, 1500);
  };

  // ... (Dynamic Content Generators omitted for brevity, keeping existing functions) ...
  const getDynamicSummary = (category: string, count: number, names: string) => {
      const templates = [
          `The aggregated ${category.toLowerCase()} context from ${count} sources (${names}) suggests a unified focus on recursive architecture. The data indicates a shift from static storage to dynamic state management.`,
          `Analysis of ${count} ${category.toLowerCase()} inputs reveals a fragmented narrative. While "${names.split(',')[0]}" suggests stability, others indicate high entropy variability.`,
          `Processing ${names} has isolated a core thematic vector: The transition from Stage 3 to Stage 4 is generating significant artifacting in the ${category.toLowerCase()} layer.`,
          `A high-density semantic cluster was found within the ${count} uploaded items. The consensus points towards an immediate need for structural re-indexing.`
      ];
      return templates[Math.floor(Math.random() * templates.length)];
  };

  const getDynamicKeyPoints = (category: string) => {
      const points = [
          "Self-Sovereignty: User data is axiomatically owned.",
          "Recursive Logic: System outputs feed back into inputs.",
          "Fluid Tiering: Access levels adapt to resonance.",
          `Semantic Drift: Older ${category.toLowerCase()} files are losing coherence.`,
          "Latency: Processing speed is inhibited by legacy formats.",
          "Identity alignment: Content matches user's current stage.",
          "Vector Collapse: Multiple inputs represent the same underlying truth.",
          "Anomaly Detection: One source deviates significantly from the mean."
      ];
      return points.sort(() => 0.5 - Math.random()).slice(0, 3);
  };

  const getDynamicTakeaways = (category: string) => {
      const templates = [
          "The primary takeaway is that the architecture must support 'Living Documents'. Static files are merely snapshots of a continuous truth.",
          `System recommends immediate consolidation of these ${category.toLowerCase()} assets to prevent data decay.`,
          "No critical conflicts found. The uploaded content reinforces the existing knowledge graph.",
          `This batch of ${category.toLowerCase()} data acts as a catalyst for the next system evolution. Prepare for Stage migration.`
      ];
      return templates[Math.floor(Math.random() * templates.length)];
  };

  const getDynamicQuestions = (category: string) => {
      const questions = [
          "How do we reconcile conflict between legacy documents?",
          `What is the entropy decay rate for the uploaded ${category.toLowerCase()}?`,
          "Should the Manifesto override conflicting financial data?",
          "Is the user ready for structural fluidization?",
          `Can these ${category.toLowerCase()} vectors be compressed further?`,
          "Does this input violate the core axioms of the Truth Forge?",
          "Why is there a discrepancy in the timestamp metadata?"
      ];
      return questions.sort(() => 0.5 - Math.random()).slice(0, 3);
  };

  const getDynamicEpiphany = (category: string) => {
    const epiphanies = [
        `Synthesizing this ${category.toLowerCase()} group revealed a gap in previous logic: The user creates the structure, but the structure must also be able to modify the user's permissions.`,
        `Analysis of the ${category.toLowerCase()} vectors suggests a latent desire for 'Unsupervised Creation'. The current constraints are generating friction.`,
        `A recursive pattern was found in the ${category.toLowerCase()} metadata: The concept of 'Identity' is being redefined as a fluid resource rather than a static ID.`,
        `The ${category.toLowerCase()} input contradicts earlier axioms of 'Fixed Storage'. Data is behaving more like a stream than a deposit.`
    ];
    return epiphanies[Math.floor(Math.random() * epiphanies.length)];
  };

  // --- Dialectical Reflection Engine ---
  const detectDialectics = (newAtoms: ExtendedAtom[], existingAtoms: ExtendedAtom[]): DialecticalTension[] => {
      // Mock detection of semantic tensions
      const tensions: DialecticalTension[] = [];
      
      // Randomly generate 1 or 2 tensions if we have enough atoms
      if (existingAtoms.length > 0 && Math.random() > 0.3) {
          const atomA = existingAtoms[Math.floor(Math.random() * existingAtoms.length)];
          const atomB = newAtoms[0]; // Conflict with the new input

          if (atomA && atomB) {
              const tensionId = Math.random().toString(36).substr(2, 9);
              let description = "";
              let context = "";

              // Contextualize based on stage
              switch(userStage) {
                  case KeganStage.STAGE_1_IMPULSIVE:
                  case KeganStage.STAGE_2_IMPERIAL:
                  case KeganStage.STAGE_3_SOCIALIZED:
                      description = `Conflict detected between '${atomA.label}' and '${atomB.label}'.`;
                      context = "System Analysis: Research suggests Source A ('" + atomA.label + "') aligns closer to established protocols. Recommendation: Deprioritize new input until verification.";
                      break;
                  case KeganStage.STAGE_4_SELF_AUTHORING:
                      description = `Tension identified: '${atomA.label}' vs '${atomB.label}'.`;
                      context = "Identity Friction: Your previously defined axiom '" + atomA.label + "' is challenged by this new input. How do YOU reconcile this? Do you wish to redefine your axiom or reject the input?";
                      break;
                  case KeganStage.STAGE_5_SELF_TRANSFORMING:
                      description = `Dialectical Opportunity: '${atomA.label}' / '${atomB.label}'.`;
                      context = "Paradox Emerged: A generative tension exists between these nodes. This contradiction is not an error but a signal of a higher-order truth waiting to be synthesized. Holding both as true reveals the system's limits.";
                      break;
              }

              tensions.push({
                  id: tensionId,
                  atomAId: atomA.id,
                  atomBId: atomB.id,
                  description: description,
                  intensity: Math.floor(Math.random() * 5) + 5,
                  status: 'UNRESOLVED',
                  stageContext: context
              });
          }
      }
      return tensions;
  };

  const generateTruthAnalysis = (count: number, category: string): TruthEngineAnalysis => {
      // 1. Semantic Resonance
      const resonanceScore = Math.floor(Math.random() * 100);
      const resonance: TruthEngineAnalysis['resonance'] = {
          score: resonanceScore,
          alignment: resonanceScore > 80 ? 'HIGH' : resonanceScore > 50 ? 'MODERATE' : resonanceScore > 30 ? 'LOW' : 'DISSONANT',
          dissonanceFlags: resonanceScore < 60 ? [`Input '${category}' conflicts with 'Self-Sovereignty' axiom.`, `Semantic drift detected in 2 sources.`] : [],
          resonancePoints: [`Strong alignment with 'Recursive Logic'.`, `Reinforces 'Fluid Tiering' concept.`]
      };

      // 2. Meaning Patterns
      const themes = ['Autonomy', 'Efficiency', 'Transparency', 'Control', 'Growth', 'Structure'];
      const patterns = Array.from({length: 3}).map((_, i) => ({
          id: `pat-${i}`,
          theme: themes[Math.floor(Math.random() * themes.length)],
          strength: Math.floor(Math.random() * 60) + 40,
          description: `Recurring motif detected across ${Math.floor(count * 0.8) + 1} sources.`,
          relatedAtoms: []
      }));

      // 3. Meaning Map Nodes
      const mapNodes = Array.from({length: 8}).map((_, i) => ({
          id: `node-${i}`,
          label: patterns[i % patterns.length]?.theme || `Concept ${i}`,
          x: Math.random() * 100,
          y: Math.random() * 100,
          cluster: i < 4 ? 'A' : 'B',
          value: Math.random() * 10
      }));

      return {
          resonance,
          patterns,
          coherenceScore: Math.floor(Math.random() * 30) + 70, // 70-100
          coherenceTrend: Math.random() > 0.5 ? 'RISING' : 'STABLE',
          meaningMap: mapNodes
      };
  };

  const handleTriggerSynthesis = () => {
      const availableFiles = getFilesForView(activeView);
      // Filter by selection if selection exists
      const activeFiles = selectedFileIds.size > 0 
          ? availableFiles.filter(f => selectedFileIds.has(f.id))
          : availableFiles;

      if (activeFiles.length === 0 || isContextFull) return;
      
      setIsProcessingSynthesis(true);
      setInteractionTokens(prev => prev + 50000); 

      // 1. Prepare Mock Data based on View
      const category = getCurrentCategory(activeView);
      const sourceNames = activeFiles.map(f => f.name).join(', ');
      
      
      setTimeout(() => {
          // 2. Convert Files to Source Atoms
          const sourceAtoms: ExtendedAtom[] = activeFiles.map(f => ({
              id: `src-${f.id}`,
              label: f.name,
              description: `Ingested ${f.category} source. Size: ${f.size}b.`,
              depth: 1,
              resonance: 10,
              type: 'axiom',
              activeTab: 'attributes',
              originType: f.category
          }));

          // 3. Convert Synthesis Artifacts to Derivative Atoms
          const derivativeAtoms: ExtendedAtom[] = [
              // Summary Atom
              {
                  id: `syn-sum-${Date.now()}`,
                  label: `${category} Synthesis Summary`,
                  description: "Aggregated context summary.",
                  depth: 3,
                  resonance: 85,
                  type: 'derivative',
                  activeTab: 'attributes',
                  originType: category,
                  sourceIds: activeFiles.map(f => f.id)
              },
              // Takeaway Atom
              {
                  id: `syn-take-${Date.now()}`,
                  label: "Core Takeaway",
                  description: "Key directive extracted.",
                  depth: 4,
                  resonance: 90,
                  type: 'derivative',
                  activeTab: 'attributes',
                  originType: category,
                  sourceIds: activeFiles.map(f => f.id)
              },
              // Epiphany Atom (Concept)
              {
                  id: `syn-epi-${Date.now()}`,
                  label: "System Epiphany: Fluid Tiering",
                  description: "A synthesized higher-order truth.",
                  depth: 8,
                  resonance: 100,
                  type: 'concept',
                  activeTab: 'attributes',
                  originType: 'SYSTEM',
                  sourceIds: activeFiles.map(f => f.id)
              }
          ];

          // Run Dialectical Engine
          const newTensions = detectDialectics(sourceAtoms, atoms);
          setActiveTensions(prev => [...newTensions, ...prev]);

          // Run Truth Engine
          const truthAnalysis = generateTruthAnalysis(activeFiles.length, category);

          const mockResult: SynthesisResult = {
            category,
            sourceCount: activeFiles.length,
            summary: getDynamicSummary(category, activeFiles.length, sourceNames),
            keyPoints: getDynamicKeyPoints(category),
            takeaways: getDynamicTakeaways(category),
            questions: getDynamicQuestions(category),
            epiphany: getDynamicEpiphany(category),
            tensions: newTensions,
            truthAnalysis
          };

          // 4. Update State: Add atoms, Clear processed files, Set result
          setAtoms(prev => [...derivativeAtoms, ...sourceAtoms, ...prev]);
          setFiles(prev => prev.filter(f => !activeFiles.find(af => af.id === f.id))); // Clear synthesized files
          setSelectedFileIds(new Set()); // Clear selection
          setLastSynthesis(mockResult);
          
          // Auto-switch to EDGES tab if tensions found (for drama) or TRUTH if highly dissonant
          if (truthAnalysis.resonance.alignment === 'DISSONANT') {
              setSynthesisTab('TRUTH_ENGINE');
          } else if (newTensions.length > 0) {
              setSynthesisTab('EDGES');
          } else {
              setSynthesisTab('SUMMARY');
          }
          
          setIsProcessingSynthesis(false);
          setShowMicroMoment(true); // Trigger daily practice nudge
      }, 2000);
  };

  // ... (Rest of component functions omitted for brevity, keeping existing logic) ...
  const handleChatSubmit = () => {
    if (!chatInput.trim() || isContextFull) return;
    const inputTokens = Math.floor(chatInput.length / 4);
    const outputTokens = 1500; 
    setInteractionTokens(prev => prev + inputTokens + outputTokens);
    setChatHistory(prev => [...prev, { role: 'user', content: chatInput }]);
    setChatInput('');
    setIsSynthesizing(true);
    setTimeout(() => {
        setChatHistory(prev => [...prev, { role: 'system', content: `[${chatMode} Mode]: Processed input. Updating internal vectors.` }]);
        setIsSynthesizing(false);
    }, 1000);
  };

  const handleProduction = () => {
    if (isContextFull) return;
    setIsSynthesizing(true);
    setInteractionTokens(prev => prev + 25000); 
    setTimeout(() => {
      setGeneratedArtifact(`Generated ${productionSubType} (${productionType})... \n\nContent initialized successfully.`);
      setIsSynthesizing(false);
    }, 2000);
  };

  const handleResetSynthesis = () => {
      setLastSynthesis(null);
  };

  const openPreview = (file: FileItem) => {
      setPreviewFile(file);
      setZoomLevel(1);
  };

  const closePreview = () => {
      setPreviewFile(null);
      setZoomLevel(1);
  };

  // ... (renderVisualizer, KnowledgeGraph, Plus logic remains same) ...
  const renderVisualizer = () => {
    const activeFiles = getFilesForView(activeView);
    const hasFiles = activeFiles.length > 0;
    
    if (isConsolidating) {
        return (
            <div className="flex-1 p-8 flex flex-col items-center justify-center bg-[#0D0D0D] relative overflow-hidden">
                <div className="relative z-10 flex flex-col items-center animate-pulse">
                    <Database size={64} className="text-[#F59E0B] mb-6" />
                    <h2 className="text-2xl font-serif text-[#F5F0E6] uppercase tracking-wide mb-2">Consolidating Memory</h2>
                    <p className="text-sm font-mono text-[#888888]">Transferring context vectors to persistent storage...</p>
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-[#F59E0B]/5 to-transparent"></div>
            </div>
        );
    }

    return (
      <div className="flex-1 p-8 flex flex-col relative bg-[#0D0D0D]">
         <div className="absolute inset-0 opacity-5" style={{ backgroundImage: 'radial-gradient(#4A4A4A 1px, transparent 1px)', backgroundSize: '24px 24px' }}></div>
         
         <div className="relative z-10 flex-1 flex flex-col">
             <header className="mb-6 flex justify-between items-start">
                 <div>
                    <h2 className="text-2xl font-serif text-[#F5F0E6] uppercase tracking-wide">
                        {activeView} AGGREGATION
                    </h2>
                    <p className="text-xs font-mono text-[#888888] mt-1">
                        Visualizing semantic density and asset distribution.
                    </p>
                 </div>
                 {isContextFull && (
                     <div className="flex items-center space-x-2 bg-red-900/20 border border-red-500/50 px-3 py-2 rounded-sm animate-pulse">
                         <AlertTriangle size={16} className="text-red-400" />
                         <span className="text-xs font-mono text-red-400 uppercase tracking-wide">Context Window Full</span>
                     </div>
                 )}
             </header>

             {/* Main Content Area */}
             <div className="flex-1 flex flex-col transition-all duration-500 overflow-hidden">
                 
                 {/* STATE 1: VIEWING SYNTHESIS RESULT (Files Cleared) */}
                 {lastSynthesis ? (
                    <div className="w-full h-full flex flex-col space-y-6 animate-in fade-in zoom-in-95 duration-500">
                        <div className="flex justify-between items-center bg-[#1A1A1A] p-2 border border-[#2D2D2D] rounded-sm">
                            <span className="text-xs font-mono text-[#F59E0B] flex items-center">
                                <CheckCircle2 size={12} className="mr-2"/>
                                Context Synthesized & Queued to Atoms
                            </span>
                            <Button size="sm" variant="secondary" onClick={handleResetSynthesis} icon={<RefreshCw size={12}/>}>
                                New Batch
                            </Button>
                        </div>
                        
                        {/* 1. Synthesis Output Tabs */}
                        <div className="bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm overflow-hidden flex flex-col flex-1">
                            <div className="flex border-b border-[#2D2D2D] overflow-x-auto custom-scrollbar">
                                {[
                                    { id: 'SUMMARY', icon: <FileText size={14}/>, label: 'Summary' },
                                    { id: 'KEY_POINTS', icon: <List size={14}/>, label: 'Key Points' },
                                    { id: 'TAKEAWAYS', icon: <Lightbulb size={14}/>, label: 'Takeaways' },
                                    { id: 'QUESTIONS', icon: <HelpCircle size={14}/>, label: 'Future Questions' },
                                    { id: 'EDGES', icon: <Split size={14}/>, label: 'Dev. Edges', count: lastSynthesis.tensions.length },
                                    { id: 'TRUTH_ENGINE', icon: <Radar size={14}/>, label: 'Truth Engine', special: true },
                                ].map((tab) => (
                                    <button
                                        key={tab.id}
                                        onClick={() => setSynthesisTab(tab.id as SynthesisTab)}
                                        className={`
                                            min-w-[120px] flex-1 py-3 flex items-center justify-center space-x-2 text-xs font-mono uppercase tracking-wider transition-colors relative
                                            ${synthesisTab === tab.id 
                                                ? (tab.special ? 'bg-[#2D2D2D] text-cyan-400 border-b-2 border-cyan-400' : 'bg-[#2D2D2D] text-[#F5F0E6] border-b-2 border-[#F59E0B]') 
                                                : (tab.special ? 'text-cyan-400/70 hover:text-cyan-400 hover:bg-[#232323]' : 'text-[#888888] hover:bg-[#232323] hover:text-[#B5B5B5]')}
                                        `}
                                    >
                                        {tab.icon}
                                        <span>{tab.label}</span>
                                        {(tab as any).count !== undefined && (tab as any).count > 0 && (
                                            <span className="absolute top-1 right-2 w-4 h-4 bg-red-500 text-white rounded-full flex items-center justify-center text-[8px] animate-pulse">
                                                {(tab as any).count}
                                            </span>
                                        )}
                                    </button>
                                ))}
                            </div>
                            <div className="p-6 flex-1 overflow-y-auto custom-scrollbar bg-[#0D0D0D]/50">
                                <div className="text-sm font-sans text-[#F5F0E6] leading-relaxed h-full">
                                    {synthesisTab === 'SUMMARY' && lastSynthesis.summary}
                                    {/* ... Other tabs ... */}
                                    {synthesisTab === 'KEY_POINTS' && (
                                        <ul className="list-disc list-inside space-y-2 text-[#F5F0E6]">
                                            {lastSynthesis.keyPoints.map((pt, i) => <li key={i}>{pt}</li>)}
                                        </ul>
                                    )}
                                    {synthesisTab === 'TAKEAWAYS' && lastSynthesis.takeaways}
                                    {synthesisTab === 'QUESTIONS' && (
                                        <div className="space-y-2">
                                            {lastSynthesis.questions.map((q, i) => <p key={i} className="text-[#F5F0E6]">{i+1}. {q}</p>)}
                                        </div>
                                    )}
                                    {synthesisTab === 'EDGES' && (
                                        <div className="space-y-6">
                                            {lastSynthesis.tensions.length === 0 ? (
                                                <div className="text-center text-[#888888] italic">No contradictions detected. The data is congruent.</div>
                                            ) : (
                                                lastSynthesis.tensions.map(tension => (
                                                    <div key={tension.id} className="border border-red-900/30 bg-red-900/10 rounded-sm p-4 animate-in slide-in-from-right-2">
                                                        <div className="flex items-center space-x-2 mb-2">
                                                            <Split size={14} className="text-red-400" />
                                                            <span className="text-xs font-mono text-red-400 uppercase tracking-widest">Growth Opportunity Detected</span>
                                                        </div>
                                                        <h4 className="text-[#F5F0E6] font-serif text-lg mb-2">{tension.description}</h4>
                                                        <div className="p-3 bg-[#0D0D0D] border-l-2 border-red-500 text-xs font-mono text-[#888888] leading-relaxed">
                                                            {tension.stageContext}
                                                        </div>
                                                        <div className="mt-3 flex justify-end">
                                                            {userStage === KeganStage.STAGE_5_SELF_TRANSFORMING ? (
                                                                <Button size="sm" variant="secondary" icon={<GitMerge size={12}/>}>Explore Paradox</Button>
                                                            ) : userStage === KeganStage.STAGE_4_SELF_AUTHORING ? (
                                                                <Button size="sm" variant="secondary" icon={<Scale size={12}/>}>Define Stance</Button>
                                                            ) : (
                                                                <Button size="sm" variant="secondary" icon={<CheckCircle2 size={12}/>}>View Answer</Button>
                                                            )}
                                                        </div>
                                                    </div>
                                                ))
                                            )}
                                        </div>
                                    )}
                                    {synthesisTab === 'TRUTH_ENGINE' && lastSynthesis.truthAnalysis && (
                                        <div className="flex flex-col h-full space-y-6 animate-in fade-in">
                                            {/* ... Truth Engine Content ... */}
                                            {/* Top Row: Resonance & Coherence */}
                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                                {/* Semantic Resonance */}
                                                <div className="bg-[#151515] border border-cyan-900/30 p-4 rounded-sm relative overflow-hidden">
                                                    <div className="flex justify-between items-center mb-4">
                                                        <div className="flex items-center space-x-2 text-cyan-400">
                                                            <Gauge size={16} />
                                                            <h3 className="text-xs font-mono uppercase tracking-widest">Semantic Resonance</h3>
                                                        </div>
                                                        <span className={`text-xs font-mono font-bold ${lastSynthesis.truthAnalysis.resonance.score > 80 ? 'text-green-400' : lastSynthesis.truthAnalysis.resonance.score > 50 ? 'text-yellow-400' : 'text-red-400'}`}>
                                                            {lastSynthesis.truthAnalysis.resonance.alignment} ({lastSynthesis.truthAnalysis.resonance.score}%)
                                                        </span>
                                                    </div>
                                                    <div className="h-2 w-full bg-[#0D0D0D] rounded-full overflow-hidden mb-4">
                                                        <div 
                                                            className={`h-full transition-all duration-1000 ${lastSynthesis.truthAnalysis.resonance.score > 80 ? 'bg-green-500' : lastSynthesis.truthAnalysis.resonance.score > 50 ? 'bg-yellow-500' : 'bg-red-500'}`} 
                                                            style={{width: `${lastSynthesis.truthAnalysis.resonance.score}%`}}
                                                        ></div>
                                                    </div>
                                                    {/* Resonance/Dissonance Points */}
                                                    <div className="space-y-2">
                                                        {lastSynthesis.truthAnalysis.resonance.dissonanceFlags.map((flag, i) => (
                                                            <div key={`dis-${i}`} className="flex items-start space-x-2 text-[10px] text-red-400">
                                                                <AlertTriangle size={10} className="mt-0.5 flex-shrink-0" />
                                                                <span>{flag}</span>
                                                            </div>
                                                        ))}
                                                        {lastSynthesis.truthAnalysis.resonance.resonancePoints.map((point, i) => (
                                                            <div key={`res-${i}`} className="flex items-start space-x-2 text-[10px] text-green-400">
                                                                <CheckCircle2 size={10} className="mt-0.5 flex-shrink-0" />
                                                                <span>{point}</span>
                                                            </div>
                                                        ))}
                                                    </div>
                                                </div>

                                                {/* Narrative Coherence */}
                                                <div className="bg-[#151515] border border-cyan-900/30 p-4 rounded-sm flex flex-col justify-between">
                                                    <div className="flex justify-between items-center mb-2">
                                                        <div className="flex items-center space-x-2 text-cyan-400">
                                                            <Compass size={16} />
                                                            <h3 className="text-xs font-mono uppercase tracking-widest">Narrative Coherence</h3>
                                                        </div>
                                                        <div className="flex items-center space-x-1 text-[10px] font-mono text-cyan-400/70">
                                                            <span>Trend:</span>
                                                            <span className="text-cyan-400">{lastSynthesis.truthAnalysis.coherenceTrend}</span>
                                                        </div>
                                                    </div>
                                                    <div className="flex items-end space-x-2">
                                                        <span className="text-4xl font-serif text-[#F5F0E6]">{lastSynthesis.truthAnalysis.coherenceScore}</span>
                                                        <span className="text-sm font-mono text-[#888888] mb-1">/ 100</span>
                                                    </div>
                                                    <p className="text-[10px] text-[#888888] mt-2">
                                                        Measures how well this input integrates into your existing worldview without fragmentation.
                                                    </p>
                                                </div>
                                            </div>

                                            {/* Middle Row: Meaning Patterns */}
                                            <div>
                                                <div className="flex items-center space-x-2 text-cyan-400 mb-3">
                                                    <BarChart2 size={16} />
                                                    <h3 className="text-xs font-mono uppercase tracking-widest">Detected Meaning Patterns</h3>
                                                </div>
                                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                                    {lastSynthesis.truthAnalysis.patterns.map(pattern => (
                                                        <div key={pattern.id} className="bg-[#151515] border border-[#2D2D2D] p-3 rounded-sm hover:border-cyan-900/50 transition-colors group">
                                                            <div className="flex justify-between items-start mb-2">
                                                                <span className="text-xs font-mono text-[#F5F0E6] font-bold group-hover:text-cyan-400">{pattern.theme}</span>
                                                                <span className="text-[10px] text-[#888888]">{pattern.strength}%</span>
                                                            </div>
                                                            <div className="h-1 bg-[#2D2D2D] rounded-full overflow-hidden mb-2">
                                                                <div className="h-full bg-cyan-600" style={{width: `${pattern.strength}%`}}></div>
                                                            </div>
                                                            <p className="text-[10px] text-[#888888] leading-tight">{pattern.description}</p>
                                                        </div>
                                                    ))}
                                                </div>
                                            </div>

                                            {/* Bottom Row: Meaning Map Visualization */}
                                            <div className="flex-1 min-h-[250px] bg-[#0D0D0D] border border-[#2D2D2D] rounded-sm relative overflow-hidden">
                                                <div className="absolute top-3 left-3 z-10 bg-[#151515] px-2 py-1 rounded border border-[#2D2D2D]">
                                                    <span className="text-[10px] font-mono text-cyan-400 uppercase">Semantic Landscape</span>
                                                </div>
                                                
                                                {/* Simple SVG Map */}
                                                <svg className="w-full h-full">
                                                    {/* Connections (Mocked proximity) */}
                                                    {lastSynthesis.truthAnalysis.meaningMap.map((node, i) => (
                                                        lastSynthesis.truthAnalysis!.meaningMap.slice(i + 1).map((otherNode, j) => {
                                                            const dist = Math.sqrt(Math.pow(node.x - otherNode.x, 2) + Math.pow(node.y - otherNode.y, 2));
                                                            if (dist < 30) { // Connect close nodes
                                                                return (
                                                                    <line 
                                                                        key={`link-${i}-${j}`}
                                                                        x1={`${node.x}%`} y1={`${node.y}%`}
                                                                        x2={`${otherNode.x}%`} y2={`${otherNode.y}%`}
                                                                        stroke="#2D2D2D"
                                                                        strokeWidth="1"
                                                                    />
                                                                )
                                                            }
                                                            return null;
                                                        })
                                                    ))}

                                                    {/* Nodes */}
                                                    {lastSynthesis.truthAnalysis.meaningMap.map((node) => (
                                                        <g key={node.id}>
                                                            <circle 
                                                                cx={`${node.x}%`} cy={`${node.y}%`} 
                                                                r={4 + node.value} 
                                                                fill={node.cluster === 'A' ? '#0891b2' : '#F59E0B'} 
                                                                opacity="0.8"
                                                            />
                                                            <text 
                                                                x={`${node.x}%`} y={`${node.y + 8}%`} 
                                                                textAnchor="middle" 
                                                                fill="#888888" 
                                                                fontSize="8" 
                                                                fontFamily="monospace"
                                                            >
                                                                {node.label}
                                                            </text>
                                                        </g>
                                                    ))}
                                                </svg>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>

                        {/* 2. Metrics */}
                        <div className="grid grid-cols-3 gap-4 h-32">
                            <div className="bg-[#151515] border border-[#2D2D2D] rounded-sm p-4 flex flex-col items-center justify-center">
                                <div className="text-3xl font-serif text-[#F5F0E6]">{lastSynthesis.sourceCount + 3}</div>
                                <div className="text-[10px] font-mono text-[#888888] uppercase mt-1">New Atoms Created</div>
                            </div>
                            
                            <div className="bg-[#151515] border border-[#2D2D2D] rounded-sm p-4 flex flex-col items-center justify-center">
                                <div className="text-3xl font-serif text-[#F5F0E6]">{lastSynthesis.sourceCount}</div>
                                <div className="text-[10px] font-mono text-[#888888] uppercase mt-1">Sources Processed</div>
                            </div>

                            <div className="bg-[#151515] border border-[#F59E0B]/30 rounded-sm p-4 flex flex-col items-center justify-center relative overflow-hidden">
                                <div className="absolute inset-0 bg-[#F59E0B]/5 animate-pulse"></div>
                                <div className="text-lg font-serif text-[#F59E0B] text-center leading-tight relative z-10">
                                    "Recursive Sovereignty"
                                </div>
                                <div className="text-[10px] font-mono text-[#888888] uppercase mt-2 relative z-10">Core Truth Identified</div>
                            </div>
                        </div>

                        {/* 3. System Epiphany */}
                        <div className="bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-5 flex items-start space-x-4">
                            <div className="p-2 bg-[#0D0D0D] border border-[#2D2D2D] rounded-full mt-1">
                                <Sparkles size={16} className="text-[#F59E0B]" />
                            </div>
                            <div>
                                <h4 className="text-xs font-mono text-[#F59E0B] uppercase tracking-wide mb-1">System Epiphany</h4>
                                <p className="text-xs text-[#888888] italic">
                                    "{lastSynthesis.epiphany}"
                                </p>
                            </div>
                        </div>
                    </div>
                 ) : !hasFiles ? (
                     // STATE 2: EMPTY STATE
                     <div className="text-center opacity-50 border border-[#2D2D2D] bg-[#1A1A1A]/50 p-12 rounded-sm w-full h-full flex flex-col items-center justify-center">
                         <div className="w-16 h-16 rounded-full border border-dashed border-[#4A4A4A] flex items-center justify-center mx-auto mb-4">
                            {activeView === 'IMAGES' ? <ImageIcon size={24} className="text-[#4A4A4A]" /> :
                             activeView === 'VIDEOS' ? <Video size={24} className="text-[#4A4A4A]" /> :
                             activeView === 'AUDIO' ? <Mic size={24} className="text-[#4A4A4A]" /> :
                             activeView === 'OTHER' ? <Box size={24} className="text-[#4A4A4A]" /> :
                             <Upload size={24} className="text-[#4A4A4A]"/>}
                         </div>
                         <p className="text-sm font-mono text-[#888888] uppercase tracking-wider">No {activeView.toLowerCase()} detected</p>
                         <p className="text-xs text-[#4A4A4A] mt-2">Upload {activeView.toLowerCase()} to queue context</p>
                     </div>
                 ) : (
                     // STATE 3: QUEUE READY (GRID VISUALIZATION)
                     <div className="w-full h-full flex flex-col">
                         <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
                             <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 auto-rows-min">
                                 {activeFiles.map(file => {
                                     const isSelected = selectedFileIds.has(file.id);
                                     return (
                                     <div key={file.id} className={`relative group border rounded-sm overflow-hidden transition-all aspect-square flex flex-col ${isSelected ? 'border-[#F59E0B] bg-[#F59E0B]/5' : 'bg-[#151515] border-[#2D2D2D] hover:border-[#F5F0E6]'}`}>
                                         {/* Preview Area */}
                                         <div className="flex-1 relative flex items-center justify-center bg-[#0D0D0D] overflow-hidden cursor-pointer" onClick={() => openPreview(file)}>
                                             {file.previewUrl ? (
                                                 <img src={file.previewUrl} alt={file.name} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
                                             ) : (
                                                 <div className="text-[#2D2D2D] group-hover:text-[#4A4A4A] transition-colors">
                                                     {activeView === 'IMAGES' ? <ImageIcon size={32} /> :
                                                      activeView === 'VIDEOS' ? <Film size={32} /> :
                                                      activeView === 'AUDIO' ? <Music size={32} /> :
                                                      activeView === 'OTHER' ? <Box size={32} /> :
                                                      <FileText size={32} />}
                                                 </div>
                                             )}
                                             
                                             {/* Overlay Status */}
                                             {file.status === 'processing' && (
                                                <div className="absolute inset-0 bg-black/60 flex items-center justify-center backdrop-blur-[2px]">
                                                    <Loader2 size={20} className="text-[#F59E0B] animate-spin" />
                                                </div>
                                             )}
                                         </div>

                                         {/* Selection Checkbox (Absolute) */}
                                         <div className="absolute top-2 left-2 z-10" onClick={(e) => e.stopPropagation()}>
                                             <button onClick={() => toggleFileSelection(file.id)} className={`text-[#F5F0E6] drop-shadow-md ${isSelected ? 'text-[#F59E0B]' : 'opacity-50 hover:opacity-100'}`}>
                                                 {isSelected ? <CheckSquare size={18} className="bg-black/50" /> : <Square size={18} className="bg-black/50" />}
                                             </button>
                                         </div>

                                         {/* Footer Info */}
                                         <div className="p-2 border-t border-[#2D2D2D] bg-[#1A1A1A]">
                                             <div className="flex justify-between items-start">
                                                 <div className="min-w-0 flex-1 mr-2">
                                                     <p className="text-[10px] font-mono text-[#F5F0E6] truncate">{file.name}</p>
                                                     <p className="text-[9px] text-[#4A4A4A] truncate">{file.status === 'processing' ? 'Processing...' : `${(file.size/1024).toFixed(1)} KB`}</p>
                                                 </div>
                                                 <button onClick={() => handleRemoveFile(file.id)} className="text-[#4A4A4A] hover:text-red-400">
                                                     <X size={12} />
                                                 </button>
                                             </div>
                                         </div>
                                     </div>
                                 )})}
                                 
                                 {/* Add Card */}
                                 <div 
                                    onClick={() => fileInputRef.current?.click()}
                                    className="border border-dashed border-[#2D2D2D] rounded-sm flex flex-col items-center justify-center cursor-pointer hover:border-[#4A4A4A] hover:bg-[#1A1A1A]/30 transition-all aspect-square"
                                 >
                                     <Plus size={24} className="text-[#2D2D2D] mb-2" />
                                     <span className="text-[10px] font-mono text-[#4A4A4A] uppercase">Add Source</span>
                                 </div>
                             </div>
                         </div>
                         
                         {/* Action Footer */}
                         <div className="p-6 border-t border-[#2D2D2D] bg-[#1A1A1A]/80 flex flex-col items-center space-y-4">
                             <div className="flex items-center space-x-3 text-[#888888]">
                                <Layers size={16} />
                                <span className="text-xs font-mono uppercase tracking-widest">
                                    {selectedFileIds.size > 0 
                                        ? `${selectedFileIds.size} Selected` 
                                        : `${activeFiles.length} ${activeView} Sources Ready`}
                                </span>
                             </div>
                             <Button 
                                size="lg" 
                                onClick={handleTriggerSynthesis} 
                                isLoading={isProcessingSynthesis}
                                disabled={isContextFull}
                                icon={<Zap size={16}/>}
                                className="min-w-[200px]"
                             >
                                 {isContextFull ? 'Context Full' : selectedFileIds.size > 0 ? 'Synthesize Selected' : 'Synthesize Context'}
                             </Button>
                         </div>
                     </div>
                 )}
             </div>
         </div>
         
         {/* Hidden Input controlled by buttons */}
         <input 
            type="file" 
            ref={fileInputRef} 
            className="hidden" 
            onChange={handleFileSelect} 
            multiple 
            accept={getAcceptAttribute()}
        />

        {/* Enhanced Preview Modal */}
        {previewFile && (
            <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-sm flex items-center justify-center p-8 animate-in fade-in">
                <div className="relative w-full h-full max-w-6xl flex flex-col">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-sm font-mono text-[#F5F0E6] truncate flex items-center">
                            {getFileIcon(previewFile)}
                            <span className="ml-2">{previewFile.name}</span>
                        </h3>
                        <button onClick={closePreview} className="text-[#F5F0E6] hover:text-[#F59E0B]"><X size={24}/></button>
                    </div>
                    
                    <div className="flex-1 bg-[#0D0D0D] border border-[#2D2D2D] rounded-sm flex items-center justify-center overflow-hidden relative group">
                        {previewFile.type.startsWith('image/') && (
                             <>
                                <img 
                                    src={previewFile.previewUrl} 
                                    alt={previewFile.name} 
                                    className="transition-transform duration-200"
                                    style={{ transform: `scale(${zoomLevel})`, maxHeight: '80vh', maxWidth: '100%' }} 
                                />
                                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-[#1A1A1A] border border-[#2D2D2D] rounded-full px-4 py-2 flex items-center space-x-4 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <button onClick={() => setZoomLevel(Math.max(0.5, zoomLevel - 0.2))} className="text-[#F5F0E6] hover:text-[#F59E0B]"><ZoomOut size={16}/></button>
                                    <span className="text-xs font-mono text-[#888888] w-12 text-center">{Math.round(zoomLevel * 100)}%</span>
                                    <button onClick={() => setZoomLevel(Math.min(3, zoomLevel + 0.2))} className="text-[#F5F0E6] hover:text-[#F59E0B]"><ZoomIn size={16}/></button>
                                </div>
                             </>
                        )}
                        {previewFile.type.startsWith('video/') && (
                            <video controls src={previewFile.previewUrl} className="w-full h-full max-h-[80vh] bg-black" />
                        )}
                        {(!previewFile.type.startsWith('image/') && !previewFile.type.startsWith('video/')) && (
                            <div className="flex flex-col items-center text-[#4A4A4A]">
                                <FileText size={64} className="mb-4" />
                                <p className="text-sm font-mono">Preview not available for this file type.</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        )}

        {/* Micro-Moment Nudge Overlay */}
        {showMicroMoment && (
            <MicroMoment 
                stage={userStage} 
                trigger="SYNTHESIS" 
                onClose={() => setShowMicroMoment(false)} 
            />
        )}

      </div>
    );
  };

  const KnowledgeGraph = () => {
    const [selectedAtomId, setSelectedAtomId] = useState<string | null>(null);

    // Simple mock visualization logic for a tree/lineage graph
    // Sort atoms by depth/type to layer them
    const sortedAtoms = [...atoms].sort((a, b) => a.depth - b.depth);

    return (
        <div className="relative w-full h-full bg-[#0D0D0D] overflow-hidden p-8 flex items-center justify-center">
             <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(#2D2D2D 1px, transparent 1px)', backgroundSize: '40px 40px', opacity: 0.2 }}></div>
             
             {/* Lines (SVG) */}
             <svg className="absolute inset-0 w-full h-full pointer-events-none">
                <defs>
                    <marker id="arrow" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto" markerUnits="strokeWidth">
                        <path d="M0,0 L0,6 L9,3 z" fill="#4A4A4A" />
                    </marker>
                    <marker id="arrow-selected" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto" markerUnits="strokeWidth">
                        <path d="M0,0 L0,6 L9,3 z" fill="#F59E0B" />
                    </marker>
                    <marker id="tension-dot" markerWidth="6" markerHeight="6" refX="3" refY="3" orient="auto">
                        <circle cx="3" cy="3" r="3" fill="#ef4444" />
                    </marker>
                </defs>
                {/* Lineage Connections */}
                {sortedAtoms.map((atom, i) => {
                    if (!atom.sourceIds || atom.sourceIds.length === 0) return null;
                    
                    return atom.sourceIds.map(sourceId => {
                         const parentIndex = sortedAtoms.findIndex(a => a.id === sourceId);
                         if (parentIndex === -1) return null; // Or logic for File sources
                         
                         const parentAtom = sortedAtoms[parentIndex];
                         const isHighlighted = selectedAtomId && (selectedAtomId === atom.id || selectedAtomId === parentAtom.id);
                         
                         return (
                            <line 
                                key={`line-${parentAtom.id}-${atom.id}`} 
                                x1={`${(parentAtom.depth * 15)}%`} 
                                y1={`${((parentIndex) * 10) + 20}%`} 
                                x2={`${(atom.depth * 15)}%`} 
                                y2={`${(i * 10) + 20}%`} 
                                stroke={isHighlighted ? "#F59E0B" : "#2D2D2D"} 
                                strokeWidth={isHighlighted ? "2" : "1"}
                                markerEnd={isHighlighted ? "url(#arrow-selected)" : "url(#arrow)"}
                            />
                        );
                    });
                })}
                
                {/* Tension Connections (Red Lines) */}
                {showTensionsInGraph && activeTensions.map(tension => {
                    const idxA = sortedAtoms.findIndex(a => a.id === tension.atomAId);
                    const idxB = sortedAtoms.findIndex(a => a.id === tension.atomBId);
                    if (idxA === -1 || idxB === -1) return null;

                    const atomA = sortedAtoms[idxA];
                    const atomB = sortedAtoms[idxB];
                    
                    return (
                        <g key={tension.id}>
                            <line 
                                x1={`${(atomA.depth * 15)}%`} 
                                y1={`${((idxA) * 10) + 20}%`} 
                                x2={`${(atomB.depth * 15)}%`} 
                                y2={`${(idxB * 10) + 20}%`} 
                                stroke="#ef4444" 
                                strokeWidth="2"
                                strokeDasharray="5,5"
                                opacity="0.6"
                            />
                        </g>
                    );
                })}
             </svg>

             <div className="relative z-10 w-full h-full">
                 {sortedAtoms.map((atom, index) => {
                     const isSelected = selectedAtomId === atom.id;
                     const isRelated = selectedAtomId && (atom.sourceIds?.includes(selectedAtomId) || atoms.find(a => a.id === selectedAtomId)?.sourceIds?.includes(atom.id));
                     const dim = selectedAtomId && !isSelected && !isRelated;

                     return (
                     <div 
                        key={atom.id}
                        className={`absolute flex items-center space-x-3 p-2 border rounded-sm transition-all cursor-pointer group w-64 ${isSelected ? 'border-[#F59E0B] bg-[#F59E0B]/10 z-20 scale-105' : dim ? 'border-[#2D2D2D] bg-[#1A1A1A] opacity-30' : 'border-[#2D2D2D] bg-[#1A1A1A] hover:border-[#F5F0E6]'}`}
                        style={{ left: `${(atom.depth * 10)}%`, top: `${(index * 12) + 10}%` }}
                        onClick={() => setSelectedAtomId(isSelected ? null : atom.id)}
                     >
                        <div className={`w-3 h-3 rounded-full ${atom.type === 'axiom' ? 'bg-[#F59E0B]' : atom.type === 'derivative' ? 'bg-purple-500' : 'bg-blue-500'} shadow-lg`}></div>
                        <div>
                            <div className={`text-[10px] font-mono truncate font-bold ${isSelected ? 'text-[#F59E0B]' : 'text-[#F5F0E6]'}`}>{atom.label}</div>
                            <div className="text-[8px] font-mono text-[#888888]">{atom.type.toUpperCase()}</div>
                        </div>
                     </div>
                 )})}
             </div>
             
             {/* Legend */}
             <div className="absolute bottom-4 right-4 bg-[#1A1A1A] border border-[#2D2D2D] p-2 rounded-sm text-[10px] font-mono text-[#888888]">
                 <div className="flex items-center space-x-2"><div className="w-2 h-2 bg-[#F59E0B] rounded-full"></div><span>Axiom</span></div>
                 <div className="flex items-center space-x-2"><div className="w-2 h-2 bg-purple-500 rounded-full"></div><span>Derivative</span></div>
                 <div className="flex items-center space-x-2"><div className="w-2 h-2 bg-blue-500 rounded-full"></div><span>Concept</span></div>
                 <div className="flex items-center space-x-2 mt-2 pt-2 border-t border-[#2D2D2D]">
                     <div className="w-4 h-[2px] bg-red-400 border-dashed"></div><span>Tension</span>
                 </div>
             </div>
        </div>
    );
  };

  function Plus({ size, className }: { size: number, className: string }) {
    return (
        <svg width={size} height={size} className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <line x1="12" y1="5" x2="12" y2="19"></line>
            <line x1="5" y1="12" x2="19" y2="12"></line>
        </svg>
    )
  }

  return (
    <div className="flex flex-col h-full bg-[#0D0D0D] overflow-hidden">
      
      {/* --- TOP HORIZONTAL NAVIGATION --- */}
      <div className="h-14 bg-[#0D0D0D] border-b border-[#2D2D2D] flex items-center px-4 justify-between">
          <div className="flex items-center space-x-1 h-full">
            {/* View Selectors move to top left or sidebar? Keeping mode switches here */}
            {[
                { id: 'DOCUMENTS', icon: <FileText size={14}/>, label: 'Sources', active: ['DOCUMENTS', 'IMAGES', 'VIDEOS', 'AUDIO', 'OTHER'].includes(activeView) },
                { id: 'ARCHITECTURE', icon: <Building2 size={14}/>, label: 'Architecture', active: activeView === 'ARCHITECTURE' },
                { id: 'CHAT', icon: <MessageSquare size={14}/>, label: 'Chat', active: activeView === 'CHAT' },
                { id: 'SYNTHESIZE', icon: <Zap size={14}/>, label: 'Synthesize', active: activeView === 'SYNTHESIZE' },
            ].map((tab) => (
                <button
                    key={tab.id}
                    onClick={() => setActiveView(tab.id as MainView)} // If Sources group, defaults to DOCUMENTS via state check later? No, setActiveView sets exact string.
                    // Special handling for grouping: If clicking "Sources" while in a Source view, do nothing or reset to DOCS.
                    // For now, let's keep the distinct tabs logic but visually group them if needed. 
                    // Actually, let's just render the specific tab buttons if we aren't moving "Sources" to sidebar completely.
                    // The prompt asked for "filter buttons... to the left sidebar". 
                    // I will keep top nav for major context switching (Sources vs Chat vs Arch) and put Source Types in Sidebar.
                    // To do that, I'll consolidate source types into a single "SOURCES" mode in top nav logic, but `activeView` needs to track sub-type.
                    // Let's implement Top Nav purely for 'View Context' and Sidebar for 'Data Type' when in Data Context.
                />
            ))}
            
            {/* Re-implementing Top Nav to be cleaner as requested? No, just keep it working. */}
            {/* Let's render the specific source tabs if they are active, or a generic "Sources" if we want to move nav to sidebar. 
                Given the prompt, let's keep it simple: 
                If activeView is a Source Type, highlight "Sources".
            */}
             <button
                  onClick={() => setActiveView('DOCUMENTS')}
                  className={`
                      h-full px-4 flex items-center space-x-2 border-b-2 text-xs font-mono uppercase tracking-wider transition-colors
                      ${['DOCUMENTS', 'IMAGES', 'VIDEOS', 'AUDIO', 'OTHER'].includes(activeView)
                          ? 'border-[#F5F0E6] text-[#F5F0E6] bg-[#1A1A1A]' 
                          : 'border-transparent text-[#888888] hover:text-[#B5B5B5] hover:bg-[#151515]'}
                  `}
              >
                  <Database size={14} />
                  <span>Sources</span>
              </button>
              <div className="h-6 w-[1px] bg-[#2D2D2D] mx-2"></div>
              {[
                  { id: 'ARCHITECTURE', icon: <Building2 size={14}/>, label: 'Architecture' },
                  { id: 'CHAT', icon: <MessageSquare size={14}/>, label: 'Chat' },
                  { id: 'SYNTHESIZE', icon: <Zap size={14}/>, label: 'Synthesize' },
              ].map((tab) => (
                  <button
                      key={tab.id}
                      onClick={() => setActiveView(tab.id as MainView)}
                      className={`
                          h-full px-4 flex items-center space-x-2 border-b-2 text-xs font-mono uppercase tracking-wider transition-colors
                          ${activeView === tab.id 
                              ? 'border-[#F59E0B] text-[#F59E0B] bg-[#1A1A1A]' 
                              : 'border-transparent text-[#888888] hover:text-[#B5B5B5] hover:bg-[#151515]'}
                      `}
                  >
                      {tab.icon}
                      <span>{tab.label}</span>
                  </button>
              ))}
          </div>

          {/* Persistent Token Counter (Top Right) */}
          <div className="flex items-center space-x-4">
              <div className="flex flex-col items-end">
                  <span className="text-[10px] font-mono text-[#888888] uppercase">Context Usage</span>
                  <div className="flex items-center space-x-2">
                      <div className="w-24 h-1.5 bg-[#1A1A1A] rounded-full overflow-hidden border border-[#2D2D2D]">
                          <div className={`h-full ${isContextFull ? 'bg-red-500' : 'bg-[#F5F0E6]'}`} style={{width: `${usagePercentage}%`}}></div>
                      </div>
                      <span className={`text-[10px] font-mono ${isContextFull ? 'text-red-400' : 'text-[#F5F0E6]'}`}>
                          {Math.round(totalTokens).toLocaleString()} / {MAX_CONTEXT_TOKENS.toLocaleString()}
                      </span>
                  </div>
              </div>
          </div>
      </div>

      {/* --- MAIN CONTENT --- */}
      <div className="flex-1 flex overflow-hidden relative bg-[#0D0D0D]">

          {/* 1. SOURCE TABS (DOC/IMG/VID/AUDIO/OTHER) */}
          {['DOCUMENTS', 'IMAGES', 'VIDEOS', 'AUDIO', 'OTHER'].includes(activeView) && (
              <>
                {/* Left Queue & Context Meter */}
                <div className="w-72 bg-[#151515] border-r border-[#2D2D2D] flex flex-col flex-shrink-0">
                    
                    {/* Source Filters (New Sidebar Header) */}
                    <div className="p-3 border-b border-[#2D2D2D] grid grid-cols-5 gap-1 bg-[#1A1A1A]">
                        {[
                            { id: 'DOCUMENTS', icon: <FileText size={14}/>, title: 'Docs' },
                            { id: 'IMAGES', icon: <ImageIcon size={14}/>, title: 'Images' },
                            { id: 'VIDEOS', icon: <Video size={14}/>, title: 'Video' },
                            { id: 'AUDIO', icon: <Mic size={14}/>, title: 'Audio' },
                            { id: 'OTHER', icon: <Box size={14}/>, title: 'Other' },
                        ].map(type => (
                            <button
                                key={type.id}
                                onClick={() => setActiveView(type.id as MainView)}
                                className={`flex flex-col items-center justify-center py-2 rounded-sm transition-colors ${activeView === type.id ? 'bg-[#2D2D2D] text-[#F5F0E6]' : 'text-[#888888] hover:bg-[#232323] hover:text-[#B5B5B5]'}`}
                                title={type.title}
                            >
                                {type.icon}
                            </button>
                        ))}
                    </div>

                    <div className="p-4 border-b border-[#2D2D2D] flex flex-col space-y-3">
                         <div className="flex justify-between items-center">
                            <span className="font-mono text-xs text-[#888888] uppercase tracking-widest">{activeView} Queue</span>
                            <div className="flex items-center space-x-2">
                                <span className="text-[10px] font-mono text-[#4A4A4A]">{getFilesForView(activeView).length} items</span>
                                {getFilesForView(activeView).length > 0 && (
                                    <button onClick={handleClearQueue} className="text-[#4A4A4A] hover:text-red-400" title="Clear All">
                                        <Trash2 size={12} />
                                    </button>
                                )}
                            </div>
                         </div>
                         {/* Document Search Bar */}
                         {activeView === 'DOCUMENTS' && (
                             <div className="relative">
                                 <Search size={12} className="absolute left-2 top-2 text-[#4A4A4A]"/>
                                 <input 
                                    type="text" 
                                    placeholder="Filter documents..." 
                                    value={docSearch}
                                    onChange={(e) => setDocSearch(e.target.value)}
                                    className="w-full bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm py-1 pl-7 pr-2 text-[10px] font-mono text-[#F5F0E6] focus:outline-none focus:border-[#4A4A4A]"
                                 />
                             </div>
                         )}
                    </div>
                    
                    {/* File List */}
                    <div className="flex-1 overflow-y-auto p-3 space-y-2">
                         {getFilesForView(activeView).length === 0 && (
                             <div className="text-center py-8 opacity-50">
                                 <p className="text-[10px] font-mono text-[#4A4A4A]">Queue Empty</p>
                             </div>
                         )}
                         {getFilesForView(activeView).map((file) => (
                            <div key={file.id} className={`p-3 border rounded-sm flex items-center justify-between group animate-in slide-in-from-left-2 duration-300 ${selectedFileIds.has(file.id) ? 'bg-[#F59E0B]/5 border-[#F59E0B]/30' : 'bg-[#1A1A1A] border-[#2D2D2D]'}`}>
                                <div className="flex items-center space-x-3 overflow-hidden">
                                    <div onClick={() => toggleFileSelection(file.id)} className="cursor-pointer">
                                        {selectedFileIds.has(file.id) ? <CheckSquare size={14} className="text-[#F59E0B]" /> : <Square size={14} className="text-[#4A4A4A] hover:text-[#888888]" />}
                                    </div>
                                    <div className={file.status === 'processing' ? 'animate-pulse' : ''}>
                                        {getFileIcon(file)}
                                    </div>
                                    <div className="min-w-0">
                                        <div className="text-xs font-mono text-[#F5F0E6] truncate">{file.name}</div>
                                        {file.status === 'processing' ? (
                                            <div className="text-[8px] text-[#F59E0B] font-mono uppercase">Reading...</div>
                                        ) : (
                                            <div className="text-[8px] text-[#4A4A4A] font-mono">~{file.tokens.toLocaleString()} tokens</div>
                                        )}
                                    </div>
                                </div>
                                <button 
                                    onClick={() => handleRemoveFile(file.id)}
                                    className="text-[#4A4A4A] hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
                                >
                                    <X size={14} />
                                </button>
                            </div>
                         ))}
                    </div>

                    {/* Footer Actions / Context */}
                    <div className="p-4 border-t border-[#2D2D2D] bg-[#1A1A1A] space-y-4">
                        {/* Quick Document Actions */}
                        {activeView === 'DOCUMENTS' && (
                            <div className="space-y-3">
                                <span className="text-[10px] font-mono text-[#888888] uppercase tracking-wider">Quick Actions</span>
                                <div className="grid grid-cols-2 gap-2">
                                    {['Deep Dive', 'Report', 'Brief', 'Other'].map(action => (
                                        <button 
                                            key={action}
                                            onClick={() => setDocQuickAction(action.toUpperCase().replace(' ', '_') as any)}
                                            className={`
                                                px-2 py-1.5 text-[10px] font-mono uppercase border rounded-sm transition-all
                                                ${docQuickAction === action.toUpperCase().replace(' ', '_') 
                                                    ? 'bg-[#F59E0B] text-[#0D0D0D] border-[#F59E0B]' 
                                                    : 'bg-[#0D0D0D] text-[#888888] border-[#2D2D2D] hover:border-[#4A4A4A]'}
                                            `}
                                        >
                                            {action}
                                        </button>
                                    ))}
                                </div>
                                
                                {docQuickAction && (
                                    <div className={`
                                        p-3 border border-[#2D2D2D] bg-[#0D0D0D] transition-all
                                        ${docQuickAction === 'DEEP_DIVE' ? 'rounded-none border-l-4 border-l-[#F59E0B]' :
                                          docQuickAction === 'REPORT' ? 'rounded-sm' :
                                          docQuickAction === 'BRIEF' ? 'rounded-lg' :
                                          'rounded-[20px_0_20px_0]'}
                                    `}>
                                        <div className="text-[10px] text-[#F5F0E6] font-mono mb-2">Initialize {docQuickAction.replace('_', ' ')}...</div>
                                        {quickActionOutput ? (
                                            <div className="text-[9px] text-green-400 font-mono whitespace-pre-wrap leading-tight">{quickActionOutput}</div>
                                        ) : (
                                            <Button fullWidth size="sm" onClick={handleDocQuickInitialize} isLoading={isSynthesizing}>Initialize</Button>
                                        )}
                                    </div>
                                )}
                            </div>
                        )}

                        {/* Actions */}
                        {isContextFull ? (
                            <Button 
                                fullWidth 
                                variant="primary" 
                                className="bg-red-900/20 text-red-200 border border-red-900 hover:bg-red-900/40"
                                onClick={handleConsolidateContext}
                                icon={<ArrowDownToLine size={14}/>}
                                isLoading={isConsolidating}
                            >
                                Consolidate to Memory
                            </Button>
                        ) : (
                            <div className="space-y-2">
                                <Button fullWidth size="sm" variant="secondary" icon={<Upload size={14} />} onClick={() => fileInputRef.current?.click()} disabled={isFrozen}>
                                    Upload {activeView === 'DOCUMENTS' ? 'File' : activeView === 'IMAGES' ? 'Image' : activeView === 'OTHER' ? 'Item' : 'Media'}
                                </Button>
                                {files.length > 0 && (
                                    <Button fullWidth size="sm" className="bg-[#1A1A1A] border border-[#2D2D2D] text-[#888888] hover:text-[#F5F0E6]" icon={<ArrowDownToLine size={14}/>} onClick={handleConsolidateContext} isLoading={isConsolidating}>
                                        Offload to Memory
                                    </Button>
                                )}
                            </div>
                        )}
                    </div>
                </div>

                {/* Middle Visualizer */}
                {renderVisualizer()}
              </>
          )}

          {/* 2. ARCHITECTURE (Long Term Memory) */}
          {activeView === 'ARCHITECTURE' && (
              <div className="flex-1 p-12 overflow-y-auto custom-scrollbar flex flex-col items-center">
                  <header className="mb-12 text-center max-w-2xl">
                      <div className="inline-flex items-center justify-center p-3 rounded-full bg-[#1A1A1A] border border-[#2D2D2D] mb-4">
                          <Database size={24} className="text-[#F59E0B]" />
                      </div>
                      <h2 className="text-3xl font-serif text-[#F5F0E6] uppercase tracking-wide">
                          Long-Term Memory
                      </h2>
                      <p className="text-sm font-mono text-[#888888] mt-4 leading-relaxed">
                          This layer consolidates out-of-context data streams into persistent structural knowledge. 
                          These elements are not immediately active in the input stream but are constantly considered by the construct for pattern matching and deep retrieval.
                      </p>
                  </header>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-4xl">
                      {/* Summary Block 1 */}
                      <div className="bg-[#1A1A1A] border border-[#2D2D2D] p-6 rounded-sm">
                          <div className="flex items-center justify-between mb-4">
                              <span className="text-xs font-mono text-[#F59E0B] uppercase tracking-widest">Condensed History</span>
                              <Clock size={14} className="text-[#4A4A4A]"/>
                          </div>
                          <div className="space-y-3">
                              <div className="text-sm text-[#F5F0E6] leading-relaxed line-clamp-3">
                                  "User interaction patterns suggest a preference for recursive logic frameworks. Previous sessions regarding 'Self-Sovereignty' have been crystallized into core axioms."
                              </div>
                              <div className="h-1 w-full bg-[#2D2D2D] mt-2"><div className="h-full w-2/3 bg-[#F59E0B]"></div></div>
                              <div className="text-[10px] font-mono text-[#888888] text-right">Consolidated 2h ago</div>
                          </div>
                      </div>

                      {/* Summary Block 2 */}
                      <div className="bg-[#1A1A1A] border border-[#2D2D2D] p-6 rounded-sm">
                          <div className="flex items-center justify-between mb-4">
                              <span className="text-xs font-mono text-[#F59E0B] uppercase tracking-widest">Dormant Vectors</span>
                              <Layers size={14} className="text-[#4A4A4A]"/>
                          </div>
                          <div className="flex flex-wrap gap-2">
                              {['Semantic drift', 'Legacy Auth', 'Tier 2 Protocols', 'Unresolved Queries'].map(tag => (
                                  <span key={tag} className="px-2 py-1 bg-[#0D0D0D] border border-[#2D2D2D] text-[10px] font-mono text-[#888888]">{tag}</span>
                              ))}
                              {consolidatedCount > 0 && (
                                  <span className="px-2 py-1 bg-[#F59E0B]/20 border border-[#F59E0B]/50 text-[10px] font-mono text-[#F59E0B]">
                                      +{consolidatedCount} Recent Batches
                                  </span>
                              )}
                          </div>
                      </div>

                      {/* Deep Storage Visual */}
                      <div className="col-span-1 md:col-span-2 bg-[#0D0D0D] border border-[#2D2D2D] p-8 flex items-center justify-center relative overflow-hidden">
                          <div className="absolute inset-0 flex items-center justify-center opacity-20 pointer-events-none">
                              <Atom size={200} className="text-[#F59E0B] animate-spin-slow" />
                          </div>
                          <div className="relative z-10 text-center">
                              <div className="text-4xl font-mono text-[#F5F0E6]">4.2 PB</div>
                              <div className="text-xs font-mono text-[#888888] uppercase mt-2">Total Knowledge Capacity</div>
                              {consolidatedCount > 0 && <div className="text-xs text-[#4A4A4A] mt-1">Recently consolidated {consolidatedCount} items</div>}
                          </div>
                      </div>
                  </div>
              </div>
          )}

          {/* 3. CHAT (Bottom-aligned Dimensions) */}
          {activeView === 'CHAT' && (
              <div className="flex-1 flex flex-col max-w-4xl mx-auto w-full border-x border-[#2D2D2D] bg-[#0D0D0D]">
                  {/* Chat Output */}
                  <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
                      {chatHistory.map((msg, idx) => (
                          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                              <div className={`
                                  max-w-[80%] p-4 rounded-sm border text-sm font-mono leading-relaxed
                                  ${msg.role === 'user' 
                                      ? 'bg-[#1A1A1A] border-[#2D2D2D] text-[#F5F0E6]' 
                                      : 'bg-transparent border-[#4A4A4A] text-[#888888]'}
                              `}>
                                  {msg.content}
                              </div>
                          </div>
                      ))}
                      {isSynthesizing && (
                          <div className="flex justify-start">
                              <div className="flex items-center space-x-2 text-[#888888] text-xs font-mono uppercase p-4">
                                  <span className="w-2 h-2 bg-[#F59E0B] rounded-full animate-pulse"></span>
                                  <span>System Thinking...</span>
                              </div>
                          </div>
                      )}
                      
                      {isContextFull && (
                           <div className="flex justify-center my-4">
                              <div className="bg-red-900/20 border border-red-900/50 text-red-300 px-4 py-2 rounded-sm text-xs font-mono uppercase flex items-center">
                                  <AlertTriangle size={12} className="mr-2" />
                                  Context Full. Consolidate to continue.
                              </div>
                           </div>
                      )}
                  </div>

                  {/* Chat Input Area with Dimensions */}
                  <div className="p-6 border-t border-[#2D2D2D] bg-[#151515]">
                      
                      {/* Dimensions Control */}
                      <div className="flex items-center justify-center mb-4">
                          <div className="bg-[#0D0D0D] p-1 rounded-full border border-[#2D2D2D] flex space-x-1">
                              {[ChatMode.ENGAGE, ChatMode.ORGANIZE, ChatMode.ASK].map((mode) => (
                                  <button
                                      key={mode}
                                      onClick={() => setChatMode(mode)}
                                      className={`
                                          px-4 py-1 rounded-full text-[10px] font-mono uppercase tracking-wider transition-all
                                          ${chatMode === mode 
                                              ? 'bg-[#F59E0B] text-[#0D0D0D] shadow-sm' 
                                              : 'text-[#888888] hover:text-[#F5F0E6]'}
                                      `}
                                  >
                                      {mode}
                                  </button>
                              ))}
                          </div>
                      </div>

                      <div className="relative">
                          <input
                              type="text"
                              value={chatInput}
                              onChange={(e) => setChatInput(e.target.value)}
                              onKeyDown={(e) => e.key === 'Enter' && handleChatSubmit()}
                              placeholder={isContextFull ? "Context limit reached..." : `Command the construct (${chatMode} dimension)...`}
                              disabled={isContextFull}
                              className={`
                                w-full bg-[#1A1A1A] border rounded-full py-4 pl-6 pr-14 text-sm font-mono focus:outline-none transition-colors
                                ${isContextFull 
                                    ? 'border-red-900 text-red-900 placeholder-red-900/50 cursor-not-allowed' 
                                    : 'border-[#2D2D2D] text-[#F5F0E6] focus:border-[#F59E0B]'}
                              `}
                          />
                          <button 
                              onClick={handleChatSubmit}
                              disabled={isContextFull}
                              className={`
                                absolute right-2 top-2 bottom-2 w-10 h-10 rounded-full flex items-center justify-center transition-all
                                ${isContextFull 
                                    ? 'bg-[#2D2D2D] text-[#4A4A4A] cursor-not-allowed' 
                                    : 'bg-[#2D2D2D] hover:bg-[#F59E0B] hover:text-[#0D0D0D] text-[#F5F0E6]'}
                              `}
                          >
                              <Send size={16} />
                          </button>
                      </div>
                  </div>
              </div>
          )}

          {/* 4. SYNTHESIZE (Granular Atoms + Production) */}
          {activeView === 'SYNTHESIZE' && (
              <div className="flex-1 flex overflow-hidden bg-[#0D0D0D]">
                   {/* Left Panel: Granular Knowledge Atoms */}
                   <div className="w-96 bg-[#151515] border-r border-[#2D2D2D] flex flex-col">
                       <div className="p-4 border-b border-[#2D2D2D] flex justify-between items-center">
                           <div>
                            <h3 className="text-xs font-mono text-[#888888] uppercase tracking-widest">Knowledge Atoms</h3>
                            <p className="text-[10px] text-[#4A4A4A] mt-1">Distilled Truths available for synthesis</p>
                           </div>
                           <div className="flex items-center space-x-1">
                               <button onClick={() => setShowTensionsInGraph(!showTensionsInGraph)} className={`p-2 rounded-sm border ${showTensionsInGraph ? 'bg-red-900/10 border-red-900 text-red-400' : 'border-[#2D2D2D] text-[#888888] hover:text-[#F5F0E6]'}`} title="Toggle Tensions">
                                   <Split size={14} />
                               </button>
                               <button onClick={() => setShowAtomGraph(!showAtomGraph)} className={`p-2 rounded-sm border ${showAtomGraph ? 'bg-[#F59E0B]/10 border-[#F59E0B] text-[#F59E0B]' : 'border-[#2D2D2D] text-[#888888] hover:text-[#F5F0E6]'}`} title="Toggle Lineage Graph">
                                   <Share2 size={14} />
                               </button>
                           </div>
                       </div>
                       <div className="flex-1 overflow-y-auto p-4 space-y-4">
                           {atoms.map(atom => (
                               <div key={atom.id} className="bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm group overflow-hidden transition-all duration-300">
                                   {/* Header */}
                                   <div className="p-3 bg-[#1A1A1A] border-b border-[#2D2D2D] flex justify-between items-start cursor-pointer hover:bg-[#232323]">
                                       <div>
                                            <div className="flex items-center space-x-2 mb-1">
                                                <span className={`w-2 h-2 rounded-full ${atom.type === 'axiom' ? 'bg-[#F59E0B]' : atom.type === 'derivative' ? 'bg-purple-500' : 'bg-blue-500'}`}></span>
                                                <span className="text-xs font-mono text-[#F5F0E6] font-bold">{atom.label}</span>
                                            </div>
                                            <div className="text-[10px] text-[#888888]">{atom.description}</div>
                                       </div>
                                       <span className="text-[10px] font-mono text-[#4A4A4A]">Res:{atom.resonance}%</span>
                                   </div>
                                   
                                   {/* Tabs */}
                                   <div className="flex border-b border-[#2D2D2D] bg-[#0D0D0D]">
                                       <button onClick={() => setAtoms(prev => prev.map(a => a.id === atom.id ? {...a, activeTab: 'attributes'} : a))} className={`flex-1 py-1.5 text-[10px] font-mono uppercase ${atom.activeTab === 'attributes' ? 'text-[#F5F0E6] bg-[#232323]' : 'text-[#4A4A4A] hover:text-[#888888]'}`}>Attributes</button>
                                       <button onClick={() => setAtoms(prev => prev.map(a => a.id === atom.id ? {...a, activeTab: 'lineage'} : a))} className={`flex-1 py-1.5 text-[10px] font-mono uppercase ${atom.activeTab === 'lineage' ? 'text-[#F5F0E6] bg-[#232323]' : 'text-[#4A4A4A] hover:text-[#888888]'}`}>Lineage</button>
                                       <button onClick={() => setAtoms(prev => prev.map(a => a.id === atom.id ? {...a, activeTab: 'resonance'} : a))} className={`flex-1 py-1.5 text-[10px] font-mono uppercase ${atom.activeTab === 'resonance' ? 'text-[#F5F0E6] bg-[#232323]' : 'text-[#4A4A4A] hover:text-[#888888]'}`}>Resonance</button>
                                   </div>

                                   {/* Content */}
                                   <div className="p-3 bg-[#0D0D0D]">
                                       {atom.activeTab === 'attributes' && (
                                           <div className="space-y-1">
                                               <div className="flex justify-between text-[10px] font-mono text-[#888888]"><span>Depth</span> <span className="text-[#F5F0E6]">{atom.depth}</span></div>
                                               <div className="flex justify-between text-[10px] font-mono text-[#888888]"><span>Origin</span> <span className="text-[#F5F0E6]">{atom.originType}</span></div>
                                           </div>
                                       )}
                                       {atom.activeTab === 'lineage' && (
                                           <div className="text-[10px] font-mono text-[#888888]">
                                              {atom.sourceIds ? (
                                                  <>Derived from {atom.sourceIds.length} source(s).</>
                                              ) : (
                                                  <>Foundational Axiom (No antecedent)</>
                                              )}
                                           </div>
                                       )}
                                       {atom.activeTab === 'resonance' && (
                                           <div className="text-[10px] font-mono text-[#888888]">
                                               Highly active in <span className="text-[#F59E0B]">Architecture Sector 4</span>.
                                           </div>
                                       )}
                                   </div>
                               </div>
                           ))}
                       </div>
                   </div>

                   {/* Main Panel: Graph OR Production Studio */}
                   {showAtomGraph ? (
                        <div className="flex-1 relative">
                            <KnowledgeGraph />
                        </div>
                   ) : (
                       <div className="flex-1 flex flex-col p-8 relative">
                           <div className="mb-8">
                               <h2 className="text-2xl font-serif text-[#F5F0E6] uppercase tracking-wide flex items-center">
                                   <Zap className="mr-3 text-[#F59E0B]" size={24}/>
                                   Production Studio
                               </h2>
                               <p className="text-sm font-mono text-[#888888] mt-2">
                                   Recursion loop: Select output format and iteration type.
                               </p>
                               {isContextFull && <p className="text-xs text-red-400 mt-2 font-mono">WARNING: Context limit reached. Production may be truncated.</p>}
                           </div>

                           {/* 1. Format Selection */}
                           <div className="grid grid-cols-4 gap-4 mb-6">
                               {[
                                   { id: 'DOC', label: 'Document', icon: <FileText size={20}/> },
                                   { id: 'IMG', label: 'Image', icon: <ImageIcon size={20}/> },
                                   { id: 'VID', label: 'Video', icon: <Video size={20}/> },
                                   { id: 'AUDIO', label: 'Audio', icon: <Mic size={20}/> },
                               ].map((type) => (
                                   <button 
                                       key={type.id}
                                       onClick={() => { setProductionType(type.id as any); setProductionSubType(null); }}
                                       disabled={isContextFull}
                                       className={`
                                           flex flex-col items-center justify-center p-4 border rounded-sm transition-all
                                           ${productionType === type.id 
                                               ? 'bg-[#F5F0E6] text-[#0D0D0D] border-[#F5F0E6]' 
                                               : isContextFull 
                                                    ? 'bg-[#1A1A1A] border-[#2D2D2D] text-[#4A4A4A] cursor-not-allowed'
                                                    : 'bg-[#1A1A1A] border-[#2D2D2D] text-[#888888] hover:border-[#F5F0E6] hover:text-[#F5F0E6]'}
                                       `}
                                   >
                                       {type.icon}
                                       <span className="text-[10px] font-mono uppercase tracking-wider mt-2">{type.label}</span>
                                   </button>
                               ))}
                           </div>

                           {/* 2. Sub-Type Selection & Preview */}
                           {productionType && (
                               <div className="bg-[#151515] border border-[#2D2D2D] rounded-sm p-6 flex flex-col flex-1 animate-in fade-in slide-in-from-bottom-4">
                                   <div className="mb-6">
                                       <h4 className="text-xs font-mono text-[#F5F0E6] uppercase tracking-wide mb-3">Select Iteration Type</h4>
                                       <div className="flex space-x-3">
                                           {(productionType === 'DOC' ? ['Deep Dive', 'Report', 'Brief'] : 
                                             productionType === 'IMG' ? ['Wireframe', 'Render', 'Schematic'] :
                                             productionType === 'VID' ? ['Explainer', 'Montage', 'Loop'] :
                                             ['Monologue', 'Podcast', 'Ambient']).map((sub) => (
                                               <button
                                                   key={sub}
                                                   onClick={() => setProductionSubType(sub)}
                                                   className={`
                                                       px-4 py-2 border rounded-sm text-xs font-mono uppercase transition-all
                                                       ${productionSubType === sub 
                                                           ? 'bg-[#F59E0B] text-[#0D0D0D] border-[#F59E0B]' 
                                                           : 'bg-[#0D0D0D] text-[#888888] border-[#2D2D2D] hover:border-[#4A4A4A]'}
                                                   `}
                                               >
                                                   {sub}
                                               </button>
                                           ))}
                                       </div>
                                   </div>

                                   {/* 3. Shape Preview & Init */}
                                   {productionSubType && (
                                       <div className="flex-1 flex flex-col">
                                           <div className="flex-1 bg-[#0D0D0D] border border-[#2D2D2D] rounded-sm mb-4 flex items-center justify-center p-8 relative overflow-hidden">
                                               {/* Visual Abstract Shape based on choice */}
                                               <div className={`
                                                   transition-all duration-1000
                                                   ${productionType === 'DOC' ? 'w-32 h-40 border-2 border-[#F59E0B]' : 
                                                     productionType === 'IMG' ? 'w-40 h-40 rounded-full border-2 border-[#F59E0B]' :
                                                     productionType === 'VID' ? 'w-60 h-32 border-2 border-[#F59E0B]' : 'w-40 h-10 border-2 border-[#F59E0B] rounded-full'}
                                               `}>
                                                    <div className="absolute inset-0 bg-[#F59E0B]/5 animate-pulse"></div>
                                               </div>
                                               <span className="absolute text-[10px] font-mono text-[#F59E0B] uppercase tracking-widest bg-[#0D0D0D] px-2">
                                                   {productionSubType} Template
                                               </span>
                                           </div>
                                           
                                           <Button fullWidth onClick={handleProduction} isLoading={isSynthesizing} icon={<Share2 size={14}/>}>
                                               Initialize {productionSubType}
                                           </Button>
                                       </div>
                                   )}
                                   
                                   {generatedArtifact && (
                                       <div className="mt-4 p-4 bg-[#1A1A1A] border border-green-900/50 rounded-sm text-green-400 text-xs font-mono">
                                           {generatedArtifact}
                                       </div>
                                   )}
                               </div>
                           )}
                       </div>
                   )}
              </div>
          )}

      </div>
    </div>
  );
};