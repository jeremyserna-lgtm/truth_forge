import React, { useState } from 'react';
import { User, KeganStage, InterfaceProposal, MetaCognitionEntry, SubscriptionTier } from '../types';
import { Button } from './Button';
import { Eye, Shield, Lock, Unlock, GitPullRequest, Terminal, AlertTriangle, CheckCircle2, X, BrainCircuit, Activity, Layers, Code, Zap } from 'lucide-react';

interface SystemAwarenessProps {
  user: User;
  onUpdateUser: (user: User) => void;
  onClose: () => void;
}

export const SystemAwareness: React.FC<SystemAwarenessProps> = ({ user, onUpdateUser, onClose }) => {
  const [activeTab, setActiveTab] = useState<'FILTERS' | 'META' | 'MUTATOR'>('FILTERS');
  const [proposalText, setProposalText] = useState('');
  const [isProposing, setIsProposing] = useState(false);
  const [reflectionText, setReflectionText] = useState('');
  const [isLogging, setIsLogging] = useState(false);

  const stage = user.developmentProfile.stage;
  const isStage5 = user.tier === SubscriptionTier.STAGE_5_STRUCTURAL;

  const handleProposeModification = () => {
      if (!proposalText.trim()) return;
      setIsProposing(true);
      
      setTimeout(() => {
          const newProposal: InterfaceProposal = {
              id: Math.random().toString(36).substr(2, 9),
              component: 'Global Navigation',
              proposal: proposalText,
              reasoning: 'User requested structural fluidity.',
              status: 'ACCEPTED',
              systemResponse: 'Proposal analyzed. Coherence verified. Patching interface vectors...',
              timestamp: Date.now()
          };
          
          onUpdateUser({
              ...user,
              developmentProfile: {
                  ...user.developmentProfile,
                  interfaceProposals: [newProposal, ...(user.developmentProfile.interfaceProposals || [])]
              }
          });
          setProposalText('');
          setIsProposing(false);
      }, 2000);
  };

  const handleLogMeta = () => {
      if (!reflectionText.trim()) return;
      setIsLogging(true);
      
      setTimeout(() => {
          const newLog: MetaCognitionEntry = {
              id: Math.random().toString(36).substr(2, 9),
              timestamp: Date.now(),
              trigger: 'System Awareness Panel',
              reflection: reflectionText,
              depthScore: Math.floor(Math.random() * 40) + 60
          };
          
          onUpdateUser({
              ...user,
              developmentProfile: {
                  ...user.developmentProfile,
                  metaCognitionLog: [newLog, ...(user.developmentProfile.metaCognitionLog || [])]
              }
          });
          setReflectionText('');
          setIsLogging(false);
      }, 1000);
  };

  const getFilters = () => {
      switch (stage) {
          case KeganStage.STAGE_3_SOCIALIZED:
              return [
                  { id: 'f1', name: 'Social Validation Protocol', status: 'ACTIVE', desc: 'Prioritizes consensus data. Hides conflict-heavy inputs.' },
                  { id: 'f2', name: 'Authority Bias', status: 'ACTIVE', desc: 'Highlights system-generated directives as "Truth".' },
                  { id: 'f3', name: 'Ambiguity Suppressor', status: 'ACTIVE', desc: 'Reduces paradox complexity to binary choices.' }
              ];
          case KeganStage.STAGE_4_SELF_AUTHORING:
              return [
                  { id: 'f1', name: 'Autonomy Projector', status: 'ACTIVE', desc: 'Reframes all tasks as self-driven goals.' },
                  { id: 'f2', name: 'Boundary Enforcement', status: 'ACTIVE', desc: 'Clearly delineates "My Data" vs "System Data".' },
                  { id: 'f3', name: 'Efficiency Optimizer', status: 'ACTIVE', desc: 'Hides emotional resonance metrics in favor of utility.' }
              ];
          case KeganStage.STAGE_5_SELF_TRANSFORMING:
              return [
                  { id: 'f1', name: 'Dialectical Lens', status: 'ACTIVE', desc: 'Highlights contradictions as generative opportunities.' },
                  { id: 'f2', name: 'System Transparency', status: 'ACTIVE', desc: 'Reveals underlying algorithmic weights.' },
                  { id: 'f3', name: 'Fluid Identity', status: 'ACTIVE', desc: 'Allows rapid role-switching and interface mutation.' }
              ];
          default: return [];
      }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 backdrop-blur-sm p-6 animate-in fade-in duration-300">
        <div className="w-full max-w-5xl h-[85vh] bg-[#0D0D0D] border border-cyan-900/50 rounded-sm shadow-[0_0_100px_rgba(8,145,178,0.1)] flex flex-col relative overflow-hidden">
            {/* Holographic header effect */}
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-cyan-500 to-transparent opacity-50"></div>
            
            {/* Header */}
            <div className="p-6 border-b border-[#2D2D2D] flex items-center justify-between bg-[#151515]">
                <div className="flex items-center space-x-4">
                    <div className="p-2 bg-cyan-900/20 border border-cyan-500/50 rounded-full">
                        <Eye size={24} className="text-cyan-400" />
                    </div>
                    <div>
                        <h2 className="text-xl font-serif text-[#F5F0E6] uppercase tracking-wide">System Awareness</h2>
                        <p className="text-xs font-mono text-cyan-400">Meta-Layer Visualization // {stage.replace('STAGE_', '').replace(/_/g, ' ')}</p>
                    </div>
                </div>
                <button onClick={onClose} className="text-[#888888] hover:text-[#F5F0E6] transition-colors"><X size={24}/></button>
            </div>

            {/* Navigation */}
            <div className="flex border-b border-[#2D2D2D] bg-[#0D0D0D]">
                <button onClick={() => setActiveTab('FILTERS')} className={`flex-1 py-4 text-xs font-mono uppercase tracking-wider border-b-2 transition-all ${activeTab === 'FILTERS' ? 'border-cyan-500 text-cyan-400 bg-cyan-900/5' : 'border-transparent text-[#888888] hover:text-[#F5F0E6]'}`}>Perceptual Filters</button>
                <button onClick={() => setActiveTab('META')} className={`flex-1 py-4 text-xs font-mono uppercase tracking-wider border-b-2 transition-all ${activeTab === 'META' ? 'border-purple-500 text-purple-400 bg-purple-900/5' : 'border-transparent text-[#888888] hover:text-[#F5F0E6]'}`}>Meta-Cognition</button>
                <button onClick={() => setActiveTab('MUTATOR')} disabled={!isStage5} className={`flex-1 py-4 text-xs font-mono uppercase tracking-wider border-b-2 transition-all ${activeTab === 'MUTATOR' ? 'border-[#F59E0B] text-[#F59E0B] bg-[#F59E0B]/5' : !isStage5 ? 'border-transparent text-[#4A4A4A] cursor-not-allowed' : 'border-transparent text-[#888888] hover:text-[#F5F0E6]'}`}>Interface Mutator {isStage5 ? '' : '(Locked)'}</button>
            </div>

            {/* Content Body */}
            <div className="flex-1 overflow-y-auto custom-scrollbar p-8">
                
                {/* 1. FILTERS TAB */}
                {activeTab === 'FILTERS' && (
                    <div className="space-y-8 animate-in slide-in-from-bottom-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            {/* Visual Representation */}
                            <div className="border border-[#2D2D2D] bg-[#1A1A1A] p-8 rounded-sm flex items-center justify-center relative overflow-hidden h-64">
                                <div className="absolute inset-0 grid grid-cols-6 grid-rows-6 gap-1 opacity-20 pointer-events-none">
                                    {Array.from({length: 36}).map((_, i) => <div key={i} className="bg-[#2D2D2D]"></div>)}
                                </div>
                                <div className="relative z-10 text-center">
                                    <Layers size={64} className="text-cyan-400 mx-auto mb-4 animate-pulse" />
                                    <div className="text-sm font-mono text-[#F5F0E6] uppercase tracking-widest">Reality Tunnel Active</div>
                                    <div className="text-xs text-[#888888] mt-2">Input data is being filtered to match cognitive capacity.</div>
                                </div>
                            </div>

                            {/* Filters List */}
                            <div className="space-y-4">
                                <h3 className="text-sm font-mono text-[#888888] uppercase tracking-wide mb-4">Active Constraints</h3>
                                {getFilters().map(filter => (
                                    <div key={filter.id} className="p-4 border border-cyan-900/30 bg-cyan-900/5 rounded-sm flex items-start space-x-3">
                                        <Activity size={16} className="text-cyan-400 mt-0.5 flex-shrink-0" />
                                        <div>
                                            <div className="flex justify-between items-center mb-1">
                                                <span className="text-sm font-serif text-[#F5F0E6]">{filter.name}</span>
                                                <span className="text-[9px] font-mono text-cyan-400 border border-cyan-900/50 px-1 rounded bg-cyan-900/20">{filter.status}</span>
                                            </div>
                                            <p className="text-xs text-[#888888] leading-relaxed">{filter.desc}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                )}

                {/* 2. META-COGNITION TAB */}
                {activeTab === 'META' && (
                    <div className="space-y-8 animate-in slide-in-from-bottom-4">
                        <div className="flex flex-col md:flex-row gap-8 h-full">
                            {/* Input Area */}
                            <div className="w-full md:w-1/3 flex flex-col space-y-4">
                                <div className="p-4 border border-purple-900/30 bg-purple-900/5 rounded-sm">
                                    <h3 className="text-sm font-mono text-purple-400 uppercase tracking-wide mb-2 flex items-center">
                                        <BrainCircuit size={16} className="mr-2"/> Observer Mode
                                    </h3>
                                    <p className="text-xs text-[#888888] mb-4">
                                        Catch yourself in the act of thinking. What patterns are you noticing in your own reactions to the system?
                                    </p>
                                    <textarea 
                                        className="w-full h-32 bg-[#0D0D0D] border border-[#2D2D2D] rounded-sm p-3 text-sm text-[#F5F0E6] focus:border-purple-500 focus:outline-none resize-none placeholder-[#4A4A4A]"
                                        placeholder="I noticed that I felt defensive when..."
                                        value={reflectionText}
                                        onChange={(e) => setReflectionText(e.target.value)}
                                    />
                                    <div className="flex justify-end mt-3">
                                        <Button size="sm" onClick={handleLogMeta} isLoading={isLogging} className="border-purple-500/50 text-purple-300 hover:bg-purple-900/20">
                                            Log Reflection
                                        </Button>
                                    </div>
                                </div>
                            </div>

                            {/* Log Feed */}
                            <div className="flex-1 border border-[#2D2D2D] bg-[#1A1A1A] rounded-sm flex flex-col overflow-hidden">
                                <div className="p-4 border-b border-[#2D2D2D] bg-[#151515]">
                                    <span className="text-xs font-mono text-[#888888] uppercase tracking-wide">Meta-Cognition Log</span>
                                </div>
                                <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
                                    {!user.developmentProfile.metaCognitionLog?.length && (
                                        <div className="text-center text-[#4A4A4A] text-xs font-mono py-12">No meta-cognitive events recorded.</div>
                                    )}
                                    {user.developmentProfile.metaCognitionLog?.map(log => (
                                        <div key={log.id} className="p-4 border border-[#2D2D2D] bg-[#0D0D0D] rounded-sm relative group hover:border-purple-500/30 transition-colors">
                                            <div className="flex justify-between items-start mb-2">
                                                <span className="text-[10px] font-mono text-purple-400 uppercase">{log.trigger}</span>
                                                <span className="text-[10px] font-mono text-[#888888]">{new Date(log.timestamp).toLocaleDateString()}</span>
                                            </div>
                                            <p className="text-sm text-[#F5F0E6] italic leading-relaxed">"{log.reflection}"</p>
                                            <div className="mt-3 flex items-center space-x-2">
                                                <span className="text-[9px] text-[#4A4A4A] uppercase">Depth Score:</span>
                                                <div className="w-24 h-1 bg-[#2D2D2D] rounded-full overflow-hidden">
                                                    <div className="h-full bg-purple-500" style={{width: `${log.depthScore}%`}}></div>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {/* 3. MUTATOR TAB (Stage 5) */}
                {activeTab === 'MUTATOR' && (
                    <div className="space-y-8 animate-in slide-in-from-bottom-4">
                        <div className="border border-[#F59E0B] bg-[#F59E0B]/5 p-6 rounded-sm mb-6">
                            <div className="flex items-start space-x-4">
                                <AlertTriangle size={24} className="text-[#F59E0B] flex-shrink-0" />
                                <div>
                                    <h3 className="text-lg font-serif text-[#F5F0E6] uppercase tracking-wide">Co-Authoring Protocols Engaged</h3>
                                    <p className="text-sm text-[#F5F0E6] opacity-80 mt-1 leading-relaxed">
                                        You have transcended the default architecture. You may now propose structural modifications to the interface itself. 
                                        The "Not-Me" companion will review code proposals for coherence and implement them if valid.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                            {/* Proposal Editor */}
                            <div className="space-y-4">
                                <h4 className="text-xs font-mono text-[#888888] uppercase tracking-wide">Interface Definition Language (Natural)</h4>
                                <div className="border border-[#2D2D2D] bg-[#1A1A1A] rounded-sm p-1">
                                    <div className="bg-[#0D0D0D] p-2 border-b border-[#2D2D2D] flex items-center space-x-2">
                                        <Terminal size={12} className="text-[#4A4A4A]"/>
                                        <span className="text-[10px] font-mono text-[#4A4A4A]">root@truth_forge:~/interface_config</span>
                                    </div>
                                    <textarea 
                                        className="w-full h-48 bg-[#0D0D0D] text-[#F5F0E6] font-mono text-xs p-4 focus:outline-none resize-none"
                                        placeholder="// Describe your desired interface change...
Example: 'Change the global accent color to a deep violet to reflect my shift towards intuition over logic.'"
                                        value={proposalText}
                                        onChange={(e) => setProposalText(e.target.value)}
                                    />
                                </div>
                                <div className="flex justify-end">
                                    <Button onClick={handleProposeModification} isLoading={isProposing} icon={<GitPullRequest size={14}/>}>
                                        Submit Pull Request
                                    </Button>
                                </div>
                            </div>

                            {/* Proposal History */}
                            <div className="space-y-4">
                                <h4 className="text-xs font-mono text-[#888888] uppercase tracking-wide">Proposal Ledger</h4>
                                <div className="space-y-3">
                                    {!user.developmentProfile.interfaceProposals?.length && (
                                        <div className="text-center text-[#4A4A4A] text-xs font-mono py-8 border border-dashed border-[#2D2D2D] rounded-sm">
                                            No structural modifications on record.
                                        </div>
                                    )}
                                    {user.developmentProfile.interfaceProposals?.map(prop => (
                                        <div key={prop.id} className="p-4 border border-[#2D2D2D] bg-[#1A1A1A] rounded-sm">
                                            <div className="flex justify-between items-start mb-2">
                                                <span className="text-xs font-mono text-[#F5F0E6] font-bold">{prop.component}</span>
                                                <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded border ${prop.status === 'ACCEPTED' ? 'border-green-900 text-green-400 bg-green-900/10' : 'border-[#F59E0B] text-[#F59E0B] bg-[#F59E0B]/10'}`}>
                                                    {prop.status}
                                                </span>
                                            </div>
                                            <p className="text-xs text-[#888888] font-mono mb-3">"{prop.proposal}"</p>
                                            {prop.systemResponse && (
                                                <div className="bg-[#0D0D0D] p-2 border-l-2 border-green-500 text-[10px] font-mono text-green-400">
                                                    > SYSTEM: {prop.systemResponse}
                                                </div>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    </div>
  );
};