import React, { useState } from 'react';
import { User, DashboardTab, SubscriptionTier, KeganStage, DevelopmentEvidence, SubjectObjectItem, VerifiableCredential, TransitionEvent, AssessmentResult } from '../types';
import { AccountSettings } from './views/AccountSettings';
import { SystemGuide } from './SystemGuide';
import { ProgressVisualization } from './ProgressVisualization'; 
import { LifeContext } from './LifeContext';
import { ContentLibrary } from './ContentLibrary';
import { FederationBridge } from './FederationBridge';
import { DevelopmentAssessment } from './DevelopmentAssessment';
import { NotMeChat } from './NotMeChat';
import { ImmunityMapTool } from './ImmunityMapTool';
import { ReflectionJournal } from './ReflectionJournal';
import { CredentialWallet } from './CredentialWallet';
import { User as UserIcon, CreditCard, LogOut, ChevronRight, Anchor, Square, Boxes, Brain, Sparkles, Activity, Search, TrendingUp, AlertCircle, PlayCircle, BookOpen, Circle, CircleDot, Shield, Award, BadgeCheck, Fingerprint, Link, ExternalLink, Network, Users, MessageCircle, Footprints, Heart, Globe, Compass, Bot, ShieldAlert, Book } from 'lucide-react';
import { Button } from './Button';

interface UserPortalProps {
  user: User;
  onLogout: () => void;
  onUpdateUser: (user: User) => void;
  onTriggerCeremony?: (event: TransitionEvent) => void; // New Prop for triggering app-level overlay
}

export const UserPortal: React.FC<UserPortalProps> = ({ user, onLogout, onUpdateUser, onTriggerCeremony }) => {
  const [activeTab, setActiveTab] = useState<DashboardTab>(DashboardTab.ACCOUNT);
  const [isSimulating, setIsSimulating] = useState(false);
  const [isMinting, setIsMinting] = useState(false);

  const isStage3 = user.tier === SubscriptionTier.STAGE_3_FROZEN;
  const isStage5 = user.tier === SubscriptionTier.STAGE_5_STRUCTURAL;

  const credentials = user.developmentProfile.credentials || [];
  const observations = user.developmentProfile.systemObservations || [];
  const hasAssessment = user.developmentProfile.assessmentHistory && user.developmentProfile.assessmentHistory.length > 0;

  // --- Kegan Logic Helpers ---
  const keganLabels: Record<KeganStage, { title: string, subtitle: string, color: string }> = {
      [KeganStage.STAGE_1_IMPULSIVE]: { title: 'Impulsive Mind', subtitle: 'Reflexive / Perceptual', color: 'text-red-400' },
      [KeganStage.STAGE_2_IMPERIAL]: { title: 'Imperial Mind', subtitle: 'Needs / Interests', color: 'text-orange-400' },
      [KeganStage.STAGE_3_SOCIALIZED]: { title: 'Socialized Mind', subtitle: 'Interpersonal / Mutuality', color: 'text-blue-400' },
      [KeganStage.STAGE_4_SELF_AUTHORING]: { title: 'Self-Authoring Mind', subtitle: 'Identity / Ideology', color: 'text-green-400' },
      [KeganStage.STAGE_5_SELF_TRANSFORMING]: { title: 'Self-Transforming Mind', subtitle: 'Inter-individual / Paradox', color: 'text-[#F59E0B]' },
  };

  const handleAssessmentComplete = (result: AssessmentResult) => {
      // Update User Stage based on result
      const updatedUser: User = {
          ...user,
          developmentProfile: {
              ...user.developmentProfile,
              stage: result.calculatedStage,
              assessmentHistory: [result, ...(user.developmentProfile.assessmentHistory || [])]
          }
      };
      onUpdateUser(updatedUser);
  };

  const simulateInteraction = (type: 'PASSIVE' | 'AUTHORITY_SEEKING' | 'CRITICAL' | 'PARADOXICAL') => {
      setIsSimulating(true);
      
      let scoreChange = 0;
      let newStage = user.developmentProfile.stage;
      let evidenceDesc = '';
      let evidenceType: DevelopmentEvidence['actionType'] = 'CONSUMPTION';
      let transitionTriggered = false;

      // Simple Assessment Logic Engine
      switch (type) {
          case 'PASSIVE':
              scoreChange = -2;
              evidenceDesc = "Consumed output without verification.";
              evidenceType = 'CONSUMPTION';
              break;
          case 'AUTHORITY_SEEKING':
              scoreChange = -5;
              evidenceDesc = "Treated System output as absolute truth.";
              evidenceType = 'CONSUMPTION';
              break;
          case 'CRITICAL':
              scoreChange = 5;
              evidenceDesc = "Challenged System assumption in output.";
              evidenceType = 'CRITIQUE';
              break;
          case 'PARADOXICAL':
              scoreChange = 10;
              evidenceDesc = "Synthesized opposing viewpoints into new framework.";
              evidenceType = 'SYNTHESIS';
              break;
      }

      const currentScore = user.developmentProfile.score;
      let nextScore = Math.max(0, Math.min(100, currentScore + scoreChange));
      
      // Check for Major Transition (Simulated for Demo)
      if (nextScore > 90 && onTriggerCeremony) {
          if (newStage === KeganStage.STAGE_3_SOCIALIZED) {
              transitionTriggered = true;
              // We don't update stage yet; we let the ceremony do it or update it here but trigger ceremony overlay
              // For smooth UX, let's trigger the ceremony which will call the update
              onTriggerCeremony({
                  fromStage: KeganStage.STAGE_3_SOCIALIZED,
                  toStage: KeganStage.STAGE_4_SELF_AUTHORING,
                  triggerContext: "The conflict between 'Social Harmony' and 'Personal Integrity'"
              });
          }
      }

      const newEvidence: DevelopmentEvidence = {
          id: Math.random().toString(36).substr(2, 9),
          timestamp: Date.now(),
          actionType: evidenceType,
          description: evidenceDesc,
          impact: scoreChange
      };

      const updatedUser: User = {
          ...user,
          developmentProfile: {
              ...user.developmentProfile,
              score: nextScore,
              evidence: [newEvidence, ...user.developmentProfile.evidence.slice(0, 4)], // Keep last 5
          }
      };

      setTimeout(() => {
          if (!transitionTriggered) {
            onUpdateUser(updatedUser);
          }
          setIsSimulating(false);
      }, 600);
  };

  const simulateScaffolding = (condition: 'STRUGGLE' | 'MASTERY') => {
      // Simulate automatic adaptation
      const currentEnv = user.developmentProfile.holdingEnvironment || { complexityLevel: 'MEDIUM', supportLevel: 'MEDIUM', inSafeMode: false, struggleIndex: 0, masteryIndex: 0 };
      
      let newEnv = { ...currentEnv };
      
      if (condition === 'STRUGGLE') {
          // Increase struggle, increase support, decrease complexity
          newEnv.struggleIndex = Math.min(100, newEnv.struggleIndex + 20);
          newEnv.supportLevel = newEnv.struggleIndex > 50 ? 'HIGH' : 'MEDIUM';
          newEnv.complexityLevel = newEnv.struggleIndex > 70 ? 'LOW' : 'MEDIUM';
          // Auto-trigger safe mode if panic
          if (newEnv.struggleIndex > 80) newEnv.inSafeMode = true;
      } else {
          // Increase mastery, decrease support, increase complexity
          newEnv.masteryIndex = Math.min(100, newEnv.masteryIndex + 20);
          newEnv.struggleIndex = Math.max(0, newEnv.struggleIndex - 10);
          newEnv.supportLevel = newEnv.masteryIndex > 60 ? 'LOW' : 'MEDIUM';
          newEnv.complexityLevel = newEnv.masteryIndex > 80 ? 'HIGH' : 'MEDIUM';
      }

      const updatedUser: User = {
          ...user,
          developmentProfile: {
              ...user.developmentProfile,
              holdingEnvironment: newEnv
          }
      };
      
      onUpdateUser(updatedUser);
  };

  const handleRequestPeerValidation = () => {
      setIsMinting(true);
      setTimeout(() => {
          setIsMinting(false);
          // Just simulate the notification for now
          alert("Request broadcasted to trusted peer network (Node Cluster A).");
      }, 1500);
  };


  const getTabLabel = (tabId: DashboardTab, tier: SubscriptionTier) => {
      if (tabId === DashboardTab.ACCOUNT) {
          switch(tier) {
              case SubscriptionTier.STAGE_3_FROZEN: return "Identity Matrix"; // External/Formal
              case SubscriptionTier.STAGE_4_FLUID: return "My Self"; // Internal/Possessive
              case SubscriptionTier.STAGE_5_STRUCTURAL: return "Entity Definition"; // Meta/Structural
          }
      }
      return "";
  };

  // Dynamic Tabs based on Tier
  const tabs = [
    { 
        id: DashboardTab.ACCOUNT, 
        label: getTabLabel(DashboardTab.ACCOUNT, user.tier), 
        icon: <UserIcon size={16} />, 
        status: isStage5 ? 'FLUID' : 'IMMUTABLE',
        desc: 'Core Identity Framework'
    },
    { 
        id: DashboardTab.PSYCHOMETRICS, 
        label: 'Psychometrics', 
        icon: <Activity size={16} />, 
        status: 'ADAPTIVE',
        desc: 'Developmental Engine & Profile'
    },
    {
        id: DashboardTab.NOT_ME_CHAT,
        label: 'Not-Me',
        icon: <Bot size={16} />,
        status: 'COMPANION',
        desc: 'Developmental Partner'
    },
    {
        id: DashboardTab.IMMUNITY_MAP,
        label: 'Immunity Map',
        icon: <ShieldAlert size={16} />,
        status: 'ANALYTICAL',
        desc: 'Resistance Analysis'
    },
    {
        id: DashboardTab.REFLECTION_JOURNAL,
        label: 'Journal',
        icon: <Book size={16} />,
        status: 'REFLECTIVE',
        desc: 'Subject-Object Shifts'
    },
    {
        id: DashboardTab.ASSESSMENT,
        label: 'Assessment',
        icon: <Compass size={16} />,
        status: 'INTERACTIVE',
        desc: 'Stage Calibration'
    },
    { 
        id: DashboardTab.JOURNEY, 
        label: 'My Journey', 
        icon: <Footprints size={16} />, 
        status: 'NARRATIVE',
        desc: 'Milestones & Evolution'
    },
    { 
        id: DashboardTab.LIBRARY, 
        label: 'Library', 
        icon: <BookOpen size={16} />, 
        status: 'CURATED',
        desc: 'Stage-Matched Resources'
    },
    { 
        id: DashboardTab.LIFE_CONTEXT, 
        label: 'Life Context', 
        icon: <Heart size={16} />, 
        status: 'INTEGRATED',
        desc: 'External Domain Mapping'
    },
    { 
        id: DashboardTab.FEDERATION, 
        label: 'Federation', 
        icon: <Globe size={16} />, 
        status: 'NETWORKED',
        desc: 'External Connections'
    },
    { 
        id: DashboardTab.GROWTH_PORTFOLIO, 
        label: 'Growth Portfolio', 
        icon: <Award size={16} />, 
        status: 'VERIFIABLE',
        desc: 'Credential Atlas Integration'
    },
    { 
        id: DashboardTab.BILLING, 
        label: "System Fuel", 
        icon: <CreditCard size={16} />, 
        status: 'IMMUTABLE',
        desc: 'Entropy Management'
    },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case DashboardTab.ACCOUNT:
        return <AccountSettings user={user} onUpdateUser={onUpdateUser} />;
      
      case DashboardTab.ASSESSMENT:
          return hasAssessment ? (
              <div className="space-y-8 animate-in fade-in">
                  <div className="bg-[#1A1A1A] border border-[#2D2D2D] p-8 rounded-sm text-center">
                      <Compass size={48} className="text-[#F59E0B] mx-auto mb-4" />
                      <h2 className="text-2xl font-serif text-[#F5F0E6] mb-2">Calibration Complete</h2>
                      <p className="text-sm font-mono text-[#888888] mb-6">
                          Your developmental structure has been mapped. Proceed to your Journey or Psychometrics to see the integration.
                      </p>
                      <div className="flex justify-center space-x-4">
                          <Button onClick={() => setActiveTab(DashboardTab.JOURNEY)} icon={<Footprints size={14}/>}>View Journey</Button>
                          <Button variant="secondary" onClick={() => setActiveTab(DashboardTab.PSYCHOMETRICS)} icon={<Activity size={14}/>}>View Metrics</Button>
                      </div>
                      <div className="mt-8 pt-8 border-t border-[#2D2D2D]">
                          <button 
                            className="text-xs text-[#4A4A4A] hover:text-[#F59E0B] underline"
                            onClick={() => {
                                // Clear assessment for demo purposes to allow retake
                                const resetUser = { ...user, developmentProfile: { ...user.developmentProfile, assessmentHistory: [] } };
                                onUpdateUser(resetUser);
                            }}
                          >
                              Recalibrate (Retake Assessment)
                          </button>
                      </div>
                  </div>
              </div>
          ) : (
              <DevelopmentAssessment user={user} onComplete={handleAssessmentComplete} />
          );

      case DashboardTab.NOT_ME_CHAT:
          return <NotMeChat user={user} onUpdateUser={onUpdateUser} />;

      case DashboardTab.IMMUNITY_MAP:
          return <ImmunityMapTool user={user} onUpdateUser={onUpdateUser} />;

      case DashboardTab.REFLECTION_JOURNAL:
          return <ReflectionJournal user={user} onUpdateUser={onUpdateUser} />;

      case DashboardTab.JOURNEY:
          return <ProgressVisualization user={user} />;

      case DashboardTab.LIFE_CONTEXT:
          return <LifeContext user={user} onUpdateUser={onUpdateUser} />;

      case DashboardTab.LIBRARY:
          return <ContentLibrary user={user} onUpdateUser={onUpdateUser} />;

      case DashboardTab.FEDERATION:
          return <FederationBridge user={user} onUpdateUser={onUpdateUser} />;

      case DashboardTab.GROWTH_PORTFOLIO:
          return <CredentialWallet user={user} onUpdateUser={onUpdateUser} />;

      case DashboardTab.PSYCHOMETRICS:
        const profile = user.developmentProfile;
        const holding = profile.holdingEnvironment || { complexityLevel: 'MEDIUM', supportLevel: 'MEDIUM', inSafeMode: false, struggleIndex: 0, masteryIndex: 0 };
        const currentMeta = keganLabels[profile.stage];
        const subjectItems = profile.subjectObjectMap?.filter(i => i.status === 'SUBJECT') || [];
        const objectItems = profile.subjectObjectMap?.filter(i => i.status === 'OBJECT') || [];

        return (
            <div className="space-y-6 animate-in fade-in duration-500">
                {/* Header Section */}
                <div className="bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-8 flex items-center justify-between relative overflow-hidden">
                    <div className="relative z-10">
                        <div className="text-[10px] font-mono text-[#888888] uppercase tracking-widest mb-2">Current Developmental Order</div>
                        <h2 className={`text-3xl font-serif ${currentMeta.color} mb-1`}>{currentMeta.title}</h2>
                        <p className="text-sm font-mono text-[#F5F0E6]">{currentMeta.subtitle}</p>
                    </div>
                    
                    {/* Gauge Visual */}
                    <div className="relative w-32 h-32 flex items-center justify-center">
                        <svg className="w-full h-full -rotate-90">
                            <circle cx="64" cy="64" r="56" fill="transparent" stroke="#2D2D2D" strokeWidth="8" />
                            <circle 
                                cx="64" cy="64" r="56" 
                                fill="transparent" 
                                stroke="currentColor" 
                                strokeWidth="8" 
                                strokeDasharray={351} 
                                strokeDashoffset={351 - (351 * profile.score) / 100}
                                className={`${currentMeta.color} transition-all duration-1000`}
                            />
                        </svg>
                        <div className="absolute flex flex-col items-center">
                            <span className="text-2xl font-mono text-[#F5F0E6]">{Math.round(profile.score)}</span>
                            <span className="text-[8px] uppercase text-[#888888]">Growth Index</span>
                        </div>
                    </div>
                    
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#1A1A1A]/50 to-transparent pointer-events-none"></div>
                </div>

                {/* Developmental Feedback Loop (NEW) */}
                <div className="bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-6 relative overflow-hidden">
                    <div className="flex items-center space-x-2 mb-4">
                        <MessageCircle size={18} className="text-[#F5F0E6]" />
                        <h3 className="text-sm font-mono text-[#F5F0E6] uppercase tracking-wide">Developmental Feedback Loop</h3>
                    </div>
                    <div className="space-y-3">
                        {!observations.length && <p className="text-xs text-[#4A4A4A] italic">No system observations recorded.</p>}
                        {observations.map(obs => (
                            <div key={obs.id} className="p-3 bg-[#0D0D0D] border-l-4 border-blue-500 rounded-r-sm">
                                <div className="flex justify-between mb-1">
                                    <span className="text-[10px] font-mono text-blue-400 uppercase tracking-widest">{obs.patternType} PATTERN</span>
                                    <span className="text-[10px] text-[#4A4A4A]">{new Date(obs.timestamp).toLocaleDateString()}</span>
                                </div>
                                <p className="text-sm text-[#F5F0E6] font-sans leading-relaxed">"{obs.observation}"</p>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Subject-Object Topology Map */}
                <div className="bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-8 relative overflow-hidden">
                    <div className="absolute top-4 left-4 z-10">
                        <div className="flex items-center space-x-2">
                             <CircleDot size={18} className="text-[#F5F0E6]" />
                             <h3 className="text-sm font-mono text-[#F5F0E6] uppercase tracking-wide">Subject-Object Topology</h3>
                        </div>
                        <p className="text-xs text-[#888888] mt-1 font-mono">Mapping what you <span className="text-[#F5F0E6]">ARE</span> (Subject) vs what you <span className="text-[#F59E0B]">HAVE</span> (Object)</p>
                    </div>

                    <div className="flex items-center justify-center min-h-[300px] relative">
                         {/* Background Rings */}
                         <div className="absolute inset-0 flex items-center justify-center opacity-10 pointer-events-none">
                             <div className="w-[400px] h-[400px] border border-[#F5F0E6] rounded-full"></div>
                             <div className="w-[200px] h-[200px] border border-[#F5F0E6] rounded-full absolute"></div>
                         </div>

                         {/* Zones Label */}
                         <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[100px] font-serif text-[#F5F0E6] opacity-5 pointer-events-none">I AM</div>
                         <div className="absolute bottom-4 right-4 text-xs font-mono text-[#888888] uppercase">Zone of Control (Object) &rarr;</div>

                         <div className="grid grid-cols-2 gap-20 w-full max-w-3xl relative z-10">
                             {/* SUBJECT ZONE */}
                             <div className="flex flex-col items-center justify-center space-y-4 p-6 rounded-full border border-[#2D2D2D] bg-[#0D0D0D]/80 backdrop-blur-sm aspect-square relative group">
                                  <div className="absolute -top-3 bg-[#1A1A1A] px-2 text-xs font-mono text-[#888888] border border-[#2D2D2D] rounded-full">Subject (Hidden/Self)</div>
                                  {subjectItems.length === 0 && <span className="text-xs text-[#4A4A4A] italic">Empty</span>}
                                  {subjectItems.map(item => (
                                      <div key={item.id} className="px-3 py-1.5 bg-[#2D2D2D] text-[#F5F0E6] text-xs font-mono rounded-sm border border-[#4A4A4A] shadow-lg animate-pulse">
                                          {item.label}
                                      </div>
                                  ))}
                             </div>

                             {/* OBJECT ZONE */}
                             <div className="flex flex-col items-center justify-center space-y-4 p-6 rounded-full border border-[#F59E0B]/30 bg-[#F59E0B]/5 backdrop-blur-sm aspect-square relative">
                                  <div className="absolute -top-3 bg-[#1A1A1A] px-2 text-xs font-mono text-[#F5F0E6] border border-[#F59E0B]/30 rounded-full">Object (Visible/Tool)</div>
                                  {objectItems.length === 0 && <span className="text-xs text-[#4A4A4A] italic">Empty</span>}
                                  {objectItems.map(item => (
                                      <div key={item.id} className="px-3 py-1.5 bg-[#1A1A1A] text-[#F59E0B] text-xs font-mono rounded-sm border border-[#F59E0B]/50 shadow-sm">
                                          {item.label}
                                      </div>
                                  ))}
                             </div>
                         </div>
                         
                         {/* Connection Arrow */}
                         <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-0">
                             <div className="w-16 h-[2px] bg-gradient-to-r from-[#4A4A4A] to-[#F59E0B]"></div>
                             <ChevronRight size={16} className="absolute right-0 top-1/2 -translate-y-1/2 text-[#F59E0B]" />
                         </div>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Assessment Engine / Simulation */}
                    <div className="bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-6">
                        <div className="flex items-center space-x-2 mb-6">
                            <Brain size={18} className="text-[#F5F0E6]" />
                            <h3 className="text-sm font-mono text-[#F5F0E6] uppercase tracking-wide">Interaction Assessment Engine</h3>
                        </div>
                        
                        <div className="space-y-4">
                            <p className="text-xs text-[#888888] mb-4">
                                The system continuously monitors your interaction patterns to assess your developmental stage. 
                                <span className="block mt-2 text-[#4A4A4A] italic">Simulate interactions below to calibrate the engine:</span>
                            </p>

                            <div className="grid grid-cols-1 gap-3">
                                <button 
                                    onClick={() => simulateInteraction('PASSIVE')}
                                    disabled={isSimulating}
                                    className="p-3 border border-[#2D2D2D] bg-[#0D0D0D] hover:border-red-900/50 hover:bg-red-900/10 text-left transition-all group"
                                >
                                    <div className="flex items-center justify-between mb-1">
                                        <span className="text-xs font-mono text-[#F5F0E6]">Passive Consumption</span>
                                        <BookOpen size={12} className="text-[#4A4A4A] group-hover:text-red-400" />
                                    </div>
                                    <p className="text-[10px] text-[#888888]">"Just tell me the answer."</p>
                                </button>

                                <button 
                                    onClick={() => simulateInteraction('AUTHORITY_SEEKING')}
                                    disabled={isSimulating}
                                    className="p-3 border border-[#2D2D2D] bg-[#0D0D0D] hover:border-orange-900/50 hover:bg-orange-900/10 text-left transition-all group"
                                >
                                    <div className="flex items-center justify-between mb-1">
                                        <span className="text-xs font-mono text-[#F5F0E6]">Authority Seeking</span>
                                        <AlertCircle size={12} className="text-[#4A4A4A] group-hover:text-orange-400" />
                                    </div>
                                    <p className="text-[10px] text-[#888888]">"The AI knows best. I will follow."</p>
                                </button>

                                <button 
                                    onClick={() => simulateInteraction('CRITICAL')}
                                    disabled={isSimulating}
                                    className="p-3 border border-[#2D2D2D] bg-[#0D0D0D] hover:border-blue-900/50 hover:bg-blue-900/10 text-left transition-all group"
                                >
                                    <div className="flex items-center justify-between mb-1">
                                        <span className="text-xs font-mono text-[#F5F0E6]">Critical Analysis</span>
                                        <Search size={12} className="text-[#4A4A4A] group-hover:text-blue-400" />
                                    </div>
                                    <p className="text-[10px] text-[#888888]">"I verify the output against my own logic."</p>
                                </button>

                                <button 
                                    onClick={() => simulateInteraction('PARADOXICAL')}
                                    disabled={isSimulating}
                                    className="p-3 border border-[#2D2D2D] bg-[#0D0D0D] hover:border-[#F59E0B]/50 hover:bg-[#F59E0B]/10 text-left transition-all group"
                                >
                                    <div className="flex items-center justify-between mb-1">
                                        <span className="text-xs font-mono text-[#F5F0E6]">Paradoxical Synthesis</span>
                                        <Sparkles size={12} className="text-[#4A4A4A] group-hover:text-[#F59E0B]" />
                                    </div>
                                    <p className="text-[10px] text-[#888888]">"The contradiction reveals a higher truth."</p>
                                </button>
                            </div>
                        </div>
                    </div>

                    {/* Scaffolding Control Center */}
                    <div className="bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm p-6 flex flex-col">
                        <div className="flex items-center space-x-2 mb-6">
                            <Shield size={18} className="text-[#10B981]" />
                            <h3 className="text-sm font-mono text-[#F5F0E6] uppercase tracking-wide">Holding Environment Status</h3>
                        </div>

                        <div className="space-y-6 flex-1">
                            <div className="grid grid-cols-2 gap-4">
                                <div className="p-3 bg-[#0D0D0D] border border-[#2D2D2D] rounded-sm">
                                    <div className="text-[10px] text-[#888888] uppercase mb-1">Support Level</div>
                                    <div className={`text-sm font-mono ${holding.supportLevel === 'HIGH' ? 'text-[#10B981]' : 'text-[#F5F0E6]'}`}>{holding.supportLevel}</div>
                                </div>
                                <div className="p-3 bg-[#0D0D0D] border border-[#2D2D2D] rounded-sm">
                                    <div className="text-[10px] text-[#888888] uppercase mb-1">Complexity</div>
                                    <div className={`text-sm font-mono ${holding.complexityLevel === 'LOW' ? 'text-[#10B981]' : 'text-[#F5F0E6]'}`}>{holding.complexityLevel}</div>
                                </div>
                            </div>

                            <div className="space-y-2">
                                <p className="text-[10px] font-mono text-[#888888]">Simulate User State (Triggers Auto-Adaptation)</p>
                                <div className="flex space-x-2">
                                    <button 
                                        onClick={() => simulateScaffolding('STRUGGLE')}
                                        className="flex-1 py-2 border border-red-900/50 bg-red-900/10 text-red-400 text-xs font-mono uppercase hover:bg-red-900/20"
                                    >
                                        Struggle +
                                    </button>
                                    <button 
                                        onClick={() => simulateScaffolding('MASTERY')}
                                        className="flex-1 py-2 border border-[#10B981]/50 bg-[#10B981]/10 text-[#10B981] text-xs font-mono uppercase hover:bg-[#10B981]/20"
                                    >
                                        Mastery +
                                    </button>
                                </div>
                            </div>
                            
                            {holding.inSafeMode && (
                                <div className="mt-4 p-3 bg-[#10B981]/10 border border-[#10B981]/30 rounded-sm text-center">
                                    <span className="text-xs font-mono text-[#10B981] uppercase tracking-wider">Safe Space Active</span>
                                    <p className="text-[10px] text-[#10B981]/80 mt-1">High-stakes elements hidden. Support pillars enabled.</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        );

      case DashboardTab.BILLING:
          return (
            <div className="flex flex-col items-center justify-center h-full text-center p-12">
                <CreditCard size={48} className="text-[#F5F0E6] mb-4" />
                <h3 className="text-xl font-serif text-[#F5F0E6] mb-2">{getTabLabel(DashboardTab.BILLING, user.tier)}</h3>
                <p className="text-[#888888] font-mono text-sm mb-6">Current Status: <span className="text-[#F5F0E6]">{user.tier}</span></p>
                
                <div className="grid gap-4 max-w-md w-full">
                    {/* Stage 3 Card */}
                    <div className={`p-4 border rounded-sm flex justify-between items-center transition-all ${isStage3 ? 'border-[#F5F0E6] bg-[#1A1A1A] shadow-[0_0_15px_rgba(245,240,230,0.1)]' : 'border-[#2D2D2D] opacity-50'}`}>
                        <div className="text-left">
                            <div className="text-sm font-mono text-[#F5F0E6]">Stage 3 (Socialized)</div>
                            <div className="text-xs text-[#888888]">Frozen State</div>
                        </div>
                        {isStage3 && <div className="text-xs font-mono text-[#F5F0E6] px-2 py-1 bg-[#2D2D2D] rounded">ACTIVE</div>}
                    </div>
                    
                    {/* Stage 4 Card */}
                    <div className={`p-4 border rounded-sm flex justify-between items-center transition-all ${!isStage3 && !isStage5 ? 'border-[#F5F0E6] bg-[#1A1A1A] shadow-[0_0_15px_rgba(245,240,230,0.1)]' : 'border-[#2D2D2D] opacity-70 hover:border-[#4A4A4A]'}`}>
                        <div className="text-left">
                            <div className="text-sm font-mono text-[#F5F0E6]">Stage 4 (Self-Authoring)</div>
                            <div className="text-xs text-[#888888]">Fluid State</div>
                        </div>
                        {(!isStage3 && !isStage5) ? <div className="text-xs font-mono text-[#F5F0E6] px-2 py-1 bg-[#2D2D2D] rounded">ACTIVE</div> : <button className="text-xs font-mono underline decoration-[#888888] hover:text-[#F5F0E6]">Upgrade</button>}
                    </div>

                     {/* Stage 5 Card */}
                     <div className={`p-4 border rounded-sm flex justify-between items-center transition-all ${isStage5 ? 'border-[#F59E0B] bg-[#F59E0B]/10 shadow-[0_0_15px_rgba(245,158,11,0.1)]' : 'border-[#2D2D2D] opacity-70 hover:border-[#4A4A4A]'}`}>
                        <div className="text-left">
                            <div className="text-sm font-mono text-[#F59E0B]">Stage 5 (Self-Transforming)</div>
                            <div className="text-xs text-[#888888]">Structural State</div>
                        </div>
                        {isStage5 ? <div className="text-xs font-mono text-[#F59E0B] px-2 py-1 bg-[#F59E0B]/20 rounded">ACTIVE</div> : <button className="text-xs font-mono underline decoration-[#888888] hover:text-[#F5F0E6]">Upgrade</button>}
                    </div>
                </div>
            </div>
          );
      default:
        return null;
    }
  };

  return (
    <div className="flex h-full bg-[#0D0D0D] overflow-hidden">
      {/* Vertical Sidebar */}
      <div className="w-64 bg-[#1A1A1A] border-r border-[#2D2D2D] flex flex-col flex-shrink-0 transition-all duration-500">
        
        {/* Portal Header */}
        <div className="h-16 flex items-center px-6 border-b border-[#2D2D2D] bg-[#151515]">
           <span className="font-mono text-xs text-[#888888] uppercase tracking-widest">
               Administrative
           </span>
        </div>

        {/* Navigation & Guide */}
        <div className="flex-1 flex flex-col overflow-hidden">
            <div className="flex-1 overflow-y-auto py-6 px-3 custom-scrollbar">
                <nav className="space-y-1 mb-6">
                    {tabs.map((tab) => (
                    <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id)}
                        className={`
                        w-full flex items-center px-3 py-3 text-xs font-mono uppercase tracking-wider transition-all duration-200 group rounded-sm border-l-2 relative overflow-hidden
                        ${activeTab === tab.id 
                            ? 'bg-[#2D2D2D] text-[#F5F0E6] border-[#F5F0E6]' 
                            : 'text-[#888888] border-transparent hover:bg-[#232323] hover:text-[#B5B5B5]'}
                        `}
                    >
                        <span className={`mr-3 ${activeTab === tab.id ? 'text-[#F5F0E6]' : 'text-[#4A4A4A] group-hover:text-[#888888]'}`}>
                        {tab.icon}
                        </span>
                        <div className="flex flex-col items-start">
                            <span>{tab.label}</span>
                        </div>
                        
                        {/* Status Indicator */}
                        {tab.status === 'IMMUTABLE' && (
                            <div className="ml-auto group/icon relative">
                                <Square size={10} className="text-[#4A4A4A] fill-[#4A4A4A]" />
                                <div className="absolute right-0 top-full mt-1 hidden group-hover/icon:block z-50 bg-black border border-[#2D2D2D] p-1 text-[10px] whitespace-nowrap text-[#888888]">
                                    Fixed Structure
                                </div>
                            </div>
                        )}

                         {tab.status === 'ADAPTIVE' && (
                            <div className="ml-auto group/icon relative">
                                <Activity size={10} className="text-[#F59E0B]" />
                            </div>
                        )}

                        {tab.status === 'COMPANION' && (
                            <div className="ml-auto group/icon relative">
                                <Bot size={10} className="text-[#F59E0B]" />
                            </div>
                        )}

                        {tab.status === 'ANALYTICAL' && (
                            <div className="ml-auto group/icon relative">
                                <ShieldAlert size={10} className="text-red-400" />
                            </div>
                        )}

                        {tab.status === 'REFLECTIVE' && (
                            <div className="ml-auto group/icon relative">
                                <Book size={10} className="text-purple-400" />
                            </div>
                        )}

                        {tab.status === 'CURATED' && (
                            <div className="ml-auto group/icon relative">
                                <BookOpen size={10} className="text-green-400" />
                            </div>
                        )}

                        {tab.status === 'INTEGRATED' && (
                            <div className="ml-auto group/icon relative">
                                <Heart size={10} className="text-red-400" />
                            </div>
                        )}

                        {tab.status === 'VERIFIABLE' && (
                            <div className="ml-auto group/icon relative">
                                <BadgeCheck size={10} className="text-blue-400" />
                            </div>
                        )}

                        {tab.status === 'NETWORKED' && (
                            <div className="ml-auto group/icon relative">
                                <Globe size={10} className="text-purple-400" />
                            </div>
                        )}

                        {tab.status === 'NARRATIVE' && (
                            <div className="ml-auto group/icon relative">
                                <Footprints size={10} className="text-purple-400" />
                            </div>
                        )}

                        {tab.status === 'INTERACTIVE' && (
                            <div className="ml-auto group/icon relative">
                                <Compass size={10} className="text-teal-400" />
                            </div>
                        )}
                        
                        {activeTab === tab.id && <ChevronRight size={14} className="ml-auto opacity-50" />}
                    </button>
                    ))}
                </nav>

                {/* Embedded System Guide */}
                <SystemGuide 
                    tier={user.tier} 
                    keganStage={user.developmentProfile?.stage || KeganStage.STAGE_3_SOCIALIZED} 
                />
            </div>
        </div>

        {/* Footer Actions */}
        <div className="border-t border-[#2D2D2D] p-4 bg-[#151515]">
            <button 
                onClick={onLogout}
                className="w-full flex items-center justify-center space-x-2 p-2 rounded-sm text-[#888888] hover:text-[#F5F0E6] hover:bg-[#2D2D2D] transition-colors font-mono text-xs uppercase"
            >
                <LogOut size={14} />
                <span>Disconnect</span>
            </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden relative bg-[#0D0D0D]">
        <header className="h-16 bg-[#0D0D0D] border-b border-[#2D2D2D] flex items-center justify-between px-8">
            <div className="flex items-center space-x-3">
                <Anchor size={16} className="text-[#4A4A4A]" />
                <h1 className="text-2xl font-serif text-[#F5F0E6] uppercase tracking-wide">
                    {tabs.find(t => t.id === activeTab)?.label}
                </h1>
                <span className="text-[10px] font-mono text-[#4A4A4A] border border-[#2D2D2D] px-1 rounded">
                   {isStage5 ? "STRUCTURAL" : isStage3 ? "FIXED" : "FLUID"}
                </span>
            </div>
            <div className="flex items-center space-x-4">
                <div className={`flex items-center space-x-2 px-3 py-1 bg-[#1A1A1A] rounded-full border ${isStage5 ? 'border-[#F59E0B]/50' : 'border-[#2D2D2D]'}`}>
                    <div className={`w-2 h-2 rounded-full ${isStage3 ? 'bg-blue-500' : isStage5 ? 'bg-[#F59E0B]' : 'bg-green-500'}`}></div>
                    <span className={`text-[10px] font-mono uppercase ${isStage5 ? 'text-[#F59E0B]' : 'text-[#888888]'}`}>
                        {user.developmentProfile?.stage.replace('STAGE_', '').replace(/_/g, ' ') || 'CALIBRATING'}
                    </span>
                </div>
            </div>
        </header>

        <main className="flex-1 overflow-y-auto bg-[#0D0D0D] p-8 custom-scrollbar">
          <div className="max-w-4xl mx-auto h-full">
            {renderContent()}
          </div>
        </main>
      </div>
    </div>
  );
};