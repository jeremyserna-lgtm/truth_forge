import React, { useState, useMemo } from 'react';
import { User, DevelopmentalResource, KeganStage, ResourceType } from '../types';
import { Button } from './Button';
import { BookOpen, Play, FileText, Dumbbell, Compass, Search, Filter, CheckCircle, Clock, ChevronRight, Lock, ArrowRight, X } from 'lucide-react';

interface ContentLibraryProps {
  user: User;
  onUpdateUser: (user: User) => void;
}

// --- MOCK DATABASE ---
const RESOURCES: DevelopmentalResource[] = [
    // STAGE 2
    {
        id: 'res-2-1',
        title: 'Mastering Your Calendar',
        author: 'Nexus Core',
        type: 'ARTICLE',
        targetStages: [KeganStage.STAGE_2_IMPERIAL],
        topics: ['Self-Management', 'Efficiency'],
        duration: '5 min read',
        difficultyLevel: 'BEGINNER',
        contentPreview: 'Learn how to use time as a tool to get what you want.',
        whyRelevant: 'Stage 2 Focus: Optimizing personal interests.'
    },
    {
        id: 'res-2-2',
        title: 'Negotiation Basics',
        author: 'System',
        type: 'VIDEO',
        targetStages: [KeganStage.STAGE_2_IMPERIAL],
        topics: ['Communication', 'Influence'],
        duration: '10 min video',
        difficultyLevel: 'INTERMEDIATE',
        contentPreview: 'How to trade value without losing ground.',
        whyRelevant: 'Stage 2 Focus: Transactional relationships.'
    },
    // STAGE 3
    {
        id: 'res-3-1',
        title: 'The Art of Active Listening',
        author: 'Not-Me',
        type: 'EXERCISE',
        targetStages: [KeganStage.STAGE_3_SOCIALIZED],
        topics: ['Empathy', 'Connection'],
        duration: '15 min practice',
        difficultyLevel: 'BEGINNER',
        contentPreview: 'A guide to hearing the person, not just the words.',
        whyRelevant: 'Stage 3 Focus: Valuing the perspective of others.'
    },
    {
        id: 'res-3-2',
        title: 'Navigating Team Conflict',
        author: 'System',
        type: 'CASE_STUDY',
        targetStages: [KeganStage.STAGE_3_SOCIALIZED],
        topics: ['Conflict', 'Belonging'],
        duration: '10 min read',
        difficultyLevel: 'INTERMEDIATE',
        contentPreview: 'Analyzing a workplace dispute from multiple emotional angles.',
        whyRelevant: 'Stage 3 Focus: Maintaining relational harmony.'
    },
    // STAGE 4
    {
        id: 'res-4-1',
        title: 'Defining Your Core Values',
        author: 'Nexus Core',
        type: 'REFLECTION',
        targetStages: [KeganStage.STAGE_4_SELF_AUTHORING],
        topics: ['Identity', 'Authorship'],
        duration: '20 min session',
        difficultyLevel: 'ADVANCED',
        contentPreview: 'Stop inheriting values. Start choosing them.',
        whyRelevant: 'Stage 4 Focus: Self-definition independent of external validation.'
    },
    {
        id: 'res-4-2',
        title: 'System Building for Leaders',
        author: 'System',
        type: 'ARTICLE',
        targetStages: [KeganStage.STAGE_4_SELF_AUTHORING],
        topics: ['Leadership', 'Structure'],
        duration: '12 min read',
        difficultyLevel: 'INTERMEDIATE',
        contentPreview: 'Creating frameworks that govern others rather than being governed by them.',
        whyRelevant: 'Stage 4 Focus: Constructing the system.'
    },
    // STAGE 5
    {
        id: 'res-5-1',
        title: 'Embracing Paradox',
        author: 'Not-Me',
        type: 'VIDEO',
        targetStages: [KeganStage.STAGE_5_SELF_TRANSFORMING],
        topics: ['Dialectics', 'Wisdom'],
        duration: '18 min video',
        difficultyLevel: 'ADVANCED',
        contentPreview: 'How to hold two opposing truths simultaneously without collapse.',
        whyRelevant: 'Stage 5 Focus: Transcending binary logic.'
    },
    {
        id: 'res-5-2',
        title: 'Inter-Paradigmatic Leadership',
        author: 'System',
        type: 'CASE_STUDY',
        targetStages: [KeganStage.STAGE_5_SELF_TRANSFORMING],
        topics: ['Systems Thinking', 'Transformation'],
        duration: '25 min read',
        difficultyLevel: 'ADVANCED',
        contentPreview: 'Leading across different value systems and reality tunnels.',
        whyRelevant: 'Stage 5 Focus: Facilitating evolution in diverse systems.'
    }
];

export const ContentLibrary: React.FC<ContentLibraryProps> = ({ user, onUpdateUser }) => {
  const [activeTab, setActiveTab] = useState<'FOR_YOU' | 'EXPLORE' | 'HISTORY'>('FOR_YOU');
  const [selectedResource, setSelectedResource] = useState<DevelopmentalResource | null>(null);
  const [isViewing, setIsViewing] = useState(false);
  const [reflection, setReflection] = useState('');
  
  const userStage = user.developmentProfile.stage;
  const libraryState = user.developmentProfile.library || { interactions: [], savedResourceIds: [] };

  const getNextStage = (current: KeganStage): KeganStage | null => {
      const stages = Object.values(KeganStage);
      const idx = stages.indexOf(current);
      return idx < stages.length - 1 ? stages[idx + 1] : null;
  };

  const nextStage = getNextStage(userStage);

  const getIcon = (type: ResourceType) => {
      switch(type) {
          case 'ARTICLE': return <FileText size={16} className="text-blue-400" />;
          case 'VIDEO': return <Play size={16} className="text-red-400" />;
          case 'EXERCISE': return <Dumbbell size={16} className="text-green-400" />;
          case 'REFLECTION': return <Compass size={16} className="text-purple-400" />;
          case 'CASE_STUDY': return <Search size={16} className="text-[#F59E0B]" />;
      }
  };

  const filteredResources = useMemo(() => {
      if (activeTab === 'FOR_YOU') {
          return RESOURCES.filter(r => r.targetStages.includes(userStage));
      }
      if (activeTab === 'EXPLORE') {
          return RESOURCES; // All resources
      }
      if (activeTab === 'HISTORY') {
          const completedIds = libraryState.interactions.map(i => i.resourceId);
          return RESOURCES.filter(r => completedIds.includes(r.id));
      }
      return [];
  }, [activeTab, userStage, libraryState]);

  const handleResourceClick = (res: DevelopmentalResource) => {
      setSelectedResource(res);
      setIsViewing(true);
  };

  const handleCompleteResource = () => {
      if (!selectedResource) return;
      
      const newInteraction = {
          resourceId: selectedResource.id,
          startedAt: Date.now(), // Simplified
          completedAt: Date.now(),
          userReflection: reflection,
          helpful: true
      };

      onUpdateUser({
          ...user,
          developmentProfile: {
              ...user.developmentProfile,
              library: {
                  ...libraryState,
                  interactions: [newInteraction, ...libraryState.interactions]
              }
          }
      });
      setIsViewing(false);
      setReflection('');
      setSelectedResource(null);
  };

  const isCompleted = (id: string) => libraryState.interactions.some(i => i.resourceId === id);

  return (
    <div className="flex h-full animate-in fade-in duration-500">
        {/* Left Sidebar: Navigation & Filters */}
        <div className="w-64 bg-[#151515] border-r border-[#2D2D2D] flex flex-col flex-shrink-0">
            <div className="p-6 border-b border-[#2D2D2D]">
                <h2 className="text-lg font-serif text-[#F5F0E6] uppercase tracking-wide flex items-center">
                    <BookOpen size={18} className="mr-2 text-[#F59E0B]" />
                    Nexus Library
                </h2>
                <p className="text-xs font-mono text-[#888888] mt-2">
                    Curated developmental vectors matching your current stage ({userStage.replace('STAGE_', '').split('_')[0]} {userStage.split('_')[1]}).
                </p>
            </div>
            
            <div className="flex-1 p-2 space-y-1">
                <button 
                    onClick={() => setActiveTab('FOR_YOU')}
                    className={`w-full flex items-center justify-between px-4 py-3 rounded-sm transition-colors ${activeTab === 'FOR_YOU' ? 'bg-[#2D2D2D] text-[#F5F0E6]' : 'text-[#888888] hover:bg-[#1A1A1A]'}`}
                >
                    <span className="text-xs font-mono uppercase">For You</span>
                    {activeTab === 'FOR_YOU' && <div className="w-1.5 h-1.5 rounded-full bg-[#F59E0B]"></div>}
                </button>
                <button 
                    onClick={() => setActiveTab('EXPLORE')}
                    className={`w-full flex items-center justify-between px-4 py-3 rounded-sm transition-colors ${activeTab === 'EXPLORE' ? 'bg-[#2D2D2D] text-[#F5F0E6]' : 'text-[#888888] hover:bg-[#1A1A1A]'}`}
                >
                    <span className="text-xs font-mono uppercase">Full Catalog</span>
                    {activeTab === 'EXPLORE' && <div className="w-1.5 h-1.5 rounded-full bg-[#F59E0B]"></div>}
                </button>
                <button 
                    onClick={() => setActiveTab('HISTORY')}
                    className={`w-full flex items-center justify-between px-4 py-3 rounded-sm transition-colors ${activeTab === 'HISTORY' ? 'bg-[#2D2D2D] text-[#F5F0E6]' : 'text-[#888888] hover:bg-[#1A1A1A]'}`}
                >
                    <span className="text-xs font-mono uppercase">History</span>
                    {activeTab === 'HISTORY' && <div className="w-1.5 h-1.5 rounded-full bg-[#F59E0B]"></div>}
                </button>
            </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 overflow-y-auto bg-[#0D0D0D] p-8 custom-scrollbar">
            
            {activeTab === 'FOR_YOU' && (
                <div className="mb-8 p-6 bg-[#1A1A1A] border border-[#F59E0B]/30 rounded-sm relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 opacity-10">
                        <Compass size={64} className="text-[#F59E0B]" />
                    </div>
                    <div className="relative z-10">
                        <span className="text-xs font-mono text-[#F59E0B] uppercase tracking-widest mb-2 block">Developmental Edge</span>
                        <h3 className="text-2xl font-serif text-[#F5F0E6] mb-2">Mastering {userStage.replace('STAGE_', '').replace(/_/g, ' ')}</h3>
                        <p className="text-sm font-mono text-[#888888] max-w-2xl leading-relaxed">
                            Your current work involves stabilizing this way of knowing. 
                            The resources below are selected to help you fully inhabit this stage before you begin to transcend it.
                        </p>
                    </div>
                </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredResources.map(res => {
                    const completed = isCompleted(res.id);
                    return (
                        <div 
                            key={res.id} 
                            onClick={() => handleResourceClick(res)}
                            className={`group border rounded-sm p-5 cursor-pointer transition-all hover:-translate-y-1 hover:shadow-lg relative overflow-hidden flex flex-col h-64 ${completed ? 'bg-[#151515] border-[#2D2D2D] opacity-70' : 'bg-[#1A1A1A] border-[#2D2D2D] hover:border-[#F59E0B]/50'}`}
                        >
                            <div className="flex justify-between items-start mb-4">
                                <div className="p-2 bg-[#0D0D0D] border border-[#2D2D2D] rounded-sm group-hover:border-[#F59E0B]/30 transition-colors">
                                    {getIcon(res.type)}
                                </div>
                                {completed && <CheckCircle size={16} className="text-green-500" />}
                            </div>
                            
                            <div className="flex-1">
                                <h4 className="text-lg font-serif text-[#F5F0E6] leading-tight mb-2 group-hover:text-[#F59E0B] transition-colors">{res.title}</h4>
                                <p className="text-xs text-[#888888] line-clamp-2 mb-3">{res.contentPreview}</p>
                            </div>

                            <div className="mt-4 pt-4 border-t border-[#2D2D2D] flex items-center justify-between text-[10px] font-mono text-[#4A4A4A]">
                                <span className="flex items-center"><Clock size={10} className="mr-1"/> {res.duration}</span>
                                <span className={`px-1.5 py-0.5 rounded border ${res.difficultyLevel === 'BEGINNER' ? 'border-green-900 text-green-500' : res.difficultyLevel === 'INTERMEDIATE' ? 'border-yellow-900 text-yellow-500' : 'border-red-900 text-red-500'}`}>
                                    {res.difficultyLevel}
                                </span>
                            </div>
                        </div>
                    );
                })}
            </div>

            {/* Next Stage Teaser (Only in FOR_YOU) */}
            {activeTab === 'FOR_YOU' && nextStage && (
                <div className="mt-12 pt-8 border-t border-[#2D2D2D]">
                    <div className="flex items-center space-x-2 mb-6">
                        <Lock size={16} className="text-[#4A4A4A]" />
                        <h3 className="text-sm font-mono text-[#888888] uppercase tracking-wide">Horizon: {nextStage.replace('STAGE_', '').replace(/_/g, ' ')}</h3>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 opacity-50 pointer-events-none grayscale">
                        {RESOURCES.filter(r => r.targetStages.includes(nextStage)).slice(0,3).map(res => (
                            <div key={res.id} className="border border-[#2D2D2D] bg-[#1A1A1A] p-5 rounded-sm">
                                <div className="h-4 w-4 bg-[#2D2D2D] rounded mb-4"></div>
                                <h4 className="text-sm font-serif text-[#F5F0E6] mb-2">{res.title}</h4>
                                <div className="h-2 w-1/2 bg-[#2D2D2D] rounded"></div>
                            </div>
                        ))}
                    </div>
                    <div className="text-center mt-4">
                        <p className="text-xs font-mono text-[#4A4A4A]">Complete current stage work to unlock horizon content.</p>
                    </div>
                </div>
            )}
        </div>

        {/* Resource Viewer Modal */}
        {isViewing && selectedResource && (
            <div className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-sm flex items-center justify-center p-6 animate-in fade-in duration-300">
                <div className="w-full max-w-4xl bg-[#1A1A1A] border border-[#2D2D2D] rounded-sm shadow-2xl flex flex-col h-[85vh] relative">
                    {/* Header */}
                    <div className="p-6 border-b border-[#2D2D2D] flex justify-between items-start bg-[#151515]">
                        <div>
                            <div className="flex items-center space-x-2 mb-2">
                                <span className="text-[10px] font-mono text-[#F59E0B] border border-[#F59E0B]/30 px-2 py-0.5 rounded bg-[#F59E0B]/10 uppercase">
                                    {selectedResource.type}
                                </span>
                                <span className="text-[10px] font-mono text-[#4A4A4A] flex items-center">
                                    <Clock size={10} className="mr-1"/> {selectedResource.duration}
                                </span>
                            </div>
                            <h2 className="text-2xl font-serif text-[#F5F0E6]">{selectedResource.title}</h2>
                            <p className="text-xs font-mono text-[#888888] mt-1">by {selectedResource.author}</p>
                        </div>
                        <button onClick={() => setIsViewing(false)} className="text-[#4A4A4A] hover:text-[#F5F0E6]"><X size={24}/></button>
                    </div>

                    {/* Content Body */}
                    <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
                        <div className="max-w-2xl mx-auto space-y-8">
                            <div className="p-4 bg-[#0D0D0D] border-l-4 border-[#F59E0B] rounded-r-sm">
                                <h4 className="text-xs font-mono text-[#F59E0B] uppercase mb-1">Developmental Context</h4>
                                <p className="text-sm text-[#F5F0E6] italic">{selectedResource.whyRelevant}</p>
                            </div>

                            {/* Simulated Content */}
                            <div className="space-y-4 text-[#F5F0E6] font-serif text-lg leading-relaxed opacity-90">
                                <p>
                                    [Content Placeholder for {selectedResource.title}]
                                </p>
                                <p>
                                    Here lies the core wisdom of the resource. It would engage you with concepts specifically tailored to challenge the limits of your current way of knowing.
                                </p>
                                <div className="h-64 bg-[#0D0D0D] border border-[#2D2D2D] flex items-center justify-center rounded-sm">
                                    <span className="text-[#4A4A4A] font-mono text-xs uppercase">Interactive Media / Text Content</span>
                                </div>
                                <p>
                                    As you engage with this, consider how it applies to your Life Context domains.
                                </p>
                            </div>

                            {/* Reflection Section */}
                            <div className="pt-8 border-t border-[#2D2D2D] space-y-4">
                                <h3 className="text-lg font-serif text-[#F5F0E6]">Integration Reflection</h3>
                                <p className="text-xs font-mono text-[#888888]">
                                    To integrate this knowledge, reflect on one takeaway.
                                </p>
                                <textarea 
                                    className="w-full h-32 bg-[#0D0D0D] border border-[#2D2D2D] rounded-sm p-4 text-[#F5F0E6] focus:outline-none focus:border-[#F59E0B] resize-none text-sm"
                                    placeholder="I learned that..."
                                    value={reflection}
                                    onChange={(e) => setReflection(e.target.value)}
                                />
                            </div>
                        </div>
                    </div>

                    {/* Footer */}
                    <div className="p-6 border-t border-[#2D2D2D] bg-[#151515] flex justify-end">
                        <Button 
                            size="lg" 
                            onClick={handleCompleteResource} 
                            disabled={!reflection.trim()}
                            icon={<CheckCircle size={16}/>}
                        >
                            Complete & Log
                        </Button>
                    </div>
                </div>
            </div>
        )}
    </div>
  );
};