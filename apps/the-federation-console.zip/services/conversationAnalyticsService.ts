import { ConversationMetrics, DevelopmentalMoment, ConversationTheme, BreakthroughEvent, NotMeEffectiveness } from '../types';

const INITIAL_MOMENTS: DevelopmentalMoment[] = [
  {
    id: 'mom-1',
    userId: 'user-732',
    timestamp: Date.now() - 1000 * 60 * 5,
    userStage: 'Stage 3',
    insight: 'User realized their hesitation to speak up is tied to fear of group exclusion.',
    themeId: 'th-belonging'
  },
  {
    id: 'mom-2',
    userId: 'user-891',
    timestamp: Date.now() - 1000 * 60 * 12,
    userStage: 'Stage 4',
    insight: 'Acknowledged that their "efficiency" framework is limiting team creativity.',
    themeId: 'th-authority'
  },
  {
    id: 'mom-3',
    userId: 'user-104',
    timestamp: Date.now() - 1000 * 60 * 25,
    userStage: 'Stage 2/3',
    insight: 'Identified a transactional pattern in how they view mentorship.',
    themeId: 'th-transactional'
  }
];

const INITIAL_THEMES: ConversationTheme[] = [
  {
    id: 'th-belonging',
    name: 'Conflict vs. Belonging',
    volume: 342,
    stageCorrelation: 'Stage 3',
    sentiment: 45
  },
  {
    id: 'th-authority',
    name: 'Internal Authority',
    volume: 156,
    stageCorrelation: 'Stage 4',
    sentiment: 68
  },
  {
    id: 'th-imposter',
    name: 'Imposter Syndrome',
    volume: 289,
    stageCorrelation: 'Stage 3/4',
    sentiment: 30
  },
  {
    id: 'th-purpose',
    name: 'Systemic Purpose',
    volume: 84,
    stageCorrelation: 'Stage 5',
    sentiment: 82
  }
];

const INITIAL_BREAKTHROUGHS: BreakthroughEvent[] = [
  {
    id: 'bk-1',
    userId: 'user-alpha-92',
    timestamp: Date.now() - 1000 * 60 * 45,
    fromState: 'Subject to Validation',
    toState: 'Object to Validation',
    triggerMessage: '"What would happen if you disappointed them but stayed true to the goal?"',
    confidence: 94
  },
  {
    id: 'bk-2',
    userId: 'user-delta-55',
    timestamp: Date.now() - 1000 * 60 * 120,
    fromState: 'Embedded in Role',
    toState: 'Author of Role',
    triggerMessage: '"Are you the manager, or are you playing the role of manager?"',
    confidence: 88
  }
];

const INITIAL_EFFECTIVENESS: NotMeEffectiveness[] = [
  { stage: 'Stage 2', effectiveness: 72, avgDepth: 3.4, activeSessions: 450 },
  { stage: 'Stage 3', effectiveness: 91, avgDepth: 6.8, activeSessions: 1200 },
  { stage: 'Stage 4', effectiveness: 85, avgDepth: 8.2, activeSessions: 550 },
  { stage: 'Stage 5', effectiveness: 64, avgDepth: 9.5, activeSessions: 40 }
];

const generateHourlyActivity = (): number[] => {
  return Array.from({ length: 24 }, () => Math.floor(Math.random() * 200) + 50);
};

export const getConversationMetrics = (): ConversationMetrics => {
  return {
    activeConversations: 2240,
    avgDepthScore: 6.7,
    moments: INITIAL_MOMENTS,
    themes: INITIAL_THEMES,
    breakthroughs: INITIAL_BREAKTHROUGHS,
    effectiveness: INITIAL_EFFECTIVENESS,
    hourlyActivity: generateHourlyActivity()
  };
};

export const formatConversationInsightsForAI = (metrics: ConversationMetrics): string => {
  let report = "CONVERSATION INTELLIGENCE (NOT-ME COMPANION DATA):\n";
  
  report += `Active Sessions: ${metrics.activeConversations} | Avg Depth: ${metrics.avgDepthScore}/10\n\n`;
  
  report += "RECENT BREAKTHROUGHS:\n";
  metrics.breakthroughs.forEach(b => {
    report += `- User ${b.userId}: Shifted from "${b.fromState}" to "${b.toState}". Trigger: ${b.triggerMessage}\n`;
  });
  
  report += "\nDOMINANT THEMES:\n";
  metrics.themes.forEach(t => {
    report += `- ${t.name} (${t.volume} sessions, correlates with ${t.stageCorrelation})\n`;
  });

  return report;
};