import { LearningState, Pattern, FeatureMetric, PredictiveModel, Anomaly } from '../types';

const INITIAL_PATTERNS: Pattern[] = [
  {
    id: 'pat-001',
    title: 'Recursive Governance Adoption',
    category: 'DEVELOPMENT',
    confidence: 94,
    description: 'Users who participate in >3 governance votes show 40% faster progression through Kegan Stage 4.',
    implications: [
      'Prioritize governance onboarding for Stage 3 users.',
      'Governance participation is a lagging indicator of self-authorship.'
    ],
    detectedAt: Date.now() - 86400000 * 2
  },
  {
    id: 'pat-002',
    title: 'Credential Decay Correlation',
    category: 'SYSTEM',
    confidence: 88,
    description: 'High rates of credential revocation correlate with api_latency > 200ms in the Truth Engine.',
    implications: [
      'System latency erodes trust fabric.',
      'Optimize Credential Atlas verification paths.'
    ],
    detectedAt: Date.now() - 86400000 * 5
  },
  {
    id: 'pat-003',
    title: 'Crisis Precursor: Silence',
    category: 'CRISIS',
    confidence: 76,
    description: 'Sudden drop in message synthesis often precedes a "Critical" health status event by 4-6 hours.',
    implications: [
      'Trigger proactive diagnostics when throughput drops <10%.',
      'Alert Human Support pool early.'
    ],
    detectedAt: Date.now() - 3600000 * 4
  }
];

const INITIAL_FEATURES: FeatureMetric[] = [
  {
    id: 'feat-1',
    name: 'ITC Mapping',
    impactScore: 92,
    engagementScore: 78,
    retentionEffect: 'POSITIVE'
  },
  {
    id: 'feat-2',
    name: 'Workflow Builder',
    impactScore: 65,
    engagementScore: 45,
    retentionEffect: 'NEUTRAL'
  },
  {
    id: 'feat-3',
    name: 'Vision Studio',
    impactScore: 88,
    engagementScore: 95,
    retentionEffect: 'POSITIVE'
  },
  {
    id: 'feat-4',
    name: 'Legacy Chat',
    impactScore: 30,
    engagementScore: 12,
    retentionEffect: 'NEGATIVE'
  }
];

const INITIAL_MODELS: PredictiveModel[] = [
  {
    id: 'mod-1',
    name: 'Stage Transition Predictor (Alpha)',
    accuracy: 89.4,
    status: 'ACTIVE',
    lastTrained: Date.now() - 86400000 * 1,
    predictionWindow: 'Next 90 Days'
  },
  {
    id: 'mod-2',
    name: 'Churn Risk Estimator',
    accuracy: 94.1,
    status: 'ACTIVE',
    lastTrained: Date.now() - 86400000 * 3,
    predictionWindow: 'Next 14 Days'
  },
  {
    id: 'mod-3',
    name: 'Resource Demand Forecaster',
    accuracy: 76.5,
    status: 'RETRAINING',
    lastTrained: Date.now() - 86400000 * 7,
    predictionWindow: 'Next 7 Days'
  }
];

const INITIAL_ANOMALIES: Anomaly[] = [
  {
    id: 'anom-1',
    severity: 'MEDIUM',
    type: 'DATA',
    description: 'Unusual spike in "Stage 5" self-reporting from unverified accounts.',
    detectedAt: Date.now() - 3600000 * 12,
    suggestedAction: 'Increase verification strictness on self-assessments.'
  },
  {
    id: 'anom-2',
    severity: 'LOW',
    type: 'SYSTEMIC',
    description: 'Minor drift in Truth Engine semantic coherence metrics.',
    detectedAt: Date.now() - 3600000 * 2,
    suggestedAction: 'Schedule calibration cycle for Truth Engine.'
  }
];

export const getLearningState = (): LearningState => {
  return {
    patterns: INITIAL_PATTERNS,
    features: INITIAL_FEATURES,
    models: INITIAL_MODELS,
    anomalies: INITIAL_ANOMALIES,
    lastUpdated: Date.now()
  };
};

export const formatLearningForAI = (state: LearningState): string => {
  let report = "FEDERATION LEARNING & INSIGHTS:\n";
  
  report += "DETECTED PATTERNS:\n";
  state.patterns.forEach(p => {
    report += `- [${p.category}] ${p.title} (${p.confidence}% Conf): ${p.description}\n`;
  });

  report += "\nPREDICTIVE MODELS:\n";
  state.models.forEach(m => {
    report += `- ${m.name}: ${m.accuracy}% Acc (${m.status})\n`;
  });

  if (state.anomalies.length > 0) {
    report += "\nACTIVE ANOMALIES:\n";
    state.anomalies.forEach(a => {
      report += `! [${a.severity}] ${a.description} -> Suggestion: ${a.suggestedAction}\n`;
    });
  }

  return report;
};