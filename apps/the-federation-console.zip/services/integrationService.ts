import { ApiContract, ModuleType, IntegrationEvent, WorkflowStep } from '../types';
import { v4 as uuidv4 } from 'uuid';

export const API_CONTRACTS: ApiContract[] = [
  {
    id: 'contract-truth',
    company: ModuleType.ORCHESTRATOR,
    version: 'v2.1.0',
    status: 'ACTIVE',
    lastUpdated: Date.now() - 86400000 * 3,
    approvedBy: 'Federation High Council',
    complianceScore: 99,
    endpoints: [
      {
        id: 'ep-synth',
        path: '/v1/synthesis/generate',
        method: 'POST',
        description: 'Synthesizes high-level strategy from raw data inputs.',
        authorizedCallers: [ModuleType.BUILDER, ModuleType.SEER],
        rateLimit: '500/min',
        requestSchema: {
          'context': { type: 'object', required: true, description: 'Raw input data' },
          'intent': { type: 'string', required: true }
        },
        responseSchema: {
          'strategy': { type: 'object', required: true },
          'confidence': { type: 'number', required: true }
        }
      },
      {
        id: 'ep-ctx',
        path: '/v1/context/query',
        method: 'GET',
        description: 'Retrieves current federation context state.',
        authorizedCallers: [ModuleType.BUILDER],
        rateLimit: '2000/min',
        requestSchema: {
          'query': { type: 'string', required: true }
        },
        responseSchema: {
          'result': { type: 'array', required: true }
        }
      }
    ],
    changelog: [
      { date: Date.now() - 86400000 * 3, note: 'Updated rate limits for Primitive Engine' },
      { date: Date.now() - 86400000 * 10, note: 'Added synthesis confidence score' }
    ]
  },
  {
    id: 'contract-builder',
    company: ModuleType.BUILDER,
    version: 'v1.4.2',
    status: 'ACTIVE',
    lastUpdated: Date.now() - 86400000 * 7,
    approvedBy: 'Technical Steering Committee',
    complianceScore: 94,
    endpoints: [
      {
        id: 'ep-build',
        path: '/v1/patterns/deploy',
        method: 'POST',
        description: 'Deploys a cognitive pattern to the active substrate.',
        authorizedCallers: [ModuleType.ORCHESTRATOR],
        rateLimit: '100/min',
        requestSchema: {
          'patternId': { type: 'string', required: true },
          'parameters': { type: 'object', required: false }
        },
        responseSchema: {
          'deploymentId': { type: 'string', required: true },
          'status': { type: 'string', required: true }
        }
      },
      {
        id: 'ep-status',
        path: '/v1/substrate/status',
        method: 'GET',
        description: 'Checks health of specific primitive clusters.',
        authorizedCallers: [ModuleType.ORCHESTRATOR, ModuleType.SEER],
        rateLimit: '5000/min',
        requestSchema: {},
        responseSchema: {
          'load': { type: 'number', required: true }
        }
      }
    ],
    changelog: [
      { date: Date.now() - 86400000 * 7, note: 'Deprecated v1/patterns/list' },
    ]
  },
  {
    id: 'contract-seer',
    company: ModuleType.SEER,
    version: 'v3.0.0-beta',
    status: 'DRAFT',
    lastUpdated: Date.now() - 86400000 * 1,
    approvedBy: 'Pending Review',
    complianceScore: 88,
    endpoints: [
      {
        id: 'ep-verify',
        path: '/v1/credentials/verify',
        method: 'POST',
        description: 'Cryptographically verifies a claim against the ledger.',
        authorizedCallers: [ModuleType.ORCHESTRATOR],
        rateLimit: '1000/min',
        requestSchema: {
          'claim': { type: 'string', required: true },
          'signature': { type: 'string', required: true }
        },
        responseSchema: {
          'valid': { type: 'boolean', required: true },
          'issuer': { type: 'string', required: true }
        }
      },
      {
        id: 'ep-issue',
        path: '/v1/credentials/issue',
        method: 'POST',
        description: 'Mints a new credential for an entity.',
        authorizedCallers: [ModuleType.ORCHESTRATOR],
        rateLimit: '50/min',
        requestSchema: {
          'subject': { type: 'string', required: true },
          'attributes': { type: 'object', required: true }
        },
        responseSchema: {
          'vc': { type: 'string', required: true }
        }
      }
    ],
    changelog: [
      { date: Date.now() - 86400000 * 1, note: 'Major version bump for DID spec compliance' }
    ]
  }
];

export const generateRandomEvent = (): IntegrationEvent => {
  const sources = [ModuleType.ORCHESTRATOR, ModuleType.BUILDER, ModuleType.SEER];
  const source = sources[Math.floor(Math.random() * sources.length)];
  let destination = sources[Math.floor(Math.random() * sources.length)];
  while (destination === source) {
    destination = sources[Math.floor(Math.random() * sources.length)];
  }

  // Find a matching endpoint if possible to make it realistic
  const contract = API_CONTRACTS.find(c => c.company === destination);
  const endpoint = contract?.endpoints[Math.floor(Math.random() * contract.endpoints.length)];
  
  const path = endpoint ? endpoint.path : '/v1/system/ping';
  const method = endpoint ? endpoint.method : 'GET';

  return {
    id: uuidv4(),
    timestamp: Date.now(),
    source,
    destination,
    eventType: 'API_CALL',
    endpoint: `${method} ${path}`,
    status: Math.random() > 0.95 ? 'FAILURE' : Math.random() > 0.98 ? 'THROTTLED' : 'SUCCESS',
    payloadSummary: `Payload size: ${Math.floor(Math.random() * 500)}b`,
    latency: Math.floor(Math.random() * 200) + 10,
    correlationId: uuidv4().substring(0, 8)
  };
};

export const generateWorkflowEvent = (step: WorkflowStep): IntegrationEvent | null => {
  // Map step action to a likely API call
  let destination = step.companyType;
  let source = ModuleType.ORCHESTRATOR; // Orchestrator usually drives workflow
  
  // If Orchestrator is the step owner, maybe it's calling someone else, or it's internal.
  // For visualization, let's assume if Step is "Orchestrator", it's internal processing, 
  // but if Step is "Builder", Orchestrator calls Builder.
  
  if (destination === ModuleType.ORCHESTRATOR) {
      // Maybe Orchestrator calls Seer for context?
      return null; // Don't generate external event for internal thought
  }

  const contract = API_CONTRACTS.find(c => c.company === destination);
  if (!contract) return null;

  const endpoint = contract.endpoints[0]; // Just grab first for simulation

  return {
    id: uuidv4(),
    timestamp: Date.now(),
    source,
    destination,
    eventType: 'WORKFLOW_STEP',
    endpoint: `${endpoint.method} ${endpoint.path}`,
    status: 'SUCCESS',
    payloadSummary: `Action: ${step.action}`,
    latency: Math.floor(Math.random() * 100) + 20,
    correlationId: uuidv4().substring(0, 8)
  };
};