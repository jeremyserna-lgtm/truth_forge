import { ImmunityAnalyticsState, AssumptionCluster, ImmunityBlocker, BreakthroughPath, InterventionRecommendation } from '../types';

const INITIAL_CLUSTERS: AssumptionCluster[] = [
  {
    id: 'ac-1',
    theme: 'Harmony vs. Truth',
    description: 'The assumption that addressing conflict directly will inevitably destroy critical relationships.',
    frequency: 842,
    stageCorrelation: 'Stage 3',
    breakthroughRate: 34,
    semanticSignature: 'Truth Engine: "fear of loss", "don\'t want to upset", "keeping peace"'
  },
  {
    id: 'ac-2',
    theme: 'Perfectionism as Safety',
    description: 'The assumption that any flaw or mistake will lead to catastrophic loss of status or value.',
    frequency: 615,
    stageCorrelation: 'Stage 3/4',
    breakthroughRate: 22,
    semanticSignature: 'Truth Engine: "must be right", "can\'t fail", "imposter"'
  },
  {
    id: 'ac-3',
    theme: 'Control vs. Trust',
    description: 'The assumption that others cannot be trusted to execute to standard, requiring total control.',
    frequency: 450,
    stageCorrelation: 'Stage 4',
    breakthroughRate: 45,
    semanticSignature: 'Truth Engine: "nobody else can", "if I don\'t do it", "quality drop"'
  }
];

const INITIAL_BLOCKERS: ImmunityBlocker[] = [
  {
    id: 'ib-1',
    assumptionType: 'Dependency on Validation',
    stageTransition: 'Stage 3 -> Stage 4',
    frequencyScore: 88,
    severity: 'HIGH'
  },
  {
    id: 'ib-2',
    assumptionType: 'Identity as Role',
    stageTransition: 'Stage 3/4 -> Stage 4',
    frequencyScore: 65,
    severity: 'MEDIUM'
  },
  {
    id: 'ib-3',
    assumptionType: 'Systemic Blindness',
    stageTransition: 'Stage 4 -> Stage 5',
    frequencyScore: 30,
    severity: 'HIGH'
  }
];

const INITIAL_PATHS: BreakthroughPath[] = [
  {
    id: 'bp-1',
    name: 'The Delegation Shift',
    stages: ['Stage 3', 'Stage 3/4', 'Stage 4'],
    keyAssumptionsChallenged: ['"I am the only one who cares"', '"Delegation is abandonment"'],
    avgTimeWeeks: 14,
    successCount: 120
  },
  {
    id: 'bp-2',
    name: 'Radical Candor Adoption',
    stages: ['Stage 3', 'Stage 3/4'],
    keyAssumptionsChallenged: ['"Kindness means silence"', '"Feedback hurts"'],
    avgTimeWeeks: 8,
    successCount: 350
  }
];

const INITIAL_INTERVENTIONS: InterventionRecommendation[] = [
  {
    id: 'ir-1',
    targetClusterId: 'ac-1',
    action: 'Safe-to-Fail Conflict Simulation',
    type: 'BEHAVIORAL',
    predictedImpact: 76
  },
  {
    id: 'ir-2',
    targetClusterId: 'ac-2',
    action: 'Error Celebration Rituals',
    type: 'SYSTEMIC',
    predictedImpact: 62
  },
  {
    id: 'ir-3',
    targetClusterId: 'ac-3',
    action: 'Cognitive Reframing: Trust Audit',
    type: 'COGNITIVE',
    predictedImpact: 55
  }
];

export const getImmunityAnalytics = (): ImmunityAnalyticsState => {
  return {
    clusters: INITIAL_CLUSTERS,
    blockers: INITIAL_BLOCKERS,
    paths: INITIAL_PATHS,
    interventions: INITIAL_INTERVENTIONS,
    lastUpdated: Date.now()
  };
};

export const formatImmunityForAI = (state: ImmunityAnalyticsState): string => {
  let report = "IMMUNITY PATTERN ANALYTICS (AGGREGATE ITC DATA):\n";
  
  report += "TOP ASSUMPTION CLUSTERS:\n";
  state.clusters.forEach(c => {
    report += `- ${c.theme} (Stage: ${c.stageCorrelation}, Freq: ${c.frequency}): ${c.description}\n`;
  });

  report += "\nMAJOR BLOCKERS:\n";
  state.blockers.forEach(b => {
    report += `- [${b.severity}] ${b.assumptionType} blocks ${b.stageTransition}\n`;
  });

  report += "\nSUGGESTED INTERVENTIONS:\n";
  state.interventions.forEach(i => {
    report += `- ${i.action} (${i.type}) for ${i.targetClusterId}\n`;
  });

  return report;
};