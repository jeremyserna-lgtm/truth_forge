import { FederationAnalytics, StageDistribution, TransitionEvent, GrowthEdgeCluster } from '../types';
import { v4 as uuidv4 } from 'uuid';

const INITIAL_DISTRIBUTION: StageDistribution[] = [
  { stage: 'Stage 2', count: 850, percentage: 12 },
  { stage: 'Stage 2/3', count: 1200, percentage: 18 },
  { stage: 'Stage 3', count: 2800, percentage: 41 },
  { stage: 'Stage 3/4', count: 1400, percentage: 21 },
  { stage: 'Stage 4', count: 450, percentage: 7 },
  { stage: 'Stage 5', count: 50, percentage: 1 }
];

const INITIAL_TRANSITIONS: TransitionEvent[] = [
  {
    id: 'tr-001',
    userId: 'user-alpha-92',
    fromStage: 'Stage 2',
    toStage: 'Stage 3',
    timestamp: Date.now() - 3600000 * 2,
    status: 'IN_PROGRESS',
    verifiedBySeer: true
  },
  {
    id: 'tr-002',
    userId: 'user-beta-44',
    fromStage: 'Stage 3',
    toStage: 'Stage 3/4',
    timestamp: Date.now() - 3600000 * 12,
    status: 'STALLED',
    verifiedBySeer: false
  },
  {
    id: 'tr-003',
    userId: 'user-gamma-11',
    fromStage: 'Stage 3/4',
    toStage: 'Stage 4',
    timestamp: Date.now() - 3600000 * 0.5,
    status: 'COMPLETED',
    verifiedBySeer: true
  },
  {
    id: 'tr-004',
    userId: 'user-delta-77',
    fromStage: 'Stage 3',
    toStage: 'Stage 3/4',
    timestamp: Date.now() - 3600000 * 24,
    status: 'IN_PROGRESS',
    verifiedBySeer: false
  }
];

const INITIAL_GROWTH_EDGES: GrowthEdgeCluster[] = [
  {
    id: 'ge-1',
    pattern: 'Dependency on External Validation',
    stageContext: 'Stage 3 -> 4',
    frequency: 412,
    immunityToChange: 'Commitment to maintaining harmony and avoiding conflict at all costs.',
    suggestedInterventions: [
      'Deploy "Conflict Simulation" workflow via Primitive Engine',
      'Prompt reflection on "Resentment" markers'
    ]
  },
  {
    id: 'ge-2',
    pattern: 'Instrumentalizing Relationships',
    stageContext: 'Stage 2 -> 3',
    frequency: 285,
    immunityToChange: 'Commitment to protecting own interests/agenda above collective flow.',
    suggestedInterventions: [
      'Empathy Mapping Exercises',
      'Shared Goal Visualization'
    ]
  },
  {
    id: 'ge-3',
    pattern: 'Analysis Paralysis / System Overwhelm',
    stageContext: 'Stage 4 -> 5',
    frequency: 45,
    immunityToChange: 'Commitment to certainty and complete theoretical mastery before action.',
    suggestedInterventions: [
      'Rapid Prototyping Constraints',
      'Paradox Holding Meditations'
    ]
  }
];

export const getFederationAnalytics = (): FederationAnalytics => {
  return {
    distribution: INITIAL_DISTRIBUTION,
    activeTransitions: INITIAL_TRANSITIONS,
    growthEdges: INITIAL_GROWTH_EDGES,
    lastUpdated: Date.now()
  };
};

export const formatStageAnalyticsForAI = (analytics: FederationAnalytics): string => {
  let report = "STAGE ANALYTICS & DEVELOPMENTAL DATA:\n";
  
  report += "DISTRIBUTION:\n";
  analytics.distribution.forEach(d => {
    report += `- ${d.stage}: ${d.percentage}% (${d.count} entities)\n`;
  });

  report += "\nGROWTH EDGE CLUSTERS (IMMUNITY TO CHANGE):\n";
  analytics.growthEdges.forEach(ge => {
    report += `[${ge.stageContext}] Pattern: "${ge.pattern}" (${ge.frequency} users)\n`;
    report += `  Immunity: ${ge.immunityToChange}\n`;
    report += `  Interventions: ${ge.suggestedInterventions.join(', ')}\n`;
  });

  report += "\nACTIVE TRANSITIONS:\n";
  analytics.activeTransitions.slice(0, 5).forEach(tr => {
    report += `- ${tr.userId}: ${tr.fromStage} -> ${tr.toStage} (${tr.status}, Verified: ${tr.verifiedBySeer})\n`;
  });

  return report;
};