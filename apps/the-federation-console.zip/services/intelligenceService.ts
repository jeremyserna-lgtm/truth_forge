import { FederationIntelligence, CohortGroup, TransitionRate, Insight, StageDistribution, MetricTrend } from '../types';
import { v4 as uuidv4 } from 'uuid';

const generateDistribution = (total: number, weights: number[]): StageDistribution[] => {
  const stages = ["Stage 2", "Stage 2/3", "Stage 3", "Stage 3/4", "Stage 4", "Stage 5"];
  let remaining = total;
  
  return stages.map((stage, index) => {
    const weight = weights[index] || 0.1;
    const count = index === stages.length - 1 ? remaining : Math.round(total * weight);
    remaining -= count;
    return {
      stage,
      count,
      percentage: (count / total) * 100
    };
  });
};

const COHORTS: CohortGroup[] = [
  {
    id: 'c-new',
    name: 'Onboarding (0-3m)',
    size: 1250,
    avgStage: 2.8,
    stageDistribution: generateDistribution(1250, [0.1, 0.3, 0.4, 0.15, 0.05, 0])
  },
  {
    id: 'c-mid',
    name: 'Established (3m-1y)',
    size: 3400,
    avgStage: 3.2,
    stageDistribution: generateDistribution(3400, [0.05, 0.15, 0.45, 0.25, 0.1, 0])
  },
  {
    id: 'c-vet',
    name: 'Veterans (1y+)',
    size: 1800,
    avgStage: 3.8,
    stageDistribution: generateDistribution(1800, [0, 0.05, 0.3, 0.35, 0.25, 0.05])
  }
];

const TRANSITIONS: TransitionRate[] = [
  { from: 'Stage 2', to: 'Stage 3', rate: 68, avgTimeWeeks: 12, trend: 'up' },
  { from: 'Stage 3', to: 'Stage 4', rate: 34, avgTimeWeeks: 48, trend: 'stable' },
  { from: 'Stage 4', to: 'Stage 5', rate: 8, avgTimeWeeks: 104, trend: 'down' }
];

const INSIGHTS: Insight[] = [
  {
    id: 'i-1',
    type: 'PATTERN',
    description: 'Users who engage with ITC mapping workflows progress 40% faster through Stage 3/4 transition.',
    confidence: 92,
    impact: 'HIGH',
    source: 'Primitive Engine Pattern Matcher'
  },
  {
    id: 'i-2',
    type: 'BOTTLENECK',
    description: 'Stage 3→4 transitions stalling. 65% of cohort stuck in "Socialized Mind" dependency loop.',
    confidence: 88,
    impact: 'HIGH',
    source: 'Truth Engine Synthesis'
  },
  {
    id: 'i-3',
    type: 'OPPORTUNITY',
    description: 'Cohort C (Veterans) showing increased receptivity to recursive governance models.',
    confidence: 75,
    impact: 'MEDIUM',
    source: 'Credential Atlas Signal Analysis'
  }
];

export const getFederationIntelligence = (): FederationIntelligence => {
  return {
    totalUsers: COHORTS.reduce((acc, c) => acc + c.size, 0),
    lastUpdated: Date.now(),
    cohorts: COHORTS,
    transitions: TRANSITIONS,
    insights: INSIGHTS
  };
};

export const formatIntelligenceForAI = (intel: FederationIntelligence): string => {
  let report = `FEDERATION INTELLIGENCE REPORT [K-ANONYMITY ACTIVE]:\n`;
  report += `Total Active Entities: ~${Math.round(intel.totalUsers / 100) * 100}\n\n`;
  
  report += `COHORT ANALYSIS:\n`;
  intel.cohorts.forEach(c => {
    report += `- ${c.name}: Avg Stage ${c.avgStage}\n`;
  });
  report += `\n`;

  report += `KEY INSIGHTS:\n`;
  intel.insights.forEach(i => {
    report += `[${i.type}] ${i.description} (Confidence: ${i.confidence}%)\n`;
  });

  return report;
};