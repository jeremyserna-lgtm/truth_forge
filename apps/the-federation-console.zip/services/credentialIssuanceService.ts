import { CredentialIssuanceState, CredentialRequest, CredentialSchema, IssuanceMetrics, CredentialEvidence } from '../types';

const INITIAL_SCHEMAS: CredentialSchema[] = [
  {
    id: 'cred-s3-socialized',
    name: 'Socialized Mind Integration',
    tier: 'FOUNDATION',
    description: 'Demonstrated ability to navigate complex social expectations and internalize group norms without losing cohesion.',
    criteria: ['Consistent role fulfillment', 'Empathy articulation', 'Group value alignment'],
    activeCount: 1240
  },
  {
    id: 'cred-s4-authorship',
    name: 'Self-Authoring Authority',
    tier: 'PRACTITIONER',
    description: 'Evidence of an internal decision-making system that operates independently of external validation or role expectations.',
    criteria: ['Boundary enforcement', 'Value-based decision making', 'Conflict initiation for integrity'],
    activeCount: 315
  },
  {
    id: 'cred-itc-mastery',
    name: 'Immunity to Change Mastery',
    tier: 'MASTER',
    description: 'Verified ability to map, test, and overturn deep-seated "Big Assumptions" holding back development.',
    criteria: ['Complete Immunity Map', 'Successful Assumption Test', 'Behavioral shift > 3 months'],
    activeCount: 85
  }
];

const INITIAL_REQUESTS: CredentialRequest[] = [
  {
    id: 'req-alpha-01',
    userId: 'user-732',
    schemaId: 'cred-s4-authorship',
    status: 'PENDING',
    submittedAt: Date.now() - 1000 * 60 * 60 * 2, // 2 hours ago
    confidenceScore: 88,
    evidence: [
      {
        id: 'ev-1',
        type: 'CONVERSATION',
        content: 'User explicitly declined a promotion that aligned with peer expectations but violated their internal "Creative Autonomy" value system. Stated: "I cannot lead a team where I do not believe in the product mission, regardless of the prestige."',
        sourceId: 'conv-session-992',
        timestamp: Date.now() - 1000 * 60 * 60 * 24 * 2,
        verified: false
      },
      {
        id: 'ev-2',
        type: 'REFLECTION',
        content: 'Journal Entry: "I used to feel guilty when saying no. Now I feel a quiet calm. The guilt was the old system trying to keep me safe by keeping me liked."',
        sourceId: 'ref-entry-331',
        timestamp: Date.now() - 1000 * 60 * 60 * 5,
        verified: true
      }
    ]
  },
  {
    id: 'req-beta-05',
    userId: 'user-104',
    schemaId: 'cred-itc-mastery',
    status: 'PENDING',
    submittedAt: Date.now() - 1000 * 60 * 60 * 12,
    confidenceScore: 65,
    evidence: [
      {
        id: 'ev-3',
        type: 'IMMUNITY_MAP',
        content: 'Map Complete. Goal: Delegate more. Immunity: Commitment to being the hero. Big Assumption: "If I don\'t save the day, I have no value."',
        sourceId: 'map-itc-22',
        timestamp: Date.now() - 1000 * 60 * 60 * 48,
        verified: true
      },
      {
        id: 'ev-4',
        type: 'BEHAVIORAL',
        content: 'Delegation rate increased by 15% in last sprint. However, user intervened in 2/5 delegated tasks.',
        sourceId: 'beh-metric-55',
        timestamp: Date.now() - 1000 * 60 * 60 * 1,
        verified: false
      }
    ]
  },
  {
    id: 'req-gamma-09',
    userId: 'user-899',
    schemaId: 'cred-s3-socialized',
    status: 'NEEDS_INFO',
    submittedAt: Date.now() - 1000 * 60 * 60 * 48,
    confidenceScore: 92,
    reviewerNotes: 'Evidence shows empathy, but need more data on role consistency.',
    evidence: [
      {
        id: 'ev-5',
        type: 'CONVERSATION',
        content: 'Successfully navigated team conflict by articulating the feelings of both sides.',
        sourceId: 'conv-session-112',
        timestamp: Date.now() - 1000 * 60 * 60 * 72,
        verified: true
      }
    ]
  }
];

const INITIAL_METRICS: IssuanceMetrics = {
  totalIssued: 4520,
  pendingCount: 12,
  avgVerificationTimeHrs: 4.5,
  rejectionRate: 12.8,
  recentActivity: [
    { timestamp: Date.now() - 1000 * 60 * 15, action: 'ISSUED', credential: 'Self-Authoring Authority' },
    { timestamp: Date.now() - 1000 * 60 * 45, action: 'REJECTED', credential: 'Immunity to Change Mastery' },
    { timestamp: Date.now() - 1000 * 60 * 120, action: 'ISSUED', credential: 'Socialized Mind Integration' }
  ]
};

export const getCredentialIssuanceState = (): CredentialIssuanceState => {
  return {
    requests: INITIAL_REQUESTS,
    schemas: INITIAL_SCHEMAS,
    metrics: INITIAL_METRICS,
    lastUpdated: Date.now()
  };
};

export const resolveRequest = (
  state: CredentialIssuanceState, 
  requestId: string, 
  decision: 'APPROVED' | 'REJECTED' | 'NEEDS_INFO',
  notes?: string
): CredentialIssuanceState => {
  const reqIndex = state.requests.findIndex(r => r.id === requestId);
  if (reqIndex === -1) return state;

  const updatedReq = { 
    ...state.requests[reqIndex], 
    status: decision, 
    reviewerNotes: notes 
  };

  const newRequests = [...state.requests];
  // If approved/rejected, move out of pending list logic typically, but for this UI we might keep it or filter it.
  // For demo, we update it in place.
  newRequests[reqIndex] = updatedReq;

  // Update metrics
  const newMetrics = { ...state.metrics };
  if (decision === 'APPROVED') {
    newMetrics.totalIssued += 1;
    newMetrics.recentActivity = [
      { timestamp: Date.now(), action: 'ISSUED', credential: state.schemas.find(s => s.id === updatedReq.schemaId)?.name || 'Credential' },
      ...newMetrics.recentActivity.slice(0, 4)
    ];
  } else if (decision === 'REJECTED') {
    newMetrics.recentActivity = [
      { timestamp: Date.now(), action: 'REJECTED', credential: state.schemas.find(s => s.id === updatedReq.schemaId)?.name || 'Credential' },
      ...newMetrics.recentActivity.slice(0, 4)
    ];
  }

  return {
    ...state,
    requests: newRequests,
    metrics: newMetrics,
    lastUpdated: Date.now()
  };
};

export const formatCredentialIssuanceForAI = (state: CredentialIssuanceState): string => {
  const pending = state.requests.filter(r => r.status === 'PENDING').length;
  let report = "CREDENTIAL ISSUANCE CONSOLE:\n";
  report += `Pending Verifications: ${pending}\n`;
  report += `Total Issued: ${state.metrics.totalIssued}\n`;
  report += `Recent Activity: ${state.metrics.recentActivity.map(a => `${a.action} ${a.credential}`).join(', ')}\n`;
  return report;
};