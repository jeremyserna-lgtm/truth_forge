import { Proposal, Vote, ModuleType, VoteDecision, ProposalStatus } from '../types';
import { v4 as uuidv4 } from 'uuid';

const INITIAL_PROPOSALS: Proposal[] = [
  {
    id: 'prop-102',
    title: 'Standardize Credential Schema v3.0',
    description: 'Update the core Verifiable Credential schema to align with W3C DID specification 1.0. This is a breaking change for the Credential Atlas issuer endpoint.',
    type: 'TECHNICAL',
    status: 'ACTIVE',
    proposer: ModuleType.SEER,
    created: Date.now() - 86400000 * 2,
    deadline: Date.now() + 86400000 * 5,
    requiredApprovals: 2,
    impactAnalysis: 'Affects 12 integrations. Requires 24h downtime for API migration. 94% of existing credentials will need re-issuance triggers.',
    votes: [
      { company: ModuleType.SEER, decision: 'APPROVE', rationale: 'Necessary for interoperability.', timestamp: Date.now() - 86400000 }
    ]
  },
  {
    id: 'prop-103',
    title: 'Emergency Resource Allocation: Alpha Cluster',
    description: 'Re-route 40% of Primitive Engine compute to handle unexpected spike in Stage 3 user synthesis demand.',
    type: 'CRISIS',
    status: 'ACTIVE',
    proposer: ModuleType.ORCHESTRATOR,
    created: Date.now() - 3600000 * 4,
    deadline: Date.now() + 3600000 * 20,
    requiredApprovals: 3,
    impactAnalysis: 'Temporary degradation of Cohort Analytics latency (up to 500ms). No user-facing downtime expected.',
    votes: []
  },
  {
    id: 'prop-099',
    title: 'Privacy Policy Update: K-Anonymity Threshold',
    description: 'Increase the minimum cohort size for public analytics from 50 to 100 users to further protect individual developmental data.',
    type: 'POLICY',
    status: 'PASSED',
    proposer: ModuleType.ORCHESTRATOR,
    created: Date.now() - 86400000 * 10,
    deadline: Date.now() - 86400000 * 2,
    requiredApprovals: 2,
    impactAnalysis: 'Reduces granularity of Cohort Analytics for "New User" segments. Improves compliance score by 15 points.',
    votes: [
      { company: ModuleType.ORCHESTRATOR, decision: 'APPROVE', rationale: 'Critical for trust framework.', timestamp: Date.now() - 86400000 * 9 },
      { company: ModuleType.SEER, decision: 'APPROVE', rationale: ' aligns with privacy mandates.', timestamp: Date.now() - 86400000 * 8 },
      { company: ModuleType.BUILDER, decision: 'ABSTAIN', rationale: 'No technical impact.', timestamp: Date.now() - 86400000 * 8 }
    ]
  }
];

export const getProposals = (): Proposal[] => {
  return [...INITIAL_PROPOSALS]; // In a real app, fetch from DB
};

export const castVote = (proposals: Proposal[], proposalId: string, company: ModuleType, decision: VoteDecision, rationale: string): Proposal[] => {
  return proposals.map(p => {
    if (p.id === proposalId && p.status === 'ACTIVE') {
      const existingVoteIndex = p.votes.findIndex(v => v.company === company);
      const newVote: Vote = { company, decision, rationale, timestamp: Date.now() };
      
      let newVotes = [...p.votes];
      if (existingVoteIndex >= 0) {
        newVotes[existingVoteIndex] = newVote;
      } else {
        newVotes.push(newVote);
      }

      // Check if passes
      const approvals = newVotes.filter(v => v.decision === 'APPROVE').length;
      let newStatus: ProposalStatus = p.status;
      if (approvals >= p.requiredApprovals) {
        newStatus = 'PASSED';
      }

      return { ...p, votes: newVotes, status: newStatus };
    }
    return p;
  });
};

export const formatGovernanceForAI = (proposals: Proposal[]): string => {
  const active = proposals.filter(p => p.status === 'ACTIVE');
  if (active.length === 0) return "GOVERNANCE STATUS: No active proposals pending decision.";

  let report = "GOVERNANCE STATUS - ACTIVE PROPOSALS:\n";
  active.forEach(p => {
    const votesCast = p.votes.map(v => `${v.company.substring(0,4)}:${v.decision}`).join(', ');
    report += `ID: ${p.id} | TITLE: ${p.title}\n`;
    report += `TYPE: ${p.type} | DEADLINE: ${new Date(p.deadline).toISOString()}\n`;
    report += `IMPACT: ${p.impactAnalysis}\n`;
    report += `VOTES: [${votesCast}] (Need ${p.requiredApprovals} approvals)\n\n`;
  });
  return report;
};