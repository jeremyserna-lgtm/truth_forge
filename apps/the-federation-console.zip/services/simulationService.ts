import { SimulationState, Scenario, SimulationParameter, SimulationOutcome, ScenarioCategory } from '../types';

const INITIAL_SCENARIOS: Scenario[] = [
  {
    id: 'sc-growth',
    name: 'Exponential User Influx',
    description: 'Simulate the systemic impact of 10x user growth over a 30-day period.',
    category: 'GROWTH',
    lastRun: Date.now() - 86400000 * 2,
    parameters: [
      { id: 'p-users', name: 'New Users / Day', min: 100, max: 10000, defaultValue: 1000, currentValue: 1000, unit: 'entities' },
      { id: 'p-retention', name: 'Retention Rate', min: 50, max: 100, defaultValue: 85, currentValue: 85, unit: '%' },
      { id: 'p-complexity', name: 'Avg Complexity', min: 1, max: 10, defaultValue: 4, currentValue: 4, unit: 'lvl' }
    ],
    outcomes: [
      { id: 'o-compute', name: 'Compute Load', value: 65, baseline: 65, unit: '%', change: 0, confidenceInterval: [60, 70] },
      { id: 'o-support', name: 'Support Tickets', value: 120, baseline: 120, unit: '/day', change: 0, confidenceInterval: [110, 130] },
      { id: 'o-rev', name: 'Est. Revenue', value: 45000, baseline: 45000, unit: 'USDC', change: 0, confidenceInterval: [40000, 50000] }
    ]
  },
  {
    id: 'sc-crisis',
    name: 'Truth Engine Outage',
    description: 'Model the cascading effects of a 2-hour downtime in the Orchestrator node.',
    category: 'CRISIS',
    lastRun: Date.now() - 86400000 * 7,
    parameters: [
      { id: 'p-duration', name: 'Downtime Duration', min: 1, max: 24, defaultValue: 2, currentValue: 2, unit: 'hrs' },
      { id: 'p-severity', name: 'Severity Level', min: 1, max: 5, defaultValue: 5, currentValue: 5, unit: 'sev' }
    ],
    outcomes: [
      { id: 'o-trust', name: 'Trust Index', value: 0.92, baseline: 0.92, unit: 'idx', change: 0, confidenceInterval: [0.91, 0.93] },
      { id: 'o-churn', name: 'Instant Churn', value: 0.5, baseline: 0.5, unit: '%', change: 0, confidenceInterval: [0.2, 0.8] }
    ]
  },
  {
    id: 'sc-resource',
    name: 'Budget Contraction',
    description: 'Analyze impact of reducing compute budget by 30%.',
    category: 'RESOURCE',
    lastRun: Date.now() - 86400000 * 14,
    parameters: [
      { id: 'p-budget', name: 'Budget Cut', min: 0, max: 80, defaultValue: 30, currentValue: 30, unit: '%' },
      { id: 'p-effic', name: 'Efficiency Gain', min: 0, max: 20, defaultValue: 5, currentValue: 5, unit: '%' }
    ],
    outcomes: [
      { id: 'o-latency', name: 'Avg Latency', value: 120, baseline: 120, unit: 'ms', change: 0, confidenceInterval: [110, 130] },
      { id: 'o-queue', name: 'Queue Depth', value: 15, baseline: 15, unit: 'reqs', change: 0, confidenceInterval: [10, 20] }
    ]
  }
];

export const getSimulationState = (): SimulationState => {
  return {
    activeScenarioId: 'sc-growth',
    scenarios: INITIAL_SCENARIOS,
    isRunning: false
  };
};

// Deterministic simulation logic for demo purposes
export const runSimulationLogic = (scenario: Scenario): Scenario => {
  const newOutcomes = scenario.outcomes.map(outcome => {
    let multiplier = 1;
    
    // Growth Logic
    if (scenario.id === 'sc-growth') {
      const users = scenario.parameters.find(p => p.id === 'p-users')?.currentValue || 1000;
      const complexity = scenario.parameters.find(p => p.id === 'p-complexity')?.currentValue || 4;
      
      // Compute Load scales with users * complexity
      if (outcome.id === 'o-compute') {
        const load = (users / 1000) * (complexity / 4) * 65; 
        multiplier = Math.min(100, Math.max(10, load)) / 65;
      }
      // Support scales with users
      if (outcome.id === 'o-support') {
         const tickets = (users / 1000) * 120;
         multiplier = tickets / 120;
      }
      // Revenue scales with users
      if (outcome.id === 'o-rev') {
        const rev = (users / 1000) * 45000;
        multiplier = rev / 45000;
      }
    }

    // Crisis Logic
    if (scenario.id === 'sc-crisis') {
      const duration = scenario.parameters.find(p => p.id === 'p-duration')?.currentValue || 2;
      
      // Trust drops as duration increases
      if (outcome.id === 'o-trust') {
        const decay = duration * 0.05;
        multiplier = Math.max(0.5, 1 - decay);
      }
      // Churn increases with duration
      if (outcome.id === 'o-churn') {
        const churn = duration * 0.5;
        multiplier = churn / 0.5;
      }
    }

    // Resource Logic
    if (scenario.id === 'sc-resource') {
      const cut = scenario.parameters.find(p => p.id === 'p-budget')?.currentValue || 0;
      
      // Latency increases as budget is cut (inverse relationship modeled simply)
      if (outcome.id === 'o-latency') {
        const lat = 120 * (1 + (cut / 100));
        multiplier = lat / 120;
      }
    }

    const newValue = outcome.baseline * multiplier;
    const change = ((newValue - outcome.baseline) / outcome.baseline) * 100;
    
    // Simulate confidence interval widening as change increases
    const variance = Math.abs(change) * 0.2; // 20% variance of the change
    
    return {
      ...outcome,
      value: Number(newValue.toFixed(2)),
      change: Number(change.toFixed(1)),
      confidenceInterval: [
        Number((newValue - (newValue * variance / 100)).toFixed(2)), 
        Number((newValue + (newValue * variance / 100)).toFixed(2))
      ] as [number, number]
    };
  });

  return {
    ...scenario,
    outcomes: newOutcomes,
    lastRun: Date.now()
  };
};

export const formatSimulationForAI = (state: SimulationState): string => {
  const active = state.scenarios.find(s => s.id === state.activeScenarioId);
  if (!active) return "SIMULATION MODULE: Idle.";

  let report = `SIMULATION ACTIVE: ${active.name} (${active.category})\n`;
  report += `PARAMETERS:\n`;
  active.parameters.forEach(p => {
    report += `- ${p.name}: ${p.currentValue}${p.unit} (Default: ${p.defaultValue})\n`;
  });
  report += `PREDICTED OUTCOMES:\n`;
  active.outcomes.forEach(o => {
    const sign = o.change > 0 ? '+' : '';
    report += `- ${o.name}: ${o.value}${o.unit} (${sign}${o.change}% vs baseline)\n`;
  });
  return report;
};