import { WorkflowTemplate, WorkflowExecution, WorkflowStatus, StepStatus, ModuleType, WorkflowStep } from '../types';
import { v4 as uuidv4 } from 'uuid';

export const WORKFLOW_TEMPLATES: WorkflowTemplate[] = [
  {
    id: 'wf-stage-transition',
    name: 'Stage Transition Ceremony',
    description: 'Orchestrates the evolution of a user entity from one developmental stage to the next.',
    steps: [
      { id: 's1', order: 0, companyType: ModuleType.BUILDER, action: 'Detect Cognitive Threshold', approvalRequired: false },
      { id: 's2', order: 1, companyType: ModuleType.ORCHESTRATOR, action: 'Synthesize Stage Reflection', approvalRequired: false },
      { id: 's3', order: 2, companyType: ModuleType.SEER, action: 'Issue Evolutionary Credential', approvalRequired: true },
      { id: 's4', order: 3, companyType: ModuleType.ORCHESTRATOR, action: 'Notify Nexus Portal', approvalRequired: false }
    ]
  },
  {
    id: 'wf-crisis-response',
    name: 'Crisis Response Protocol',
    description: 'Rapid escalation path for detected systemic anomalies or user distress signals.',
    steps: [
      { id: 'c1', order: 0, companyType: ModuleType.SEER, action: 'Verify Anomaly Signature', approvalRequired: false },
      { id: 'c2', order: 1, companyType: ModuleType.ORCHESTRATOR, action: 'Assess Severity & Impact', approvalRequired: false },
      { id: 'c3', order: 2, companyType: ModuleType.BUILDER, action: 'Deploy Mitigation Pattern', approvalRequired: true },
      { id: 'c4', order: 3, companyType: ModuleType.ORCHESTRATOR, action: 'Generate Incident Report', approvalRequired: false }
    ]
  },
  {
    id: 'wf-new-user',
    name: 'New Entity Onboarding',
    description: 'Initialization sequence for new federation participants.',
    steps: [
      { id: 'n1', order: 0, companyType: ModuleType.SEER, action: 'Identity Verification', approvalRequired: false },
      { id: 'n2', order: 1, companyType: ModuleType.BUILDER, action: 'Allocate Primitive Workspace', approvalRequired: false },
      { id: 'n3', order: 2, companyType: ModuleType.ORCHESTRATOR, action: 'Initialize Context Graph', approvalRequired: false }
    ]
  }
];

export const createWorkflowExecution = (templateId: string): WorkflowExecution | null => {
  const template = WORKFLOW_TEMPLATES.find(t => t.id === templateId);
  if (!template) return null;

  return {
    id: uuidv4(),
    templateId: template.id,
    name: `${template.name} - ${new Date().toLocaleTimeString()}`,
    status: 'RUNNING', // Auto-start
    currentStepIndex: 0,
    startedAt: Date.now(),
    steps: template.steps.map(s => ({
      ...s,
      status: 'PENDING',
      logs: []
    }))
  };
};

export const tickWorkflow = (execution: WorkflowExecution): { updated: WorkflowExecution, changed: boolean } => {
  if (execution.status === 'COMPLETED' || execution.status === 'FAILED') {
    return { updated: execution, changed: false };
  }

  const currentStep = execution.steps[execution.currentStepIndex];
  
  // If step is pending, start it
  if (currentStep.status === 'PENDING') {
    const updatedStep: WorkflowStep = { 
      ...currentStep, 
      status: 'RUNNING', 
      startTime: Date.now(),
      logs: [`Started execution at ${new Date().toLocaleTimeString()}`] 
    };
    const newSteps = [...execution.steps];
    newSteps[execution.currentStepIndex] = updatedStep;
    
    return {
      updated: { ...execution, steps: newSteps, status: 'RUNNING' },
      changed: true
    };
  }

  // If running, simulate progress or completion
  if (currentStep.status === 'RUNNING') {
    // Random chance to finish tick
    if (Math.random() > 0.7) {
      // Check for approval
      if (currentStep.approvalRequired) {
        const updatedStep: WorkflowStep = { 
          ...currentStep, 
          status: 'WAITING_APPROVAL',
          logs: [...currentStep.logs, 'Paused for manual verification.']
        };
        const newSteps = [...execution.steps];
        newSteps[execution.currentStepIndex] = updatedStep;
        return {
          updated: { ...execution, steps: newSteps, status: 'WAITING_APPROVAL' },
          changed: true
        };
      } else {
        // Complete step
        const updatedStep: WorkflowStep = { 
          ...currentStep, 
          status: 'COMPLETED', 
          endTime: Date.now(),
          logs: [...currentStep.logs, 'Completed successfully.']
        };
        const newSteps = [...execution.steps];
        newSteps[execution.currentStepIndex] = updatedStep;

        // Advance to next step or finish workflow
        const nextIndex = execution.currentStepIndex + 1;
        if (nextIndex >= newSteps.length) {
          return {
            updated: { ...execution, steps: newSteps, status: 'COMPLETED', completedAt: Date.now() },
            changed: true
          };
        } else {
          return {
            updated: { ...execution, steps: newSteps, currentStepIndex: nextIndex },
            changed: true
          };
        }
      }
    }
  }

  return { updated: execution, changed: false };
};

export const approveStep = (execution: WorkflowExecution): WorkflowExecution => {
  if (execution.status !== 'WAITING_APPROVAL') return execution;

  const currentStep = execution.steps[execution.currentStepIndex];
  if (currentStep.status !== 'WAITING_APPROVAL') return execution;

  const updatedStep: WorkflowStep = {
    ...currentStep,
    status: 'COMPLETED',
    endTime: Date.now(),
    logs: [...currentStep.logs, 'Manual approval received.', 'Step completed.']
  };

  const newSteps = [...execution.steps];
  newSteps[execution.currentStepIndex] = updatedStep;

  const nextIndex = execution.currentStepIndex + 1;
  if (nextIndex >= newSteps.length) {
    return { ...execution, steps: newSteps, status: 'COMPLETED', completedAt: Date.now() };
  } else {
    return { ...execution, steps: newSteps, currentStepIndex: nextIndex, status: 'RUNNING' };
  }
};