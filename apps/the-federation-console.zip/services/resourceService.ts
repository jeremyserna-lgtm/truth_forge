import { FederatedResource, ResourceRequest, ResourceType, ModuleType, AllocationState } from '../types';
import { v4 as uuidv4 } from 'uuid';

const INITIAL_RESOURCES: FederatedResource[] = [
  {
    id: 'res-compute',
    type: ResourceType.COMPUTE,
    name: 'Federation Compute Grid',
    totalCapacity: 1000000,
    allocated: 650000,
    unit: 'TPU-h',
    utilization: 65,
    history: [60, 62, 65, 64, 68, 65, 65, 66, 65, 65]
  },
  {
    id: 'res-support',
    type: ResourceType.SUPPORT,
    name: 'Human Support Pool',
    totalCapacity: 2000,
    allocated: 1850,
    unit: 'hrs/wk',
    utilization: 92.5,
    history: [88, 89, 90, 91, 93, 94, 95, 94, 93, 92.5]
  },
  {
    id: 'res-dev',
    type: ResourceType.DEVELOPMENT,
    name: 'Core Engineering',
    totalCapacity: 800,
    allocated: 780,
    unit: 'story-pts',
    utilization: 97.5,
    history: [95, 95, 96, 96, 97, 98, 98, 97, 97, 97.5]
  },
  {
    id: 'res-cap',
    type: ResourceType.CAPITAL,
    name: 'Innovation Fund',
    totalCapacity: 5000000,
    allocated: 1200000,
    unit: 'USDC',
    utilization: 24,
    history: [20, 20, 21, 22, 22, 23, 23, 24, 24, 24]
  }
];

const INITIAL_REQUESTS: ResourceRequest[] = [
  {
    id: 'req-1',
    requester: ModuleType.BUILDER,
    resourceType: ResourceType.COMPUTE,
    amount: 50000,
    justification: 'Scaling Primitive Engine for anticipated Stage 3 user influx.',
    priority: 'HIGH',
    status: 'PENDING',
    timestamp: Date.now() - 3600000 * 2
  },
  {
    id: 'req-2',
    requester: ModuleType.SEER,
    resourceType: ResourceType.DEVELOPMENT,
    amount: 80,
    justification: 'W3C DID schema migration support.',
    priority: 'MEDIUM',
    status: 'PENDING',
    timestamp: Date.now() - 3600000 * 5
  },
  {
    id: 'req-3',
    requester: ModuleType.BUILDER,
    resourceType: ResourceType.SUPPORT,
    amount: 200,
    justification: 'Community moderation for new onboarding cohort.',
    priority: 'CRITICAL',
    status: 'PENDING',
    timestamp: Date.now() - 3600000 * 1
  }
];

export const getResourceState = (): AllocationState => {
  return {
    resources: INITIAL_RESOURCES,
    requests: INITIAL_REQUESTS,
    lastUpdated: Date.now()
  };
};

export const updateResourceState = (
  currentState: AllocationState, 
  action: { type: 'APPROVE' | 'REJECT', requestId: string }
): AllocationState => {
  const requestIndex = currentState.requests.findIndex(r => r.id === action.requestId);
  if (requestIndex === -1) return currentState;

  const request = currentState.requests[requestIndex];
  const newRequests = [...currentState.requests];
  const newResources = [...currentState.resources];

  if (action.type === 'APPROVE') {
    newRequests[requestIndex] = { ...request, status: 'APPROVED' };
    
    // Update resource allocation
    const resIndex = newResources.findIndex(r => r.type === request.resourceType);
    if (resIndex !== -1) {
      const res = newResources[resIndex];
      const newAllocated = res.allocated + request.amount;
      const newUtilization = (newAllocated / res.totalCapacity) * 100;
      
      newResources[resIndex] = {
        ...res,
        allocated: newAllocated,
        utilization: newUtilization,
        history: [...res.history.slice(1), newUtilization]
      };
    }
  } else {
    newRequests[requestIndex] = { ...request, status: 'REJECTED' };
  }

  return {
    resources: newResources,
    requests: newRequests,
    lastUpdated: Date.now()
  };
};

export const formatResourcesForAI = (state: AllocationState): string => {
  let report = "RESOURCE ALLOCATION REPORT:\n";
  state.resources.forEach(r => {
    report += `${r.name} (${r.type}): ${r.utilization.toFixed(1)}% Utilized (${r.allocated}/${r.totalCapacity} ${r.unit})\n`;
  });
  
  const pending = state.requests.filter(r => r.status === 'PENDING');
  if (pending.length > 0) {
    report += `\nPENDING REQUESTS:\n`;
    pending.forEach(r => {
      report += `- [${r.priority}] ${r.requester} asks for ${r.amount} ${r.resourceType}: "${r.justification}"\n`;
    });
  }
  
  return report;
};