import { ReflectionAnalyticsState, FederationShiftTrend, ShiftVelocityMetric, GrowthCohort, ReflectionCorrelation, ModuleType } from '../types';

const INITIAL_TRENDS: FederationShiftTrend[] = [
  {
    id: 'tr-1',
    shiftType: 'Subject to Validation -> Object to Validation',
    frequency: 342,
    avgTimeWeeks: 18,
    trend: 'up',
    stageContext: 'Stage 3'
  },
  {
    id: 'tr-2',
    shiftType: 'Subject to Control -> Object to Control',
    frequency: 156,
    avgTimeWeeks: 24,
    trend: 'stable',
    stageContext: 'Stage 4'
  },
  {
    id: 'tr-3',
    shiftType: 'Role Identification -> Role Authorship',
    frequency: 289,
    avgTimeWeeks: 32,
    trend: 'up',
    stageContext: 'Stage 3/4'
  }
];

const INITIAL_VELOCITY: ShiftVelocityMetric[] = [
  { id: 'v1', userId: 'user-732', recentShifts: 2, momentum: 85, status: 'ACCELERATING', primaryDriver: 'Immunity Map' },
  { id: 'v2', userId: 'user-891', recentShifts: 1, momentum: 65, status: 'STEADY', primaryDriver: 'Conversation' },
  { id: 'v3', userId: 'user-104', recentShifts: 0, momentum: 20, status: 'STALLED', primaryDriver: 'None' },
  { id: 'v4', userId: 'user-555', recentShifts: 3, momentum: 94, status: 'ACCELERATING', primaryDriver: 'Crisis Workflow' },
  { id: 'v5', userId: 'user-221', recentShifts: 1, momentum: 60, status: 'STEADY', primaryDriver: 'Conversation' }
];

const INITIAL_COHORTS: GrowthCohort[] = [
  {
    id: 'gc-1',
    name: 'Rapid Integrators',
    trajectory: 'High velocity movement through Stage 3/4 transition zone.',
    size: 450,
    commonThemes: ['Authority', 'Boundaries', 'Feedback'],
    avgVelocity: 82
  },
  {
    id: 'gc-2',
    name: 'Deep Processors',
    trajectory: 'Slower, stable integration of Stage 4 complexity.',
    size: 1200,
    commonThemes: ['Systemic View', 'Paradox', 'Delegation'],
    avgVelocity: 45
  },
  {
    id: 'gc-3',
    name: 'Stalled Vectors',
    trajectory: 'High resistance at Stage 3 Immunity points.',
    size: 850,
    commonThemes: ['Conflict Avoidance', 'Belonging', 'Safety'],
    avgVelocity: 15
  }
];

const INITIAL_CORRELATIONS: ReflectionCorrelation[] = [
  {
    id: 'cor-1',
    sourceModule: ModuleType.IMMUNITY_PATTERNS,
    eventType: 'Map Completion',
    shiftType: 'Subject -> Object (Assumption)',
    correlationStrength: 88
  },
  {
    id: 'cor-2',
    sourceModule: ModuleType.CONVERSATION,
    eventType: 'High Depth Dialogue',
    shiftType: 'Subject -> Object (Emotion)',
    correlationStrength: 76
  },
  {
    id: 'cor-3',
    sourceModule: ModuleType.WORKFLOW,
    eventType: 'Crisis Response',
    shiftType: 'Adaptive Capacity Increase',
    correlationStrength: 62
  }
];

const INITIAL_THEMES = [
  { word: 'Authority', weight: 95 },
  { word: 'Boundaries', weight: 88 },
  { word: 'Conflict', weight: 82 },
  { word: 'Trust', weight: 75 },
  { word: 'Identity', weight: 70 },
  { word: 'Failure', weight: 65 },
  { word: 'Control', weight: 60 },
  { word: 'Belonging', weight: 58 },
  { word: 'Empathy', weight: 55 },
  { word: 'Role', weight: 50 }
];

export const getReflectionAnalytics = (): ReflectionAnalyticsState => {
  return {
    trends: INITIAL_TRENDS,
    velocity: INITIAL_VELOCITY,
    cohorts: INITIAL_COHORTS,
    correlations: INITIAL_CORRELATIONS,
    themes: INITIAL_THEMES,
    lastUpdated: Date.now()
  };
};

export const formatReflectionForAI = (state: ReflectionAnalyticsState): string => {
  let report = "REFLECTION INSIGHTS (SUBJECT-OBJECT SHIFT DYNAMICS):\n";
  
  report += "SHIFT TRENDS:\n";
  state.trends.forEach(t => {
    report += `- ${t.shiftType}: ${t.frequency} shifts (Avg ${t.avgTimeWeeks} wks) [${t.trend.toUpperCase()}]\n`;
  });

  report += "\nGROWTH COHORTS:\n";
  state.cohorts.forEach(c => {
    report += `- ${c.name} (${c.size} users): ${c.trajectory} (Vel: ${c.avgVelocity})\n`;
  });

  report += "\nKEY CORRELATIONS:\n";
  state.correlations.forEach(c => {
    report += `- ${c.sourceModule} -> ${c.shiftType}: ${c.correlationStrength}% strength\n`;
  });

  return report;
};