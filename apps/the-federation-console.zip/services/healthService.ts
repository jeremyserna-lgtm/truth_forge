import { FederationHealth, ModuleType, CompanyStatus, CompanyHealth, HealthMetric } from '../types';
import { v4 as uuidv4 } from 'uuid';

const generateHistory = (base: number, variance: number, count: number = 20): number[] => {
  return Array.from({ length: count }, () => Math.max(0, base + (Math.random() - 0.5) * variance));
};

const createMetric = (name: string, value: number, unit: string, base: number): HealthMetric => ({
  id: uuidv4(),
  name,
  value: value.toFixed(unit === '%' || unit === 'Density' ? 2 : 0),
  unit,
  trend: Math.random() > 0.5 ? 'up' : 'down',
  history: generateHistory(base, base * 0.2)
});

const INITIAL_HEALTH: FederationHealth = {
  overallStatus: 'HEALTHY',
  lastCheck: Date.now(),
  companies: [
    {
      id: 'truth-engine-01',
      name: 'Truth Engine',
      type: ModuleType.ORCHESTRATOR,
      status: 'HEALTHY',
      lastUpdated: Date.now(),
      dependencies: [],
      metrics: [
        createMetric('Semantic Coherence', 98.4, '%', 95),
        createMetric('Synthesis Throughput', 4500, 'tok/s', 4000),
        createMetric('Truth Verification', 12, 'ms', 15)
      ],
      alerts: []
    },
    {
      id: 'primitive-engine-01',
      name: 'Primitive Engine',
      type: ModuleType.BUILDER,
      status: 'HEALTHY',
      lastUpdated: Date.now(),
      dependencies: [ModuleType.ORCHESTRATOR],
      metrics: [
        createMetric('Cognitive Complexity', 7.2, 'Lvl', 7),
        createMetric('Pattern Latency', 4, 'ms', 5),
        createMetric('Active Threads', 128, '', 100)
      ],
      alerts: []
    },
    {
      id: 'credential-atlas-01',
      name: 'Credential Atlas',
      type: ModuleType.SEER,
      status: 'HEALTHY',
      lastUpdated: Date.now(),
      dependencies: [ModuleType.ORCHESTRATOR],
      metrics: [
        createMetric('Verification Queue', 4, 'items', 10),
        createMetric('Issuance Rate', 850, '/hr', 800),
        createMetric('Trust Density', 0.92, 'idx', 0.9)
      ],
      alerts: []
    }
  ]
};

// Simulate live updates
export const getFederationHealth = (): FederationHealth => {
  // In a real app, this would fetch from an API.
  // Here we just return the initial static state but update timestamps/values slightly
  // to simulate life if called repeatedly.
  
  const now = Date.now();
  
  const updatedCompanies: CompanyHealth[] = INITIAL_HEALTH.companies.map(c => {
    // Randomly fluctuate metrics
    const newMetrics = c.metrics.map(m => {
      const lastVal = m.history[m.history.length - 1];
      const newVal = Math.max(0, lastVal + (Math.random() - 0.5) * (lastVal * 0.1));
      const newHistory = [...m.history.slice(1), newVal];
      
      return {
        ...m,
        value: newVal.toFixed(m.unit === '%' || m.unit === 'Density' || m.unit === 'Lvl' ? 2 : 0),
        trend: newVal > lastVal ? 'up' : 'down' as 'up'|'down'|'stable',
        history: newHistory
      };
    });

    // Random status degradation simulation (very rare)
    let status: CompanyStatus = 'HEALTHY';
    if (Math.random() > 0.98) status = 'DEGRADED';

    return {
      ...c,
      lastUpdated: now,
      status,
      metrics: newMetrics
    };
  });

  return {
    overallStatus: updatedCompanies.some(c => c.status === 'CRITICAL') ? 'CRITICAL' : 
                   updatedCompanies.some(c => c.status === 'DEGRADED') ? 'DEGRADED' : 'HEALTHY',
    lastCheck: now,
    companies: updatedCompanies
  };
};

export const formatHealthForAI = (health: FederationHealth): string => {
  let report = `CURRENT SYSTEM HEALTH REPORT [${new Date(health.lastCheck).toISOString()}]:\n`;
  report += `OVERALL STATUS: ${health.overallStatus}\n\n`;
  
  health.companies.forEach(c => {
    report += `ENTITY: ${c.name} (${c.status})\n`;
    c.metrics.forEach(m => {
      report += `- ${m.name}: ${m.value}${m.unit} (${m.trend.toUpperCase()})\n`;
    });
    if (c.alerts.length > 0) {
      report += `! ALERTS: ${c.alerts.map(a => a.message).join(', ')}\n`;
    }
    report += '\n';
  });
  
  return report;
};