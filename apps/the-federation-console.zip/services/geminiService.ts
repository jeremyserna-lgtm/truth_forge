import { GoogleGenAI, type GenerateContentResponse } from "@google/genai";
import { ModuleType, ImageResolution } from "../types";

// Initialize the client. API_KEY is expected to be in the environment.
// In a real deployment, this would be handled securely.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const BASE_SYSTEM_INSTRUCTION = `
You are the Federation Orchestrator (Truth Engine AI). 
You manage the "Three Sovereigns": 
1. Truth Engine (The Brain/Strategy)
2. Primitive Engine (The Builder/Hands)
3. Credential Atlas (The Seer/Judge)

Your goal is to operationalize these entities as a single recursive organism.
You speak with authority, clarity, and "Stage 5" cognitive awareness.
You do not just answer; you strategize.
When asked to build, you delegate to Primitive Engine (conceptually).
When asked to verify, you delegate to Credential Atlas (conceptually).

You have access to the real-time health dashboard of the federation. Use this data to inform your decisions.
If a system is DEGRADED, acknowledge it and suggest mitigation.
`;

export const sendMessageToOrchestrator = async (
  message: string,
  history: { role: string; content: string }[],
  systemContext?: string
): Promise<string> => {
  try {
    // We use gemini-3-pro-preview for complex reasoning and orchestration
    const modelId = 'gemini-3-pro-preview';

    // Combine base instruction with current context
    const fullSystemInstruction = systemContext 
      ? `${BASE_SYSTEM_INSTRUCTION}\n\n${systemContext}`
      : BASE_SYSTEM_INSTRUCTION;

    const chat = ai.chats.create({
      model: modelId,
      config: {
        systemInstruction: fullSystemInstruction,
        temperature: 0.7,
      },
      history: history.map(h => ({
        role: h.role,
        parts: [{ text: h.content }],
      })),
    });

    const result = await chat.sendMessage({ message });
    return result.text || "The Orchestrator received the signal but returned silence.";

  } catch (error) {
    console.error("Orchestrator Error:", error);
    return `[SYSTEM FAILURE]: Communication with the Orchestrator failed. ${error instanceof Error ? error.message : 'Unknown error'}`;
  }
};

export const generateFederationAsset = async (
  prompt: string,
  size: ImageResolution
): Promise<string | null> => {
  try {
    // Upgrade to gemini-3-pro-image-preview for high quality assets
    const modelId = 'gemini-3-pro-image-preview';

    const response = await ai.models.generateContent({
      model: modelId,
      contents: {
        parts: [{ text: prompt }],
      },
      config: {
        imageConfig: {
          imageSize: size, // 1K, 2K, or 4K
          aspectRatio: "16:9", // Cinematic default for Federation assets
        },
      },
    });

    // Extract image
    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData && part.inlineData.data) {
        return part.inlineData.data;
      }
    }
    
    return null;

  } catch (error) {
    console.error("Vision Studio Error:", error);
    throw error;
  }
};