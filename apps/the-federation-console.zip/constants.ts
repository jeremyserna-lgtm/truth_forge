export const APP_NAME = "Federation Console";
export const VERSION = "1.0.0";