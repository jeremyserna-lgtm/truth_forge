import React from 'react';
import { ReflectionAnalyticsState, SystemLog, ModuleType } from '../types';

interface ReflectionInsightsProps {
  state: ReflectionAnalyticsState;
  addLog: (log: SystemLog) => void;
}

const ReflectionInsights: React.FC<ReflectionInsightsProps> = ({ state }) => {

  const getMomentumColor = (mom: number) => {
    if (mom >= 80) return 'text-rose-500';
    if (mom >= 50) return 'text-orange-500';
    return 'text-blue-500';
  };

  const getStatusBg = (status: string) => {
    switch (status) {
      case 'ACCELERATING': return 'bg-rose-900/30 border-rose-500/50 text-rose-300';
      case 'STEADY': return 'bg-blue-900/30 border-blue-500/50 text-blue-300';
      default: return 'bg-gray-800 border-gray-600 text-gray-400';
    }
  };

  return (
    <div className="h-full flex flex-col p-6 bg-surface/20 overflow-y-auto">
      {/* Header */}
      <div className="flex justify-between items-end mb-8 border-b border-highlight/30 pb-4">
        <div>
           <h2 className="text-2xl font-light text-white tracking-tight flex items-center gap-3">
            <svg className="w-6 h-6 text-rose-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            Reflection Insights
          </h2>
          <div className="text-xs text-gray-500 font-mono mt-1">
            SUBJECT-OBJECT SHIFT DYNAMICS & GROWTH VELOCITY
          </div>
        </div>
        <div className="text-right flex gap-6">
           <div>
             <div className="text-[10px] text-gray-500 font-mono uppercase">System Velocity</div>
             <div className="text-2xl font-mono font-bold text-rose-400 tracking-tighter">
               {Math.round(state.velocity.reduce((acc, v) => acc + v.momentum, 0) / state.velocity.length)}/100
             </div>
           </div>
           <div>
             <div className="text-[10px] text-gray-500 font-mono uppercase">Shift Events</div>
             <div className="text-2xl font-mono font-bold text-white tracking-tighter">
               {state.trends.reduce((acc, t) => acc + t.frequency, 0)}
             </div>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1">
        
        {/* Left Column: Shift Trends */}
        <div className="space-y-6">
          <div className="bg-void border border-highlight/30 rounded-lg p-5">
            <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-4 flex items-center gap-2">
              Active Shift Patterns
            </h3>
            <div className="space-y-4">
              {state.trends.map(trend => (
                <div key={trend.id} className="relative pl-3 border-l-2 border-rose-500/30">
                  <div className="flex justify-between items-start mb-1">
                    <span className="text-[10px] font-bold text-rose-300 bg-rose-900/20 px-1.5 rounded">{trend.stageContext}</span>
                    <span className={`text-[10px] uppercase font-mono ${trend.trend === 'up' ? 'text-green-500' : 'text-gray-500'}`}>
                      {trend.trend}
                    </span>
                  </div>
                  <div className="text-xs text-white font-medium mb-1">{trend.shiftType}</div>
                  <div className="flex justify-between items-end">
                    <div className="text-[10px] text-gray-500 font-mono">{trend.frequency} Detected</div>
                    <div className="text-[10px] text-gray-500">Avg Time: {trend.avgTimeWeeks}wks</div>
                  </div>
                  {/* Frequency Bar */}
                  <div className="mt-2 h-1 w-full bg-gray-800 rounded-full overflow-hidden">
                    <div className="h-full bg-rose-600" style={{ width: `${Math.min(100, trend.frequency / 3)}%` }}></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-surface/10 border border-highlight/30 rounded-lg p-5">
            <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-4">Reflection Theme Cloud</h3>
            <div className="flex flex-wrap gap-2 justify-center">
              {state.themes.map((theme, i) => {
                const sizeClass = theme.weight > 80 ? 'text-lg' : theme.weight > 60 ? 'text-sm' : 'text-xs';
                const opacity = theme.weight / 100;
                return (
                  <span 
                    key={i} 
                    className={`font-mono ${sizeClass} text-rose-200 transition-all hover:text-white cursor-default`}
                    style={{ opacity: Math.max(0.3, opacity) }}
                  >
                    {theme.word}
                  </span>
                );
              })}
            </div>
          </div>
        </div>

        {/* Middle Column: Velocity & Cohorts */}
        <div className="space-y-6">
           <div className="bg-void border border-highlight/30 rounded-lg p-5">
             <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-4">Growth Arc Cohorts</h3>
             <div className="space-y-3">
               {state.cohorts.map(cohort => (
                 <div key={cohort.id} className="bg-surface/20 p-3 rounded border border-highlight/20 hover:border-rose-500/30 transition-colors">
                   <div className="flex justify-between items-center mb-1">
                     <span className="text-xs font-bold text-white">{cohort.name}</span>
                     <span className={`text-[10px] font-mono ${getMomentumColor(cohort.avgVelocity)}`}>
                       VEL: {cohort.avgVelocity}
                     </span>
                   </div>
                   <p className="text-[10px] text-gray-400 mb-2 leading-tight">{cohort.trajectory}</p>
                   <div className="flex flex-wrap gap-1">
                     {cohort.commonThemes.map((th, i) => (
                       <span key={i} className="text-[9px] px-1 bg-black rounded text-gray-500">{th}</span>
                     ))}
                   </div>
                 </div>
               ))}
             </div>
           </div>

           <div className="bg-surface/10 border border-highlight/30 rounded-lg p-5">
              <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-4">Individual Velocity (Sample)</h3>
              <div className="space-y-2">
                 {state.velocity.map(vel => (
                   <div key={vel.id} className="flex items-center justify-between text-xs">
                     <span className="text-gray-500 font-mono">{vel.userId}</span>
                     <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${getStatusBg(vel.status)}`}>
                       {vel.status}
                     </span>
                     <span className={`font-mono font-bold w-8 text-right ${getMomentumColor(vel.momentum)}`}>{vel.momentum}</span>
                   </div>
                 ))}
              </div>
           </div>
        </div>

        {/* Right Column: Correlations & Systemics */}
        <div className="space-y-6">
           <div className="bg-rose-900/5 border border-rose-900/20 rounded-lg p-5 h-full flex flex-col">
              <h3 className="text-xs font-mono font-bold text-rose-400 uppercase tracking-wider mb-6 flex items-center gap-2">
                 <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" /></svg>
                 System Correlations
              </h3>
              
              <div className="flex-1 space-y-5 overflow-y-auto">
                 {state.correlations.map(cor => (
                    <div key={cor.id} className="relative">
                       <div className="flex justify-between text-[10px] text-gray-400 mb-1">
                          <span className="uppercase">{cor.sourceModule}</span>
                          <span className="font-mono">{cor.correlationStrength}% Correlation</span>
                       </div>
                       <div className="bg-black/40 p-3 rounded border border-rose-500/20">
                          <div className="text-[10px] text-rose-300 font-bold mb-1">EVENT: {cor.eventType}</div>
                          <div className="flex justify-center my-1 text-gray-600">
                             <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" /></svg>
                          </div>
                          <div className="text-xs text-white mb-0.5">{cor.shiftType}</div>
                       </div>
                    </div>
                 ))}
              </div>

              <div className="mt-4 pt-4 border-t border-rose-500/20 text-[10px] text-rose-400/70 text-center font-mono">
                 Credential Atlas: Shift Verification
                 <br/>
                 Truth Engine: Theme Extraction
              </div>
           </div>
        </div>

      </div>
    </div>
  );
};

export default ReflectionInsights;