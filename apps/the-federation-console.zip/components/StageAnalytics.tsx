import React from 'react';
import { FederationAnalytics, SystemLog, ModuleType } from '../types';

interface StageAnalyticsProps {
  analytics: FederationAnalytics;
  addLog: (log: SystemLog) => void;
}

const StageAnalytics: React.FC<StageAnalyticsProps> = ({ analytics }) => {
  
  const getStageColor = (stage: string) => {
    if (stage.includes('2')) return 'bg-red-500 text-red-100';
    if (stage.includes('3')) return 'bg-amber-500 text-amber-100';
    if (stage.includes('4')) return 'bg-green-500 text-green-100';
    if (stage.includes('5')) return 'bg-blue-500 text-blue-100';
    return 'bg-gray-500 text-gray-100';
  };

  const maxCount = Math.max(...analytics.distribution.map(d => d.count));

  return (
    <div className="h-full flex flex-col p-6 bg-surface/20 overflow-y-auto">
      {/* Header */}
      <div className="flex justify-between items-end mb-8 border-b border-highlight/30 pb-4">
        <div>
           <h2 className="text-2xl font-light text-white tracking-tight flex items-center gap-3">
            <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
            Stage Analytics
          </h2>
          <div className="text-xs text-gray-500 font-mono mt-1">
            DEVELOPMENTAL DISTRIBUTION & GROWTH VECTORS
          </div>
        </div>
        <div className="text-right">
           <div className="text-[10px] text-gray-500 font-mono uppercase">Total Population</div>
           <div className="text-2xl font-mono font-bold text-white tracking-tighter">
             {analytics.distribution.reduce((acc, curr) => acc + curr.count, 0).toLocaleString()}
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1">
        
        {/* Left Column: Distribution & Transitions */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Stage Distribution Chart */}
          <div className="bg-void border border-highlight/30 rounded-lg p-5">
            <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-6">Population by Kegan Stage</h3>
            <div className="space-y-4">
              {analytics.distribution.map(dist => (
                <div key={dist.stage} className="relative">
                  <div className="flex justify-between items-end mb-1 z-10 relative">
                    <span className="text-xs font-mono font-bold text-white">{dist.stage}</span>
                    <span className="text-xs text-gray-400">{dist.count} ({dist.percentage}%)</span>
                  </div>
                  <div className="h-4 bg-surface rounded-sm overflow-hidden relative">
                    {/* Background track */}
                    <div className="absolute inset-0 bg-gray-800/30"></div>
                    {/* Bar */}
                    <div 
                      className={`h-full ${getStageColor(dist.stage).split(' ')[0]} bg-opacity-80 relative`} 
                      style={{ width: `${(dist.count / maxCount) * 100}%` }}
                    >
                      <div className="absolute right-0 top-0 bottom-0 w-[1px] bg-white/50"></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Active Transitions Stream */}
          <div className="bg-surface/10 border border-highlight/30 rounded-lg p-5">
            <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-4 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
              Transitions In Progress
            </h3>
            <div className="space-y-2">
              {analytics.activeTransitions.map(tr => (
                <div key={tr.id} className="flex items-center justify-between p-3 bg-black/40 border border-highlight/20 rounded">
                  <div className="flex items-center gap-3">
                    <div className="text-xs font-mono text-gray-300">{tr.userId}</div>
                    <div className="text-[10px] text-gray-500 font-mono flex items-center gap-2">
                      <span className="text-gray-400">{tr.fromStage}</span>
                      <span className="text-gray-600">→</span>
                      <span className="text-white font-bold">{tr.toStage}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className={`text-[10px] font-bold px-1.5 py-0.5 rounded border 
                      ${tr.status === 'IN_PROGRESS' ? 'border-blue-500 text-blue-400' : 
                        tr.status === 'COMPLETED' ? 'border-green-500 text-green-400' : 'border-red-500 text-red-400'}`}>
                      {tr.status}
                    </div>
                    {tr.verifiedBySeer && (
                      <div className="text-green-500" title="Verified by Credential Atlas">
                        <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" /></svg>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Right Column: Growth Edges */}
        <div className="space-y-6">
          <div className="bg-green-900/5 border border-green-900/20 rounded-lg p-5 h-full flex flex-col">
            <h3 className="text-xs font-mono font-bold text-green-400 uppercase tracking-wider mb-4">
              Growth Edge Clusters
            </h3>
            <div className="space-y-4 overflow-y-auto flex-1 pr-1">
              {analytics.growthEdges.map(edge => (
                <div key={edge.id} className="bg-void border border-green-500/20 p-4 rounded hover:border-green-500/50 transition-colors">
                  <div className="flex justify-between items-start mb-2">
                    <div className="text-[10px] font-bold text-green-300 bg-green-900/40 px-2 py-0.5 rounded">
                      {edge.stageContext}
                    </div>
                    <div className="text-[10px] text-gray-500">{edge.frequency} users</div>
                  </div>
                  <h4 className="text-sm font-bold text-gray-200 mb-2">{edge.pattern}</h4>
                  
                  {edge.immunityToChange && (
                    <div className="mb-3 pl-3 border-l-2 border-red-500/40">
                      <div className="text-[9px] text-red-400 font-bold uppercase mb-0.5">Immunity to Change</div>
                      <p className="text-xs text-gray-400 italic">"{edge.immunityToChange}"</p>
                    </div>
                  )}

                  <div className="bg-white/5 p-2 rounded">
                    <div className="text-[9px] text-gray-500 font-bold uppercase mb-1">Interventions</div>
                    <ul className="list-disc list-inside text-[10px] text-gray-300 space-y-0.5">
                      {edge.suggestedInterventions.map((int, i) => (
                        <li key={i}>{int}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default StageAnalytics;