import React, { useState } from 'react';
import { IntegrationEvent, ModuleType } from '../types';

interface EventBusMonitorProps {
  events: IntegrationEvent[];
}

const EventBusMonitor: React.FC<EventBusMonitorProps> = ({ events }) => {
  const [filterSource, setFilterSource] = useState<string>('ALL');

  const filteredEvents = events.filter(e => 
    filterSource === 'ALL' || e.source === filterSource
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'SUCCESS': return 'text-green-500';
      case 'FAILURE': return 'text-red-500';
      case 'THROTTLED': return 'text-yellow-500';
      default: return 'text-gray-500';
    }
  };

  const getModuleShort = (mod: ModuleType) => {
    switch (mod) {
      case ModuleType.ORCHESTRATOR: return 'TRUTH';
      case ModuleType.BUILDER: return 'PRIM';
      case ModuleType.SEER: return 'ATLAS';
      default: return 'SYS';
    }
  };

  // Helper to format time with milliseconds manually to avoid TS errors with 'fractionalSecondDigits'
  const formatTimeWithMs = (timestamp: number) => {
    const d = new Date(timestamp);
    // Use standard locale time string for HH:MM:SS, then append milliseconds
    return `${d.toLocaleTimeString([], { hour12: false, hour: '2-digit', minute:'2-digit', second:'2-digit' })}.${d.getMilliseconds().toString().padStart(3, '0')}`;
  };

  return (
    <div className="h-full flex flex-col bg-black w-1/2">
      {/* Header */}
      <div className="p-4 border-b border-highlight/30 flex justify-between items-center bg-surface/50">
        <h2 className="text-sm font-mono font-bold text-gray-300 uppercase tracking-wider flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
          Event Bus
        </h2>
        <div className="flex gap-2 text-[10px] font-mono">
           <button 
             onClick={() => setFilterSource('ALL')}
             className={`px-2 py-1 rounded ${filterSource === 'ALL' ? 'bg-white text-black' : 'text-gray-500 hover:text-white'}`}
           >
             ALL
           </button>
           <button 
             onClick={() => setFilterSource(ModuleType.ORCHESTRATOR)}
             className={`px-2 py-1 rounded ${filterSource === ModuleType.ORCHESTRATOR ? 'bg-truth text-white' : 'text-gray-500 hover:text-white'}`}
           >
             TRUTH
           </button>
           <button 
             onClick={() => setFilterSource(ModuleType.BUILDER)}
             className={`px-2 py-1 rounded ${filterSource === ModuleType.BUILDER ? 'bg-primitive text-white' : 'text-gray-500 hover:text-white'}`}
           >
             PRIM
           </button>
        </div>
      </div>

      {/* Events Stream */}
      <div className="flex-1 overflow-y-auto p-0 font-mono text-xs">
        {filteredEvents.length === 0 ? (
          <div className="p-8 text-center text-gray-600 italic">No traffic detected</div>
        ) : (
          <div className="flex flex-col-reverse min-h-full">
            {filteredEvents.slice().reverse().map((event, index) => (
              <div 
                key={event.id} 
                className={`p-3 border-b border-highlight/20 hover:bg-highlight/10 transition-colors group cursor-default
                  ${index === 0 ? 'animate-pulse bg-highlight/5' : ''}`}
              >
                <div className="flex justify-between items-start mb-1">
                  <div className="text-gray-500 text-[10px]">
                    {formatTimeWithMs(event.timestamp)}
                  </div>
                  <div className={`text-[10px] font-bold ${getStatusColor(event.status)}`}>
                    {event.status} {event.status === 'SUCCESS' ? `(${event.latency}ms)` : ''}
                  </div>
                </div>
                
                <div className="flex items-center gap-2 mb-1">
                  <span className={`font-bold ${
                    event.source === ModuleType.ORCHESTRATOR ? 'text-truth' :
                    event.source === ModuleType.BUILDER ? 'text-primitive' : 'text-credential'
                  }`}>
                    {getModuleShort(event.source)}
                  </span>
                  <span className="text-gray-600">→</span>
                  <span className={`font-bold ${
                    event.destination === ModuleType.ORCHESTRATOR ? 'text-truth' :
                    event.destination === ModuleType.BUILDER ? 'text-primitive' : 'text-credential'
                  }`}>
                    {getModuleShort(event.destination)}
                  </span>
                  <span className="text-gray-300 bg-highlight/30 px-1 rounded">
                    {event.eventType}
                  </span>
                </div>

                <div className="text-gray-400 break-all pl-2 border-l-2 border-highlight/30 group-hover:border-white/30 transition-colors">
                  {event.endpoint}
                </div>
                
                {/* Expandable details on hover or click could go here, strictly simplified for now */}
                <div className="mt-1 text-[10px] text-gray-600 flex gap-4">
                  <span>CID: {event.correlationId}</span>
                  <span>{event.payloadSummary}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Footer Stats */}
      <div className="p-2 border-t border-highlight/30 bg-surface/50 flex justify-between text-[10px] font-mono text-gray-500">
        <div>Total Events: {events.length}</div>
        <div>Throughput: {Math.round(events.length / 5)} ev/min</div>
      </div>
    </div>
  );
};

export default EventBusMonitor;