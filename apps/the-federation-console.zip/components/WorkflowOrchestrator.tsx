import React, { useState, useEffect } from 'react';
import { WorkflowExecution, WorkflowTemplate, WorkflowStep, ModuleType, SystemLog } from '../types';
import { WORKFLOW_TEMPLATES, createWorkflowExecution } from '../services/workflowService';
import { v4 as uuidv4 } from 'uuid';

interface WorkflowOrchestratorProps {
  executions: WorkflowExecution[];
  onStartWorkflow: (templateId: string) => void;
  onApproveStep: (executionId: string) => void;
  addLog: (log: SystemLog) => void;
}

const WorkflowOrchestrator: React.FC<WorkflowOrchestratorProps> = ({ 
  executions, 
  onStartWorkflow, 
  onApproveStep,
  addLog 
}) => {
  const [selectedExecutionId, setSelectedExecutionId] = useState<string | null>(null);

  const activeExecution = executions.find(e => e.id === selectedExecutionId) || executions[executions.length - 1];

  useEffect(() => {
    // If no selection but executions exist, select the last one
    if (!selectedExecutionId && executions.length > 0) {
      setSelectedExecutionId(executions[executions.length - 1].id);
    }
  }, [executions, selectedExecutionId]);

  const handleStart = (templateId: string) => {
    onStartWorkflow(templateId);
    const template = WORKFLOW_TEMPLATES.find(t => t.id === templateId);
    addLog({
      id: uuidv4(),
      timestamp: Date.now(),
      module: ModuleType.WORKFLOW,
      event: `Initiated workflow: ${template?.name}`,
      status: 'info'
    });
  };

  const getModuleColor = (type: ModuleType) => {
    switch (type) {
      case ModuleType.ORCHESTRATOR: return 'border-truth text-truth';
      case ModuleType.BUILDER: return 'border-primitive text-primitive';
      case ModuleType.SEER: return 'border-credential text-credential';
      default: return 'border-gray-500 text-gray-500';
    }
  };

  const getModuleBg = (type: ModuleType) => {
    switch (type) {
      case ModuleType.ORCHESTRATOR: return 'bg-truth/10';
      case ModuleType.BUILDER: return 'bg-primitive/10';
      case ModuleType.SEER: return 'bg-credential/10';
      default: return 'bg-gray-500/10';
    }
  };

  return (
    <div className="h-full flex bg-surface/20">
      {/* Sidebar - Workflow List */}
      <div className="w-64 border-r border-highlight/30 bg-surface/50 flex flex-col">
        <div className="p-4 border-b border-highlight/30">
          <h2 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-4">New Workflow</h2>
          <div className="space-y-2">
            {WORKFLOW_TEMPLATES.map(t => (
              <button
                key={t.id}
                onClick={() => handleStart(t.id)}
                className="w-full text-left px-3 py-2 rounded border border-highlight/50 bg-void hover:bg-highlight/30 hover:border-truth/50 transition-colors text-xs font-mono text-gray-300"
              >
                + {t.name}
              </button>
            ))}
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4">
           <h2 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-4">Active Operations</h2>
           <div className="space-y-2">
             {executions.slice().reverse().map(exec => (
               <div 
                 key={exec.id}
                 onClick={() => setSelectedExecutionId(exec.id)}
                 className={`p-3 rounded border cursor-pointer transition-all ${
                   selectedExecutionId === exec.id 
                     ? 'bg-highlight/30 border-white/30' 
                     : 'bg-void border-highlight/30 hover:border-gray-500'
                 }`}
               >
                 <div className="text-xs text-white font-bold mb-1 truncate">{exec.name}</div>
                 <div className="flex justify-between items-center">
                    <span className={`text-[10px] px-1.5 py-0.5 rounded ${
                      exec.status === 'RUNNING' ? 'bg-blue-900/50 text-blue-200 animate-pulse' :
                      exec.status === 'COMPLETED' ? 'bg-green-900/50 text-green-200' :
                      exec.status === 'WAITING_APPROVAL' ? 'bg-yellow-900/50 text-yellow-200' :
                      'bg-gray-800 text-gray-400'
                    }`}>
                      {exec.status}
                    </span>
                    <span className="text-[10px] text-gray-500">{Math.round(((exec.currentStepIndex + (exec.status === 'COMPLETED' ? 1 : 0)) / exec.steps.length) * 100)}%</span>
                 </div>
               </div>
             ))}
             {executions.length === 0 && (
               <div className="text-center text-gray-600 text-xs py-8 italic">No active workflows</div>
             )}
           </div>
        </div>
      </div>

      {/* Main Area - Visualization */}
      <div className="flex-1 flex flex-col min-w-0 bg-void/50 p-8 overflow-y-auto">
        {activeExecution ? (
          <div className="max-w-4xl mx-auto w-full">
            <div className="flex justify-between items-start mb-12">
              <div>
                <h1 className="text-2xl text-white font-light tracking-tight">{activeExecution.name}</h1>
                <div className="text-sm text-gray-500 font-mono mt-2">ID: {activeExecution.id}</div>
              </div>
              <div className="text-right font-mono text-xs text-gray-400">
                STARTED: {new Date(activeExecution.startedAt).toLocaleTimeString()}
                {activeExecution.completedAt && <><br/>COMPLETED: {new Date(activeExecution.completedAt).toLocaleTimeString()}</>}
              </div>
            </div>

            {/* Steps Visualization */}
            <div className="relative space-y-8">
              {/* Connecting Line */}
              <div className="absolute left-6 top-6 bottom-6 w-0.5 bg-highlight/30 -z-10"></div>

              {activeExecution.steps.map((step, index) => {
                const isActive = activeExecution.status !== 'COMPLETED' && index === activeExecution.currentStepIndex;
                const isCompleted = step.status === 'COMPLETED';
                
                return (
                  <div key={step.id} className={`relative pl-16 transition-all duration-500 ${isActive ? 'scale-105' : 'opacity-80'}`}>
                    {/* Status Dot */}
                    <div className={`absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 rounded-full border-2 z-10 bg-void 
                      ${isActive ? 'border-white animate-pulse' : isCompleted ? 'border-green-500' : 'border-gray-700'}`}>
                      {isCompleted && <div className="absolute inset-0 bg-green-500 rounded-full opacity-50"></div>}
                    </div>

                    {/* Step Card */}
                    <div className={`border rounded-lg p-5 flex items-center gap-6 relative overflow-hidden ${getModuleColor(step.companyType)} ${isActive ? 'bg-surface border-opacity-50 shadow-lg' : 'bg-void border-opacity-20'}`}>
                      
                      {/* Background Pulse for active */}
                      {isActive && (
                        <div className={`absolute inset-0 ${getModuleBg(step.companyType)} opacity-10 animate-pulse pointer-events-none`}></div>
                      )}

                      <div className="flex-1">
                        <div className="flex justify-between items-center mb-1">
                           <span className="text-[10px] font-mono opacity-70 uppercase">{step.companyType}</span>
                           <span className={`text-[10px] font-bold px-2 py-0.5 rounded border border-opacity-30 ${
                             step.status === 'WAITING_APPROVAL' ? 'text-yellow-400 border-yellow-500 bg-yellow-900/20' : 
                             step.status === 'RUNNING' ? 'text-blue-400 border-blue-500 bg-blue-900/20' :
                             step.status === 'COMPLETED' ? 'text-green-400 border-green-500 bg-green-900/20' :
                             'text-gray-500 border-gray-600'
                           }`}>
                             {step.status}
                           </span>
                        </div>
                        <h3 className="text-lg text-gray-200 font-light">{step.action}</h3>
                        
                        {/* Logs mini-view */}
                        {step.logs.length > 0 && (
                          <div className="mt-3 text-[10px] font-mono text-gray-500 bg-black/30 p-2 rounded">
                            {step.logs[step.logs.length - 1]}
                          </div>
                        )}
                      </div>

                      {/* Action Button */}
                      {step.status === 'WAITING_APPROVAL' && (
                        <button
                          onClick={() => {
                            onApproveStep(activeExecution.id);
                            addLog({
                              id: uuidv4(),
                              timestamp: Date.now(),
                              module: ModuleType.WORKFLOW,
                              event: `Manual approval granted for step: ${step.action}`,
                              status: 'success'
                            });
                          }}
                          className="px-4 py-2 bg-yellow-600 hover:bg-yellow-500 text-white text-xs font-mono rounded shadow-[0_0_10px_rgba(234,179,8,0.4)] animate-pulse"
                        >
                          APPROVE
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

          </div>
        ) : (
          <div className="flex items-center justify-center h-full text-gray-500 font-mono text-sm">
            Select or start a workflow execution
          </div>
        )}
      </div>
    </div>
  );
};

export default WorkflowOrchestrator;