import React, { useState } from 'react';
import { Proposal, Vote, ModuleType, VoteDecision, SystemLog } from '../types';
import { v4 as uuidv4 } from 'uuid';

interface GovernancePanelProps {
  proposals: Proposal[];
  onCastVote: (proposalId: string, decision: VoteDecision, rationale: string) => void;
  addLog: (log: SystemLog) => void;
}

const GovernancePanel: React.FC<GovernancePanelProps> = ({ proposals, onCastVote, addLog }) => {
  const [selectedProposalId, setSelectedProposalId] = useState<string | null>(null);
  const [voteRationale, setVoteRationale] = useState('');
  
  // For simulation, the operator can vote on behalf of the active user/orchestrator
  // In a real app, this would be tied to auth.
  const actingAs = ModuleType.ORCHESTRATOR; 

  const activeProposals = proposals.filter(p => p.status === 'ACTIVE');
  const historyProposals = proposals.filter(p => p.status !== 'ACTIVE');
  const [viewMode, setViewMode] = useState<'ACTIVE' | 'HISTORY'>('ACTIVE');

  const selectedProposal = proposals.find(p => p.id === selectedProposalId) || activeProposals[0] || historyProposals[0];

  const handleVote = (decision: VoteDecision) => {
    if (!selectedProposal) return;
    
    onCastVote(selectedProposal.id, decision, voteRationale || "Executive decision via Console.");
    addLog({
      id: uuidv4(),
      timestamp: Date.now(),
      module: ModuleType.GOVERNANCE,
      event: `Vote cast: ${decision} on ${selectedProposal.id}`,
      status: 'info'
    });
    setVoteRationale('');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ACTIVE': return 'bg-blue-600 text-white';
      case 'PASSED': return 'bg-green-600 text-white';
      case 'REJECTED': return 'bg-red-600 text-white';
      default: return 'bg-gray-600';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'CRISIS': return 'text-red-400 border-red-900/50 bg-red-900/10';
      case 'TECHNICAL': return 'text-blue-400 border-blue-900/50 bg-blue-900/10';
      case 'POLICY': return 'text-yellow-400 border-yellow-900/50 bg-yellow-900/10';
      default: return 'text-gray-400';
    }
  };

  return (
    <div className="h-full flex bg-surface/20">
      {/* Sidebar List */}
      <div className="w-80 border-r border-highlight/30 bg-surface/50 flex flex-col">
        <div className="flex border-b border-highlight/30">
          <button 
            onClick={() => setViewMode('ACTIVE')}
            className={`flex-1 py-3 text-[10px] font-mono font-bold uppercase transition-colors ${viewMode === 'ACTIVE' ? 'bg-void text-white border-b-2 border-yellow-500' : 'text-gray-500 hover:text-gray-300'}`}
          >
            Pending ({activeProposals.length})
          </button>
          <button 
            onClick={() => setViewMode('HISTORY')}
            className={`flex-1 py-3 text-[10px] font-mono font-bold uppercase transition-colors ${viewMode === 'HISTORY' ? 'bg-void text-white border-b-2 border-gray-500' : 'text-gray-500 hover:text-gray-300'}`}
          >
            Archive ({historyProposals.length})
          </button>
        </div>

        <div className="flex-1 overflow-y-auto">
          {(viewMode === 'ACTIVE' ? activeProposals : historyProposals).map(prop => (
             <div 
               key={prop.id}
               onClick={() => setSelectedProposalId(prop.id)}
               className={`p-4 border-b border-highlight/20 cursor-pointer transition-colors ${selectedProposal?.id === prop.id ? 'bg-highlight/30' : 'hover:bg-highlight/10'}`}
             >
               <div className="flex justify-between items-start mb-2">
                 <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${getTypeColor(prop.type)}`}>{prop.type}</span>
                 <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${getStatusColor(prop.status)}`}>{prop.status}</span>
               </div>
               <h3 className="text-sm text-white font-medium leading-tight mb-2">{prop.title}</h3>
               <div className="flex justify-between items-center text-[10px] text-gray-500 font-mono">
                 <span>ID: {prop.id.split('-')[1]}</span>
                 <span>Votes: {prop.votes.length}/{prop.requiredApprovals}</span>
               </div>
             </div>
          ))}
          {(viewMode === 'ACTIVE' ? activeProposals : historyProposals).length === 0 && (
            <div className="p-8 text-center text-gray-500 text-xs italic">No records found.</div>
          )}
        </div>
      </div>

      {/* Main Detail Area */}
      <div className="flex-1 flex flex-col min-w-0 bg-void/50 p-8 overflow-y-auto">
        {selectedProposal ? (
          <div className="max-w-3xl mx-auto w-full">
            
            {/* Header */}
            <div className="mb-8">
              <div className="flex items-center gap-3 text-xs font-mono text-gray-400 mb-2">
                <span>PROPOSAL {selectedProposal.id.toUpperCase()}</span>
                <span>•</span>
                <span>PROPOSER: {selectedProposal.proposer}</span>
                <span>•</span>
                <span>CREATED: {new Date(selectedProposal.created).toLocaleDateString()}</span>
              </div>
              <h1 className="text-2xl text-white font-light tracking-tight mb-4">{selectedProposal.title}</h1>
              <p className="text-gray-300 leading-relaxed text-sm bg-surface/40 p-4 rounded border border-highlight/30">
                {selectedProposal.description}
              </p>
            </div>

            {/* Impact & Analysis */}
            <div className="grid grid-cols-2 gap-6 mb-8">
              <div className="bg-red-900/5 border border-red-900/20 p-4 rounded">
                <h3 className="text-xs font-mono font-bold text-red-400 uppercase mb-2">Impact Analysis</h3>
                <p className="text-xs text-red-200/80 leading-relaxed">
                  {selectedProposal.impactAnalysis}
                </p>
              </div>
              <div className="bg-blue-900/5 border border-blue-900/20 p-4 rounded">
                <h3 className="text-xs font-mono font-bold text-blue-400 uppercase mb-2">Decision Criteria</h3>
                <div className="space-y-2 text-xs text-blue-200/80">
                  <div className="flex justify-between">
                     <span>Required Approvals:</span>
                     <span className="font-bold">{selectedProposal.requiredApprovals}</span>
                  </div>
                  <div className="flex justify-between">
                     <span>Deadline:</span>
                     <span>{new Date(selectedProposal.deadline).toLocaleDateString()}</span>
                  </div>
                  <div className="flex justify-between">
                     <span>Type:</span>
                     <span>{selectedProposal.type}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Votes List */}
            <div className="mb-8">
               <h3 className="text-xs font-mono font-bold text-gray-400 uppercase mb-3">Voting Record</h3>
               <div className="space-y-2">
                 {[ModuleType.ORCHESTRATOR, ModuleType.BUILDER, ModuleType.SEER].map(company => {
                   const vote = selectedProposal.votes.find(v => v.company === company);
                   return (
                     <div key={company} className="flex items-center justify-between p-3 border border-highlight/30 rounded bg-black/20">
                        <div className="flex items-center gap-3">
                           <div className={`w-2 h-2 rounded-full ${company === ModuleType.ORCHESTRATOR ? 'bg-truth' : company === ModuleType.BUILDER ? 'bg-primitive' : 'bg-credential'}`}></div>
                           <span className="text-xs text-gray-300 font-bold">{company}</span>
                        </div>
                        {vote ? (
                           <div className="text-right">
                             <span className={`text-xs font-bold px-2 py-0.5 rounded 
                               ${vote.decision === 'APPROVE' ? 'bg-green-900/30 text-green-400' : 
                                 vote.decision === 'REJECT' ? 'bg-red-900/30 text-red-400' : 'bg-gray-700 text-gray-300'}`}>
                               {vote.decision}
                             </span>
                             <div className="text-[10px] text-gray-500 mt-1 max-w-xs">{vote.rationale}</div>
                           </div>
                        ) : (
                          <span className="text-xs text-gray-600 italic">Pending Vote</span>
                        )}
                     </div>
                   );
                 })}
               </div>
            </div>

            {/* Actions */}
            {selectedProposal.status === 'ACTIVE' && (
              <div className="bg-highlight/10 border-t border-highlight/30 p-6 -mx-8 -mb-8 mt-8">
                <h3 className="text-xs font-mono font-bold text-gray-400 uppercase mb-4">Cast Vote (As {actingAs})</h3>
                <textarea
                  className="w-full bg-black/50 border border-highlight/50 rounded p-3 text-sm text-white focus:outline-none focus:border-white mb-4 h-20 resize-none"
                  placeholder="Enter rationale for decision..."
                  value={voteRationale}
                  onChange={(e) => setVoteRationale(e.target.value)}
                />
                <div className="flex gap-4">
                  <button 
                    onClick={() => handleVote('APPROVE')}
                    className="flex-1 py-3 bg-green-700 hover:bg-green-600 text-white text-xs font-mono font-bold rounded transition-colors"
                  >
                    APPROVE
                  </button>
                  <button 
                    onClick={() => handleVote('REJECT')}
                    className="flex-1 py-3 bg-red-700 hover:bg-red-600 text-white text-xs font-mono font-bold rounded transition-colors"
                  >
                    REJECT
                  </button>
                  <button 
                    onClick={() => handleVote('ABSTAIN')}
                    className="flex-1 py-3 bg-gray-700 hover:bg-gray-600 text-white text-xs font-mono font-bold rounded transition-colors"
                  >
                    ABSTAIN
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="flex items-center justify-center h-full text-gray-500 font-mono text-sm">
            Select a proposal to view details
          </div>
        )}
      </div>
    </div>
  );
};

export default GovernancePanel;