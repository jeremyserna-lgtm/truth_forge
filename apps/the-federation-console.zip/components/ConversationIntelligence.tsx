import React from 'react';
import { ConversationMetrics, SystemLog, ModuleType } from '../types';

interface ConversationIntelligenceProps {
  metrics: ConversationMetrics;
  addLog: (log: SystemLog) => void;
}

const ConversationIntelligence: React.FC<ConversationIntelligenceProps> = ({ metrics }) => {
  
  const getStageColor = (stage: string) => {
    if (stage.includes('2')) return 'text-red-400 border-red-500/30';
    if (stage.includes('3')) return 'text-amber-400 border-amber-500/30';
    if (stage.includes('4')) return 'text-green-400 border-green-500/30';
    if (stage.includes('5')) return 'text-blue-400 border-blue-500/30';
    return 'text-gray-400 border-gray-500/30';
  };

  return (
    <div className="h-full flex flex-col p-6 bg-surface/20 overflow-y-auto">
      {/* Header */}
      <div className="flex justify-between items-end mb-8 border-b border-highlight/30 pb-4">
        <div>
           <h2 className="text-2xl font-light text-white tracking-tight flex items-center gap-3">
            <svg className="w-6 h-6 text-orange-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
            Conversation Intelligence
          </h2>
          <div className="text-xs text-gray-500 font-mono mt-1">
            NOT-ME COMPANION: DEVELOPMENTAL DIALOGUE TRACKING
          </div>
        </div>
        <div className="flex gap-6 text-right">
           <div>
             <div className="text-[10px] text-gray-500 font-mono uppercase">Active Dialogues</div>
             <div className="text-2xl font-mono font-bold text-white tracking-tighter">
               {metrics.activeConversations.toLocaleString()}
             </div>
           </div>
           <div>
             <div className="text-[10px] text-gray-500 font-mono uppercase">Avg Depth</div>
             <div className="text-2xl font-mono font-bold text-orange-400 tracking-tighter">
               {metrics.avgDepthScore}<span className="text-sm text-gray-600">/10</span>
             </div>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1">
        
        {/* Left Column: Live Feed & Heatmap */}
        <div className="space-y-6">
          
          {/* Developmental Moments Feed */}
          <div className="bg-surface/10 border border-highlight/30 rounded-lg p-5 flex flex-col h-96">
            <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-4 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-orange-500 animate-pulse"></span>
              Live Developmental Moments
            </h3>
            <div className="flex-1 overflow-y-auto space-y-3 pr-2">
              {metrics.moments.map(mom => (
                <div key={mom.id} className="bg-black/40 p-3 rounded border border-highlight/20">
                  <div className="flex justify-between items-start mb-1">
                    <span className="text-[10px] text-gray-500 font-mono">{new Date(mom.timestamp).toLocaleTimeString()}</span>
                    <span className={`text-[10px] font-bold px-1.5 rounded border ${getStageColor(mom.userStage)}`}>
                      {mom.userStage}
                    </span>
                  </div>
                  <p className="text-xs text-gray-200 leading-snug mb-2">"{mom.insight}"</p>
                  <div className="text-[9px] text-gray-600 font-mono uppercase tracking-wide">
                    Theme: {mom.themeId.replace('th-', '')}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Activity Heatmap (Simulated Grid) */}
          <div className="bg-void border border-highlight/30 rounded-lg p-5">
             <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-4">24h Conversation Volume</h3>
             <div className="flex items-end gap-[2px] h-24">
                {metrics.hourlyActivity.map((count, i) => {
                  const height = Math.min(100, (count / 250) * 100);
                  const opacity = Math.min(1, count / 200);
                  return (
                    <div key={i} className="flex-1 flex flex-col justify-end group">
                      <div 
                        className="w-full bg-orange-500 rounded-sm hover:bg-orange-400 transition-all"
                        style={{ height: `${height}%`, opacity: Math.max(0.2, opacity) }}
                      ></div>
                    </div>
                  );
                })}
             </div>
             <div className="flex justify-between mt-2 text-[10px] text-gray-600 font-mono">
               <span>-24H</span>
               <span>NOW</span>
             </div>
          </div>

        </div>

        {/* Middle Column: Themes & Effectiveness */}
        <div className="space-y-6">
          
          {/* Top Themes */}
          <div className="bg-void border border-highlight/30 rounded-lg p-5">
            <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-4">Dominant Themes</h3>
            <div className="space-y-4">
              {metrics.themes.map(theme => (
                <div key={theme.id}>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-xs font-bold text-gray-300">{theme.name}</span>
                    <span className="text-[10px] text-gray-500 font-mono">{theme.stageCorrelation}</span>
                  </div>
                  <div className="h-1.5 w-full bg-surface rounded-full overflow-hidden mb-1">
                    <div 
                      className="h-full bg-blue-600"
                      style={{ width: `${(theme.volume / 400) * 100}%` }}
                    ></div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] text-gray-600">{theme.volume} active threads</span>
                    <span className={`text-[10px] ${theme.sentiment > 60 ? 'text-green-500' : theme.sentiment < 40 ? 'text-red-500' : 'text-gray-500'}`}>
                      Sentiment: {theme.sentiment}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Not-Me Effectiveness */}
          <div className="bg-surface/10 border border-highlight/30 rounded-lg p-5">
            <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-4">Companion Effectiveness</h3>
            <div className="space-y-3">
              {metrics.effectiveness.map(eff => (
                <div key={eff.stage} className="flex items-center gap-3">
                  <div className="w-16 text-[10px] font-bold text-gray-400">{eff.stage}</div>
                  <div className="flex-1">
                    <div className="h-2 w-full bg-black rounded-full overflow-hidden">
                      <div 
                        className={`h-full ${getStageColor(eff.stage).split(' ')[0].replace('text-', 'bg-')}`}
                        style={{ width: `${eff.effectiveness}%` }}
                      ></div>
                    </div>
                  </div>
                  <div className="w-24 text-right text-[10px] text-gray-500 font-mono">
                    Depth: {eff.avgDepth}
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Right Column: Breakthroughs */}
        <div className="space-y-6">
          <div className="bg-orange-900/10 border border-orange-500/20 rounded-lg p-5 h-full flex flex-col">
            <h3 className="text-xs font-mono font-bold text-orange-400 uppercase tracking-wider mb-6 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
              Breakthrough Detection
            </h3>
            
            <div className="flex-1 space-y-4 overflow-y-auto">
              {metrics.breakthroughs.map(bk => (
                <div key={bk.id} className="bg-black/60 border border-orange-500/30 rounded p-4 shadow-[0_0_15px_rgba(249,115,22,0.1)]">
                  <div className="flex justify-between items-start mb-3">
                    <span className="text-[10px] font-bold text-orange-300 bg-orange-900/40 px-2 py-0.5 rounded">
                      SUBJ &rarr; OBJ SHIFT
                    </span>
                    <span className="text-[10px] text-gray-500 font-mono">{bk.confidence}% CONF</span>
                  </div>
                  
                  <div className="flex items-center gap-2 text-xs text-gray-300 mb-3 font-mono">
                    <span className="text-red-400 opacity-80">{bk.fromState}</span>
                    <span className="text-gray-600">&rarr;</span>
                    <span className="text-green-400 font-bold">{bk.toState}</span>
                  </div>

                  <div className="bg-white/5 p-3 rounded border-l-2 border-orange-500/50">
                    <div className="text-[9px] text-gray-500 font-bold uppercase mb-1">Catalyst Prompt</div>
                    <p className="text-xs text-orange-100 italic">
                      {bk.triggerMessage}
                    </p>
                  </div>
                  
                  <div className="mt-3 text-[10px] text-gray-600 text-right">
                    User: {bk.userId} | {new Date(bk.timestamp).toLocaleTimeString()}
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-4 pt-4 border-t border-orange-500/20 text-center">
              <p className="text-[10px] text-orange-500/70">
                Detecting shifts in Subject-Object relation structure.
              </p>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default ConversationIntelligence;