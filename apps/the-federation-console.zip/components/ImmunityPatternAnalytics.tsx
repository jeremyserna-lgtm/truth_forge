import React from 'react';
import { ImmunityAnalyticsState, SystemLog, ModuleType } from '../types';

interface ImmunityPatternAnalyticsProps {
  state: ImmunityAnalyticsState;
  addLog: (log: SystemLog) => void;
}

const ImmunityPatternAnalytics: React.FC<ImmunityPatternAnalyticsProps> = ({ state }) => {
  
  const getSeverityColor = (sev: string) => {
    if (sev === 'HIGH') return 'text-red-500 bg-red-900/20 border-red-500/30';
    if (sev === 'MEDIUM') return 'text-orange-500 bg-orange-900/20 border-orange-500/30';
    return 'text-yellow-500 bg-yellow-900/20 border-yellow-500/30';
  };

  return (
    <div className="h-full flex flex-col p-6 bg-surface/20 overflow-y-auto">
      {/* Header */}
      <div className="flex justify-between items-end mb-8 border-b border-highlight/30 pb-4">
        <div>
           <h2 className="text-2xl font-light text-white tracking-tight flex items-center gap-3">
            <svg className="w-6 h-6 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
            Immunity Pattern Analytics
          </h2>
          <div className="text-xs text-gray-500 font-mono mt-1">
            AGGREGATE IMMUNITY MAPS & BIG ASSUMPTIONS
          </div>
        </div>
        <div className="text-right flex gap-6">
           <div>
             <div className="text-[10px] text-gray-500 font-mono uppercase">Tracked Patterns</div>
             <div className="text-2xl font-mono font-bold text-white tracking-tighter">
               {state.clusters.length}
             </div>
           </div>
           <div>
             <div className="text-[10px] text-gray-500 font-mono uppercase">Breakthroughs</div>
             <div className="text-2xl font-mono font-bold text-green-400 tracking-tighter">
               {state.paths.reduce((acc, p) => acc + p.successCount, 0)}
             </div>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1">
        
        {/* Left Column: Assumption Clusters (Visual) */}
        <div className="space-y-6">
          <div className="bg-void border border-highlight/30 rounded-lg p-5 h-96 flex flex-col relative overflow-hidden">
             <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-4 z-10">Assumption Constellation</h3>
             
             {/* Simple Visualization of Bubbles */}
             <div className="flex-1 relative">
                {state.clusters.map((cluster, i) => {
                  // rudimentary positioning for demo
                  const size = Math.max(80, Math.min(160, cluster.frequency / 5));
                  const top = 20 + (i * 30);
                  const left = 10 + (i * 20);
                  
                  return (
                    <div 
                      key={cluster.id}
                      className="absolute rounded-full border border-red-500/30 bg-red-900/20 flex flex-col items-center justify-center p-2 text-center hover:bg-red-900/40 hover:scale-105 transition-all cursor-default z-0"
                      style={{ 
                        width: `${size}px`, 
                        height: `${size}px`,
                        top: `${top}%`,
                        left: `${left}%`
                      }}
                    >
                      <div className="text-[10px] font-bold text-red-200 leading-tight mb-1">{cluster.theme}</div>
                      <div className="text-[9px] text-red-400 font-mono">{cluster.frequency} Users</div>
                    </div>
                  );
                })}
                
                {/* Connecting Lines (Decorative) */}
                <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-20">
                   <line x1="30%" y1="30%" x2="50%" y2="60%" stroke="white" strokeWidth="1" />
                   <line x1="50%" y1="60%" x2="70%" y2="40%" stroke="white" strokeWidth="1" />
                </svg>
             </div>

             <div className="mt-4 pt-4 border-t border-highlight/20 text-[10px] text-gray-500 font-mono flex justify-between">
                <span className="flex items-center gap-1">
                   <div className="w-2 h-2 rounded-full bg-red-500/50"></div> High Frequency
                </span>
                <span>Truth Engine Semantic Analysis</span>
             </div>
          </div>
          
          <div className="bg-surface/10 border border-highlight/30 rounded-lg p-5">
             <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-4">Semantic Signatures</h3>
             <div className="space-y-3">
               {state.clusters.map(c => (
                 <div key={c.id} className="text-[10px] text-gray-500 border-l-2 border-highlight/30 pl-2">
                    <span className="text-gray-300 font-bold">{c.theme}:</span> {c.semanticSignature.replace('Truth Engine: ', '')}
                 </div>
               ))}
             </div>
          </div>
        </div>

        {/* Middle Column: Stuckness Heatmap */}
        <div className="space-y-6">
           <div className="bg-surface/10 border border-highlight/30 rounded-lg p-5">
              <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-4 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
                Transition Blockers
              </h3>
              <div className="space-y-3">
                 {state.blockers.map(blocker => (
                   <div key={blocker.id} className="bg-black/40 p-3 rounded border border-highlight/20">
                      <div className="flex justify-between items-center mb-1">
                         <span className="text-xs font-bold text-white">{blocker.assumptionType}</span>
                         <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${getSeverityColor(blocker.severity)}`}>
                            {blocker.severity}
                         </span>
                      </div>
                      <div className="flex justify-between items-center mb-2">
                         <span className="text-[10px] text-gray-400 font-mono">Blocks: {blocker.stageTransition}</span>
                         <span className="text-[10px] text-gray-500 font-mono">Impact: {blocker.frequencyScore}/100</span>
                      </div>
                      <div className="h-1.5 w-full bg-surface rounded-full overflow-hidden">
                         <div className="h-full bg-red-600" style={{ width: `${blocker.frequencyScore}%` }}></div>
                      </div>
                   </div>
                 ))}
              </div>
           </div>

           <div className="bg-void border border-highlight/30 rounded-lg p-5">
              <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-4">Breakthrough Paths</h3>
              <div className="space-y-4">
                 {state.paths.map(path => (
                    <div key={path.id} className="relative pl-4 border-l border-green-500/30">
                       <div className="absolute -left-[5px] top-0 w-2.5 h-2.5 rounded-full bg-green-500 border border-black"></div>
                       <h4 className="text-sm font-bold text-green-400 mb-1">{path.name}</h4>
                       <div className="text-[10px] text-gray-500 mb-2">
                          Avg Time: {path.avgTimeWeeks} weeks • {path.successCount} successes
                       </div>
                       <div className="bg-green-900/10 p-2 rounded border border-green-500/20">
                          <div className="text-[9px] text-green-300 font-bold uppercase mb-1">Challenge Sequence</div>
                          <ul className="list-disc list-inside text-[10px] text-gray-400">
                             {path.keyAssumptionsChallenged.map((k, i) => (
                                <li key={i}>{k.replace(/"/g, '')}</li>
                             ))}
                          </ul>
                       </div>
                    </div>
                 ))}
              </div>
           </div>
        </div>

        {/* Right Column: Interventions */}
        <div className="space-y-6">
           <div className="bg-blue-900/5 border border-blue-900/20 rounded-lg p-5 h-full flex flex-col">
              <h3 className="text-xs font-mono font-bold text-blue-400 uppercase tracking-wider mb-6 flex items-center gap-2">
                 <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.384-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" /></svg>
                 System Interventions
              </h3>
              
              <div className="flex-1 space-y-4 overflow-y-auto">
                 {state.interventions.map(int => (
                    <div key={int.id} className="bg-black/50 border border-blue-500/20 rounded p-4 shadow-[0_0_15px_rgba(59,130,246,0.1)] hover:border-blue-500/50 transition-colors">
                       <div className="flex justify-between items-start mb-2">
                          <span className="text-[10px] font-bold text-blue-300 bg-blue-900/40 px-2 py-0.5 rounded">
                             {int.type}
                          </span>
                          <span className="text-[10px] text-gray-500 font-mono">Impact: {int.predictedImpact}</span>
                       </div>
                       <h4 className="text-sm font-bold text-gray-200 mb-2">{int.action}</h4>
                       <div className="text-[10px] text-gray-500 italic">
                          Targets: {state.clusters.find(c => c.id === int.targetClusterId)?.theme || int.targetClusterId}
                       </div>
                    </div>
                 ))}
              </div>

              <div className="mt-4 pt-4 border-t border-blue-500/20 text-[10px] text-blue-400/70 text-center font-mono">
                 Primitive Engine: Hook Available
                 <br/>
                 Credential Atlas: Verification Ready
              </div>
           </div>
        </div>

      </div>
    </div>
  );
};

export default ImmunityPatternAnalytics;