import React, { useState } from 'react';
import { generateFederationAsset } from '../services/geminiService';
import { ImageResolution, ModuleType, SystemLog } from '../types';
import { v4 as uuidv4 } from 'uuid';

interface VisionStudioProps {
  addLog: (log: SystemLog) => void;
}

const VisionStudio: React.FC<VisionStudioProps> = ({ addLog }) => {
  const [prompt, setPrompt] = useState('');
  const [resolution, setResolution] = useState<ImageResolution>('1K');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!prompt) return;

    setIsGenerating(true);
    addLog({
      id: uuidv4(),
      timestamp: Date.now(),
      module: ModuleType.VISION,
      event: `Initializing asset generation protocol: ${resolution}`,
      status: 'info'
    });

    try {
      const base64Data = await generateFederationAsset(prompt, resolution);
      if (base64Data) {
        setGeneratedImage(`data:image/png;base64,${base64Data}`);
        addLog({
          id: uuidv4(),
          timestamp: Date.now(),
          module: ModuleType.VISION,
          event: `Asset rendered successfully.`,
          status: 'success'
        });
      } else {
        throw new Error("No image data returned.");
      }
    } catch (error) {
      addLog({
        id: uuidv4(),
        timestamp: Date.now(),
        module: ModuleType.VISION,
        event: `Generation failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
        status: 'error'
      });
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="h-full flex flex-col p-6 bg-surface/50">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-light text-white tracking-tight flex items-center gap-2">
          <svg className="w-5 h-5 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
          Vision Studio
        </h2>
        <div className="text-xs text-gray-500 font-mono">MODEL: GEMINI-3-PRO-IMAGE-PREVIEW</div>
      </div>

      <div className="flex gap-4 flex-1 min-h-0">
        {/* Controls */}
        <div className="w-1/3 flex flex-col gap-4">
          <div className="bg-void p-4 rounded-lg border border-highlight/30 flex-1 flex flex-col">
            <label className="text-xs text-gray-400 mb-2 font-mono uppercase">Prompt Input</label>
            <textarea
              className="w-full bg-transparent text-sm text-white resize-none focus:outline-none flex-1"
              placeholder="Describe the asset to materialize..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
            />
          </div>

          <div className="flex gap-4 items-center">
            <div className="flex-1 bg-void rounded-lg border border-highlight/30 px-3 py-2">
              <label className="text-[10px] text-gray-500 font-mono block mb-1">RESOLUTION</label>
              <select 
                value={resolution} 
                onChange={(e) => setResolution(e.target.value as ImageResolution)}
                className="w-full bg-transparent text-sm text-white focus:outline-none cursor-pointer"
              >
                <option value="1K">1K (Standard)</option>
                <option value="2K">2K (High)</option>
                <option value="4K">4K (Ultra)</option>
              </select>
            </div>
            
            <button
              onClick={handleGenerate}
              disabled={isGenerating || !prompt}
              className={`h-full px-6 rounded-lg font-mono text-sm transition-all duration-300
                ${isGenerating 
                  ? 'bg-highlight text-gray-500 cursor-not-allowed' 
                  : 'bg-white text-black hover:bg-purple-200'
                }`}
            >
              {isGenerating ? 'RENDERING...' : 'MATERIALIZE'}
            </button>
          </div>
        </div>

        {/* Preview Area */}
        <div className="w-2/3 bg-void rounded-lg border border-highlight/30 flex items-center justify-center relative overflow-hidden group">
          {generatedImage ? (
            <>
              <img 
                src={generatedImage} 
                alt="Generated Asset" 
                className="max-w-full max-h-full object-contain"
              />
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <a 
                  href={generatedImage} 
                  download={`federation-asset-${Date.now()}.png`}
                  className="px-4 py-2 bg-white text-black font-mono text-xs rounded hover:bg-gray-200"
                >
                  DOWNLOAD ASSET
                </a>
              </div>
            </>
          ) : (
            <div className="text-gray-600 font-mono text-xs text-center">
              AWAITING VISUAL DATA<br/>
              <span className="opacity-50">Configured for 16:9 Aspect Ratio</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default VisionStudio;