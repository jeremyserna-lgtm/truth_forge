import React, { useState } from 'react';
import { CredentialIssuanceState, SystemLog, ModuleType, CredentialRequest } from '../types';
import { resolveRequest } from '../services/credentialIssuanceService';
import { v4 as uuidv4 } from 'uuid';

interface CredentialIssuanceProps {
  state: CredentialIssuanceState;
  updateState: (newState: CredentialIssuanceState) => void;
  addLog: (log: SystemLog) => void;
}

const CredentialIssuance: React.FC<CredentialIssuanceProps> = ({ state, updateState, addLog }) => {
  const [selectedRequestId, setSelectedRequestId] = useState<string | null>(null);
  const [notes, setNotes] = useState('');

  const activeRequest = state.requests.find(r => r.id === selectedRequestId);
  const activeSchema = activeRequest ? state.schemas.find(s => s.id === activeRequest.schemaId) : null;

  const handleDecision = (decision: 'APPROVED' | 'REJECTED' | 'NEEDS_INFO') => {
    if (!activeRequest) return;

    const newState = resolveRequest(state, activeRequest.id, decision, notes);
    updateState(newState);
    
    addLog({
      id: uuidv4(),
      timestamp: Date.now(),
      module: ModuleType.CREDENTIAL_ISSUANCE,
      event: `Verification decision for ${activeRequest.id}: ${decision}`,
      status: decision === 'APPROVED' ? 'success' : 'warning'
    });

    setNotes('');
    // Optionally deselect or stay
  };

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'MASTER': return 'text-amber-400 border-amber-500/50 bg-amber-900/20';
      case 'PRACTITIONER': return 'text-emerald-400 border-emerald-500/50 bg-emerald-900/20';
      default: return 'text-blue-400 border-blue-500/50 bg-blue-900/20';
    }
  };

  return (
    <div className="h-full flex flex-col p-6 bg-surface/20 overflow-y-auto">
      {/* Header */}
      <div className="flex justify-between items-end mb-8 border-b border-highlight/30 pb-4">
        <div>
           <h2 className="text-2xl font-light text-white tracking-tight flex items-center gap-3">
            <svg className="w-6 h-6 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            Credential Issuance
          </h2>
          <div className="text-xs text-gray-500 font-mono mt-1">
            VERIFICATION PROTOCOL & LEDGER MANAGEMENT
          </div>
        </div>
        <div className="flex gap-6 text-right">
           <div>
             <div className="text-[10px] text-gray-500 font-mono uppercase">Total Issued</div>
             <div className="text-2xl font-mono font-bold text-white tracking-tighter">
               {state.metrics.totalIssued.toLocaleString()}
             </div>
           </div>
           <div>
             <div className="text-[10px] text-gray-500 font-mono uppercase">Avg Verify Time</div>
             <div className="text-2xl font-mono font-bold text-emerald-400 tracking-tighter">
               {state.metrics.avgVerificationTimeHrs}h
             </div>
           </div>
        </div>
      </div>

      <div className="flex-1 flex gap-6 min-h-0">
        
        {/* Left: Queue */}
        <div className="w-1/4 bg-void border border-highlight/30 rounded-lg flex flex-col">
          <div className="p-4 border-b border-highlight/30">
            <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider">Verification Queue</h3>
          </div>
          <div className="flex-1 overflow-y-auto p-2 space-y-2">
            {state.requests.filter(r => r.status === 'PENDING' || r.status === 'NEEDS_INFO').map(req => {
              const schema = state.schemas.find(s => s.id === req.schemaId);
              return (
                <div 
                  key={req.id}
                  onClick={() => setSelectedRequestId(req.id)}
                  className={`p-3 rounded border cursor-pointer transition-all ${
                    selectedRequestId === req.id
                      ? 'bg-emerald-900/30 border-emerald-500/50' 
                      : 'bg-surface/20 border-highlight/20 hover:border-emerald-500/30'
                  }`}
                >
                  <div className="flex justify-between items-start mb-1">
                    <span className="text-[10px] text-gray-500 font-mono">{new Date(req.submittedAt).toLocaleTimeString()}</span>
                    <span className={`text-[9px] font-bold px-1.5 rounded ${req.status === 'NEEDS_INFO' ? 'bg-yellow-900/50 text-yellow-500' : 'bg-blue-900/50 text-blue-400'}`}>
                      {req.status}
                    </span>
                  </div>
                  <div className="text-xs font-bold text-gray-200 mb-1 truncate">{schema?.name}</div>
                  <div className="flex justify-between items-center text-[10px] text-gray-500 font-mono">
                    <span>{req.userId}</span>
                    <span className={req.confidenceScore > 80 ? 'text-green-500' : 'text-yellow-500'}>
                      AI: {req.confidenceScore}%
                    </span>
                  </div>
                </div>
              );
            })}
            {state.requests.filter(r => r.status === 'PENDING').length === 0 && (
              <div className="text-center text-gray-600 text-xs py-8 italic">Queue Empty</div>
            )}
          </div>
        </div>

        {/* Center: Review Console */}
        <div className="flex-1 bg-surface/10 border border-highlight/30 rounded-lg p-6 flex flex-col overflow-hidden">
          {activeRequest && activeSchema ? (
            <>
              {/* Review Header */}
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h3 className="text-xl font-light text-white">{activeSchema.name}</h3>
                  <p className="text-sm text-gray-400 mt-1">{activeSchema.description}</p>
                </div>
                <div className={`px-3 py-1 rounded text-xs font-bold font-mono border ${getTierColor(activeSchema.tier)}`}>
                  {activeSchema.tier}
                </div>
              </div>

              {/* Criteria Checklist (ReadOnly for visual context) */}
              <div className="mb-6 p-4 bg-void/50 rounded border border-highlight/20">
                <h4 className="text-[10px] font-mono font-bold text-gray-500 uppercase mb-2">Verification Criteria</h4>
                <div className="grid grid-cols-2 gap-2">
                  {activeSchema.criteria.map((crit, i) => (
                    <div key={i} className="flex items-center gap-2 text-xs text-gray-300">
                      <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></div>
                      {crit}
                    </div>
                  ))}
                </div>
              </div>

              {/* Evidence Stream */}
              <div className="flex-1 overflow-y-auto mb-6 space-y-4 pr-2">
                <h4 className="text-[10px] font-mono font-bold text-gray-500 uppercase mb-2 sticky top-0 bg-surface/10 py-1 backdrop-blur-sm">Submitted Evidence</h4>
                {activeRequest.evidence.map(ev => (
                  <div key={ev.id} className="bg-black/40 border border-highlight/30 rounded p-4 relative">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-[10px] font-bold text-emerald-400 bg-emerald-900/20 px-2 py-0.5 rounded uppercase">
                        {ev.type.replace('_', ' ')}
                      </span>
                      <span className="text-[10px] font-mono text-gray-600">
                        SRC: {ev.sourceId}
                      </span>
                    </div>
                    <p className="text-sm text-gray-200 font-serif italic leading-relaxed pl-3 border-l-2 border-emerald-500/30">
                      "{ev.content}"
                    </p>
                    {ev.verified && (
                      <div className="absolute top-4 right-4 text-emerald-500 opacity-20">
                        <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" /></svg>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Action Bar */}
              <div className="pt-4 border-t border-highlight/30">
                <textarea
                  className="w-full bg-void border border-highlight/50 rounded p-3 text-sm text-white mb-4 h-20 resize-none focus:outline-none focus:border-emerald-500/50"
                  placeholder="Reviewer notes or rejection reasoning..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
                <div className="flex gap-4">
                  <button 
                    onClick={() => handleDecision('APPROVED')}
                    className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded text-xs tracking-wider transition-colors shadow-[0_0_15px_rgba(16,185,129,0.3)]"
                  >
                    VERIFY & ISSUE
                  </button>
                  <button 
                    onClick={() => handleDecision('NEEDS_INFO')}
                    className="px-6 py-3 bg-yellow-600 hover:bg-yellow-500 text-white font-bold rounded text-xs tracking-wider transition-colors"
                  >
                    REQUEST INFO
                  </button>
                  <button 
                    onClick={() => handleDecision('REJECTED')}
                    className="px-6 py-3 bg-red-600 hover:bg-red-500 text-white font-bold rounded text-xs tracking-wider transition-colors"
                  >
                    REJECT
                  </button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center h-full text-gray-500 font-mono text-sm flex-col gap-2">
              <svg className="w-8 h-8 opacity-20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              <span>Select a request to begin verification</span>
            </div>
          )}
        </div>

        {/* Right: Registry */}
        <div className="w-1/4 space-y-6">
          <div className="bg-void border border-highlight/30 rounded-lg p-5">
            <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-4">Credential Registry</h3>
            <div className="space-y-3">
              {state.schemas.map(schema => (
                <div key={schema.id} className="border-b border-highlight/20 pb-2 last:border-0">
                  <div className="text-xs font-bold text-gray-300 mb-1">{schema.name}</div>
                  <div className="flex justify-between text-[10px] text-gray-500 font-mono">
                    <span>{schema.tier}</span>
                    <span>{schema.activeCount} Issued</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-emerald-900/10 border border-emerald-500/20 rounded-lg p-5 flex-1">
            <h3 className="text-xs font-mono font-bold text-emerald-400 uppercase tracking-wider mb-4">Trust Network</h3>
            <div className="text-[10px] text-gray-500 font-mono mb-2">RECENT BLOCKS</div>
            <div className="space-y-2 font-mono text-[9px]">
              {state.metrics.recentActivity.map((act, i) => (
                <div key={i} className="flex gap-2 items-center">
                  <span className="text-gray-600">{new Date(act.timestamp).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}</span>
                  <span className={act.action === 'ISSUED' ? 'text-emerald-500' : 'text-red-500'}>{act.action}</span>
                  <span className="text-gray-400 truncate flex-1">{act.credential}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default CredentialIssuance;