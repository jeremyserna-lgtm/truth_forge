import React, { useState, useRef, useEffect } from 'react';
import { sendMessageToOrchestrator } from '../services/geminiService';
import { Message, ModuleType, SystemLog } from '../types';
import { v4 as uuidv4 } from 'uuid';

interface OrchestratorChatProps {
  addLog: (log: SystemLog) => void;
  systemContext?: string;
  onTriggerWorkflow?: (command: string) => void;
}

const OrchestratorChat: React.FC<OrchestratorChatProps> = ({ addLog, systemContext, onTriggerWorkflow }) => {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'init',
      role: 'model',
      content: "I am the Orchestrator. The Federation protocols are active. How shall we proceed with the sister companies today?",
      timestamp: Date.now(),
      module: ModuleType.ORCHESTRATOR
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg: Message = {
      id: uuidv4(),
      role: 'user',
      content: input,
      timestamp: Date.now(),
      module: ModuleType.BUILDER // User acts as Builder/Requester initially
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    // Check for workflow/governance triggers commands locally (Simulated "Tool Use" or Intent Recognition)
    if (onTriggerWorkflow) {
       onTriggerWorkflow(input);
    }

    // Convert internal message format to history format for API
    const history = messages.map(m => ({ role: m.role, content: m.content }));

    addLog({
      id: uuidv4(),
      timestamp: Date.now(),
      module: ModuleType.ORCHESTRATOR,
      event: 'Processing cognitive request...',
      status: 'info'
    });

    try {
      // Pass the systemContext to the orchestrator
      const responseText = await sendMessageToOrchestrator(input, history, systemContext);
      
      const modelMsg: Message = {
        id: uuidv4(),
        role: 'model',
        content: responseText,
        timestamp: Date.now(),
        module: ModuleType.ORCHESTRATOR
      };

      setMessages(prev => [...prev, modelMsg]);
      addLog({
        id: uuidv4(),
        timestamp: Date.now(),
        module: ModuleType.ORCHESTRATOR,
        event: 'Response synthesized.',
        status: 'success'
      });
    } catch (error) {
       addLog({
        id: uuidv4(),
        timestamp: Date.now(),
        module: ModuleType.ORCHESTRATOR,
        event: 'Cognitive failure in Orchestrator.',
        status: 'error'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const quickCommands = [
    "Start Stage Transition workflow",
    "Vote APPROVE on active proposal",
    "Simulate 10x user growth",
    "Report status of Truth Engine"
  ];

  return (
    <div className="h-full flex flex-col bg-surface/30">
      {/* Header */}
      <div className="p-4 border-b border-highlight/30 flex justify-between items-center bg-surface/80 backdrop-blur-sm">
        <div className="flex items-center gap-3">
          <div className="w-2 h-2 rounded-full bg-truth animate-pulse" />
          <h2 className="text-sm font-mono tracking-widest text-truth uppercase">Orchestrator Link</h2>
        </div>
        <div className="text-[10px] font-mono text-gray-500">GEMINI-3-PRO-PREVIEW</div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {messages.map((msg) => (
          <div 
            key={msg.id} 
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div 
              className={`max-w-[80%] p-4 rounded-sm border ${
                msg.role === 'user' 
                  ? 'bg-highlight/20 border-highlight/50 text-gray-200' 
                  : 'bg-truth/10 border-truth/30 text-white'
              }`}
            >
              <div className="text-[10px] font-mono mb-2 opacity-50 uppercase flex justify-between gap-4">
                <span>{msg.role === 'user' ? 'ME (OPERATOR)' : 'ORCHESTRATOR'}</span>
                <span>{new Date(msg.timestamp).toLocaleTimeString()}</span>
              </div>
              <div className="whitespace-pre-wrap font-sans text-sm leading-relaxed">
                {msg.content}
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
             <div className="p-4 bg-truth/5 border border-truth/20 rounded-sm flex gap-1 items-center">
                <div className="w-1.5 h-1.5 bg-truth rounded-full animate-bounce" style={{animationDelay: '0ms'}}/>
                <div className="w-1.5 h-1.5 bg-truth rounded-full animate-bounce" style={{animationDelay: '150ms'}}/>
                <div className="w-1.5 h-1.5 bg-truth rounded-full animate-bounce" style={{animationDelay: '300ms'}}/>
             </div>
          </div>
        )}
        <div ref={scrollRef} />
      </div>

      {/* Quick Commands & Input */}
      <div className="p-4 border-t border-highlight/30 bg-surface">
        <div className="flex gap-2 mb-3 overflow-x-auto pb-2 scrollbar-hide">
          {quickCommands.map(cmd => (
            <button
              key={cmd}
              onClick={() => setInput(cmd)}
              className="text-[10px] font-mono border border-highlight/50 bg-highlight/10 text-gray-400 px-2 py-1 rounded hover:bg-highlight/30 whitespace-nowrap"
            >
              {cmd}
            </button>
          ))}
        </div>
        <div className="flex gap-4">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Issue command to the Federation..."
            className="flex-1 bg-void border border-highlight/50 rounded p-3 text-sm text-white font-mono focus:outline-none focus:border-truth/50 resize-none h-14"
          />
          <button
            onClick={handleSend}
            disabled={isLoading || !input.trim()}
            className="px-6 bg-white text-black font-mono text-xs hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            TRANSMIT
          </button>
        </div>
      </div>
    </div>
  );
};

export default OrchestratorChat;