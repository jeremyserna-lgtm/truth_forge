import React, { useEffect, useRef } from 'react';
import { SystemLog, ModuleType } from '../types';

interface ConsoleLogProps {
  logs: SystemLog[];
}

const ConsoleLog: React.FC<ConsoleLogProps> = ({ logs }) => {
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const getModuleColor = (mod: ModuleType) => {
    switch (mod) {
      case ModuleType.ORCHESTRATOR: return 'text-truth';
      case ModuleType.BUILDER: return 'text-primitive';
      case ModuleType.SEER: return 'text-credential';
      case ModuleType.VISION: return 'text-purple-400';
      default: return 'text-gray-400';
    }
  };

  return (
    <div className="h-full flex flex-col font-mono text-xs bg-void border-t border-highlight/50 p-2 overflow-hidden">
      <div className="text-gray-500 uppercase tracking-widest text-[10px] mb-2 border-b border-highlight/30 pb-1">
        Federation Event Stream
      </div>
      <div className="flex-1 overflow-y-auto space-y-1">
        {logs.map((log) => (
          <div key={log.id} className="flex gap-3 opacity-80 hover:opacity-100 transition-opacity">
            <span className="text-gray-600 min-w-[60px]">
              {new Date(log.timestamp).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute:'2-digit', second:'2-digit' })}
            </span>
            <span className={`font-bold min-w-[100px] ${getModuleColor(log.module)}`}>
              [{log.module}]
            </span>
            <span className={log.status === 'error' ? 'text-red-500' : 'text-gray-300'}>
              {log.event}
            </span>
          </div>
        ))}
        <div ref={endRef} />
      </div>
    </div>
  );
};

export default ConsoleLog;