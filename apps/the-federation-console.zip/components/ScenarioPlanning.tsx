import React, { useState } from 'react';
import { SimulationState, ModuleType, SystemLog, Scenario, SimulationParameter } from '../types';
import { runSimulationLogic } from '../services/simulationService';
import { v4 as uuidv4 } from 'uuid';

interface ScenarioPlanningProps {
  state: SimulationState;
  updateState: (newState: SimulationState) => void;
  addLog: (log: SystemLog) => void;
}

const ScenarioPlanning: React.FC<ScenarioPlanningProps> = ({ state, updateState, addLog }) => {
  const activeScenario = state.scenarios.find(s => s.id === state.activeScenarioId) || state.scenarios[0];
  const [isSimulating, setIsSimulating] = useState(false);

  const handleScenarioChange = (id: string) => {
    updateState({
      ...state,
      activeScenarioId: id
    });
  };

  const handleParamChange = (paramId: string, value: number) => {
    const updatedScenarios = state.scenarios.map(s => {
      if (s.id === activeScenario.id) {
        return {
          ...s,
          parameters: s.parameters.map(p => p.id === paramId ? { ...p, currentValue: value } : p)
        };
      }
      return s;
    });
    updateState({ ...state, scenarios: updatedScenarios });
  };

  const runSimulation = () => {
    setIsSimulating(true);
    addLog({
      id: uuidv4(),
      timestamp: Date.now(),
      module: ModuleType.SIMULATION,
      event: `Starting Monte Carlo simulation for: ${activeScenario.name}`,
      status: 'info'
    });

    // Simulate compute delay
    setTimeout(() => {
      const updatedScenario = runSimulationLogic(activeScenario);
      const updatedScenarios = state.scenarios.map(s => s.id === activeScenario.id ? updatedScenario : s);
      
      updateState({ ...state, scenarios: updatedScenarios });
      setIsSimulating(false);
      addLog({
        id: uuidv4(),
        timestamp: Date.now(),
        module: ModuleType.SIMULATION,
        event: `Simulation complete. Outcomes updated.`,
        status: 'success'
      });
    }, 800);
  };

  const getCategoryColor = (cat: string) => {
    switch (cat) {
      case 'GROWTH': return 'text-green-400 border-green-500/30 bg-green-900/10';
      case 'CRISIS': return 'text-red-400 border-red-500/30 bg-red-900/10';
      case 'RESOURCE': return 'text-cyan-400 border-cyan-500/30 bg-cyan-900/10';
      default: return 'text-gray-400 border-gray-500/30 bg-gray-900/10';
    }
  };

  return (
    <div className="h-full flex bg-surface/20">
      {/* Sidebar: Scenario Selector */}
      <div className="w-64 border-r border-highlight/30 bg-surface/50 flex flex-col">
        <div className="p-4 border-b border-highlight/30">
           <h2 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-2">Scenario Library</h2>
        </div>
        <div className="flex-1 overflow-y-auto p-2 space-y-2">
           {state.scenarios.map(sc => (
             <div 
               key={sc.id}
               onClick={() => handleScenarioChange(sc.id)}
               className={`p-3 rounded border cursor-pointer transition-all ${
                 state.activeScenarioId === sc.id
                   ? 'bg-highlight/40 border-white/40' 
                   : 'bg-void border-highlight/30 hover:border-gray-500'
               }`}
             >
               <div className="flex justify-between items-center mb-1">
                 <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${getCategoryColor(sc.category).replace('text-', 'border-').split(' ')[1]}`}>
                    {sc.category}
                 </span>
                 <span className="text-[9px] text-gray-500">{new Date(sc.lastRun).toLocaleDateString()}</span>
               </div>
               <h3 className="text-xs text-white font-bold">{sc.name}</h3>
             </div>
           ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 bg-void/50 p-6 overflow-y-auto">
         {/* Header */}
         <div className="flex justify-between items-start mb-8">
            <div>
               <h1 className="text-2xl text-white font-light tracking-tight flex items-center gap-2">
                 <svg className="w-6 h-6 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.384-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" /></svg>
                 {activeScenario.name}
               </h1>
               <p className="text-sm text-gray-400 mt-1 max-w-2xl">{activeScenario.description}</p>
            </div>
            <button 
               onClick={runSimulation}
               disabled={isSimulating}
               className={`px-6 py-2 rounded font-mono text-xs font-bold transition-all
                 ${isSimulating 
                   ? 'bg-indigo-900/50 text-indigo-300 cursor-wait' 
                   : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-[0_0_15px_rgba(79,70,229,0.4)]'}`}
            >
               {isSimulating ? 'MODELING...' : 'RUN SIMULATION'}
            </button>
         </div>

         <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Parameters Column */}
            <div className="space-y-6">
               <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-4 border-b border-highlight/30 pb-2">Simulation Parameters</h3>
               {activeScenario.parameters.map(param => (
                 <div key={param.id} className="bg-surface/30 p-4 rounded border border-highlight/30">
                    <div className="flex justify-between items-center mb-2">
                       <label className="text-xs font-bold text-gray-200">{param.name}</label>
                       <span className="text-xs font-mono text-indigo-400">{param.currentValue} {param.unit}</span>
                    </div>
                    <input 
                      type="range" 
                      min={param.min} 
                      max={param.max} 
                      value={param.currentValue}
                      onChange={(e) => handleParamChange(param.id, parseInt(e.target.value))}
                      className="w-full h-1.5 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                    />
                    <div className="flex justify-between text-[10px] text-gray-500 mt-1 font-mono">
                       <span>{param.min}</span>
                       <span>Default: {param.defaultValue}</span>
                       <span>{param.max}</span>
                    </div>
                 </div>
               ))}
            </div>

            {/* Results Column */}
            <div className="lg:col-span-2 space-y-6">
               <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-4 border-b border-highlight/30 pb-2">Predicted Outcomes</h3>
               
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 {activeScenario.outcomes.map(outcome => {
                   const isPositive = outcome.change >= 0;
                   return (
                     <div key={outcome.id} className="bg-void border border-highlight/30 p-5 rounded-lg relative overflow-hidden group">
                        {/* Background trend visual */}
                        <div className={`absolute right-0 bottom-0 opacity-10 text-6xl font-mono font-bold pointer-events-none ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
                           {isPositive ? '↗' : '↘'}
                        </div>

                        <div className="text-xs text-gray-500 font-mono uppercase mb-1">{outcome.name}</div>
                        <div className="flex items-baseline gap-2 mb-2">
                           <span className="text-3xl font-bold text-white tracking-tighter">{outcome.value}</span>
                           <span className="text-sm text-gray-400">{outcome.unit}</span>
                        </div>

                        {/* Change Indicator */}
                        <div className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold mb-4
                          ${isPositive ? 'bg-green-900/30 text-green-400' : 'bg-red-900/30 text-red-400'}`}>
                           {isPositive ? '+' : ''}{outcome.change}% vs Baseline ({outcome.baseline})
                        </div>

                        {/* Confidence Interval Bar */}
                        <div>
                           <div className="flex justify-between text-[10px] text-gray-500 mb-1">
                              <span>Low: {outcome.confidenceInterval[0]}</span>
                              <span className="text-indigo-400">Confidence Range</span>
                              <span>High: {outcome.confidenceInterval[1]}</span>
                           </div>
                           <div className="h-1.5 bg-gray-800 rounded-full overflow-hidden relative">
                              <div 
                                 className="absolute h-full bg-indigo-500/50"
                                 style={{ 
                                   left: '20%', 
                                   right: '20%' 
                                 }} 
                              ></div>
                              <div 
                                 className="absolute h-full w-1 bg-white"
                                 style={{ left: '50%' }}
                              ></div>
                           </div>
                        </div>
                     </div>
                   );
                 })}
               </div>

               {/* Sensitivity Hint */}
               <div className="bg-indigo-900/10 border border-indigo-900/30 rounded p-4 text-xs text-indigo-300 font-mono">
                  <span className="font-bold">SENSITIVITY ANALYSIS:</span> Changes in "{activeScenario.parameters[0].name}" have the highest correlation with outcome variability in this model.
               </div>
            </div>
         </div>
      </div>
    </div>
  );
};

export default ScenarioPlanning;