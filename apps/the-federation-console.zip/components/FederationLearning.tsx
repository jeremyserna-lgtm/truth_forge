import React from 'react';
import { LearningState, SystemLog, ModuleType } from '../types';

interface FederationLearningProps {
  state: LearningState;
  addLog: (log: SystemLog) => void;
}

const FederationLearning: React.FC<FederationLearningProps> = ({ state }) => {

  const getCategoryColor = (cat: string) => {
    switch (cat) {
      case 'DEVELOPMENT': return 'text-purple-400 bg-purple-900/20 border-purple-500/30';
      case 'SYSTEM': return 'text-blue-400 bg-blue-900/20 border-blue-500/30';
      case 'FEATURE': return 'text-green-400 bg-green-900/20 border-green-500/30';
      case 'CRISIS': return 'text-red-400 bg-red-900/20 border-red-500/30';
      default: return 'text-gray-400 bg-gray-900/20 border-gray-500/30';
    }
  };

  const getAccuracyColor = (acc: number) => {
    if (acc >= 90) return 'text-green-500';
    if (acc >= 80) return 'text-yellow-500';
    return 'text-red-500';
  };

  return (
    <div className="h-full flex flex-col p-6 bg-surface/20 overflow-y-auto">
      {/* Header */}
      <div className="flex justify-between items-end mb-8 border-b border-highlight/30 pb-4">
        <div>
           <h2 className="text-2xl font-light text-white tracking-tight flex items-center gap-3">
            <svg className="w-6 h-6 text-fuchsia-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.384-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" /></svg>
            Federation Learning
          </h2>
          <div className="text-xs text-gray-500 font-mono mt-1">
            PATTERN RECOGNITION & PREDICTIVE ANALYTICS
          </div>
        </div>
        <div className="text-right flex gap-6">
           <div>
             <div className="text-[10px] text-gray-500 font-mono uppercase">Active Models</div>
             <div className="text-2xl font-mono font-bold text-white tracking-tighter">
               {state.models.filter(m => m.status === 'ACTIVE').length}
             </div>
           </div>
           <div>
             <div className="text-[10px] text-gray-500 font-mono uppercase">Anomalies</div>
             <div className={`text-2xl font-mono font-bold tracking-tighter ${state.anomalies.length > 0 ? 'text-red-500 animate-pulse' : 'text-gray-400'}`}>
               {state.anomalies.length}
             </div>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1">
        
        {/* Left Column: Patterns & Features */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Pattern Stream */}
          <div>
            <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-4">Detected Patterns</h3>
            <div className="space-y-3">
              {state.patterns.map(pat => (
                <div key={pat.id} className={`p-4 rounded border ${getCategoryColor(pat.category)}`}>
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-black/40 border border-white/10">{pat.category}</span>
                      <h4 className="text-sm font-bold text-white">{pat.title}</h4>
                    </div>
                    <div className="text-[10px] font-mono opacity-80">{pat.confidence}% CONFIDENCE</div>
                  </div>
                  <p className="text-xs text-gray-300 mb-3">{pat.description}</p>
                  <div className="text-[10px] text-gray-400 bg-black/20 p-2 rounded">
                    <span className="font-bold">IMPLICATION:</span> {pat.implications[0]}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Feature Impact Matrix */}
          <div className="bg-void border border-highlight/30 rounded-lg p-5">
             <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-4">Feature Effectiveness</h3>
             <div className="space-y-4">
               {state.features.map(feat => (
                 <div key={feat.id} className="flex items-center gap-4">
                   <div className="w-32 text-xs font-mono text-gray-300 truncate">{feat.name}</div>
                   <div className="flex-1">
                      <div className="flex justify-between text-[10px] text-gray-500 mb-1">
                        <span>Development Impact</span>
                        <span>{feat.impactScore}/100</span>
                      </div>
                      <div className="h-1.5 bg-surface rounded-full overflow-hidden">
                        <div className="h-full bg-fuchsia-600" style={{ width: `${feat.impactScore}%` }}></div>
                      </div>
                   </div>
                   <div className="flex-1">
                      <div className="flex justify-between text-[10px] text-gray-500 mb-1">
                        <span>Engagement</span>
                        <span>{feat.engagementScore}/100</span>
                      </div>
                      <div className="h-1.5 bg-surface rounded-full overflow-hidden">
                        <div className="h-full bg-cyan-600" style={{ width: `${feat.engagementScore}%` }}></div>
                      </div>
                   </div>
                   <div className={`text-[10px] font-bold w-16 text-center px-1 py-0.5 rounded
                     ${feat.retentionEffect === 'POSITIVE' ? 'text-green-500 bg-green-900/20' : 
                       feat.retentionEffect === 'NEGATIVE' ? 'text-red-500 bg-red-900/20' : 'text-gray-500 bg-gray-900/20'}`}>
                     {feat.retentionEffect.substring(0,3)}
                   </div>
                 </div>
               ))}
             </div>
          </div>

        </div>

        {/* Right Column: Models & Anomalies */}
        <div className="space-y-6">
          
          {/* Predictive Models */}
          <div className="bg-surface/10 border border-highlight/30 rounded-lg p-5">
             <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-4">Predictive Models</h3>
             <div className="space-y-3">
               {state.models.map(mod => (
                 <div key={mod.id} className="bg-void p-3 rounded border border-highlight/20">
                   <div className="flex justify-between items-center mb-1">
                     <span className="text-xs font-bold text-gray-200">{mod.name}</span>
                     <span className={`text-[10px] ${mod.status === 'ACTIVE' ? 'text-green-500' : 'text-yellow-500'}`}>
                       {mod.status}
                     </span>
                   </div>
                   <div className="flex justify-between items-center mt-2">
                     <div className="text-[10px] text-gray-500">
                       Window: {mod.predictionWindow}
                     </div>
                     <div className={`text-sm font-mono font-bold ${getAccuracyColor(mod.accuracy)}`}>
                       {mod.accuracy}%
                     </div>
                   </div>
                 </div>
               ))}
             </div>
          </div>

          {/* Anomaly Detection */}
          <div className="bg-red-900/5 border border-red-900/20 rounded-lg p-5 h-full">
             <h3 className="text-xs font-mono font-bold text-red-400 uppercase tracking-wider mb-4 flex items-center gap-2">
               <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
               Anomaly Detection
             </h3>
             {state.anomalies.length === 0 ? (
               <div className="text-center text-gray-600 text-xs py-4">System Nominal</div>
             ) : (
               <div className="space-y-3">
                 {state.anomalies.map(anom => (
                   <div key={anom.id} className="bg-black/40 border-l-2 border-red-500 p-3">
                     <div className="flex justify-between text-[10px] text-red-300 font-bold mb-1">
                       <span>{anom.type}</span>
                       <span>{anom.severity}</span>
                     </div>
                     <p className="text-xs text-gray-300 mb-2">{anom.description}</p>
                     <div className="text-[10px] text-gray-500 italic">
                       Action: {anom.suggestedAction}
                     </div>
                   </div>
                 ))}
               </div>
             )}
          </div>

        </div>

      </div>
    </div>
  );
};

export default FederationLearning;