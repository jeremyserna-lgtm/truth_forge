import React from 'react';
import { FederationIntelligence, CohortGroup, StageDistribution } from '../types';
import Sparkline from './Sparkline';

interface CohortAnalyticsProps {
  intelligence: FederationIntelligence;
}

const CohortAnalytics: React.FC<CohortAnalyticsProps> = ({ intelligence }) => {
  
  const getStageColor = (stage: string) => {
    if (stage.includes("2")) return "bg-red-500";
    if (stage.includes("3")) return "bg-orange-500";
    if (stage.includes("4")) return "bg-green-500";
    if (stage.includes("5")) return "bg-blue-500";
    return "bg-gray-500";
  };

  const getMaxPercentage = (dists: StageDistribution[]) => Math.max(...dists.map(d => d.percentage));

  return (
    <div className="h-full flex flex-col bg-surface/20 p-6 overflow-y-auto">
      {/* Header */}
      <div className="flex justify-between items-end mb-8 border-b border-highlight/30 pb-4">
        <div>
           <h2 className="text-2xl font-light text-white tracking-tight flex items-center gap-3">
            <svg className="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
            Federation Intelligence
          </h2>
          <div className="text-xs text-gray-500 font-mono mt-1 flex gap-4">
            <span>COHORT ANALYTICS</span>
            <span className="text-green-500 flex items-center gap-1">
              <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              K-ANONYMITY ACTIVE (MIN 50)
            </span>
          </div>
        </div>
        
        <div className="text-right">
           <div className="text-[10px] text-gray-500 font-mono uppercase">Total Active Population</div>
           <div className="text-3xl font-mono font-bold text-white tracking-tighter">
             {intelligence.totalUsers.toLocaleString()}
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1">
        
        {/* Main Chart Area: Cohort Distributions */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-void border border-highlight/30 rounded-lg p-5">
            <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-6">Developmental Stage Distribution by Cohort</h3>
            
            <div className="space-y-8">
              {intelligence.cohorts.map(cohort => (
                <div key={cohort.id}>
                  <div className="flex justify-between items-baseline mb-2">
                    <span className="text-sm text-white font-medium">{cohort.name}</span>
                    <span className="text-xs text-gray-500 font-mono">Avg Stage: {cohort.avgStage}</span>
                  </div>
                  
                  {/* Custom Bar Chart */}
                  <div className="h-24 flex items-end gap-2 border-b border-highlight/30 pb-1">
                    {cohort.stageDistribution.map((dist) => (
                      <div key={dist.stage} className="flex-1 flex flex-col justify-end group relative">
                        {/* Tooltip */}
                        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 bg-gray-800 text-white text-[10px] p-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10 pointer-events-none">
                          {dist.stage}: {dist.count} users ({dist.percentage.toFixed(1)}%)
                        </div>
                        
                        <div 
                          className={`w-full rounded-t ${getStageColor(dist.stage)} opacity-70 group-hover:opacity-100 transition-all duration-500`}
                          style={{ height: `${(dist.percentage / 60) * 100}%` }} // Scaling factor
                        ></div>
                        <div className="text-[10px] text-gray-600 font-mono text-center mt-1 truncate">{dist.stage}</div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Transition Rates */}
          <div className="grid grid-cols-3 gap-4">
            {intelligence.transitions.map((t, idx) => (
              <div key={idx} className="bg-void border border-highlight/30 rounded-lg p-4 relative overflow-hidden">
                <div className="text-[10px] text-gray-500 font-mono uppercase mb-1">Transition Velocity</div>
                <div className="text-sm text-white mb-2">{t.from} → {t.to}</div>
                <div className="flex items-end gap-2">
                  <div className="text-2xl font-bold text-white">{t.rate}%</div>
                  <div className="text-[10px] text-gray-500 mb-1">success rate</div>
                </div>
                <div className="text-[10px] text-gray-400 mt-2 flex items-center gap-1">
                  <svg className="w-3 h-3 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                  Avg {t.avgTimeWeeks} weeks
                </div>
                {/* Trend indicator */}
                <div className={`absolute top-4 right-4 w-2 h-2 rounded-full ${t.trend === 'up' ? 'bg-green-500' : t.trend === 'down' ? 'bg-red-500' : 'bg-gray-500'}`}></div>
              </div>
            ))}
          </div>
        </div>

        {/* Side Panel: Insights */}
        <div className="space-y-6">
          <div className="bg-surface/40 border border-highlight/30 rounded-lg p-5 h-full flex flex-col">
            <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-4 flex items-center gap-2">
              <svg className="w-4 h-4 text-purple-400 animate-pulse" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
              Pattern Recognition
            </h3>

            <div className="flex-1 space-y-4 overflow-y-auto">
              {intelligence.insights.map(insight => (
                <div key={insight.id} className="bg-black/40 border border-highlight/20 rounded p-4 hover:border-purple-500/30 transition-colors">
                  <div className="flex justify-between items-start mb-2">
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded
                      ${insight.type === 'PATTERN' ? 'bg-blue-900/40 text-blue-300' : 
                        insight.type === 'BOTTLENECK' ? 'bg-red-900/40 text-red-300' : 'bg-green-900/40 text-green-300'}`}>
                      {insight.type}
                    </span>
                    <span className="text-[10px] text-gray-500 font-mono">{insight.confidence}% CONF</span>
                  </div>
                  <p className="text-xs text-gray-200 leading-relaxed mb-3">
                    {insight.description}
                  </p>
                  <div className="pt-2 border-t border-highlight/10 flex justify-between items-center text-[10px] text-gray-600 font-mono">
                    <span>SRC: {insight.source.split(' ')[0].toUpperCase()}</span>
                    <span>IMPACT: {insight.impact}</span>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-4 pt-4 border-t border-highlight/30 text-[10px] text-gray-500 text-center font-mono">
              AI Analysis Updated: {new Date(intelligence.lastUpdated).toLocaleTimeString()}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default CohortAnalytics;