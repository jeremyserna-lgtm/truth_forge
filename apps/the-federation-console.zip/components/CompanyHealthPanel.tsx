import React from 'react';
import { CompanyHealth, ModuleType } from '../types';
import Sparkline from './Sparkline';

interface CompanyHealthPanelProps {
  company: CompanyHealth;
}

const CompanyHealthPanel: React.FC<CompanyHealthPanelProps> = ({ company }) => {
  const getThemeColor = (type: ModuleType) => {
    switch (type) {
      case ModuleType.ORCHESTRATOR: return 'text-truth border-truth/30';
      case ModuleType.BUILDER: return 'text-primitive border-primitive/30';
      case ModuleType.SEER: return 'text-credential border-credential/30';
      default: return 'text-gray-400 border-gray-600';
    }
  };

  const getHexColor = (type: ModuleType) => {
    switch (type) {
      case ModuleType.ORCHESTRATOR: return '#3b82f6';
      case ModuleType.BUILDER: return '#f59e0b';
      case ModuleType.SEER: return '#10b981';
      default: return '#9ca3af';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'HEALTHY': return 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]';
      case 'DEGRADED': return 'bg-yellow-500 shadow-[0_0_8px_rgba(234,179,8,0.6)]';
      case 'CRITICAL': return 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.6)] animate-pulse';
      default: return 'bg-gray-500';
    }
  };

  const themeClass = getThemeColor(company.type);
  const hexColor = getHexColor(company.type);

  return (
    <div className={`bg-void border ${themeClass.split(' ')[1]} p-5 rounded-lg flex flex-col h-full relative overflow-hidden group hover:bg-surface/30 transition-colors`}>
      {/* Background Decor */}
      <div className="absolute top-0 right-0 p-2 opacity-10 pointer-events-none text-4xl font-bold font-mono tracking-tighter">
        {company.type.substring(0, 3)}
      </div>

      {/* Header */}
      <div className="flex justify-between items-start mb-6">
        <div>
          <h3 className={`font-mono text-lg font-bold uppercase tracking-wider ${themeClass.split(' ')[0]}`}>
            {company.name}
          </h3>
          <div className="text-[10px] text-gray-500 font-mono mt-1 flex gap-2">
            ID: {company.id.split('-').pop()}
          </div>
        </div>
        <div className="flex items-center gap-2 bg-surface/80 px-2 py-1 rounded border border-highlight/50">
           <div className={`w-2 h-2 rounded-full ${getStatusColor(company.status)}`}></div>
           <span className="text-[10px] font-bold text-gray-300 tracking-wide">{company.status}</span>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="space-y-4 flex-1">
        {company.metrics.map(metric => (
          <div key={metric.id} className="border-b border-highlight/20 pb-2 last:border-0">
             <div className="flex justify-between items-end mb-1">
               <span className="text-xs text-gray-400 font-mono uppercase">{metric.name}</span>
               <div className="text-right">
                  <span className={`font-mono font-bold text-sm ${themeClass.split(' ')[0]}`}>{metric.value}</span>
                  <span className="text-[10px] text-gray-600 ml-1">{metric.unit}</span>
               </div>
             </div>
             <div className="h-8 w-full opacity-60 group-hover:opacity-100 transition-opacity">
                <Sparkline data={metric.history} color={hexColor} height={30} />
             </div>
          </div>
        ))}
      </div>

      {/* Alerts Section (conditionally rendered if alerts exist) */}
      {company.alerts.length > 0 && (
        <div className="mt-4 border-t border-highlight/30 pt-3">
          <div className="text-[10px] text-red-400 font-bold mb-2 flex items-center gap-1">
            <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
            ACTIVE ALERTS ({company.alerts.length})
          </div>
          <div className="space-y-1">
            {company.alerts.map(alert => (
              <div key={alert.id} className="text-[10px] text-red-300 bg-red-900/10 p-1.5 rounded border border-red-900/30">
                {alert.message}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default CompanyHealthPanel;