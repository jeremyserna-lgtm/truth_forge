import React, { useState } from 'react';
import { ApiContract, ModuleType } from '../types';
import { API_CONTRACTS } from '../services/integrationService';

const ApiContractViewer: React.FC = () => {
  const [selectedCompany, setSelectedCompany] = useState<ModuleType>(ModuleType.ORCHESTRATOR);

  const activeContract = API_CONTRACTS.find(c => c.company === selectedCompany);

  const getCompanyColor = (type: ModuleType) => {
    switch (type) {
      case ModuleType.ORCHESTRATOR: return 'text-truth border-truth';
      case ModuleType.BUILDER: return 'text-primitive border-primitive';
      case ModuleType.SEER: return 'text-credential border-credential';
      default: return 'text-gray-400 border-gray-400';
    }
  };

  const getComplianceColor = (score: number) => {
    if (score >= 95) return 'text-green-500';
    if (score >= 80) return 'text-yellow-500';
    return 'text-red-500';
  };

  return (
    <div className="h-full flex flex-col bg-void border-r border-highlight/30 w-1/2">
      {/* Header */}
      <div className="p-4 border-b border-highlight/30 flex justify-between items-center bg-surface/50">
        <h2 className="text-sm font-mono font-bold text-gray-300 uppercase tracking-wider">
          API Contracts
        </h2>
        <select 
          value={selectedCompany}
          onChange={(e) => setSelectedCompany(e.target.value as ModuleType)}
          className="bg-black border border-highlight/50 text-xs font-mono text-white p-1 rounded focus:outline-none focus:border-white"
        >
          <option value={ModuleType.ORCHESTRATOR}>TRUTH ENGINE</option>
          <option value={ModuleType.BUILDER}>PRIMITIVE ENGINE</option>
          <option value={ModuleType.SEER}>CREDENTIAL ATLAS</option>
        </select>
      </div>

      {/* Contract Details */}
      {activeContract ? (
        <div className="flex-1 overflow-y-auto p-6 space-y-8">
          
          {/* Metadata Card */}
          <div className={`border p-4 rounded-lg bg-surface/20 ${getCompanyColor(activeContract.company)} bg-opacity-5`}>
            <div className="flex justify-between items-start mb-4">
              <div>
                <div className="text-2xl font-light text-white tracking-tight">{activeContract.company}</div>
                <div className="text-xs font-mono text-gray-500 mt-1">
                  VERSION: <span className="text-white">{activeContract.version}</span>
                </div>
              </div>
              <div className="text-right">
                <div className="text-[10px] font-mono text-gray-500 uppercase">Compliance Score</div>
                <div className={`text-xl font-bold font-mono ${getComplianceColor(activeContract.complianceScore)}`}>
                  {activeContract.complianceScore}%
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mt-4 pt-4 border-t border-white/10">
              <div>
                <div className="text-[10px] text-gray-500 font-mono uppercase">Status</div>
                <div className={`text-xs font-bold ${activeContract.status === 'ACTIVE' ? 'text-green-400' : 'text-yellow-400'}`}>
                  {activeContract.status}
                </div>
              </div>
              <div>
                <div className="text-[10px] text-gray-500 font-mono uppercase">Last Updated</div>
                <div className="text-xs text-gray-300">
                  {new Date(activeContract.lastUpdated).toLocaleDateString()}
                </div>
              </div>
              <div>
                <div className="text-[10px] text-gray-500 font-mono uppercase">Approved By</div>
                <div className="text-xs text-gray-300">
                  {activeContract.approvedBy}
                </div>
              </div>
            </div>
          </div>

          {/* Endpoints List */}
          <div>
            <h3 className="text-xs font-mono font-bold text-gray-500 uppercase mb-3">Public Endpoints</h3>
            <div className="space-y-4">
              {activeContract.endpoints.map(ep => (
                <div key={ep.id} className="border border-highlight/30 rounded bg-black/40 p-3">
                  <div className="flex items-center gap-3 mb-2">
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded text-black
                      ${ep.method === 'GET' ? 'bg-blue-400' : 
                        ep.method === 'POST' ? 'bg-green-400' : 'bg-yellow-400'}`}>
                      {ep.method}
                    </span>
                    <span className="font-mono text-sm text-gray-300">{ep.path}</span>
                  </div>
                  <div className="text-xs text-gray-500 mb-3 pl-1">{ep.description}</div>
                  
                  <div className="grid grid-cols-2 gap-4 text-[10px] font-mono bg-highlight/10 p-2 rounded">
                    <div>
                      <span className="text-gray-600 block mb-1">REQ SCHEMA</span>
                      <div className="text-gray-400">
                        {Object.keys(ep.requestSchema).length > 0 ? (
                           Object.keys(ep.requestSchema).map(k => (
                             <div key={k}>{k}{ep.requestSchema[k].required ? '*' : ''}: {ep.requestSchema[k].type}</div>
                           ))
                        ) : (
                          <span className="opacity-50">None</span>
                        )}
                      </div>
                    </div>
                    <div>
                      <span className="text-gray-600 block mb-1">RES SCHEMA</span>
                      <div className="text-gray-400">
                        {Object.keys(ep.responseSchema).map(k => (
                           <div key={k}>{k}: {ep.responseSchema[k].type}</div>
                        ))}
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-2 flex justify-between items-center text-[10px] text-gray-600 font-mono pt-2 border-t border-highlight/20">
                    <div>Rate Limit: {ep.rateLimit}</div>
                    <div>Callers: {ep.authorizedCallers.map(c => c.split('_')[0]).join(', ')}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Governance / Changelog */}
          <div>
            <h3 className="text-xs font-mono font-bold text-gray-500 uppercase mb-3">Governance Log</h3>
            <div className="border-l-2 border-highlight/30 pl-4 space-y-4">
              {activeContract.changelog.map((log, i) => (
                <div key={i} className="relative">
                  <div className="absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full bg-highlight border border-gray-600"></div>
                  <div className="text-[10px] text-gray-500 font-mono mb-0.5">
                    {new Date(log.date).toLocaleDateString()}
                  </div>
                  <div className="text-xs text-gray-300">{log.note}</div>
                </div>
              ))}
            </div>
          </div>

        </div>
      ) : (
        <div className="p-8 text-center text-gray-500">Select a company to view contract</div>
      )}
    </div>
  );
};

export default ApiContractViewer;