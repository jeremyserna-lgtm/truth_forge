import React, { useEffect } from 'react';
import { FederationHealth, SystemLog, ModuleType } from '../types';
import CompanyHealthPanel from './CompanyHealthPanel';
import { v4 as uuidv4 } from 'uuid';

interface FederationDashboardProps {
  healthData: FederationHealth;
  addLog: (log: SystemLog) => void;
}

const FederationDashboard: React.FC<FederationDashboardProps> = ({ healthData, addLog }) => {
  
  // Log an access event when mounted
  useEffect(() => {
    addLog({
      id: uuidv4(),
      timestamp: Date.now(),
      module: ModuleType.DASHBOARD,
      event: 'Operator accessed Health Control Grid.',
      status: 'info'
    });
  }, []);

  // Calculate some aggregate stats
  const totalAlerts = healthData.companies.reduce((acc, c) => acc + c.alerts.length, 0);
  const systemStatusColor = healthData.overallStatus === 'HEALTHY' ? 'text-green-500' : 'text-red-500';

  return (
    <div className="h-full flex flex-col p-6 bg-surface/20 overflow-y-auto">
      {/* Dashboard Header */}
      <div className="flex justify-between items-end mb-8 border-b border-highlight/30 pb-4">
        <div>
           <h2 className="text-2xl font-light text-white tracking-tight flex items-center gap-3">
            <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
            System Health Grid
          </h2>
          <div className="text-xs text-gray-500 font-mono mt-1">
            MONITORING CLUSTER: FED-ALPHA-1 // UPTIME: 99.99%
          </div>
        </div>
        
        <div className="flex gap-8 text-right">
           <div>
             <div className="text-[10px] text-gray-500 font-mono uppercase">System Status</div>
             <div className={`text-lg font-mono font-bold ${systemStatusColor}`}>{healthData.overallStatus}</div>
           </div>
           <div>
             <div className="text-[10px] text-gray-500 font-mono uppercase">Active Alerts</div>
             <div className={`text-lg font-mono font-bold ${totalAlerts > 0 ? 'text-red-500' : 'text-gray-400'}`}>{totalAlerts}</div>
           </div>
           <div>
             <div className="text-[10px] text-gray-500 font-mono uppercase">Last Sync</div>
             <div className="text-lg font-mono font-bold text-gray-400">
               {new Date(healthData.lastCheck).toLocaleTimeString([], { hour12: false })}
             </div>
           </div>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 flex-1 min-h-0">
        {healthData.companies.map(company => (
          <CompanyHealthPanel key={company.id} company={company} />
        ))}
      </div>
      
      {/* Footer / Dependencies Visual (Stylized) */}
      <div className="mt-8 border-t border-highlight/30 pt-4 opacity-50">
        <div className="flex justify-center items-center gap-4 text-[10px] text-gray-600 font-mono">
           <span>DEPENDENCY CHAIN:</span>
           <span>PRIMITIVE_ENGINE</span>
           <span>&larr;</span>
           <span className="text-truth font-bold">ORCHESTRATOR</span>
           <span>&rarr;</span>
           <span>CREDENTIAL_ATLAS</span>
        </div>
      </div>
    </div>
  );
};

export default FederationDashboard;