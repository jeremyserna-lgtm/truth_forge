import React from 'react';
import ApiContractViewer from './ApiContractViewer';
import EventBusMonitor from './EventBusMonitor';
import { IntegrationEvent } from '../types';

interface IntegrationHubProps {
  events: IntegrationEvent[];
}

const IntegrationHub: React.FC<IntegrationHubProps> = ({ events }) => {
  return (
    <div className="h-full flex bg-surface/20">
      <ApiContractViewer />
      <EventBusMonitor events={events} />
    </div>
  );
};

export default IntegrationHub;