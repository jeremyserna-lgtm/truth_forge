import React, { useState } from 'react';
import { AllocationState, ModuleType, ResourceRequest, ResourceType, SystemLog } from '../types';
import Sparkline from './Sparkline';
import { v4 as uuidv4 } from 'uuid';

interface ResourceAllocationProps {
  state: AllocationState;
  onUpdateRequest: (type: 'APPROVE' | 'REJECT', requestId: string) => void;
  addLog: (log: SystemLog) => void;
}

const ResourceAllocation: React.FC<ResourceAllocationProps> = ({ state, onUpdateRequest, addLog }) => {
  
  const getUtilColor = (util: number) => {
    if (util >= 95) return 'text-red-500 bg-red-500';
    if (util >= 85) return 'text-yellow-500 bg-yellow-500';
    return 'text-cyan-500 bg-cyan-500';
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'CRITICAL': return 'text-red-500 bg-red-900/30 border-red-500/50';
      case 'HIGH': return 'text-orange-400 bg-orange-900/30 border-orange-500/50';
      case 'MEDIUM': return 'text-yellow-400 bg-yellow-900/30 border-yellow-500/50';
      default: return 'text-blue-400 bg-blue-900/30 border-blue-500/50';
    }
  };

  const handleAction = (type: 'APPROVE' | 'REJECT', req: ResourceRequest) => {
    onUpdateRequest(type, req.id);
    addLog({
      id: uuidv4(),
      timestamp: Date.now(),
      module: ModuleType.RESOURCES,
      event: `Request ${req.id} ${type}ED: ${req.amount} ${req.resourceType} for ${req.requester}`,
      status: type === 'APPROVE' ? 'success' : 'warning'
    });
  };

  const pendingRequests = state.requests.filter(r => r.status === 'PENDING');
  const processedRequests = state.requests.filter(r => r.status !== 'PENDING');

  return (
    <div className="h-full flex flex-col p-6 bg-surface/20 overflow-y-auto">
      {/* Header */}
      <div className="flex justify-between items-end mb-8 border-b border-highlight/30 pb-4">
        <div>
           <h2 className="text-2xl font-light text-white tracking-tight flex items-center gap-3">
            <svg className="w-6 h-6 text-cyan-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
            Resource Allocation Grid
          </h2>
          <div className="text-xs text-gray-500 font-mono mt-1">
            CAPACITY PLANNING & ECONOMIC LOGIC
          </div>
        </div>
        <div className="text-right">
           <div className="text-[10px] text-gray-500 font-mono uppercase">Pending Requests</div>
           <div className="text-3xl font-mono font-bold text-white tracking-tighter">
             {pendingRequests.length}
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1">
        
        {/* Main Resource Cards */}
        <div className="lg:col-span-2 space-y-6">
          <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-2">Federated Capacity</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {state.resources.map(res => {
              const utilColor = getUtilColor(res.utilization);
              return (
                <div key={res.id} className="bg-void border border-highlight/30 rounded-lg p-5 relative overflow-hidden group">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h4 className="text-sm font-bold text-gray-200 uppercase tracking-wide">{res.name}</h4>
                      <div className="text-[10px] text-gray-500 font-mono">{res.type}</div>
                    </div>
                    <div className={`text-xl font-mono font-bold ${utilColor.split(' ')[0]}`}>
                      {res.utilization.toFixed(1)}%
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="h-2 w-full bg-surface rounded-full overflow-hidden mb-2">
                    <div 
                      className={`h-full transition-all duration-500 ${utilColor.split(' ')[1]}`} 
                      style={{ width: `${Math.min(100, res.utilization)}%` }}
                    />
                  </div>
                  
                  <div className="flex justify-between text-[10px] text-gray-400 font-mono mb-4">
                    <span>Allocated: {res.allocated.toLocaleString()}</span>
                    <span>Total: {res.totalCapacity.toLocaleString()} {res.unit}</span>
                  </div>

                  {/* Usage Trend */}
                  <div className="h-8 w-full opacity-50 group-hover:opacity-100 transition-opacity">
                    <Sparkline data={res.history} color={res.utilization > 90 ? '#ef4444' : '#06b6d4'} height={32} />
                  </div>
                  
                  {res.utilization > 95 && (
                    <div className="absolute top-2 right-2 flex items-center gap-1 text-[10px] text-red-500 bg-red-900/20 px-2 py-0.5 rounded animate-pulse">
                      <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                      CRITICAL
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Forecasting Visualization (Simple Representation) */}
          <div className="bg-surface/10 border border-highlight/30 rounded-lg p-5 mt-6">
            <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-4">Capacity Forecast (Next 3 Months)</h3>
            <div className="h-32 flex items-end gap-1">
               {Array.from({ length: 12 }).map((_, i) => (
                 <div key={i} className="flex-1 flex flex-col gap-1 items-center group">
                    <div className="w-full bg-cyan-900/40 rounded-t h-full relative">
                       {/* Projected Demand Line */}
                       <div 
                         className="absolute bottom-0 w-full bg-cyan-500/50 transition-all group-hover:bg-cyan-400"
                         style={{ height: `${40 + i * 5}%` }} 
                       ></div>
                       {/* Capacity Limit Line */}
                       <div className="absolute top-[10%] w-full h-[1px] bg-red-500/30 border-t border-dashed border-red-500"></div>
                    </div>
                    <div className="text-[9px] text-gray-600 font-mono">W{i+1}</div>
                 </div>
               ))}
            </div>
            <div className="mt-2 flex gap-4 text-[10px] text-gray-500 justify-center">
               <div className="flex items-center gap-1"><div className="w-2 h-2 bg-cyan-500/50"></div>Projected Demand</div>
               <div className="flex items-center gap-1"><div className="w-2 h-2 border-t border-dashed border-red-500"></div>Capacity Ceiling</div>
            </div>
          </div>
        </div>

        {/* Request Queue */}
        <div className="bg-void border border-highlight/30 rounded-lg p-5 flex flex-col h-full">
           <h3 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider mb-4">Request Queue</h3>
           
           <div className="flex-1 overflow-y-auto space-y-3 pr-2">
             {pendingRequests.length === 0 ? (
               <div className="text-center text-gray-600 text-xs italic py-10">No pending requests</div>
             ) : (
               pendingRequests.map(req => (
                 <div key={req.id} className="bg-surface/20 border border-highlight/20 p-3 rounded hover:border-highlight/50 transition-colors">
                    <div className="flex justify-between items-start mb-2">
                       <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${getPriorityColor(req.priority)}`}>
                         {req.priority}
                       </span>
                       <span className="text-[10px] font-mono text-gray-500">{new Date(req.timestamp).toLocaleTimeString()}</span>
                    </div>
                    
                    <div className="text-sm text-gray-200 font-bold mb-1">
                      {req.amount.toLocaleString()} <span className="text-xs font-normal text-gray-400">{req.resourceType}</span>
                    </div>
                    
                    <div className="text-xs text-gray-400 mb-2 italic">
                      " {req.justification} "
                    </div>
                    
                    <div className="text-[10px] text-gray-500 font-mono mb-3">
                       REQ: {req.requester}
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <button 
                        onClick={() => handleAction('APPROVE', req)}
                        className="bg-green-900/30 hover:bg-green-800/50 text-green-400 border border-green-900/50 text-[10px] font-bold py-1 rounded transition-colors"
                      >
                        APPROVE
                      </button>
                      <button 
                        onClick={() => handleAction('REJECT', req)}
                        className="bg-red-900/30 hover:bg-red-800/50 text-red-400 border border-red-900/50 text-[10px] font-bold py-1 rounded transition-colors"
                      >
                        REJECT
                      </button>
                    </div>
                 </div>
               ))
             )}
           </div>

           {/* Recently Processed */}
           <div className="mt-4 pt-4 border-t border-highlight/20">
              <h4 className="text-[10px] font-mono font-bold text-gray-500 uppercase mb-2">History</h4>
              <div className="space-y-1 max-h-32 overflow-y-auto">
                {processedRequests.slice(0, 5).map(req => (
                  <div key={req.id} className="flex justify-between text-[10px] text-gray-500">
                    <span>{req.requester} / {req.resourceType}</span>
                    <span className={req.status === 'APPROVED' ? 'text-green-600' : 'text-red-600'}>{req.status}</span>
                  </div>
                ))}
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default ResourceAllocation;