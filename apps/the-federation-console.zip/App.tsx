import React, { useState, useEffect } from 'react';
import { ModuleType, SystemLog, FederationHealth, WorkflowExecution, IntegrationEvent, FederationIntelligence, Proposal, VoteDecision, AllocationState, LearningState, SimulationState, FederationAnalytics, ConversationMetrics, ImmunityAnalyticsState, ReflectionAnalyticsState, CredentialIssuanceState } from './types';
import OrchestratorChat from './components/OrchestratorChat';
import VisionStudio from './components/VisionStudio';
import FederationDashboard from './components/FederationDashboard';
import WorkflowOrchestrator from './components/WorkflowOrchestrator';
import IntegrationHub from './components/IntegrationHub';
import CohortAnalytics from './components/CohortAnalytics';
import GovernancePanel from './components/GovernancePanel';
import ResourceAllocation from './components/ResourceAllocation';
import FederationLearning from './components/FederationLearning';
import ScenarioPlanning from './components/ScenarioPlanning';
import StageAnalytics from './components/StageAnalytics';
import ConversationIntelligence from './components/ConversationIntelligence';
import ImmunityPatternAnalytics from './components/ImmunityPatternAnalytics';
import ReflectionInsights from './components/ReflectionInsights';
import CredentialIssuance from './components/CredentialIssuance';
import ConsoleLog from './components/ConsoleLog';
import { getFederationHealth, formatHealthForAI } from './services/healthService';
import { createWorkflowExecution, tickWorkflow, approveStep } from './services/workflowService';
import { generateRandomEvent, generateWorkflowEvent } from './services/integrationService';
import { getFederationIntelligence, formatIntelligenceForAI } from './services/intelligenceService';
import { getProposals, castVote, formatGovernanceForAI } from './services/governanceService';
import { getResourceState, updateResourceState, formatResourcesForAI } from './services/resourceService';
import { getLearningState, formatLearningForAI } from './services/learningService';
import { getSimulationState, formatSimulationForAI } from './services/simulationService';
import { getFederationAnalytics, formatStageAnalyticsForAI } from './services/analyticsService';
import { getConversationMetrics, formatConversationInsightsForAI } from './services/conversationAnalyticsService';
import { getImmunityAnalytics, formatImmunityForAI } from './services/immunityAnalyticsService';
import { getReflectionAnalytics, formatReflectionForAI } from './services/reflectionAnalyticsService';
import { getCredentialIssuanceState, formatCredentialIssuanceForAI } from './services/credentialIssuanceService';
import { v4 as uuidv4 } from 'uuid';

// Check for API Key
const hasApiKey = !!process.env.API_KEY;

const App: React.FC = () => {
  const [activeModule, setActiveModule] = useState<ModuleType>(ModuleType.ORCHESTRATOR);
  const [healthData, setHealthData] = useState<FederationHealth>(getFederationHealth());
  const [intelligenceData, setIntelligenceData] = useState<FederationIntelligence>(getFederationIntelligence());
  const [resourceState, setResourceState] = useState<AllocationState>(getResourceState());
  const [learningState, setLearningState] = useState<LearningState>(getLearningState());
  const [simulationState, setSimulationState] = useState<SimulationState>(getSimulationState());
  const [stageAnalytics, setStageAnalytics] = useState<FederationAnalytics>(getFederationAnalytics());
  const [conversationMetrics, setConversationMetrics] = useState<ConversationMetrics>(getConversationMetrics());
  const [immunityAnalytics, setImmunityAnalytics] = useState<ImmunityAnalyticsState>(getImmunityAnalytics());
  const [reflectionAnalytics, setReflectionAnalytics] = useState<ReflectionAnalyticsState>(getReflectionAnalytics());
  const [credentialIssuance, setCredentialIssuance] = useState<CredentialIssuanceState>(getCredentialIssuanceState());
  const [workflowExecutions, setWorkflowExecutions] = useState<WorkflowExecution[]>([]);
  const [integrationEvents, setIntegrationEvents] = useState<IntegrationEvent[]>([]);
  const [proposals, setProposals] = useState<Proposal[]>(getProposals());
  const [logs, setLogs] = useState<SystemLog[]>([
    {
      id: 'init-1',
      timestamp: Date.now(),
      module: ModuleType.ORCHESTRATOR,
      event: 'Federation System Online. Truth Engine Active.',
      status: 'success'
    },
    {
      id: 'init-2',
      timestamp: Date.now() + 100,
      module: ModuleType.BUILDER,
      event: 'Primitive Engine Substrate Loaded.',
      status: 'info'
    },
    {
      id: 'init-3',
      timestamp: Date.now() + 200,
      module: ModuleType.SEER,
      event: 'Credential Atlas Verification Protocols Standby.',
      status: 'info'
    }
  ]);

  const addLog = (log: SystemLog) => {
    setLogs(prev => [...prev, log]);
  };

  const addEvent = (event: IntegrationEvent) => {
    setIntegrationEvents(prev => [...prev.slice(-49), event]); // Keep last 50
  };

  // Simulate health data ticking
  useEffect(() => {
    const interval = setInterval(() => {
      setHealthData(getFederationHealth());
    }, 5000); // Update every 5 seconds
    return () => clearInterval(interval);
  }, []);

  // Background Event Noise (Simulate organic traffic)
  useEffect(() => {
    const interval = setInterval(() => {
      if (Math.random() > 0.6) { // 40% chance of event every 2s
        addEvent(generateRandomEvent());
      }
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  // Workflow Ticking Logic & Integration Event Generation
  useEffect(() => {
    const interval = setInterval(() => {
      setWorkflowExecutions(prev => {
        let hasChanges = false;
        const nextExecutions = prev.map(exec => {
          if (exec.status === 'RUNNING') {
            const { updated, changed } = tickWorkflow(exec);
            if (changed) {
              hasChanges = true;
              // Check if a step just started or completed to log an integration event
              const prevStep = exec.steps[exec.currentStepIndex];
              const nextStep = updated.steps[updated.currentStepIndex];
              
              // Simple heuristic: if step status changed to RUNNING or COMPLETED, log event
              if (nextStep.status === 'RUNNING' && prevStep.status !== 'RUNNING') {
                const evt = generateWorkflowEvent(nextStep);
                if (evt) addEvent(evt);
              }
            }
            return updated;
          }
          return exec;
        });
        return hasChanges ? nextExecutions : prev;
      });
    }, 1000); // Check workflows every second
    return () => clearInterval(interval);
  }, []);

  const handleStartWorkflow = (templateId: string) => {
    const newExec = createWorkflowExecution(templateId);
    if (newExec) {
      setWorkflowExecutions(prev => [...prev, newExec]);
      setActiveModule(ModuleType.WORKFLOW);
    }
  };

  const handleApproveStep = (executionId: string) => {
    setWorkflowExecutions(prev => prev.map(exec => {
      if (exec.id === executionId) {
        return approveStep(exec);
      }
      return exec;
    }));
  };
  
  const handleCastVote = (proposalId: string, decision: VoteDecision, rationale: string) => {
    setProposals(prev => castVote(prev, proposalId, ModuleType.ORCHESTRATOR, decision, rationale));
  };
  
  const handleResourceRequestUpdate = (type: 'APPROVE' | 'REJECT', requestId: string) => {
    setResourceState(prev => updateResourceState(prev, { type, requestId }));
  };

  // Allow Orchestrator to "start" workflows by text command (simulated hook)
  const triggerActionFromChat = (command: string) => {
    const lower = command.toLowerCase();
    if (lower.includes('start') && lower.includes('workflow')) {
       if (lower.includes('stage transition')) handleStartWorkflow('wf-stage-transition');
       else if (lower.includes('crisis')) handleStartWorkflow('wf-crisis-response');
       else if (lower.includes('onboard')) handleStartWorkflow('wf-new-user');
    } else if (lower.includes('vote') && lower.includes('approve')) {
       const activeProp = proposals.find(p => p.status === 'ACTIVE');
       if (activeProp) handleCastVote(activeProp.id, 'APPROVE', 'Executed via voice command.');
       addLog({ id: uuidv4(), timestamp: Date.now(), module: ModuleType.GOVERNANCE, event: 'Vote triggered via Chat', status: 'success' });
    } else if (lower.includes('approve') && lower.includes('resource')) {
       const pending = resourceState.requests.find(r => r.status === 'PENDING');
       if (pending) {
         handleResourceRequestUpdate('APPROVE', pending.id);
         addLog({ id: uuidv4(), timestamp: Date.now(), module: ModuleType.RESOURCES, event: 'Resource request approved via Chat', status: 'success' });
       }
    } else if (lower.includes('simulate') || lower.includes('scenario')) {
      setActiveModule(ModuleType.SIMULATION);
      addLog({ id: uuidv4(), timestamp: Date.now(), module: ModuleType.SIMULATION, event: 'Simulation dashboard invoked via Chat', status: 'info' });
    }
  };

  if (!hasApiKey) {
    return (
      <div className="h-screen w-screen bg-black flex items-center justify-center text-white font-mono">
        <div className="text-center space-y-4">
          <h1 className="text-red-500 text-xl">CRITICAL ERROR</h1>
          <p>MISSING_API_KEY_ENVIRONMENT_VARIABLE</p>
          <p className="text-gray-500 text-sm max-w-md">
            The Federation requires a valid Google GenAI API Key to operate. 
            Ensure `process.env.API_KEY` is configured in the environment.
          </p>
        </div>
      </div>
    );
  }

  // Derived context for AI
  const systemContext = `${formatHealthForAI(healthData)}\n\n${formatIntelligenceForAI(intelligenceData)}\n\n${formatGovernanceForAI(proposals)}\n\n${formatResourcesForAI(resourceState)}\n\n${formatLearningForAI(learningState)}\n\n${formatSimulationForAI(simulationState)}\n\n${formatStageAnalyticsForAI(stageAnalytics)}\n\n${formatConversationInsightsForAI(conversationMetrics)}\n\n${formatImmunityForAI(immunityAnalytics)}\n\n${formatReflectionForAI(reflectionAnalytics)}\n\n${formatCredentialIssuanceForAI(credentialIssuance)}`;

  return (
    <div className="h-screen w-screen bg-black flex flex-col overflow-hidden">
      {/* Top Bar */}
      <header className="h-12 border-b border-highlight/30 bg-surface/90 flex items-center justify-between px-6 z-10">
        <div className="flex items-center gap-4">
          <div className="w-3 h-3 bg-white rounded-full shadow-[0_0_10px_rgba(255,255,255,0.5)]" />
          <h1 className="font-mono text-sm tracking-[0.2em] text-white uppercase">
            The Federation <span className="text-gray-500">Console</span>
          </h1>
        </div>
        <div className="flex gap-6 text-[10px] font-mono text-gray-400">
          <div className="flex items-center gap-2">
            <span className={`w-1.5 h-1.5 rounded-full ${healthData.companies.find(c => c.type === ModuleType.ORCHESTRATOR)?.status === 'HEALTHY' ? 'bg-truth' : 'bg-red-500 animate-pulse'}`}></span>
            TRUTH ENGINE
          </div>
          <div className="flex items-center gap-2">
            <span className={`w-1.5 h-1.5 rounded-full ${healthData.companies.find(c => c.type === ModuleType.BUILDER)?.status === 'HEALTHY' ? 'bg-primitive' : 'bg-red-500 animate-pulse'}`}></span>
            PRIMITIVE ENGINE
          </div>
          <div className="flex items-center gap-2">
            <span className={`w-1.5 h-1.5 rounded-full ${healthData.companies.find(c => c.type === ModuleType.SEER)?.status === 'HEALTHY' ? 'bg-credential' : 'bg-red-500 animate-pulse'}`}></span>
            CREDENTIAL ATLAS
          </div>
        </div>
      </header>

      <div className="flex-1 flex min-h-0">
        {/* Sidebar */}
        <nav className="w-16 border-r border-highlight/30 bg-surface flex flex-col items-center py-6 gap-6">
          <button
            onClick={() => setActiveModule(ModuleType.ORCHESTRATOR)}
            className={`w-10 h-10 rounded flex items-center justify-center transition-all ${
              activeModule === ModuleType.ORCHESTRATOR 
                ? 'bg-truth text-white shadow-[0_0_15px_rgba(59,130,246,0.3)]' 
                : 'text-gray-500 hover:text-white hover:bg-highlight'
            }`}
            title="Orchestrator Chat"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>
          </button>
          
          <button
            onClick={() => setActiveModule(ModuleType.DASHBOARD)}
            className={`w-10 h-10 rounded flex items-center justify-center transition-all ${
              activeModule === ModuleType.DASHBOARD
                ? 'bg-emerald-600 text-white shadow-[0_0_15px_rgba(16,185,129,0.3)]' 
                : 'text-gray-500 hover:text-white hover:bg-highlight'
            }`}
            title="Health Dashboard"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
          </button>

          <button
            onClick={() => setActiveModule(ModuleType.WORKFLOW)}
            className={`w-10 h-10 rounded flex items-center justify-center transition-all ${
              activeModule === ModuleType.WORKFLOW
                ? 'bg-amber-600 text-white shadow-[0_0_15px_rgba(245,158,11,0.3)]' 
                : 'text-gray-500 hover:text-white hover:bg-highlight'
            }`}
            title="Workflow Orchestrator"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.384-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" /></svg>
          </button>

          <button
            onClick={() => setActiveModule(ModuleType.INTEGRATION)}
            className={`w-10 h-10 rounded flex items-center justify-center transition-all ${
              activeModule === ModuleType.INTEGRATION
                ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)]' 
                : 'text-gray-500 hover:text-white hover:bg-highlight'
            }`}
            title="Integration Hub"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
          </button>

          <button
            onClick={() => setActiveModule(ModuleType.STAGE_ANALYTICS)}
            className={`w-10 h-10 rounded flex items-center justify-center transition-all ${
              activeModule === ModuleType.STAGE_ANALYTICS
                ? 'bg-green-600 text-white shadow-[0_0_15px_rgba(34,197,94,0.3)]' 
                : 'text-gray-500 hover:text-white hover:bg-highlight'
            }`}
            title="Stage Analytics"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
          </button>

          <button
             onClick={() => setActiveModule(ModuleType.CONVERSATION)}
             className={`w-10 h-10 rounded flex items-center justify-center transition-all ${
               activeModule === ModuleType.CONVERSATION
                 ? 'bg-orange-600 text-white shadow-[0_0_15px_rgba(249,115,22,0.3)]' 
                 : 'text-gray-500 hover:text-white hover:bg-highlight'
             }`}
             title="Conversation Intelligence"
           >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
           </button>

           <button
             onClick={() => setActiveModule(ModuleType.IMMUNITY_PATTERNS)}
             className={`w-10 h-10 rounded flex items-center justify-center transition-all ${
               activeModule === ModuleType.IMMUNITY_PATTERNS
                 ? 'bg-red-600 text-white shadow-[0_0_15px_rgba(220,38,38,0.3)]' 
                 : 'text-gray-500 hover:text-white hover:bg-highlight'
             }`}
             title="Immunity Patterns"
           >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
           </button>

           <button
             onClick={() => setActiveModule(ModuleType.REFLECTION_INSIGHTS)}
             className={`w-10 h-10 rounded flex items-center justify-center transition-all ${
               activeModule === ModuleType.REFLECTION_INSIGHTS
                 ? 'bg-rose-600 text-white shadow-[0_0_15px_rgba(225,29,72,0.3)]' 
                 : 'text-gray-500 hover:text-white hover:bg-highlight'
             }`}
             title="Reflection Insights"
           >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
           </button>

           <button
             onClick={() => setActiveModule(ModuleType.CREDENTIAL_ISSUANCE)}
             className={`w-10 h-10 rounded flex items-center justify-center transition-all ${
               activeModule === ModuleType.CREDENTIAL_ISSUANCE
                 ? 'bg-emerald-600 text-white shadow-[0_0_15px_rgba(16,185,129,0.3)]' 
                 : 'text-gray-500 hover:text-white hover:bg-highlight'
             }`}
             title="Credential Issuance"
           >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
           </button>

          <button
            onClick={() => setActiveModule(ModuleType.INTELLIGENCE)}
            className={`w-10 h-10 rounded flex items-center justify-center transition-all ${
              activeModule === ModuleType.INTELLIGENCE
                ? 'bg-purple-500 text-white shadow-[0_0_15px_rgba(168,85,247,0.3)]' 
                : 'text-gray-500 hover:text-white hover:bg-highlight'
            }`}
            title="Federation Intelligence"
          >
             <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z" /></svg>
          </button>

          <button
            onClick={() => setActiveModule(ModuleType.GOVERNANCE)}
            className={`w-10 h-10 rounded flex items-center justify-center transition-all ${
              activeModule === ModuleType.GOVERNANCE
                ? 'bg-yellow-600 text-white shadow-[0_0_15px_rgba(234,179,8,0.3)]' 
                : 'text-gray-500 hover:text-white hover:bg-highlight'
            }`}
            title="Governance & Policy"
          >
             <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" /></svg>
          </button>

          <button
            onClick={() => setActiveModule(ModuleType.RESOURCES)}
            className={`w-10 h-10 rounded flex items-center justify-center transition-all ${
              activeModule === ModuleType.RESOURCES
                ? 'bg-cyan-600 text-white shadow-[0_0_15px_rgba(8,145,178,0.3)]' 
                : 'text-gray-500 hover:text-white hover:bg-highlight'
            }`}
            title="Resource Allocation"
          >
             <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
          </button>

          <button
             onClick={() => setActiveModule(ModuleType.LEARNING)}
             className={`w-10 h-10 rounded flex items-center justify-center transition-all ${
               activeModule === ModuleType.LEARNING
                 ? 'bg-fuchsia-600 text-white shadow-[0_0_15px_rgba(192,38,211,0.3)]' 
                 : 'text-gray-500 hover:text-white hover:bg-highlight'
             }`}
             title="Federation Learning"
           >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" /></svg>
           </button>

           <button
             onClick={() => setActiveModule(ModuleType.SIMULATION)}
             className={`w-10 h-10 rounded flex items-center justify-center transition-all ${
               activeModule === ModuleType.SIMULATION
                 ? 'bg-indigo-600 text-white shadow-[0_0_15px_rgba(79,70,229,0.3)]' 
                 : 'text-gray-500 hover:text-white hover:bg-highlight'
             }`}
             title="Scenario Planning"
           >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.384-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" /></svg>
           </button>

          <button
            onClick={() => setActiveModule(ModuleType.VISION)}
            className={`w-10 h-10 rounded flex items-center justify-center transition-all ${
              activeModule === ModuleType.VISION 
                ? 'bg-pink-600 text-white shadow-[0_0_15px_rgba(219,39,119,0.3)]' 
                : 'text-gray-500 hover:text-white hover:bg-highlight'
            }`}
            title="Vision Studio"
          >
             <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
          </button>
        </nav>

        {/* Main Content Area */}
        <main className="flex-1 flex flex-col min-w-0 bg-void">
          <div className="flex-1 min-h-0 relative">
             {activeModule === ModuleType.ORCHESTRATOR && (
               <OrchestratorChat 
                 addLog={addLog} 
                 systemContext={systemContext} 
                 onTriggerWorkflow={triggerActionFromChat}
               />
             )}
             {activeModule === ModuleType.DASHBOARD && (
               <FederationDashboard healthData={healthData} addLog={addLog} />
             )}
             {activeModule === ModuleType.WORKFLOW && (
               <WorkflowOrchestrator 
                 executions={workflowExecutions} 
                 onStartWorkflow={handleStartWorkflow} 
                 onApproveStep={handleApproveStep}
                 addLog={addLog}
               />
             )}
             {activeModule === ModuleType.INTEGRATION && (
               <IntegrationHub events={integrationEvents} />
             )}
             {activeModule === ModuleType.STAGE_ANALYTICS && (
               <StageAnalytics analytics={stageAnalytics} addLog={addLog} />
             )}
             {activeModule === ModuleType.CONVERSATION && (
               <ConversationIntelligence metrics={conversationMetrics} addLog={addLog} />
             )}
             {activeModule === ModuleType.IMMUNITY_PATTERNS && (
               <ImmunityPatternAnalytics state={immunityAnalytics} addLog={addLog} />
             )}
             {activeModule === ModuleType.REFLECTION_INSIGHTS && (
               <ReflectionInsights state={reflectionAnalytics} addLog={addLog} />
             )}
             {activeModule === ModuleType.CREDENTIAL_ISSUANCE && (
               <CredentialIssuance state={credentialIssuance} updateState={setCredentialIssuance} addLog={addLog} />
             )}
             {activeModule === ModuleType.INTELLIGENCE && (
               <CohortAnalytics intelligence={intelligenceData} />
             )}
             {activeModule === ModuleType.GOVERNANCE && (
               <GovernancePanel proposals={proposals} onCastVote={handleCastVote} addLog={addLog} />
             )}
             {activeModule === ModuleType.RESOURCES && (
               <ResourceAllocation state={resourceState} onUpdateRequest={handleResourceRequestUpdate} addLog={addLog} />
             )}
             {activeModule === ModuleType.LEARNING && (
               <FederationLearning state={learningState} addLog={addLog} />
             )}
             {activeModule === ModuleType.SIMULATION && (
               <ScenarioPlanning state={simulationState} updateState={setSimulationState} addLog={addLog} />
             )}
             {activeModule === ModuleType.VISION && (
               <VisionStudio addLog={addLog} />
             )}
          </div>
          
          {/* Bottom Console Log */}
          <div className="h-48 min-h-[12rem]">
            <ConsoleLog logs={logs} />
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;