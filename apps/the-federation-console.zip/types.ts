export enum ModuleType {
  ORCHESTRATOR = 'ORCHESTRATOR', // Truth Engine
  BUILDER = 'BUILDER', // Primitive Engine
  SEER = 'SEER', // Credential Atlas
  VISION = 'VISION', // Image Gen Capability
  DASHBOARD = 'DASHBOARD', // Health Monitoring
  WORKFLOW = 'WORKFLOW', // Workflow Orchestration
  INTEGRATION = 'INTEGRATION', // API Contracts & Event Bus
  INTELLIGENCE = 'INTELLIGENCE', // User Cohort Analytics
  GOVERNANCE = 'GOVERNANCE', // Decision Support
  RESOURCES = 'RESOURCES', // Resource Allocation
  LEARNING = 'LEARNING', // Federation Learning & Patterns
  SIMULATION = 'SIMULATION', // Scenario Planning
  STAGE_ANALYTICS = 'STAGE_ANALYTICS', // Developmental Data & Kegan Stages
  CONVERSATION = 'CONVERSATION', // Not-Me Companion Analytics
  IMMUNITY_PATTERNS = 'IMMUNITY_PATTERNS', // Aggregate Immunity-to-Change Analysis
  REFLECTION_INSIGHTS = 'REFLECTION_INSIGHTS', // Subject-Object Shift Dynamics
  CREDENTIAL_ISSUANCE = 'CREDENTIAL_ISSUANCE' // Verification & Issuance Console
}

export interface Message {
  id: string;
  role: 'user' | 'model' | 'system';
  content: string;
  timestamp: number;
  module?: ModuleType; // Which "Mind" is speaking
}

export interface SystemLog {
  id: string;
  timestamp: number;
  module: ModuleType;
  event: string;
  status: 'info' | 'success' | 'warning' | 'error';
}

export type ImageResolution = '1K' | '2K' | '4K';

export interface GeneratedAsset {
  id: string;
  prompt: string;
  base64Data: string;
  resolution: ImageResolution;
  timestamp: number;
}

// Health Monitoring Types
export type CompanyStatus = 'HEALTHY' | 'DEGRADED' | 'CRITICAL' | 'OFFLINE';
export type MetricTrend = 'up' | 'down' | 'stable';

export interface HealthMetric {
  id: string;
  name: string;
  value: string | number;
  unit?: string;
  trend: MetricTrend;
  history: number[]; // For sparklines (last 10-20 data points)
}

export interface HealthAlert {
  id: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  message: string;
  timestamp: number;
  acknowledged: boolean;
}

export interface CompanyHealth {
  id: string;
  name: string;
  type: ModuleType;
  status: CompanyStatus;
  metrics: HealthMetric[];
  alerts: HealthAlert[];
  lastUpdated: number;
  dependencies: ModuleType[];
}

export interface FederationHealth {
  overallStatus: CompanyStatus;
  lastCheck: number;
  companies: CompanyHealth[];
}

// Workflow Orchestration Types
export type WorkflowStatus = 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'WAITING_APPROVAL';
export type StepStatus = 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'WAITING_APPROVAL';

export interface WorkflowStepTemplate {
  id: string;
  order: number;
  companyType: ModuleType;
  action: string;
  approvalRequired: boolean;
}

export interface WorkflowTemplate {
  id: string;
  name: string;
  description: string;
  steps: WorkflowStepTemplate[];
}

export interface WorkflowStep extends WorkflowStepTemplate {
  status: StepStatus;
  logs: string[];
  startTime?: number;
  endTime?: number;
}

export interface WorkflowExecution {
  id: string;
  templateId: string;
  name: string;
  status: WorkflowStatus;
  currentStepIndex: number;
  steps: WorkflowStep[];
  startedAt: number;
  completedAt?: number;
}

// API Contracts & Integration Types
export interface SchemaProperty {
  type: string;
  required: boolean;
  description?: string;
}

export interface Endpoint {
  id: string;
  path: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  description: string;
  requestSchema: Record<string, SchemaProperty>;
  responseSchema: Record<string, SchemaProperty>;
  authorizedCallers: ModuleType[];
  rateLimit: string; // e.g., "1000/min"
}

export interface ApiContract {
  id: string;
  company: ModuleType;
  version: string;
  status: 'ACTIVE' | 'DEPRECATED' | 'DRAFT';
  lastUpdated: number;
  approvedBy: string;
  endpoints: Endpoint[];
  complianceScore: number; // 0-100
  changelog: { date: number; note: string }[];
}

export interface IntegrationEvent {
  id: string;
  timestamp: number;
  source: ModuleType;
  destination: ModuleType;
  eventType: string; // e.g., "API_CALL", "WEBHOOK"
  endpoint: string;
  status: 'SUCCESS' | 'FAILURE' | 'THROTTLED';
  payloadSummary: string;
  latency: number;
  correlationId?: string;
}

// Federation Intelligence Types
export interface StageDistribution {
  stage: string; // e.g., "Stage 2", "Stage 3", "Stage 3/4", "Stage 4", "Stage 5"
  count: number;
  percentage: number;
}

export interface TransitionRate {
  from: string;
  to: string;
  rate: number; // 0-100%
  avgTimeWeeks: number;
  trend: MetricTrend;
}

export interface CohortGroup {
  id: string;
  name: string; // "New Users", "6 Month Cohort"
  size: number;
  avgStage: number;
  stageDistribution: StageDistribution[];
}

export interface Insight {
  id: string;
  type: 'PATTERN' | 'BOTTLENECK' | 'OPPORTUNITY';
  description: string;
  confidence: number;
  impact: 'HIGH' | 'MEDIUM' | 'LOW';
  source: string; // e.g., "Primitive Engine Pattern Matcher"
}

export interface FederationIntelligence {
  totalUsers: number;
  lastUpdated: number;
  cohorts: CohortGroup[];
  transitions: TransitionRate[];
  insights: Insight[];
}

// Governance Types
export type VoteDecision = 'APPROVE' | 'REJECT' | 'ABSTAIN';
export type ProposalType = 'POLICY' | 'TECHNICAL' | 'OPERATIONAL' | 'CRISIS';
export type ProposalStatus = 'ACTIVE' | 'PASSED' | 'REJECTED';

export interface Vote {
  company: ModuleType;
  decision: VoteDecision;
  rationale: string;
  timestamp: number;
}

export interface Proposal {
  id: string;
  title: string;
  description: string;
  type: ProposalType;
  status: ProposalStatus;
  proposer: ModuleType;
  votes: Vote[];
  deadline: number;
  impactAnalysis: string;
  requiredApprovals: number;
  created: number;
}

// Resource Allocation Types
export enum ResourceType {
  COMPUTE = 'COMPUTE', // GPU/TPU hours, API Tokens
  SUPPORT = 'SUPPORT', // Human hours
  DEVELOPMENT = 'DEVELOPMENT', // Dev hours
  CAPITAL = 'CAPITAL' // Credits/Currency
}

export interface FederatedResource {
  id: string;
  type: ResourceType;
  name: string;
  totalCapacity: number;
  allocated: number;
  unit: string;
  utilization: number; // 0-100
  history: number[]; // For usage trend
}

export interface ResourceRequest {
  id: string;
  requester: ModuleType;
  resourceType: ResourceType;
  amount: number;
  justification: string;
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  timestamp: number;
}

export interface AllocationState {
  resources: FederatedResource[];
  requests: ResourceRequest[];
  lastUpdated: number;
}

// Learning & Pattern Recognition Types
export interface Pattern {
  id: string;
  title: string;
  category: 'DEVELOPMENT' | 'SYSTEM' | 'FEATURE' | 'CRISIS';
  confidence: number; // 0-100
  description: string;
  implications: string[];
  detectedAt: number;
}

export interface FeatureMetric {
  id: string;
  name: string;
  impactScore: number; // 0-100 (Developmental Impact)
  engagementScore: number; // 0-100
  retentionEffect: 'POSITIVE' | 'NEUTRAL' | 'NEGATIVE';
}

export interface PredictiveModel {
  id: string;
  name: string;
  accuracy: number; // 0-100
  status: 'ACTIVE' | 'RETRAINING' | 'DEGRADED';
  lastTrained: number;
  predictionWindow: string; // e.g. "Next 30 Days"
}

export interface Anomaly {
  id: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  type: 'BEHAVIORAL' | 'SYSTEMIC' | 'DATA';
  description: string;
  detectedAt: number;
  suggestedAction: string;
}

export interface LearningState {
  patterns: Pattern[];
  features: FeatureMetric[];
  models: PredictiveModel[];
  anomalies: Anomaly[];
  lastUpdated: number;
}

// Simulation & Scenario Planning Types
export type ScenarioCategory = 'GROWTH' | 'CRISIS' | 'FEATURE' | 'RESOURCE';

export interface SimulationParameter {
  id: string;
  name: string;
  min: number;
  max: number;
  defaultValue: number;
  currentValue: number;
  unit: string;
}

export interface SimulationOutcome {
  id: string;
  name: string;
  value: number;
  baseline: number;
  unit: string;
  change: number; // percentage change relative to baseline
  confidenceInterval: [number, number]; // [low, high]
}

export interface Scenario {
  id: string;
  name: string;
  description: string;
  category: ScenarioCategory;
  parameters: SimulationParameter[];
  outcomes: SimulationOutcome[];
  lastRun: number;
}

export interface SimulationState {
  activeScenarioId: string | null;
  scenarios: Scenario[];
  isRunning: boolean;
}

// Stage Analytics Types
export interface TransitionEvent {
  id: string;
  userId: string;
  fromStage: string;
  toStage: string;
  timestamp: number;
  status: 'IN_PROGRESS' | 'COMPLETED' | 'STALLED';
  verifiedBySeer: boolean;
}

export interface GrowthEdgeCluster {
  id: string;
  pattern: string; // e.g. "Difficulty delegating authority"
  stageContext: string; // e.g. "Stage 3 -> 4"
  frequency: number; // count of users exhibiting this
  suggestedInterventions: string[];
  immunityToChange?: string; // e.g. "Commitment to being liked"
}

export interface FederationAnalytics {
  distribution: StageDistribution[];
  activeTransitions: TransitionEvent[];
  growthEdges: GrowthEdgeCluster[];
  lastUpdated: number;
}

// Conversation Intelligence Types
export interface DevelopmentalMoment {
  id: string;
  userId: string;
  timestamp: number;
  userStage: string;
  insight: string; // The extracted realization
  themeId: string;
}

export interface ConversationTheme {
  id: string;
  name: string;
  volume: number; // active conversations on this topic
  stageCorrelation: string; // e.g. "Stage 3"
  sentiment: number; // 0-100
}

export interface BreakthroughEvent {
  id: string;
  userId: string;
  timestamp: number;
  fromState: string; // e.g. "Subject to Anger"
  toState: string; // e.g. "Object to Anger"
  triggerMessage: string; // The "Not-Me" prompt that caused it
  confidence: number;
}

export interface NotMeEffectiveness {
  stage: string;
  effectiveness: number; // 0-100
  avgDepth: number; // 0-10
  activeSessions: number;
}

export interface ConversationMetrics {
  activeConversations: number;
  avgDepthScore: number; // 0-10
  moments: DevelopmentalMoment[];
  themes: ConversationTheme[];
  breakthroughs: BreakthroughEvent[];
  effectiveness: NotMeEffectiveness[];
  hourlyActivity: number[]; // Last 24 hours of volume
}

// Immunity Pattern Analytics Types
export interface AssumptionCluster {
  id: string;
  theme: string; // e.g., "Conflict Avoidance"
  description: string;
  frequency: number; // How many users hold this
  stageCorrelation: string; // e.g., "Stage 3"
  breakthroughRate: number; // 0-100% success in challenging
  semanticSignature: string; // Truth Engine hook
}

export interface ImmunityBlocker {
  id: string;
  assumptionType: string;
  stageTransition: string; // e.g., "Stage 3 -> Stage 4"
  frequencyScore: number; // 0-100 relative magnitude
  severity: 'HIGH' | 'MEDIUM' | 'LOW';
}

export interface BreakthroughPath {
  id: string;
  name: string;
  stages: string[];
  keyAssumptionsChallenged: string[];
  avgTimeWeeks: number;
  successCount: number;
}

export interface InterventionRecommendation {
  id: string;
  targetClusterId: string;
  action: string;
  type: 'COGNITIVE' | 'BEHAVIORAL' | 'SYSTEMIC';
  predictedImpact: number;
}

export interface ImmunityAnalyticsState {
  clusters: AssumptionCluster[];
  blockers: ImmunityBlocker[];
  paths: BreakthroughPath[];
  interventions: InterventionRecommendation[];
  lastUpdated: number;
}

// Reflection Insights Types
export interface FederationShiftTrend {
  id: string;
  shiftType: string; // e.g., "Subject to Anger -> Object to Anger"
  frequency: number;
  avgTimeWeeks: number;
  trend: MetricTrend;
  stageContext: string;
}

export interface ShiftVelocityMetric {
  id: string;
  userId: string; // Anonymized
  recentShifts: number; // Count in last 30 days
  momentum: number; // 0-100
  status: 'ACCELERATING' | 'STEADY' | 'STALLED';
  primaryDriver: string; // e.g. "Immunity Map"
}

export interface GrowthCohort {
  id: string;
  name: string;
  trajectory: string; // Description
  size: number;
  commonThemes: string[];
  avgVelocity: number;
}

export interface ReflectionCorrelation {
  id: string;
  sourceModule: ModuleType; // e.g. CONVERSATION
  eventType: string; // e.g. "Breakthrough detected"
  shiftType: string;
  correlationStrength: number; // 0-100
}

export interface ReflectionAnalyticsState {
  trends: FederationShiftTrend[];
  velocity: ShiftVelocityMetric[];
  cohorts: GrowthCohort[];
  correlations: ReflectionCorrelation[];
  themes: { word: string; weight: number }[]; // For word cloud
  lastUpdated: number;
}

// Credential Issuance Types
export interface CredentialEvidence {
  id: string;
  type: 'CONVERSATION' | 'IMMUNITY_MAP' | 'REFLECTION' | 'BEHAVIORAL';
  content: string; // Text snippet, summary, or data hash
  sourceId: string; // Link to original module object
  timestamp: number;
  verified: boolean;
}

export interface CredentialRequest {
  id: string;
  userId: string;
  schemaId: string; // e.g. "cred-stage-4-authorship"
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'NEEDS_INFO';
  submittedAt: number;
  evidence: CredentialEvidence[];
  reviewerNotes?: string;
  confidenceScore: number; // AI pre-assessment 0-100
}

export interface CredentialSchema {
  id: string;
  name: string;
  tier: 'FOUNDATION' | 'PRACTITIONER' | 'MASTER';
  description: string;
  criteria: string[];
  activeCount: number;
}

export interface IssuanceMetrics {
  totalIssued: number;
  pendingCount: number;
  avgVerificationTimeHrs: number;
  rejectionRate: number;
  recentActivity: { timestamp: number; action: string; credential: string }[];
}

export interface CredentialIssuanceState {
  requests: CredentialRequest[];
  schemas: CredentialSchema[];
  metrics: IssuanceMetrics;
  lastUpdated: number;
}